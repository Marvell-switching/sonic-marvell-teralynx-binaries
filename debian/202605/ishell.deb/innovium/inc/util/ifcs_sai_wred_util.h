/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_wred_util.h
 * @brief ISAI Util Include file for WRED module
 */


#ifndef __IFCS_SAI_WRED_UTIL_H__
#define __IFCS_SAI_WRED_UTIL_H__

#include "util/ifcs_sai_wred_util_dep.h"
/*
 * @brief  Initializes wred module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_wred_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Initialize defaults SAI attr for wred obj
 *
 * @param [in,out] obj_p        - wred DSO object
 * @param [in] id        - wred OID
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_default_attr(
    isai_shim_qos_info_t *obj_p,
    sai_object_id_t      id);

/*
 * @brief Fill defaults SAI attr for wred obj if user has not provided
 * those values.
 *
 * @param [in] id        -     node_Id
 * @param [in,out] obj_p        - wred DSO object
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_default_attr_fill(ifcs_node_id_t       node_id,
                               isai_shim_qos_info_t *obj_p);


/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in] switch_id        - Switch OID
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_queue_attr_stoi(
    sai_object_id_t       switch_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);

/*
 * @brief Delete Egress ACL rule to drop drained packetd from Queue for PFCWD
 *
 * @param [in] node_id        -     node_Id
 * @param [in] switch_deinit_info_p   - printer to switch_deinit_info[switch_id, node_id, restart type etc…]
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_port_pfc_egress_acl_deinit(ifcs_node_id_t           node_id,
                                        sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_wred_port_pfc_egress_acl_setup(sai_object_id_t switch_oid,
                                       sai_object_id_t port_oid);

sai_status_t
isai_im_wred_port_pfc_egress_acl_cleanup(sai_object_id_t switch_oid,
                                         sai_object_id_t port_oid);

sai_status_t
isai_im_wred_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_wred_deinit(sai_switch_deinit_info_t  *switch_deinit_info_p);

sai_status_t
isai_im_wred_enable_ecn_statistics(sai_switch_init_info_t *sw_info_p);

sai_status_t
isai_im_wred_obj_validate(sai_object_id_t object_id);

/**
 * @brief Attach/detach a SAI object to another SAI object.
 * Eg: attach a wred to a queue
 * Type information is encoded in the object-ids.
 * @param[in] wred_object_id - object that is being attached
 * @param[in] bindpoint_obj_id - object to which we are attaching
 * @param[in] is_attach - if true attach else detach
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_sai_object_attach(sai_object_id_t wred_object_id,
                               sai_object_id_t bindpoint_obj_id,
                               bool is_attach);
/**
 * @brief Program hardware on attach of a SAI object to another SAI object.
 * Eg: attach a wred to a queue
 * attributes.
 * @param[in] action_obj_id   -  object that is being attached;
 *                               pass SAI_NULL_OBJECT_ID to signify unprogram.
 * @param[in] action_obj_type -  isai action object type when
 *                               action_obj_type is SAI_NULL_OBJECT_ID
 * @param[in] target_obj_id   -  object to which we are attaching
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_hw_update(ifcs_node_id_t  node_id,
                       sai_object_id_t action_obj_id,
                       sai_object_type_t  action_obj_type,
                       sai_object_id_t target_obj_id);

/**
 * @brief Program ECN threshold mode
 *
 * @param[in] switch_oid   -  switch object id
 * @param[in] threshold_enable - bool
 * @return sai_status_t
 */
sai_status_t
isai_im_wred_ecn_threshold_mode_update(sai_object_id_t switch_oid,
                                       bool threshold_enable);

sai_status_t
isai_im_wred_port_pfc_egress_storm_control_ace_create(
    ifcs_node_id_t                      node_id,
    uint8_t                             ib,
    uint32_t                            ibp,
    uint32_t                            qid,
    ii_queue_mod_pfcwd_acl_table_info_t *pfcwd_acl_table_info_p);

sai_status_t
isai_im_wred_port_pfc_egress_storm_control_ace_remove(
    ifcs_node_id_t                      node_id,
    uint8_t                             ib,
    uint32_t                            ibp,
    uint32_t                            qid,
    ii_queue_mod_pfcwd_acl_table_info_t *pfcwd_acl_table_info_p);

sai_status_t
isai_im_wred_port_pfc_egress_flood_control_ace_create(
    sai_object_id_t                     switch_id,
    uint8_t                             ib,
    uint32_t                            ibp,
    sai_object_id_t                     q_oid,
    uint32_t                            qid,
    ii_queue_mod_pfcwd_acl_table_info_t *pfcwd_acl_table_info_p);

sai_status_t
isai_im_wred_port_pfc_egress_flood_control_ace_delete(
    sai_object_id_t                     switch_id,
    uint8_t                             ib,
    uint32_t                            ibp,
    sai_object_id_t                     q_oid,
    uint32_t                            qid,
    ii_queue_mod_pfcwd_acl_table_info_t *pfcwd_acl_table_info_p);


/*
 * @brief Get the wred Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_wred_get_object_count(sai_object_id_t switch_id,
                                           uint32_t *object_count);

/*
 * @brief Get the wred Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_wred_get_object_key(sai_object_id_t switch_id,
                                         uint32_t *object_count,
                                         sai_object_key_t *object_list);

#endif /* __IFCS_SAI_WRED_UTIL_H__ */
