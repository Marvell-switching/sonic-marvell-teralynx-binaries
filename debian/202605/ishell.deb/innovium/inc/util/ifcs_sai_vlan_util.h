/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_vlan_util.h
 * @brief ISAI Util Include file for VLAN module
 */


#ifndef __IFCS_SAI_VLAN_UTIL_H__
#define __IFCS_SAI_VLAN_UTIL_H__

#include "util/ifcs_sai_vlan_util_dep.h"

sai_status_t
isai_im_vlan_is_sysport_member_of_multi_vlan(ifcs_node_id_t        node_id,
                                 ifcs_handle_t         sysport,
                                 sai_object_id_t       vlan_oid,
                                 const sai_object_id_t *skip_vlan_list_p,
                                 const uint32_t        vlan_count,
                                 bool                  *result_p);


sai_status_t
isai_im_vlan_get_mdg(ifcs_node_id_t node_id,
                  ifcs_handle_t  vni_hdl,
                  ifcs_handle_t  *mdg_hdl);

sai_status_t
isai_im_vlan_is_configured(ifcs_node_id_t  node_id,
                        uint16_t    vlan_id,
                        bool        *is_configured_p);

sai_status_t
isai_im_vlan_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_vlan_deinit(const sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_vlan_get_vlan_member_oid(sai_object_id_t vlan_oid,
                             sai_object_id_t     port_oid,
                             sai_object_id_t     *vlan_mem_oid_p);

/*
 * @brief L2MCG Memeber remove notification to VLAN module -
       It is processed in VLAN module for the flood control type combined
 * @param [in]  node_id                -  node_id
 * @param [in]  uuc_flood_group        - Unknown Unicast flood group oid
 * @param [in]  local_dst_handle       - local destination handle
 * @param [in]  nh_handle              - Nexthop handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_vlan_l2mcg_member_remove(ifcs_node_id_t node_id,
                            sai_object_id_t  uuc_flood_group_oid,
                            ifcs_handle_t local_dst_handle,
                            ifcs_handle_t nh_handle);

/*
 * @brief L2MCG Memeber add notification to VLAN module
 *        It is processed in VLAN module for the flood control type combined
 * @param [in]  node_id                -  node_id
 * @param [in]  uuc_flood_group        - Unknown Unicast flood group oid
 * @param [in]  local_dst_handle       - local destination handle
 * @param [in]  nh_handle              - Nexthop handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_vlan_l2mcg_member_add(ifcs_node_id_t node_id,
                            sai_object_id_t  uuc_flood_group_oid,
                            ifcs_handle_t local_dst_handle,
                            ifcs_handle_t nh_handle);

/**
 * @brief: Create Vlan
 *
 * @param [in] vlan_object_id_p       - Pointer to vlan object
 * @param [in] switch_id              - Switch Id
 * @param [in] attr_count             - Number of attributes
 * @param [in] attr_list_p            - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_vlan_create(sai_object_id_t       *vlan_object_id_p,
                    sai_object_id_t       switch_id,
                    uint32_t              attr_count,
                    const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove Vlan
 *
 * @param [in] vlan_object_id   - vlan object
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_vlan_remove( sai_object_id_t vlan_object_id );

/**
 * @brief: Create Vlan Member
 *
 * @param [in] vlan_member_object_id_p       - Pointer to vlan member object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                    - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_vlan_member_create(sai_object_id_t       *vlan_member_object_id_p,
                           sai_object_id_t       switch_id,
                           uint32_t              attr_count,
                           const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove Vlan Member
 *
 * @param [in] vlan_member_object_id   - Vlan Member object
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_vlan_member_remove(sai_object_id_t vlan_member_object_id);

sai_status_t
isai_im_vlan_mem_get_vlan_oid(sai_object_id_t vlan_member_oid,
                              sai_object_id_t *vlan_oid_p);
/**
 * @brief: Get vlan member count
 *
 * @param [in]  node_id           -  Node id
 * @param [in]  l2vni_handle      - L2vni Handle
 * @param [out] count             - Members count
 */
sai_status_t
isai_im_vlan_member_count_get(ifcs_node_id_t   node_id,
                              ifcs_handle_t    l2vni_handle,
                              uint32_t         *count);

sai_status_t
isai_im_vlan_get_l2vni_id(sai_object_id_t   vlan_oid,
                          uint16_t          *vlan_id_p);

sai_status_t
isai_im_vlan_get_l2vni_hdl(sai_object_id_t   vlan_oid,
                          ifcs_handle_t     *vlan_hdl_p);

sai_status_t
isai_im_vlan_get_vlan_oid(ifcs_node_id_t    node_id, ifcs_handle_t l2vni_hdl,
                          sai_object_id_t   *vlan_oid_p);
sai_status_t
isai_im_vlan_member_process_tunnel_underlay_port_update(ifcs_node_id_t   node_id,
                                                        sai_object_id_t  tun_nh_oid,
                                                        ifcs_handle_t    tun_nh_hdl,
                                                        ifcs_handle_t    old_out_port,
							ifcs_handle_t    out_port,
                 				        bool             is_add);

/**
 * @brief Apply (or revert) ES / ES-DF programming on a sysport that is being
 *        added to (or removed from) a LAG, mirroring the
 *        SAI_VLAN_MEMBER_ATTR_TUNNEL_TERM_BUM_TX_DROP configuration of every
 *        VLAN member attached to the LAG's bridge port.
 *
 * This is the IM/util wrapper that acquires the VLAN module lock before
 * iterating the VLAN member data store. It must be invoked from the LAG
 * member add and delete paths so that the new/old LAG member sysport stays
 * in sync with the EVPN-MH P2P Designated Forwarder programming applied on
 * the rest of the LAG members.
 *
 * The function is a no-op when EVPN-MH P2P is not enabled, when @a lag_bp_oid
 * is SAI_NULL_OBJECT_ID (LAG is not a bridge port), or when no VLAN member on
 * the LAG bridge port has SAI_VLAN_MEMBER_ATTR_TUNNEL_TERM_BUM_TX_DROP
 * configured.
 *
 * @param [in] node_id      IFCS node id
 * @param [in] lag_bp_oid   Bridge port OID of the LAG
 *                          (SAI_NULL_OBJECT_ID -> no-op)
 * @param [in] sysport_hdl  Sysport handle of the LAG member being added/removed
 * @param [in] is_add       true on LAG member add; false on LAG member remove
 * @return sai_status_t
 */
sai_status_t
isai_im_vlan_apply_tun_term_bum_tx_drop_on_lag_member(
    ifcs_node_id_t  node_id,
    sai_object_id_t lag_bp_oid,
    ifcs_handle_t   sysport_hdl,
    bool            is_add);


/*
 * @brief Get the vlan Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_vlan_get_object_count(sai_object_id_t switch_id,
                                           uint32_t *object_count);

/*
 * @brief Get the vlan Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_vlan_get_object_key(sai_object_id_t switch_id,
                                         uint32_t *object_count,
                                         sai_object_key_t *object_list);

/*
 * @brief Get the vlan_member Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_vlan_member_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the vlan_member Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_vlan_member_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

#endif /* __IFCS_SAI_VLAN_UTIL_H__ */
