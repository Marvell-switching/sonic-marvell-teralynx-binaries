/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_udf_util.h
 * @brief ISAI Util Include file for UDF module
 */


#ifndef __IFCS_SAI_UDF_UTIL_H__
#define __IFCS_SAI_UDF_UTIL_H__

#include "util/ifcs_sai_udf_util_dep.h"

sai_status_t
isai_im_udf_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_udf_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_udf_get_udf_group_db_entry(sai_object_id_t         udf_group_oid,
                                   ifcs_sai_udf_group_ds_t *entry_p);

sai_status_t
isai_im_udf_alloc_fpf_cookie(ifcs_node_id_t   node_id,
                             bool             is_ingress,
                             uint8_t          *fpf_cookie_p);

sai_status_t
isai_im_udf_dealloc_fpf_cookie(ifcs_node_id_t   node_id,
                               bool             is_ingress,
                               uint8_t          fpf_cookie);

sai_status_t
isai_im_udf_group_list_update_from_hash
(
    ifcs_node_id_t              node_id,
    const sai_object_list_t     *udf_group_list_p,
    sai_object_id_t             hash_oid,
    bool                        is_set
);


/*
 * @brief Get the udf Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_udf_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the udf Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_udf_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

/*
 * @brief Get the udf_match Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_udf_match_get_object_count(sai_object_id_t switch_id,
                                                uint32_t *object_count);

/*
 * @brief Get the udf_match Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_udf_match_get_object_key(sai_object_id_t switch_id,
                                              uint32_t *object_count,
                                              sai_object_key_t *object_list);

/*
 * @brief Get the udf_group Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_udf_group_get_object_count(sai_object_id_t switch_id,
                                                uint32_t *object_count);

/*
 * @brief Get the udf_group Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_udf_group_get_object_key(sai_object_id_t switch_id,
                                              uint32_t *object_count,
                                              sai_object_key_t *object_list);

#endif /* __IFCS_SAI_UDF_UTIL_H__ */
