
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import sys
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from collections import OrderedDict

# Initialize Parameters
port1 = 1
port2 = 2
port3 = 21
port4 = 22
port5 = 23
port6 = 24
port7 = 43
port8 = 44

l2vni = 0x64

def getSysportHandleFromDevPort(devPort):
    attr = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_ctypes.ifcs_devport_attr_get(0, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

def create_ctc_trap(node_id):
    ctc_trap_handle = ifcs_ctypes.ifcs_handle_t()
    ctc_trap_handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

    attr = (ifcs_ctypes.ifcs_attr_t * 1 )()

    attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM
    attr[0].value.u32 = 0

    rc = ifcs_ctypes.ifcs_hostif_trap_create(node_id, pointer(ctc_trap_handle), 1, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "COPY to CPU trap creation FAILED"

    return ctc_trap_handle

def delete_ctc_trap(node_id, ctc_trap_handle):
    rc = ifcs_ctypes.ifcs_hostif_trap_delete(node_id, ctc_trap_handle);
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "COPY to CPU trap deletion FAILED"
    return

def txrx_packet():
    # instantiate tx and expected packets
    pkts_tx = []
    pkts_exp = []

    i = 0
    # Transmitted Packets
    dmac ="00:01:02:03:04:05"
    pkt_fp = Teralynx(PktID=1234, PktLength=102+42+4, SrcLocalPort=i, Reserved=0)/ \
             Ether(dst=dmac) /  \
             Dot1Q(vlan=l2vni)/ \
             IP(dst="127.0.0.1")/ \
             UDP(dport=model_server.fp_port)
    pkt_fp = model_packet.pad(pkt_fp,102)
    pkts_tx.append(pkt_fp)

    # Expected Packets (update Ethernet Header Fields)
    pkt_fp = Teralynx(PktID=1234, PktLength=102+42+4, SrcLocalPort=i, Reserved=(i+1))/ \
             Ether(dst=dmac) /  \
             Dot1Q(vlan=l2vni)/ \
             IP(dst="127.0.0.1")/ \
             UDP(dport=model_server.fp_port)
    pkt_fp = model_packet.pad(pkt_fp,102)
    hexdump(pkt_fp)
    pkts_exp.append(pkt_fp)

    # overloadable function call to set up hash structure of server packet buffers
    model_server.hash_setup('SrcPort','DestPort')

    # append function call to add expected packets to server-side hash tree (parsing, dissection, processing, key generation are all automatically handled)
    for packet in pkts_exp:
        model_server.expected_packets.append(packet)

    # transmit all packets in the passed container through front panel UDP socket (agnostic of device port)
    model_server.transmit(pkts_tx)
# Class implements L2vni related command

class Vni(Command):
    def __init__(self, cli):
        self.sub_cmds = {'create'   : self.create,
                         'delete'   : self.delete,
                         'add'      : self.add,
                         'remove'   : self.remove,
                         'basicl2'  : self.basicl2,
                         'deletel2' : self.deletel2,
                         'flushl2'  : self.flushl2,
                         'lb'       : self.lb,
                         'help'     : self.help,
                         '?'        : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Vni, self).__init__()
        self.vni_handles = {}

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def run_cmd(self, args):
        log_dbg(1, "in L2vni run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (ValueError):
            try:
                l2vni_id = int(self.arg_list[1])
                if (l2vni_id < 0 or l2vni_id >= self.num_l2vnis):
                    log_err("Valid l2vni ids are between 0 and " + str((self.num_l2vnis-1)))
                    self.help(args)
                    return
                log_dbg(1, "Setting active l2vni to " + str(l2vni_id))
                self.active_l2vni = l2vni_id
            except:
                log_err('L2vniValueTryError')
        except (KeyError):
            log_dbg(1, 'L2vniKeyError')
            self.help(args)
        except (IndexError):
            log_dbg(1, 'L2vniIndexError')
            self.help(args)
        except:
            log_dbg(1, 'L2vniOtherError')
            self.help(args)
        return

    def create(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id in self.vni_handles:
            log_err("Handle already exists")
            return

        try:
            self.vni_handles[l2vni_id] = ifcs_ctypes.ifcs_handle_t()
            rc = ifcs_ctypes.ifcs_l2vni_create(0, pointer(self.vni_handles[l2vni_id]),
                                   0, 0)
            if rc != 0:
                log_err("l2vni create FAILED!!")
                return
        except:
            log_err("Usage: l2vni create <l2vni>")
            return

    def delete(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_delete(0, self.vni_handles[l2vni_id])
            if rc != 0:
                log_err("l2vni delete FAILED!!")
                return

        except:
            log_err("Usage: l2vni delete <l2vni>")
            return

    def add(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        port = int(self.arg_list.pop(0))

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        actual_count = c_uint32()
        rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, 1, pointer(attr),
                                pointer(actual_count))
        if rc != 0:
            log_err("l2vni port_attr_get FAILED!!")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_member_add(0, self.vni_handles[l2vni_id],
                                       attr.value.handle, 0)
            if rc != 0:
                log_err("l2vni member add FAILED!!")
                return

        except:
            log_err("Usage: l2vni add <l2vni>")
            return

    def remove(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        port = int(self.arg_list.pop(0))

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        actual_count = c_uint32()
        rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, 1, pointer(attr),
                                pointer(actual_count))
        if rc != 0:
            log_err("l2vni port_attr_get")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_member_remove(0, self.vni_handles[l2vni_id],
                                          attr.value.handle)
            if rc != 0:
                log_err("l2vni member remove FAILED!!")
                return

        except:
            log_err("Usage: l2vni remove <l2vni>")
            return

    def basicl2(self, args):
        devport_arg_list = self.arg_list[2].split(",")
        devport_list = []
        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = self.arg_list[2].split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    devport_list.append(j)
            else:
                devport_list.append(int(dp))


        ret = ifcs_ctypes.ifcs_status_t()
        stp_hdl = ifcs_ctypes.ifcs_handle_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        attr = ifcs_ctypes.ifcs_attr_t()
        vni_attr = (ifcs_ctypes.ifcs_attr_t * 2)()
        mac_addr_t = c_uint8 * 6

        #ifcs_ctypes.node_model_server_dbglvl_set(0, 0, 5)
        dsp_fldlst = []
        #fldlst = []

        '''
        attr.id = ifcs_ctypes.IFCS_NODE_ATTR_ENABLE
        attr.value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        rc = ifcs_ctypes.ifcs_node_attr_set(0, 1, pointer(attr))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Node enable FAILED!!. RC " + str(rc)
        '''

        log("Node enabled")

        #attr.id = ifcs_ctypes.IFCS_NODE_ATTR_L2ENTRY_AGING_INTERVAL
        #attr.value.u32 = 0

        #rc = ifcs_ctypes.ifcs_node_attr_set(0, 1, pointer(attr))
        #assert rc == ifcs_ctypes.IFCS_SUCCESS, "Learning set FAILED!!. RC " + str(rc)


        #fldlst = read_pen(ifcs_ctypes.DSP_L2TAG_ACTION_PROFILE, 0, dsp_fldlst)
        #log(dsp_fldlst)
        #fldlst = read_pen(ifcs_ctypes.DSP_L2TAG_ACTION_PROFILE, 1, dsp_fldlst)
        #log(fldlst)

        #maxPorts = 121
        maxPorts = 129
        cpu_port = 129

        port_sp_hdl=OrderedDict()

        try:
            for port in devport_list:
                port_sp_hdl[port] = getSysportHandleFromDevPort(port)
                #port_sp1 = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl_1)

                #ret = ifcs_ctypes.ifcs_devport_stats_clear(0, port, ifcs_ctypes.IFCS_DEVPORT_STATS_ID_ALL, None)
                #assert ret == ifcs_ctypes.IFCS_SUCCESS, "Devport Stats clear FAILED!!"

        except:
            log("Sysport get FAILED!!")
            pass

        log("Sysport get done")

        ####### STEP0 #######
        ###### STP CONFIG #######
        try:
            stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
            ret = ifcs_ctypes.ifcs_stp_create(0, pointer(stp_hdl),
                                           0, pointer(attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance creation FAILED!!"
        except:
            log("STP create FAILED!!")
            pass

        log("STP create done")

        try:
            mbrs=OrderedDict()
            for mbr in port_sp_hdl:
                mbrVal = ifcs_ctypes.IFCS_HANDLE_VALUE(mbr)
                mbrs[mbr] = ifcs_ctypes.IFCS_HANDLE_SYSPORT(mbrVal)
                #log(mbr, mbrs[mbr])

            member_count = len(mbrs)
            member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

            member_attr_count = 0
            member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

            count=0
            for mbr in mbrs:
                member_list[count] = mbrs[mbr]
                count += 1

            stp_attr_count = 1
            stp_attr = ifcs_ctypes.ifcs_attr_t()
            stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;

            ret = ifcs_ctypes.ifcs_stp_port_add(0, stp_hdl, count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t), stp_attr_count, pointer(stp_attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni)
            #for mbr in mbrs:
            #    if mbr == 0:
            #        continue
            #    ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbrs[mbr], stp_attr_count, pointer(stp_attr))
            #    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
            #           "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
            #            str(l2vni)
        except:
            log("STP port set FAILED!!")
            pass

        log("Finished STP port config")

        ###### VNI CONFIG ######
        # Create VNI and add members
        try:
            ###### VNI CONFIG ######
            # Create VNI and add members
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
            for i in devport_list:
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(i)
                if (i == 0):
                    continue
                ret = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, pointer(attr))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI creation " + str(i)

            # Set STP instance for created VNI
            vni_attr[0].id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
            vni_attr[0].value.handle = stp_hdl
            #vni_attr[1].id = ifcs_ctypes.IFCS_L2VNI_ATTR_FLOOD_GROUP
            #vni_attr[1].value.handle = flood_group_hdl
            ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_ctypes.ifcs_attr_t))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set FAILED!!"

            for i in devport_list:
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(i)
                if (i == 0):
                    continue
                ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                             member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni)
                #Add CPU port to VNI membership
                cpu_handle = ifcs_ctypes.ifcs_handle_t()
                cpu_handle.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(cpu_port)
                ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                             1, pointer(cpu_handle),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni)
        except:
            log("Hit except (STP/VNI) config")
            pass

        log("Finished VNI config")


        try:
            ###### MDG CONFIG ######
            # Create MDG and add sysports as destinations
            flood_group_hdl = ifcs_ctypes.ifcs_handle_t()
            flood_group_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
            ret = ifcs_ctypes.ifcs_mdg_create(0, pointer(flood_group_hdl), 0, None)
            assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during MDG creation "
        except:
            log("MDG create FAILED!!")
            pass

        log("MDG create done")

        try:
            mc_mbrs=OrderedDict()
            for mc_mbr in port_sp_hdl:
                mc_mbrVal = ifcs_ctypes.IFCS_HANDLE_VALUE(mc_mbr)
                mc_mbrs[mc_mbr] = ifcs_ctypes.IFCS_HANDLE_SYSPORT(mc_mbrVal)
                #log(mbr, mbrs[mbr])

            mc_member_count = len(mc_mbrs)
            mc_member_list = (ifcs_ctypes.ifcs_handle_t * mc_member_count)()

            mc_dest_attr_count = 1
            mc_dest_attr = ifcs_ctypes.ifcs_attr_t()
            mc_dest_attr.id        = ifcs_ctypes.IFCS_MC_DEST_ATTR_SYSPORT;

            count=0
            for mbr in mc_mbrs:
                mc_dest_attr.value.handle = mc_mbrs[mbr];
                mc_dest_hdl = ifcs_ctypes.ifcs_handle_t()
                mc_dest_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
                ret = ifcs_ctypes.ifcs_mc_dest_create(0, pointer(mc_dest_hdl), mc_dest_attr_count, pointer(mc_dest_attr))
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during MC_DEST creation "
                mc_member_list[count]=mc_dest_hdl
                count+=1
        except:
            log("MDG DEST create FAILED!!")
            pass

        log("MC dest create done")

        try:
            ret = ifcs_ctypes.ifcs_mdg_mc_dest_add(0, flood_group_hdl, mc_member_count, compat_pointer(mc_member_list, ifcs_ctypes.ifcs_handle_t), 0, None)
            assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during add MC_DEST to MDG"

        except:
            log("MDG mc_dest add FAILED!!")
            pass

        log("MDG mc_dest add done")

        try:
            #flood_group_hdl = ifcs_ctypes.ifcs_handle_t()
            #flood_group_hdl.value = 0x4c400080
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
            l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(l2vni)

            vni_attr[0].id = ifcs_ctypes.IFCS_L2VNI_ATTR_FLOOD_GROUP
            vni_attr[0].value.handle = flood_group_hdl
            ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_ctypes.ifcs_attr_t))
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "VNI instance vni attr set FAILED!!"
        except:
            log("VNI MDG update FAILED!!")
            pass

        log("VNI MDG update done")


        ###### FDB Config #######
        # 1
        #l2entry_array = ifcs_ctypes.ifcs_l2_entry_key_t
        #attr_count = 2
        #attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        #port_hdl = ifcs_ctypes.ifcs_handle_t()


        try:

            l2_entry_array = (ifcs_ctypes.ifcs_l2_entry_key_t * maxPorts)()
            attr_count = 2
            attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

            # Skip list of devports for pic ports which are not working
            # SRC MAC
            for port in devport_list:

                count = port
                port_hdl = ifcs_ctypes.ifcs_handle_t()
                #port_sp_hdl[port] = getSysportHandleFromDevPort(port)
                port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[port])
                mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
                port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                ifcs_ctypes.ifcs_l2_entry_key_t_init(compat_pointerAtIndex(l2_entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, count))

                l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
                l2_entry.key_type = ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
                l2_entry.key.mac_l2vni.mac_addr = mac_addr
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port)
                l2_entry.key.mac_l2vni.l2vni = l2vni_hdl

                l2_entry_array[count] = l2_entry

                attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
                attr[0].value.handle = port_hdl
                attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
                attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
                rc = ifcs_ctypes.ifcs_l2_entry_create(0, compat_pointerAtIndex(l2_entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, count), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (Src L2entry) config")
            pass

        log("Finished Src L2 entry config")

        try:
            # Dest MAC of packet
            for i, port in enumerate(devport_list):

                count = port
                port_hdl = ifcs_ctypes.ifcs_handle_t()
                #port_sp_hdl[port] = getSysportHandleFromDevPort(port)
                #if port == devport_list[-1]:
                #    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[1])
                #else:
                #    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_sp_hdl[devport_list[i+1]])
                mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
                #if (port == devport_list[-1]):
                #    port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(devport_list[0])
                #else:
                #    port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(devport_list[i])
                port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(devport_list[i])

                ifcs_ctypes.ifcs_l2_entry_key_t_init(compat_pointerAtIndex(l2_entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, count))

                l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
                l2_entry.key_type = ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
                l2_entry.key.mac_l2vni.mac_addr = mac_addr
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port)
                l2_entry.key.mac_l2vni.l2vni = l2vni_hdl

                l2_entry_array[count] = l2_entry

                attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
                attr[0].value.handle = port_hdl
                attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
                attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
                rc = ifcs_ctypes.ifcs_l2_entry_create(0, compat_pointerAtIndex(l2_entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, count), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry FAILED!!: rc = [" + str(rc) + "]"

        except:
            log("Hit except (Dest L2entry) config")
            pass

        log("Finished Dest L2 entry config")

        try:
            # SYSPORT attr set
            #Build Sysport attr for Default VID config
            default_vid = l2vni
            sp_attr_ct = 3
            sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

            for i, port in enumerate(devport_list):
                if (port == 0):
                    continue
                sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
                if port == devport_list[-1]:
                    sp_attr[0].value.u16 = devport_list[0]
                else:
                    sp_attr[0].value.u16 = devport_list[i + 1]
                sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
                sp_attr[1].value.u16 = port
                sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
                sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_TRUE

                rc = ifcs_ctypes.ifcs_sysport_attr_set(0, port_sp_hdl[port], 3, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
        except:
            log("Hit except (Sysport) config")
            pass

        log("Finished Sysport VID  config")


        try:
            # Disable all the ports
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

            for port in devport_list:
                if (port == 0):
                    continue
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            for port in devport_list:
                if (port == 0):
                    continue
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

            # Enable all the ports
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

            for port in devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)
        except:
            log("Hit except (Devport loopback) config")
            pass

        log("Finished Devport LB config")


    def deletel2(self, args):
        ret = ifcs_ctypes.ifcs_status_t()
        stp_hdl = ifcs_ctypes.ifcs_handle_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        attr = ifcs_ctypes.ifcs_attr_t()
        vni_attr = ifcs_ctypes.ifcs_attr_t()
        mac_addr_t = c_uint8 * 6

        try:
            for port in range(1,maxPorts):
                mac_addr = mac_addr_t(0, 0, 0, 0, 0, port)
                l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)

                rc = ifcs_ctypes.ifcs_l2entry_delete(0, pointer(l2entry_array))
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete FDB entry FAILED!!: rc = [" + str(rc) + "]"

        except:
            pass


    def flushl2(self, args):
        attr = ifcs_ctypes.ifcs_attr_t()
        attrCount = 1

        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(l2vni)

        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRIES_BY_L2VNI
        attr[0].value.handle = l2vni_hdl

        rc = ifcs_ctypes.ifcs_l2entry_flush(0, 1, pointer(attr));
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Flush FDB entry FAILED!!: rc = [" + str(rc) + "]"

    def lb(self, args):
        node_id = self.cli.node_id
        attr = ifcs_ctypes.ifcs_attr_t()
        vni_attr = ifcs_ctypes.ifcs_attr_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        stp_hdl = ifcs_ctypes.ifcs_handle_t()
        mac_addr_t = c_uint8 * 6

        port_cnt  = 4
        first_port = 1
        num_ports = first_port + port_cnt
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        # Disable all the ports
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin disable:" +\
                str(devport)

        # Set all the ports in loopback
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port loopback set:" +\
                str(devport)

        # Enable all the ports
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin enable:" +\
                str(devport)


        l2vni = 0x64

        ###### VNI CONFIG ######
        # Create VNI and add members
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(l2vni)
        ret = ifcs_ctypes.ifcs_l2vni_create(node_id, pointer(l2vni_hdl), 0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
               "ERR during L2VNI creation " + str(l2vni)

        ctc_trap_handle = create_ctc_trap(node_id)

        ####### STEP0 #######
        ###### STP CONFIG #######
        stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
        ret = ifcs_ctypes.ifcs_stp_create(node_id, pointer(stp_hdl),
                                         0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST, "STP instance creation FAILED"

        dst_sp_hdl = getSysportHandleFromDevPort(0)
        dst_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl)
        mbr1 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        member_count = 1
        member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

        member_attr_count = 0
        member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

        member_list[0] = mbr1

        ret = ifcs_ctypes.ifcs_l2vni_member_add(node_id, l2vni_hdl,
                                     member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                     member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
               "ERR during L2VNI mbr add " + str(l2vni)

        stp_attr_count = 1
        stp_attr = ifcs_ctypes.ifcs_attr_t()
        stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
        stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;
        #ret = ifcs_ctypes.ifcs_stp_port_attr_set(node_id, stp_hdl, mbr1,\
        #                             stp_attr_count, pointer(stp_attr))
        ret = ifcs_ctypes.ifcs_stp_port_add(node_id, stp_hdl, member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),\
                                     stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr1.value))

        # 1.2
        ###### FDB Config #######
        attr_count = 4
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 1)
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        l2entry_dst = ifcs_ctypes.ifcs_l2_entry_key_t
        l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
        l2_entry.key_type = ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
        l2_entry.key.mac_l2vni.mac_addr = mac_addr
        l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
        l2entry_dst = l2_entry

        attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
        attr[2].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY
        attr[2].value.fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_DROP
        attr[3].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY
        attr[3].value.ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
        attr[3].value.ctc_policy.trap_handle = ctc_trap_handle
        rc = ifcs_ctypes.ifcs_l2_entry_create(node_id, pointer(l2entry_dst), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "Create FDB entry FAILED: rc = [" + str(rc) + "]"

        l2entry_array = (ifcs_ctypes.ifcs_l2_entry_key_t * num_ports)()
        src_port_hdl = ifcs_ctypes.ifcs_handle_t()

        # Set up an L2entry with CTC
        for devport in range(first_port, num_ports):
            src_sp_hdl = getSysportHandleFromDevPort(devport)
            src_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(src_sp_hdl)

            ####### STEP1 #######
            # 1.1

            mbr2 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)

            member_count = 1
            member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

            member_attr_count = 0
            member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

            member_list[0] = mbr2

            ret = ifcs_ctypes.ifcs_l2vni_member_add(node_id, l2vni_hdl,
                                         member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                         member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
            assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
                   "ERR during L2VNI mbr add " + str(l2vni)

            stp_attr_count = 1
            stp_attr = ifcs_ctypes.ifcs_attr_t()
            stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;
            #ret = ifcs_ctypes.ifcs_stp_port_attr_set(node_id, stp_hdl, mbr2,\
            #                             stp_attr_count, pointer(stp_attr))
            ret = ifcs_ctypes.ifcs_stp_port_add(node_id, stp_hdl, member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),\
                                         stp_attr_count, pointer(stp_attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni) + ", Port Hdl: " + str(hex(mbr2.value))

            mac_addr = mac_addr_t(0, 0, 0, 0, 0, devport+1)
            src_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)
            attr_count = 2

            l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
            l2_entry.key_type = ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
            l2_entry.key.mac_l2vni.mac_addr = mac_addr
            l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
            l2entry_array[devport] = l2_entry
            attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
            attr[0].value.handle = src_port_hdl
            attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
            attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
            rc = ifcs_ctypes.ifcs_l2_entry_create(node_id, compat_pointerAtIndex(l2entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, devport), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            assert rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "Create FDB entry FAILED: rc = [" + str(rc) + "]"


            ssp_attr = ifcs_ctypes.ifcs_attr_t()
            ssp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
            ssp_attr.value.u32 = l2vni
            ret = ifcs_ctypes.ifcs_sysport_attr_set(node_id, src_sp_hdl, 1, pointer(ssp_attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "SSP default PVID set FAILED: ret = [" + str(ret) + "]"

        # Set STP instance for created VNI
        vni_attr.id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
        vni_attr.value.handle = stp_hdl
        ret = ifcs_ctypes.ifcs_l2vni_attr_set(node_id, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "STP instance vni attr set FAILED"
        return

    def snake(self):
        parser = argparse.ArgumentParser(description='Snake test')
        parser.add_argument('-p', type=str, default="1-2", help='Port list')
        parser.add_argument('-n', nargs=1, type=int, default=[500], help='Number of packets')
        parser.add_argument('-s', nargs=1, type=int, default=[200], help='Packet size')
        parser.add_argument('-c', nargs=1, type=int, default=[3], help='Loop count for stats')
        parser.add_argument('-i', nargs=1, type=int, default=[5], help='Interval for stats')
        parser.add_argument('-l', nargs=1, type=int, default=[1], help='Loopback type(1-PCS)')
        parser.add_argument('-t', nargs=1, type=int, default=[1], help='Test type(1-Linerate,2-CPU)')
        parser.add_argument('-v', nargs=1, type=int, default=[0], help='1-Verbose')
        try:
            res = parser.parse_args(self.arg_list)
        except:
            parser.print_help()
            return "FAILED"
        try:
            devport_arg_list = res.p.split(",")
        except:
            devport_arg_list = "1-2"
        length = res.s[0]
        if (length < 64):
            length = 128
        num_pkt = res.n[0]
        interval = res.i[0]
        loop_count = res.c[0]
        lb_type = res.l[0]
        test_type = res.t[0]
        verbose = res.v[0]
        node_id = self.cli.node_id
        devport_list = []

        devport_rx_frames = [0] * MAX_DEV_PORTS
        devport_rx_bytes = [0] * MAX_DEV_PORTS
        devport_rx_gbps = [0] * MAX_DEV_PORTS
        vni_attr.value.handle = stp_hdl
        ret = ifcs_ctypes.ifcs_l2vni_attr_set(node_id, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST, "STP instance vni attr set FAILED"

    def help(self, args):
        self.cli.error()
        log("Usage: \n", \
              "vni create <l2vni_id>         - create l2VNI\n", \
              "vni delete <l2vni_id>         - delete l2VNI\n", \
              "vni add <l2vni_id>, <sysport> - l2vni add member\n", \
              "vni remove <l2vni_id>         - l2vni remove member\n", \
              "vni lb                        - put port in loopback mdoe\n", \
              "vni help or ?                 - show this text\n")
