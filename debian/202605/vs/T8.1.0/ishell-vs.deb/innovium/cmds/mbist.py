#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
from ifcs_cmds.node import Node as ifcs_node


# Class implements Diagtest related command
class Mbist(Command):
    def __init__(self, cli):
        self.sub_cmds = {'run'          : self.mbist_run,
                         'status'       : self.mbist_status,
                         ''             : self.mbist_status,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        super(Mbist, self).__init__()
        self.num_nodes = cli.num_nodes
        self.active_node = 0

    def run_cmd(self, args):
        log_dbg(1, "in mbist")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            if len(self.arg_list) > 2:
                rc = self.sub_cmds[self.arg_list[2]](args)
            else:
                rc = self.sub_cmds[''](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except Exception:
            log_dbg(
                1, "OtherError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def print_result_mbist_run(self, bist_status, bisr_status, detail):
        if ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            log("SMS BIST: 0x{:04x}".format(bist_status))
            log("SMS BISR: 0x{:04x}".format(bisr_status))
        else:
            log("SMS BIST: 0x{:016x}".format(bist_status))
            log("SMS BISR: 0x{:016x}".format(bisr_status))

        if bist_status:
            if (detail):
                log("\nMBIST failed before Self Repair")
            else:
                log("\nMBIST failed")
            failed_rings_bist = []
            for i in range(64):
                if bist_status & (1 << i):
                    failed_rings_bist.append(i + 1)
            failed_rings_bist_str = ','.join(map(str, failed_rings_bist))
            if (detail):
                log("Failed Ring numbers after BIST: {:s}\n".format(failed_rings_bist_str))
        else:
            if (detail):
                log("\nMBIST passed Without Self Repair")
            else:
                log("\nMBIST passed")
        if bisr_status:
            if (detail):
                log("MBIST failed after Self Repair")
            failed_rings_bisr = []
            for i in range(64):
                if bisr_status & (1 << i):
                    failed_rings_bisr.append(i + 1)
            failed_rings_bisr_str = ','.join(map(str, failed_rings_bisr))
            if (detail):
                log("Failed Ring numbers after BISR: {:s}\n".format(failed_rings_bisr_str))
        else:
            if (detail):
                log("MBIST passed after Self Repair\n")

    def mbist_run(self, args):
        '''
        Run SMS MBIST post node create
        '''
        detail = 1
        node_obj = ifcs_node(self.cli)
        if self.cli.node_id is None:
            log("Err: Invalid node ID, trying to run mbist prior to node create")
            return

        if ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id) == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_T100:
            return self._t100_mbist_run(args)

        log("Running mbist...")
        sms_run_status = node_obj.setSmsBistRun(1)
        sms_bist_status = node_obj.getSmsBistStatus()
        sms_bisr_status = node_obj.getSmsBisrStatus()
        log("\nMBIST RUN result:\n")
        self.print_result_mbist_run(sms_bist_status, sms_bisr_status, detail)
        log("\nReinitialize SDK before proceeding\n")
        return

    def mbist_status(self, args):
        '''
        Run SMS MBIST Status get
        '''
        detail = 0
        node_obj = ifcs_node(self.cli)
        if self.cli.node_id is None:
            log("Err: Invalid node ID, trying to run mbist prior to node create")
            return
        arg_list = shlex.split(args)
        if (len(arg_list) == 4):
            if (arg_list[3] == 'detail'):
                detail = 1
        if ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id) == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_T100:
            self._t100_print_bist_results(detail)
            return
        # Just print the mbist result as captured
        # in ifcs_ctypes.IFCS_NODE_ATTR_MBIST_RESULT
        if ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            #TL7
            mbist_result = node_obj.getMbistResult()
            sms_bist_status = ifcs_ctypes.IM_NODE_MBIST_STATUS(mbist_result)
            sms_bisr_status = ifcs_ctypes.IM_NODE_MBISR_STATUS(mbist_result)
            self.print_result_mbist_run(sms_bist_status, sms_bisr_status, detail)
        else:
            # TL10
            sms_bist_status = node_obj.getSmsBistStatus()
            sms_bisr_status = node_obj.getSmsBisrStatus()
            self.print_result_mbist_run(sms_bist_status, sms_bisr_status, detail)

        return

    # Domain tokens accepted on the T100 'diagtest mbist run' command
    T100_BIST_DOMAINS = ('sram', 'tcam', 'comphy')

    # Sentinel for a failure entry with no XSB index (e.g. SRAM); matches the
    # SDK's II_T100_NODE_DFX_BIST_XSB_IDX_INVALID (0xFF).
    XSB_IDX_INVALID = 0xFF

    # Sentinel server index used by the SDK to mark a domain-level error with no
    # locatable failing client (e.g. an SRAM IFCS_CONFIG error on a re-run);
    # matches II_T100_NODE_DFX_BIST_IDX_INVALID (UINT32_MAX). An entry with this
    # server index means "domain errored" (ERROR), not a real failing client (FAIL).
    SRV_IDX_INVALID = 0xFFFFFFFF

    def _bist_mode_from_token(self, token):
        mode_map = {
            'soft_repair': ifcs_ctypes.IFCS_BIST_MODE_SOFT_REPAIR,
            'no_repair': ifcs_ctypes.IFCS_BIST_MODE_NO_REPAIR,
        }
        return mode_map.get(token)

    def _bist_mode_str(self, mode):
        if mode == ifcs_ctypes.IFCS_BIST_MODE_SOFT_REPAIR:
            return 'soft_repair'
        if mode == ifcs_ctypes.IFCS_BIST_MODE_NO_REPAIR:
            return 'no_repair'
        return 'disabled'

    def _status_str(self, rc):
        return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))

    def _t100_set_bist_mode(self, sram, tcam, comphy):
        # Build ifcs_bist_domain_select_t and set the IM-level DFX BIST mode
        # attribute; setting it triggers the standalone DFX BIST in the SDK.
        domain_select = ifcs_ctypes.ifcs_bist_domain_select_t()
        assert ifcs_ctypes.ifcs_bist_domain_select_t_init(
            pointer(domain_select)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_bist_domain_select_t_sram_set(
            pointer(domain_select), sram) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_bist_domain_select_t_tcam_set(
            pointer(domain_select), tcam) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_bist_domain_select_t_comphy_set(
            pointer(domain_select), comphy) == ifcs_ctypes.IFCS_SUCCESS

        attr = ifcs_ctypes.ifcs_attr_t()
        assert ifcs_ctypes.ifcs_attr_t_init(
            pointer(attr)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(attr),
            ifcs_ctypes.IFCS_NODE_ATTR_DFX_BIST_MODE) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_value_bist_domain_select_set(
            pointer(attr), pointer(domain_select)) == ifcs_ctypes.IFCS_SUCCESS

        return ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.im_node_attr_set(self.cli.node_id, 1, pointer(attr)))

    def _t100_get_bist_results(self):
        # DFX BIST results are an IM-level attribute that embeds variable-length
        # per-domain failure arrays. The IM framework uses the standard two-pass
        # list-get contract: the first call reports each domain's failure count and
        # returns IFCS_LENGTH_MISMATCH (arr left NULL); we then allocate the arrays
        # and re-read to fill in the failure detail.

        attr = ifcs_ctypes.ifcs_attr_t()
        assert ifcs_ctypes.ifcs_attr_t_init(
            pointer(attr)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(attr),
            ifcs_ctypes.IFCS_NODE_ATTR_DFX_BIST_RESULTS) == ifcs_ctypes.IFCS_SUCCESS

        actual_count = c_uint32(0)
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.im_node_attr_get(self.cli.node_id, 1, pointer(attr),
                                         pointer(actual_count)))
        if rc != ifcs_ctypes.IFCS_SUCCESS and rc != ifcs_ctypes.IFCS_LENGTH_MISMATCH:
            log("Err: Unable to read DFX BIST results: rc={}".format(
                self._status_str(rc)))
            return None
        if attr.bitmap.dfx_bist_results != 1:
            return None

        if rc == ifcs_ctypes.IFCS_LENGTH_MISMATCH:
            # Allocate the per-domain failure arrays from the reported counts and
            # re-read. Keep references alive so ctypes does not free the buffers
            # while attr still points at them.
            results = attr.value.dfx_bist_results
            self._bist_fail_bufs = []
            entry_t = ifcs_ctypes.ifcs_dfx_bist_result_entry_t
            for dom in (results.sram_bist, results.tcam_mbist,
                        results.tcam_cbist, results.comphy_bist):
                n = dom.failures.count
                if n:
                    buf = (entry_t * n)()
                    self._bist_fail_bufs.append(buf)
                    dom.failures.arr = cast(buf, POINTER(entry_t))
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.im_node_attr_get(self.cli.node_id, 1, pointer(attr),
                                             pointer(actual_count)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Err: Unable to read DFX BIST result details: rc={}".format(
                    self._status_str(rc)))
                # Summary counts are still valid even if detail could not be read.
        return attr.value.dfx_bist_results

    def _t100_mbist_run(self, args):
        '''
        Run standalone DFX BIST on T100 for the requested domain(s).
        Syntax: diagtest mbist run [sram|tcam|comphy ...] [soft_repair|no_repair]
        With no domain specified, all domains (sram, tcam, comphy) are run.
        '''
        arg_list = shlex.split(args)
        # arg_list = ['diagtest', 'mbist', 'run', [domain]..., [mode]]
        tokens = [tok.lower() for tok in arg_list[3:]]

        domains = []
        mode = ifcs_ctypes.IFCS_BIST_MODE_NO_REPAIR
        for tok in tokens:
            if tok in self.T100_BIST_DOMAINS:
                if tok not in domains:
                    domains.append(tok)
                continue
            parsed = self._bist_mode_from_token(tok)
            if parsed is None:
                self.cli.error()
                log("Invalid argument '{}'. Expected domain (sram|tcam|comphy) "
                    "or mode (soft_repair|no_repair)".format(tok))
                return
            mode = parsed

        # Domain specification is optional: when no domain is given, run all
        # domains. This matches TL10, where 'diagtest mbist run' runs BIST by
        # default.
        if not domains:
            domains = list(self.T100_BIST_DOMAINS)

        disabled = ifcs_ctypes.IFCS_BIST_MODE_DISABLED
        sram_mode = mode if 'sram' in domains else disabled
        tcam_mode = mode if 'tcam' in domains else disabled
        comphy_mode = mode if 'comphy' in domains else disabled

        log("Running T100 DFX BIST: domains={} mode={}".format(
            ','.join(domains), self._bist_mode_str(mode)))
        rc = self._t100_set_bist_mode(sram_mode, tcam_mode, comphy_mode)

        # SOFT_REPAIR is not supported yet: the SDK rejects the attr set with
        # IFCS_UNSUPPORTED and no BIST runs. Report the requested domains as
        # "not supported" and skip the results table, which would otherwise show
        # stale results carried over from a prior run.
        if mode == ifcs_ctypes.IFCS_BIST_MODE_SOFT_REPAIR:
            self._t100_print_bist_unsupported(domains, mode)
            log("\nReinitialize SDK before proceeding\n")
            return

        # Show per-domain BIST status only; there is no overall summary line since
        # domains can differ (one PASS, another FAIL/ERROR). Each domain's status
        # is derived from its own recorded result, so a non-success aggregate run
        # rc (e.g. an SRAM IFCS_CONFIG on re-run) does not mark other domains as
        # ERROR. The aggregate rc is only logged for debugging.
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_dbg(1, "DFX BIST run failed: rc={}".format(self._status_str(rc)))
        self._t100_print_bist_results(detail=1)

        log("\nReinitialize SDK before proceeding\n")
        return

    # (domain label, bist type label, request key) rows for the results table.
    T100_BIST_RESULT_ROWS = [
        ('SRAM',   'MBIST', 'sram'),
        ('TCAM',   'MBIST', 'tcam'),
        ('TCAM',   'CBIST', 'tcam'),
        ('COMPHY', 'BIST',  'comphy'),
    ]

    def _t100_print_bist_unsupported(self, requested_domains, mode):
        # No BIST ran, so don't read the (stale) result store. Requested domains
        # are shown as "not supported" (with the requested mode, matching the
        # normal results format); the rest keep the usual "not run".
        requested = set(requested_domains)
        log("\nT100 DFX BIST results:\n")
        for domain_name, type_name, key in self.T100_BIST_RESULT_ROWS:
            if key in requested:
                log("{:6s} {:6s} [mode={}] : not supported".format(
                    domain_name, type_name, self._bist_mode_str(mode)))
            else:
                log("{:6s} {:6s} : not run".format(domain_name, type_name))

    def _t100_classify_domain(self, domain_result):
        '''
        Classify a per-domain BIST outcome from that domain's OWN result only, so
        one domain's error never affects another's reported status:
          PASS  - domain ran with no failures/errors
          FAIL  - one or more real failing clients (valid server index)
          ERROR - domain-level error with no locatable failing client (a sentinel
                  entry with SRV_IDX_INVALID, e.g. an SRAM IFCS_CONFIG on re-run)
        Returns (status_str, real_failures) where real_failures is the list of
        genuine failing-client entries (sentinels excluded) for detail printing.
        '''
        count = domain_result.failures.count
        real = []
        errored = False
        if count and domain_result.failures.arr:
            for i in range(count):
                e = domain_result.failures.arr[i]
                if e.server_idx == self.SRV_IDX_INVALID:
                    errored = True
                else:
                    real.append(e)
        elif count:
            # Detail array unavailable; the count is authoritative, so treat the
            # domain as failing rather than silently passing it.
            return ("FAIL ({} failure(s))".format(count), real)

        if real:
            return ("FAIL ({} failure(s))".format(len(real)), real)
        if errored:
            return ("ERROR", real)
        return ("PASS", real)

    def _t100_print_bist_results(self, detail=0, run_rc=None):
        results = self._t100_get_bist_results()
        if results is None:
            log("No DFX BIST results available")
            return

        # (domain result, domain label, bist type label)
        domains = [
            (results.sram_bist, 'SRAM', 'MBIST'),
            (results.tcam_mbist, 'TCAM', 'MBIST'),
            (results.tcam_cbist, 'TCAM', 'CBIST'),
            (results.comphy_bist, 'COMPHY', 'BIST'),
        ]

        log("\nT100 DFX BIST results:\n")
        for domain_result, domain_name, type_name in domains:
            mode = domain_result.mode
            if mode == ifcs_ctypes.IFCS_BIST_MODE_DISABLED:
                log("{:6s} {:6s} : not run".format(domain_name, type_name))
                continue
            status_str, real = self._t100_classify_domain(domain_result)
            log("{:6s} {:6s} [mode={}] : {}".format(
                domain_name, type_name, self._bist_mode_str(mode), status_str))
            # Only real failing clients carry location detail; domain-level error
            # sentinels have no client and are excluded by _t100_classify_domain.
            if detail:
                for e in real:
                    # XSB only applies to TCAM/COMPHY; SRAM uses the invalid
                    # sentinel (0xFF), shown as N/A.
                    xsb = "N/A" if e.xsb_idx == self.XSB_IDX_INVALID else e.xsb_idx
                    log("    server={} pipe={} client={} xsb={}".format(
                        e.server_idx, e.pipe_idx, e.client_idx, xsb))

    def show(self, args):
        pass

    def help(self, args):
        self.cli.error()
        log("Usage: \n", \
              "<no_option> diagtest mbist  - diagtest mbist status\n", \
              "status  diagtest mbist status - diagtest mbist status\n", \
              "run  diagtest mbist run  - diagtest mbist run\n", \
              "T100 run  diagtest mbist run [sram|tcam|comphy ...] [soft_repair|no_repair] (default: all domains)\n", \
              "T100 status  diagtest mbist status [detail] - per-domain DFX BIST result\n", \
              "Show this text  - diagtest help or ?\n")
