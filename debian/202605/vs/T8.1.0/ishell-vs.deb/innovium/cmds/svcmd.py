#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import cmdmgr
import cmd
import sys
import time
import os.path
import traceback
import pkgutil
import importlib
import shlex
import argparse

import sv_cmds as subcmd_pkg
import sv_util as reloadable_util
import testutil as reloadable_testutil

import sv_util
from sv_util import platform_util
from verbosity import log, log_no_newline
from utils.compat_util import *
#from cliparse import Namespace


def parse_subcommand_rest(line):
    split = line.split(None, 2)
    cmd = split[1] if len(split) > 1 else None
    rest = split[2] if len(split) > 2 else ''
    return cmd, rest

class SV(cmdmgr.Command, cmd.Cmd):
    def __init__(self, cli):
        super(SV, self).__init__()
        cmd.Cmd.__init__(self, completekey='tab')
        self.cli = cli
        self.name = 'sv'
        self.parser = None
        self.submodules = None
        self.subcmd_strings = None
        self.extra_cmds = {}     # map from cmd name to module name for things outside of sv_cmds
        self.cur_subcmd = None   # the module name for for the (sub-)sub-shell we're in
        self.prompt_suffix = '> '
        self.exit_on_return = True
        self.debug = False
        self.transport_name = "unknown"

    ###### Interface used by ifcs_cli / cmdmgr

    # is given the entire line, including this command as first word
    def run_cmd(self, line):
        try:
            if line == self.name:
                self.cur_subcmd = None
                self.prompt = self.name + self.prompt_suffix
                self.run_subcli()
            else:
                self.onecmd(line[len(self.name):])
        except Exception as ex:
            traceback.print_exc(file=sys.stdout)

    def subcomplete(self, text, line):
        self.dbg_complete('\nautocompleting')
        self.dbg_complete('text: "%s"' % text)
        self.dbg_complete('line: "%s"' % line)
        if self.submodules is None:
            self.load_subcmds()

        # this is crappy, but if the last word includes a '-' or a '/', 'text' will only include everything after that character
        # there is no way to distinguish between "foo bar/<tab>" and "foo bar/ <tab>"
        # so try to recover the correct 'text' if it included '-' or '/':
        splitline_all = shlex.split(line)
        if self.cur_subcmd is not None:
            splitline_all = [self.cur_subcmd] + splitline_all
        self.dbg_complete("rawsplit: '%s'" % splitline_all)

        if len(splitline_all) == 0:
            return self.subcmd_strings

        last = splitline_all[-1]
        if last.endswith('-' + text) or last.endswith('/' + text):
            # i.e. the last word ended with a splitting char followed by text.  Try to complete _that_:
            text = splitline_all[-1]

        # remove optional arguments, to make a list that we can walk vs the argparse tree
        # heuristic: assume that any arguments after a "--xyz" that start with a number
        #            should also get removed, as an argument to that --xyz
        splitline = []
        in_opt_arg = False
        for w in splitline_all:
            if in_opt_arg and w[0].isdigit():
                in_opt_arg = False
                continue
            if w.startswith('-'):
                in_opt_arg = True
                continue
            splitline += [w]

        self.dbg_complete("preappend: '%s'" % splitline)

        # ensure that our split line ends with the thing we're trying to find, in case that is a blank or a --option
        if len(splitline) == 0 or splitline[-1] != text:
            splitline += [text]

        self.dbg_complete("splitline: '%s'" % splitline)

        p = self.parser
        out = []
        while p is not None and len(splitline) > 0:
            self.dbg_complete('====')
            self.dbg_complete("At subcommand '%s'" % p)
            actions = p._get_positional_actions()
            if actions is None or len(actions) == 0:
                self.dbg_complete("No positional actions:  adding options that start with '%s', from" % text)
                for k in p._option_string_actions.keys():
                    self.dbg_complete("    %s" % k)
                out = [k for k in p._option_string_actions.keys() if k.startswith(text)]
                break
            else:
                self.dbg_complete('actions is not None: %d <=? %d' % (len(splitline), len(actions)))
                if len(splitline) <= len(actions):
                    # the word we're trying to complete belongs in this subcommand
                    nth = len(splitline) - 1

                    if actions[nth].choices is not None:                  # auto-complete a 'choice'
                        self.dbg_complete("\nTrying to complete choice (%d of %s)" % (nth, splitline))
                        self.dbg_complete("choices: %s" % actions[nth].choices)
                        out = [k for k in actions[nth].choices if k.startswith(splitline[nth])]
                    elif type(actions[nth].type) == argparse.FileType:    # auto-complete a filename
                        self.dbg_complete("\nTrying to complete filename")
                        out = []
                        # get list of files, and downselect
                        dirname = os.path.dirname(text)
                        fn_start = os.path.basename(text)
                        if dirname == '':
                            dirname = './'

                        for j in os.listdir(dirname):
                            if j.startswith(fn_start):
                                if os.path.isdir(dirname + "/" + j):
                                    out += [j + '/']
                                else:
                                    out += [j]
                    else:
                        # not a choice or a filename.  No obvious completions other than the optionals
                        out = []
                    # add any possible optional arguments
                    out += [k for k in p._option_string_actions.keys() if k.startswith(text)]
                    self.dbg_complete("Adding options that start with '%s', from" % text)
                    for k in p._option_string_actions.keys():
                        self.dbg_complete("    %s" % k)
                    break
                else:
                    if splitline[0] in actions[0].choices:
                        # there is a valid subcommand, so recurse into it
                        p = actions[0].choices[splitline[0]]
                        splitline.pop(0)
                        continue
                    else:
                        # we're not within the range where it should be an argument of p
                        # and we don't have a valid subcommand.  Should be an optional argument of p:
                        # add any possible optional arguments
                        self.dbg_complete("Adding options that start with '%s', from" % text)
                        for k in p._option_string_actions.keys():
                            self.dbg_complete("    %s" % k)
                        out = [k for k in p._option_string_actions.keys() if k.startswith(text)]
                        break

        # the Cmd completer doesn't deal well with the leading '-'s, so strip them
        while text.startswith('-'):
            text = text[1:]
            out = [o[1:] for o in out]

        # if we've only got one option and it isn't a directory name, fully-complete it by appending a space
        if len(out) == 1 and not out[0].endswith('/'):
            out[0] = out[0] + ' '
        return out

    def help(self, line):
        line_no_help = line[len(self.name):].replace(' help ',' ')
        # not sure this is needed... revisit when cmds are in place
        if line_no_help.endswith(' help'):
            line_no_help = line_no_help[:-5]
        self.onecmd(line_no_help + ' --help')

    # Commands via argparse
    def sleep(self, args):
        time.sleep(args.seconds)

    ###### Class-specific methods
    def dbg_complete(self, s):
        if self.debug:
            log(s)

    def load_subcmds(self, verbose=False):
        if self.transport_name == 'unknown':
            self.do_transport("pcie " + platform_util.get_device_name(0))

        self.parser = argparse.ArgumentParser(prog=self.name)
        self.subparsers = self.parser.add_subparsers()
        self.submodules = {}
        self.subcmds = []
        for module_loader, mod_name, ispkg in pkgutil.iter_modules(subcmd_pkg.__path__):
            if mod_name == "sv_cmds":
                continue
            cmd_name = mod_name[:-3] if mod_name.endswith('cmd') else mod_name
            full_name = subcmd_pkg.__name__ + '.' + mod_name
            if verbose:
                #print '  loading %s' % full_name
                log_no_newline('.')
            this_module = importlib.import_module(full_name)
            this_subparser = self.subparsers.add_parser(cmd_name, help=this_module.__doc__)
            eval("this_module.add_parser(this_subparser)")
            self.submodules[cmd_name] = this_module
        for cmd in dict(self.extra_cmds).keys():
            self.load_extracmd(cmd)
            if verbose:
                log_no_newline('.')
        p = self.subparsers.add_parser('sleep', help='Delay');
        p.add_argument('seconds', type=float, help='delay time in seconds')
        p.set_defaults(func=self.sleep)
        if verbose:
            log("")

    def load_extracmd(self, cmd):
        try:
            for module_loader, mod_name, ispkg in pkgutil.iter_modules():
                cmd_name = mod_name[:-3] if mod_name.endswith('cmd') else mod_name
                if cmd_name == cmd:
                    this_module = importlib.import_module(mod_name)
                    this_subparser = self.subparsers.add_parser(cmd_name, help=this_module.__doc__)
                    eval("this_module.add_parser(this_subparser)")
                    self.submodules[cmd_name] = this_module
                    return mod_name
            return None
        except:
            log("Failed to add cmd '%s'" % cmd)
            traceback.print_exc(file=sys.stdout)
            return None

    def reload_subcmds(self):
        # reload sv_utils
        for module_loader, mod_name, ispkg in pkgutil.iter_modules(reloadable_util.__path__):
            full_name = reloadable_util.__name__ + '.' + mod_name
            this_module = importlib.import_module(full_name)
            if self.debug:
                log("Reloading %s" % full_name)
            try:
                eval("this_module.pre_reload()")
            except:
                pass
            compat_reload(this_module)
        # reload testutil
        for module_loader, mod_name, ispkg in pkgutil.iter_modules(reloadable_testutil.__path__):
            full_name = reloadable_testutil.__name__ + '.' + mod_name
            if self.debug:
                log("Reloading %s" % full_name)
            compat_reload(importlib.import_module(full_name))
        # reload subcmds
        for module_loader, mod_name, ispkg in pkgutil.iter_modules(subcmd_pkg.__path__):
            full_name = subcmd_pkg.__name__ + '.' + mod_name
            if self.debug:
                log("Reloading %s" % full_name)
            compat_reload(importlib.import_module(full_name))
        # reload any specified full commands
        for mod_name in self.extra_cmds.values():
            if self.debug:
                log("Reloading %s" % mod_name)
            compat_reload(importlib.import_module(mod_name))

        log('Reloading')
        self.load_subcmds(verbose=True)
        self.do_transport(self.last_transport_arg)

    ##### Cmd Class methods for sub-CLI

    def run_subcli(self):
        self.cmdloop()

    def emptyline(self):
        return self.exit_on_return  # exit this sub-cli

    def do_quit(self, arg):
        raise SystemExit(99) # tell main CLI that we actually want to quit

    def do_exit(self, arg):
        raise SystemExit(99)

    def do_EOF(self, arg):
        log("")
        raise SystemExit(99)

    def do_shell(self, arg):
        os.system(arg)

    def do_reload(self, arg):
        """Reload python command modules"""
        self.reload_subcmds()

    def do_add(self, arg):
        """ add a specific cmd from anywhere in path (including 'cmds' dir)"""
        if self.parser is None:
            self.load_subcmds()
        mod_name = self.load_extracmd(arg)
        if mod_name is not None:
            self.extra_cmds[arg] = mod_name

    def do_debug_completion(self, arg):
        if arg.lower() == "on":
            self.debug = True
        elif arg.lower() == "off":
            self.debug = False
        else:
            self.debug = not self.debug

    def do_transport(self, arg):
        self.last_transport_arg = arg
        args = arg.split()
        args[0] = args[0].lower()
        if args[0] == "pcie":
            pcie_access = importlib.import_module("sv_util.pcie_access")
            msn_isn = importlib.import_module("sv_util.msn_isn")
            self.msn_transport  = pcie_access.msn(args[1])
            self.isn_transport  = msn_isn.isn(self.msn_transport, 1, args[1])
            self.mdio_transport = None
            self.transport_name = args[0]
        elif args[0] == "rpi":
            rpi_access = importlib.import_module("sv_util.rpi_access")
            msn_isn = importlib.import_module("sv_util.msn_isn")
            self.msn_transport  = rpi_access.cpui2c_msn(args[1])
            self.isn_transport  = msn_isn.isn(self.msn_transport, 1, args[1])
            self.mdio_transport = None
            self.transport_name = args[0]
        elif args[0] == "rpi-dbgi2c":
            rpi_access = importlib.import_module("sv_util.rpi_access")
            msn_isn = importlib.import_module("sv_util.msn_isn")
            self.msn_transport  = rpi_access.dbgi2c_msn(args[1])
            self.isn_transport  = msn_isn.isn(self.msn_transport, 1, args[1])
            self.mdio_transport = None
            self.transport_name = args[0]
        elif arg.lower() == "tsec":
            log("No implemented tsec transport")
        else:
            log("Unexpected transport: use 'local' or 'tsec'")

    def do_help(self, arg):
        self.onecmd(arg + ' --help')

    def completedefault(self, text, line, begidx, endidx):
        return self.subcomplete(text, line)

    def completenames(self, text, line, begidx, endidx):
        return self.subcomplete(text, line)

    def set_prompt(self):
        if self.cur_subcmd is None:
            self.prompt = self.name + self.prompt_suffix
        else:
            try:
                extra = self.submodules[self.cur_subcmd].prompt_extra()
            except:
                extra = ''
            self.prompt = self.name + ' ' + self.cur_subcmd + extra + self.prompt_suffix

    def postcmd(self, stop, line):
        if not stop:
            self.set_prompt()
        return stop

    def default(self, wholeline):
        lines = wholeline.split(';')
        try:
            if self.parser is None:
                self.load_subcmds()

            for line in lines:
                if self.cur_subcmd is None or line.startswith(self.name + ' '):
                    # if the command is full, just use it
                    arg_list = shlex.split(line)
                else:
                    # include the current subcommand as prefix
                    arg_list = shlex.split(self.cur_subcmd + ' ' + line)

                if len(arg_list) == 1 and arg_list[0] in self.submodules:
                    self.cur_subcmd = arg_list[0]
                    self.set_prompt()
                    old_exit = self.exit_on_return
                    self.exit_on_return = True
                    self.run_subcli()
                    self.exit_on_return = old_exit
                    self.cur_subcmd = None
                    return False

                try:
                    args = self.parser.parse_args(arg_list)
                except SystemExit:
                    # raised by argparse because of a bad command line.  Don't actually exit
                    return False
                try:
                    if args.func:
                        args.mdio_transport = self.mdio_transport
                        args.msn_transport = self.msn_transport
                        args.isn_transport = self.isn_transport
                        args.func(args)
                    else:
                        log("no associated function for " + args)
                except ValueError as ex:
                    log("Value Error: %s" % ":".join(ex.args))
                except:
                    log('exception processing svcmd "%s"' % ('[' + str(self.cur_subcmd) + '] ' + line))
                    traceback.print_exc(file=sys.stdout)
                self.stdout.flush()
        except SystemExit:
            # a sub-command got 'quit', so keep quitting
            raise
        except:
            log('svcmd caught exception:')
            traceback.print_exc(file=sys.stdout)
        return False
