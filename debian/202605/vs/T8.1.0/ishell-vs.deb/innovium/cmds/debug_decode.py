#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import os
import sys
import json
import time
try:
    import cPickle as pickle
except BaseException:
    import pickle
from ctypes import *
from ctypes import Array
from collections import OrderedDict
from utils.compat_util import *
from verbosity import *
from debug_encode import read_pen
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

FIELD_NAME_MAX_LENGTH = 48
PEN_NAME_MAX_LENGTH = 48

#------------------------------------------
# ---- UTILS ---- #


def get_pen_info(pen_id):
    """
        Get pen info
    """
    peninfo = ifcs_ctypes.pen_t()
    ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
    return peninfo

#------------------------------------------


def get_flds_from_pen_id(pen_id):
    """
        Get fields from pen id
    """
    peninfo = get_pen_info(pen_id)
    nflds = c_uint32()
    nflds.value = peninfo.num_flds
    fldinfo = (ifcs_ctypes.pen_field_t * nflds.value)()
    try:
        ifcs_ctypes.node_get_pen_fields(
            0,
            pen_id,
            pointer(peninfo),
            byref(nflds),
            compat_pointer(fldinfo, ifcs_ctypes.pen_field_t))
    except Exception as ex:
        log(type(ex).__name__, ex.args)
    return nflds, fldinfo


#------------------------------------------

def get_flds_from_peninfo(pen_id, peninfo):
    """
        Get fields from peninfo
    """
    nflds = c_uint32()
    nflds.value = peninfo.num_flds
    fldinfo = (ifcs_ctypes.pen_field_t * nflds.value)()
    rc = ifcs_ctypes.node_get_pen_fields(
        0,
        pen_id,
        pointer(peninfo),
        byref(nflds),
        compat_pointer(fldinfo, ifcs_ctypes.pen_field_t))
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Get PEN Fields Failed for Pen " + str(pen_id)
    return nflds, fldinfo

#------------------------------------------


def get_fld_info(pen_id, fld):
    """
        Get field info
    """
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def get_fld_info_from_flds(nflds, fldinfo, pen_id, fld):
    """
        Get field info from fields
    """
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def get_fld_width(nflds, fldinfo, pen_id, fld):
    """
        Get field width
    """
    fld_width = -1
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            fld_width = fldinfo[j].width
            break
    return fld_width

#------------------------------------------


def get_fld_val_from_fldlst(pen_id, fldlst, fld_id):
    """
        Get field value from field list
    """
    val = -1
    for fld in fldlst:
        if fld[0] == fld_id:
            val = fld[1]
            return val

    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def check_fld_present(pen_id, fld_id):
    """
        Check if the field is present
    """
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if (fldinfo[j].fname == fld_id):
            return 1
    return 0

#------------------------------------------


def convert_ctypes_array_to_list(array):
    """
        Convert ctypes list to python list
    """

    if not isinstance(array, Array):
        return array

    lst = list()
    for i in range(len(array)):
        lst.append(array[i])

    return lst

#------------------------------------------


def gen_fldlst_from_tentry(pen_id, nflds, fldinfo, entry, verbose):
    """
        Function to get field list from tentry length
    """

    fldlst = []

    for j in range(nflds.value):
        fld_str = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
        rc = ifcs_ctypes.node_get_pen_field_name(
            0, fldinfo[j].fname, fld_str, FIELD_NAME_MAX_LENGTH)
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for field id " + \
            str(fld_id)
        fld_str_val = compat_bytesToStr(fld_str.value)

        if (fldinfo[j].width <= 32):
            rd_val = c_uint(0)
            rc = ifcs_ctypes.tentry_get_item(
                0,
                pen_id,
                fldinfo[j].fname,
                ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                entry,
                pointer(rd_val))
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN " + \
                str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed"
            rdval = c_uint32(rd_val.value).value
            fldlst.append([fldinfo[j].fname, rdval])
            if verbose:
                log("    %s : 0x%X " % (fld_str_val, rdval))
        else:
            nbytes = compat_division((fldinfo[j].width + 7), 8)
            buf = (c_ubyte * nbytes)()
            rc = ifcs_ctypes.tentry_get_item(
                0,
                pen_id,
                fldinfo[j].fname,
                ifcs_ctypes.TENTRY_FLD_TYPE_ANY,
                entry,
                compat_pointer(buf, c_ubyte))
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN " + \
                str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed"
            fldlst.append([fldinfo[j].fname, buf])
            if verbose:
                log("    %s : " % (fld_str_val), [hex(i) for i in buf])

    return fldlst

#------------------------------------------


def get_fld_len(pen_id, fld_id):
    """
        Function to get field length
    """
    pen_str = c_char_p(b" " * PEN_NAME_MAX_LENGTH)
    fld_str = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)

    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, PEN_NAME_MAX_LENGTH)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    fld_info = get_fld_info(pen_id, fld_id)
    rc = ifcs_ctypes.node_get_pen_field_name(0, fld_id, fld_str, FIELD_NAME_MAX_LENGTH)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for field id " + str(fld_id)

    return fld_info.width

#------------------------------------------


def get_sfld_width(
        nflds,
        fldinfo,
        pen_id,
        pen_str,
        mfld,
        mfld_str,
        mk,
        prof,
        sfld,
        sfld_str):
    mfld_info = get_fld_info_from_flds(nflds, fldinfo, pen_id, mfld)
    if (mk == 1):
        mmk = cast(mfld_info.mk_profile, POINTER(ifcs_ctypes.mk_profile_list_t))
        for j in range(mmk[prof].num_fields):
            if (mmk[prof].fields[j].fname == sfld):
                return mmk[prof].fields[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + \
            ": Could not find field " + sfld_str.value + " in mk_id = " + str(prof)

    else:
        mepp = cast(mfld_info.ep_profile, POINTER(ifcs_ctypes.ep_profile_list_t))
        for j in range(mepp[prof].num_actions):
            if (mepp[prof].ep_profiles[j].fname == sfld):
                return mepp[prof].ep_profiles[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + \
            ": Could not find field " + sfld_str.value + " in epp = " + str(prof)


#---------------------------------------------------
def debug_decode(fileName=None, ib_id_list=[], comp_id_list=[], pens_per_file=0, excep_file="", pen_name="", internal=False, state=[]):
    """
        Function that takes an encoded file
        and converts to a human readable data
    """
    def debug_decode_callback(node_id, buff):
        log_dbg(1, "%s" % compat_bytesToStr(buff))

    callback_type = CFUNCTYPE(
        ifcs_ctypes.UNCHECKED(None),
        ifcs_ctypes.ifcs_node_id_t,
        c_char_p)
    callback = callback_type(debug_decode_callback)

    # Check if the file exists.
    if not os.path.exists(fileName):
        log("File " + fileName + " not found")
        return

    # Form the comp id list. The cmp_id list [1, 3, 5, 6, 7, 8, 16] is statically set
    # in the c code
    if not comp_id_list or (len(comp_id_list) == 0):
        comp_id_list = [1, 3, 5, 6, 7, 8, 16]

    cmpid_len = len(comp_id_list)
    cmpid_memory = (c_uint32 * cmpid_len)(*comp_id_list)

    log('Decoding the state dump {0}. This might take a while..'.format(fileName))

    # File found. Uncompress it
    cmd = "tar --no-same-owner -zxf {}".format(fileName)
    os.system(cmd)

    # Form the fileName base
    fileName       = fileName.split(".tar.gz")[0].split('/')[-1]
    fileName_base  = fileName.split('stateDump_')[-1] + '.gz'
    fileName_untar = fileName.split('stateDump_')[-1]

    # Iterate and unzip all files corresponding to an IB
    ibs = []
    for ib in ib_id_list:
        ib_f  = str(ib) + '_' + fileName_base
        ib_f_ = str(ib) + '_' + fileName_untar

        # Check if the file exists
        if not os.path.exists(ib_f):
            log("File does not exist for IB {}".format(str(ib)))
            continue

        # Unzip the file per ib
        try:
            cmd = "gunzip {}".format(ib_f)
            log("Unzipping state for ib {0} ..".format(str(ib)))
            os.system(cmd)
        except:
            continue

        filesize = os.path.getsize(ib_f_)
        if filesize == 0:
            log("Null encoded file for ib {0}".format(str(ib)))
            continue

        # Form the outfile
        outFile = os.environ['HOME'] + '/stateDecode_' + ib_f_

        entries = ifcs_ctypes.pendump_decode_pendata(0, ib_f_, compat_pointer(cmpid_memory, c_uint32), cmpid_len, pens_per_file,
                                         excep_file, pen_name, outFile,
                                         compat_funcPointer(callback, ifcs_ctypes.pendump_user_cb_t))

        if entries > 0:
            log("output file name: {}".format(outFile))
            log("{} entries written to file {}".format(entries, outFile))
        else:
            log("No decoded output for IB {}".format(str(ib)))

        try:
            cmd = "rm {}".format(ib_f_)
            os.system(cmd)
        except:
            continue

    return


# ------------------------------------------------------

#-----------------------------------------------------------------------


def main():
    debug()


if __name__ == "__main__":
    debug()
