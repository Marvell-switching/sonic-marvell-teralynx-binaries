#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import os
import sys
from utils.log_utils import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from collections import OrderedDict
from ifcs_cmds.all import *
from ifcs_cmds.cli_types import *
from debug_encode import *
from print_table import PrintTable
 

# Class implements Debug state dump related commands
class Debug(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(Debug, self).__init__()

        self.sub_cmds = {
            'ifcs': self.debug_ifcs,
            'device': self.debug_device,
            'cli': self.debug_cli,
 
            'help': self.help,
            '?': self.help
        }

        self.sub_device_cmds = {
            'pen': self.debug_device_pen,
 
            'event': self.debug_device_event,
        }

 
        self.sub_device_event_cmds = {
            'pic_intr': self.device_event_pic_intr,
        }
        self.sub_cli_cmds = {
            'show': {
                'summary': self.debug_cli_show_summary
            },
            'clear': {
                'counters': self.debug_cli_clear_counters
            }
        }
 
        self.show_debug_names = ['ifcs', 'device', 'cli']

    def __del__(self):
        return

    def _validate_ifcs_all_outfile(self, outfile):
        if os.path.isdir(outfile):
            raise ValueError(
                "Output path must be a file, not a directory: {}".format(
                    outfile))

        parent_dir = os.path.dirname(os.path.abspath(outfile))
        if not os.path.isdir(parent_dir):
            raise ValueError(
                "Output directory does not exist: {}".format(parent_dir))

        if not os.access(parent_dir, os.W_OK):
            raise ValueError(
                "Output directory is not writable: {}".format(parent_dir))

        if os.path.exists(outfile) and not os.access(outfile, os.W_OK):
            raise ValueError(
                "Output file is not writable: {}".format(outfile))

    def validate_ifcs_args(self, args):
        # Validate "debug ifcs ..." before dispatch.
        #
        # Supported forms (after optional outfile strip for "all"):
        #   debug ifcs all [<file>]
        #   debug ifcs snapshot
        #   debug ifcs <api_name>
        #   debug ifcs <api_name> <id>
        #   debug ifcs <api_name> mod
        #   debug ifcs <api_name> <id> stats
        #
        # Raises ValueError with an actionable message on failure.

        arg_list = args.split()

        # "debug ifcs all <file>" — peel off and validate outfile first.
        # Exclude stats/mod so "debug ifcs all stats" is not misparsed as
        # an outfile path.
        if (arg_list[-2] == 'all' and len(arg_list) > 3
                and arg_list[-1] not in ('stats', 'mod')):
            self._validate_ifcs_all_outfile(arg_list[-1])
            arg_list = arg_list[:-1]

        if len(arg_list) < 3:
            raise ValueError(
                "Invalid command: too few arguments "
                "(expected: debug ifcs <api_name> ...)")

        ifcsObjs = IfcsAll(self.cli)
        api_class = arg_list[2]  # token after "debug ifcs"

        if api_class == 'snapshot' and len(arg_list) > 3:
            raise ValueError(
                "Invalid command: snapshot does not accept additional "
                "arguments")

        # Derive dispatch from token count. arg_list is always
        # [debug, ifcs, <api_name>, ...].
        #
        # 4 tokens — one of:
        #   debug ifcs <api_name> <id>   single-object dump
        #   debug ifcs <api_name> mod      module-level dump
        #   debug ifcs <api_name> stats    invalid (missing <id>)
        #
        # 5 tokens — debug ifcs <api_name> <id> stats
        if len(arg_list) == 4:
            if arg_list[-1] in ('stats', 'mod'):
                dispatch = arg_list[-1]
            else:
                dispatch = arg_list[-2]          # <api_name>
        else:
            dispatch = arg_list[-1]

        obj_names = ifcsObjs.get_ifcs_obj_names()

        if (len(arg_list) > 2) and ((api_class not in obj_names) and (api_class != "all" and api_class != "snapshot")):
            raise ValueError(
                "Invalid command: unknown api_name '{}'".format(api_class))

        if dispatch == 'stats':
            if len(arg_list) != 5:
                raise ValueError(
                    "Invalid command: stats requires object id "
                    "(debug ifcs <api_name> <id> stats)")
            if api_class not in obj_names:
                raise ValueError(
                    "Invalid command: stats requires a valid api_name "
                    "(debug ifcs <api_name> <id> stats)")
            try:
                int(arg_list[3], 0)
            except ValueError:
                raise ValueError("Invalid object id: {}".format(arg_list[3]))
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(api_class)
            if ifcs_obj is None or not hasattr(ifcs_obj, 'stats_get'):
                raise ValueError(
                    "Invalid command: '{}' does not support stats "
                    "(debug ifcs <api_name> <id> stats)".format(api_class))

        # Reject stray tokens (e.g. debug ifcs <api_name> <bad>).
        if dispatch != 'stats' and dispatch != api_class and dispatch != 'mod':
            raise ValueError(
                "Invalid command: unrecognized token '{}'".format(dispatch))

        # Single-object dump: debug ifcs <api_name> <id>
        if (len(arg_list) == 4 and arg_list[-1] not in ('mod', 'stats')
                and api_class in obj_names):
            try:
                int(arg_list[3], 0)
            except ValueError:
                raise ValueError("Invalid object id: {}".format(arg_list[3]))

        return

    def parse_ifcs_args(self, args):
        # split the args
        arg_list = args.split()

        if (arg_list[-2] == 'all' and len(arg_list) > 3
                and arg_list[-1] not in ('stats', 'mod')):
            self._validate_ifcs_all_outfile(arg_list[-1])
            arg_list = arg_list[:-1]

        # get the last arg
        last_arg = arg_list[-1]

        if last_arg == 'all' or last_arg == 'snapshot':
            dispatch = last_arg
        elif last_arg == 'stats':
            dispatch = last_arg
        else:
            dispatch = 'modules'

        return dispatch, args

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in debug [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except (ValueError):
            log_dbg(
                1, "ValueError in debug [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except BaseException:
            log_dbg(
                1, "OtherError in debug [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        elif remline == text:
            if 'ifcs' == cmd.rstrip():
                return self.complete_ifcs(cmd, remline, line, text)
            elif 'device' == cmd.rstrip():
                return [
                    j for j in self.sub_device_cmds.keys() if j.startswith(text)]
            elif 'cli' == cmd.rstrip():
                return [
                    j for j in self.sub_cli_cmds.keys() if j.startswith(text)]
            else:
                return None
        else:
            try:
                return getattr(
                    self,
                    'complete_' +
                    cmd)(
                    cmd,
                    remline,
                    line,
                    text)
            except AttributeError:
                return None

    def complete_device(self, cmd, remline, line, text):
        if remline == 'decode':
            return [i.lower() for i in self.sub_device_decode_cmds.keys()]
        elif remline == 'restore':
            return [i.lower() for i in self.sub_device_restore_cmds.keys()]
        elif remline in self.sub_device_cmds.keys():
            log('Text = ' + text)
            return [i.lower()
                    for i in ['-ib', '-comp'] if i.lower().startswith(text)]
        elif remline.split()[1] in self.sub_device_cmds.keys():
            return [i.lower()
                    for i in ['-ib', '-comp'] if i.lower().startswith(text)]
        else:
            return [i.lower() for i in self.sub_device_cmds.keys()
                    if i.lower().startswith(text)]

    def complete_ifcs(self, cmd, remline, line, text):
        # Tab completion for "debug ifcs ...".
        #
        # remline: tokens after "ifcs" (e.g. "l2vni 32768" for
        #          "debug ifcs l2vni 32768")
        # text:    partial token being completed (empty when user
        #          typed a trailing space before TAB)
        #
        # Returns literal command tokens only (no instance id lookup).
        # Object ids and file paths must be typed manually.
        # Grammar mirrors ifcs_help_str:
        #   debug ifcs all [<file>]
        #   debug ifcs snapshot
        #   debug ifcs <api_name> [<id_or_handle>] [stats]
        #   debug ifcs <api_name> mod

        IFCS_COMPLETE_TOP = ['all', 'snapshot']
        IFCS_COMPLETE_MOD = ['mod']
        IFCS_COMPLETE_STATS = ['stats']

        ifcsObjs = IfcsAll(self.cli)
        obj_names = [n.lower() for n in ifcsObjs.get_ifcs_obj_names()]
        top_level = IFCS_COMPLETE_TOP + obj_names

        args = shlex.split(remline) if remline else []
        text_l = text.lower() if text else ''

        def filtered(options):
            return [o for o in options if o.startswith(text_l)]

        # Level 1: "debug ifcs <TAB>" or "debug ifcs l2<TAB>"
        if not args or (len(args) == 1 and args[0] == text):
            return filtered(top_level)

        api = args[0].lower()

        # "debug ifcs snapshot" — terminal, no further tokens
        if api == 'snapshot':
            return []

        # "debug ifcs all [<file>]" — path must be typed manually
        if api == 'all':
            return []

        if api not in obj_names:
            return []

        # "debug ifcs <api_name> <TAB>" — offer mod only
        if len(args) == 1:
            return filtered(IFCS_COMPLETE_MOD)

        # "debug ifcs <api_name> <second-token>"
        if len(args) == 2:
            if args[1] == 'mod':
                # "debug ifcs <api_name> mod" — terminal
                return []
            if args[1] == text:
                # Still typing second token (e.g. "m" for mod)
                return filtered(IFCS_COMPLETE_MOD)
            # Id complete (trailing space): "debug ifcs l2vni 32768 <TAB>"
            return filtered(IFCS_COMPLETE_STATS)

        # "debug ifcs <api_name> <id> st<TAB>"
        if len(args) == 3 and args[2] == text:
            return filtered(IFCS_COMPLETE_STATS)

        return []

    def complete_cli(self, cmd, remline, line, text):
        if remline in self.sub_cli_cmds:
            return compat_listkeys(self.sub_cli_cmds[remline])
        parts = remline.split()
        if len(parts) == 2 and parts[0] in self.sub_cli_cmds and text:
            return [i for i in self.sub_cli_cmds[parts[0]].keys()
                    if i.startswith(text)]
        return None

    def debug_snapshot(self, args):
        log('Generating ifcs state dump. This might take a while..')
        ifcs_ctypes.im_nmgr_wb_snapshot(self.cli.node_id)
        wb_file = os.environ.get('IFCS_WB_FILE', 'wb.dump.json')
        log('Saved IFCS State to ' + wb_file)
        try:
            debug_encode([], [])
        except MemoryError as me:
            log_err("Out of memory : {}".format(sys.exc_info()))
        except Exception as e:
            log_err("Error occurred : {}".format(sys.exc_info()))


    def get_stats_dict_from_stats(self, ifcs_obj, obj):
        stats     = {}
        stats_list = ifcs_obj.stats_get(obj)
        # Decode the stat ids into stat names
        for stat_id in range(len(stats_list)):
            stats[ifcs_obj.statslist[stat_id].lower()] = int(
                stats_list[stat_id])
        return stats

    def debug_all_ifcs(self, args):
        log('Generating ifcs state dump. This might take a while..')

        outfile = ''
        arg_list = args.split()

        if arg_list[-2] == 'all' and len(arg_list) > 3:
            outfile = arg_list[-1]
            arg_list = arg_list[:-1]
            args = ' '.join(arg_list)

        arg_split = args.split()
        arg_split.append('mod')
        args = ' '.join(arg_split)
        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            api_state = {}
            mod_state = {}
            state     = []
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                mod_state['module']  = ifcs_obj.getAllIfcsState(args)
            except:
                mod_state['module']  = {}
            state.append(mod_state)
            try:
                count = 0
                rc, all_objs = getattr(ifcs_obj, 'bulk_get_all_'+name+'_keys')()
                for count, obj in enumerate(all_objs):
                    obj_state = OrderedDict()
                    obj_state[name] = count
                    try:
                        obj_state['attributes'] = json.loads(ifcs_obj.getIfcsState(obj))
                    except:
                        obj_state['attributes'] = {}
                    try:
                        obj_state['stats'] = self.get_stats_dict_from_stats(ifcs_obj, obj)
                    except:
                        obj_state['stats'] = {}
                    state.append(obj_state)
            except Exception as e:
                exp_msg = "{}".format(e)
                if 'no attribute' in exp_msg:
                    obj_state = {}
                    obj_state['attributes'] = {}
                    obj_state['stats'] = {}
                    state.append(obj_state)
                else:
                    log_err(exp_msg)
                    return

            # Fill up the object
            api_state[name.capitalize()] = state
            all_state.append(api_state)

        if outfile:
            log('..Writing ifcs state dump to ' + outfile)
            with open(outfile, 'w') as f:
                f.write(json.dumps(all_state, indent=4, sort_keys=True))
                f.flush()
                f.close()
        log(json.dumps(all_state, indent=4, sort_keys=True))
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_statlist_ifcs(self, args):

        # fetch ifcs all object
        arg_list     = args.split()
        ifcsObjs     = IfcsAll(self.cli)
        all_stats    = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        object_name  = arg_list[2]
        object_id    = int(arg_list[3], 0)
        OBJ_NAME     = object_name.upper()

        # find the object in question
        for name in ifcsObjNames:
            if name.lower() != object_name:
                continue

            # found the object
            obj_state     = {}
            stats         = {}
            ifcs_obj      = ifcsObjs.get_ifcs_obj_from_name(name)
            handle_ctor = getattr(ifcs_ctypes, 'IFCS_HANDLE_%s' % OBJ_NAME, None)
            if handle_ctor is not None:
                object_key = handle_ctor(object_id)
            else:
                object_key = object_id
            try:
                stats_list = ifcs_obj.stats_get(object_key)
            except Exception as e:
                log_err(
                    "Failed to get stats for {} {}".format(
                        object_name, object_id))
                log_dbg(
                    1, "stats_get failed for {} {}: {}".format(
                        object_name, object_id, e))
                raise ValueError(
                    "Failed to get stats for {} {}".format(
                        object_name, object_id))

            # Decode the stat ids into stat names
            for stat_id in range(len(stats_list)):
                stats[ifcs_obj.statslist[stat_id].lower()] = int(
                    stats_list[stat_id])

            # Fill up the object
            if handle_ctor is not None:
                obj_state[name.capitalize()] = hex(object_key)
            else:
                obj_state[name.capitalize()] = object_key
            obj_state['Stats']           = stats
            all_stats.append(obj_state)

        log(json.dumps(all_stats, indent=4, sort_keys=True))
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_modlist_ifcs(self, args):
        log('Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        arg_list = args.split()
        api_name = arg_list[2].lower() if len(arg_list) > 2 else ''

        for name in ifcsObjNames:
            if name.lower() != api_name:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                exp_msg = "{}".format(e)
                if 'no attribute' in exp_msg:
                    state = ''
                else:
                    log_err(exp_msg)
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        log(json.dumps(all_state, indent=4, sort_keys=True))
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_ifcs(self, args):
        log_dbg(1, "Debugging ifcs state ..")

        # check if api log is enabled. If so, bail
        if (self.is_api_log_enabled()):
            log("Please disable API logging and try again. Set IFCS_NODE_ATTR_API_LOG_ENABLE to FALSE..")
            log("Use cli 'ifcs set node api_log_enable 0' to disable API logging")
            return

        # setup the cmd dispatch dictionary
        dispatch_cmds = {
            'snapshot'  : self.debug_snapshot,
            'all'       : self.debug_all_ifcs,
            'modules'   : self.debug_modlist_ifcs,
            'stats'     : self.debug_statlist_ifcs,
        }

        # validate args
        try:
            self.validate_ifcs_args(args)
        except Exception as e:
            log_err("{}".format(e))
            # Re-raise so the caller also displays help.
            raise

        # parse the args
        try:
            dispatch, args = self.parse_ifcs_args(args)
        except Exception as e:
            log_err("{}".format(e))
            # Re-raise so the caller also displays help.
            raise

        # dispatch the command
        dispatch_cmds[dispatch](args)

    def debug_device(self, args):
        log_dbg(1, "Debugging device state ..")

        # check if api log is enabled. If so, bail
        if (self.is_api_log_enabled()):
            log("Please disable API logging and try again. Set IFCS_NODE_ATTR_API_LOG_ENABLE to FALSE..")
            log("Use cli 'ifcs set node api_log_enable 0' to disable API logging")
            return

        arg_list = args.split()

        if arg_list[2] not in self.sub_device_cmds.keys():
            log_err("Invalid command")
            return ifcs_ctypes.IFCS_INVAL

        self.sub_device_cmds[arg_list[2]](args)
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_device_pen(self, args):
        log_dbg(1, "Debugging pen state..")
        """
            debug device pen -ib <ib-id> -comp <cmp-id>
            or
            debug device pen -ib <ib-id>
            or
            debug device pen -comp <cmp-id>
            or
            debug device pen
        """
        arg_list = args.split()

        if arg_list[2] != 'pen':
            log_err("Invalid command")
            return ifcs_ctypes.IFCS_INVAL

        parser = argparse.ArgumentParser(prog="debug")
        parser.add_argument("group")
        parser.add_argument("cmd")
        parser.add_argument("obj")

        ib_id = []
        if '-ib' in arg_list:
            parser.add_argument("-ib", nargs="+", type=int)

        cmp_id = []
        if '-comp' in arg_list:
            parser.add_argument("-comp", nargs="+", type=int)

        if 'internal' in arg_list:
            parser.add_argument("internal")
        parsed_res = parser.parse_args(arg_list)

        try:
            ib_id = parsed_res.ib
        except BaseException:
            pass

        try:
            cmp_id = parsed_res.comp
        except BaseException:
            pass

        try:
            if parsed_res.internal:
                debug_internal(cmp_id, ib_id)
                return
        except Exception as e:
            pass

        try:
            debug_encode(cmp_id, ib_id)
        except MemoryError as me:
            log_err("Out of memory : {}".format(sys.exc_info()))
        except Exception as e:
            log_err("Error occurred : {}".format(sys.exc_info()))
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_device_event(self, args):
        log_dbg(1, "Debug device event..")

        try:
            obj = args.split()[3]
        except BaseException:
            log_err("Invalid command")
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL

        if obj not in self.sub_device_event_cmds.keys():
            log_err("Invalid command")
            return ifcs_ctypes.IFCS_INVAL

        self.sub_device_event_cmds[obj](args)
        return ifcs_ctypes.IFCS_SUCCESS

    def device_event_pic_intr(self, args):
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            arglist = shlex.split(args)
            return pic_intr_event.run_cmd(arglist[4:])
        else:
            log("Command not valid for chip type!")
            return ifcs_ctypes.IFCS_INVAL
        return ifcs_ctypes.IFCS_SUCCESS

    def is_api_log_enabled(self):

        attr = (1 * ifcs_ctypes.ifcs_attr_t)()
        count = c_uint32()
        attr[0].id = ifcs_ctypes.IFCS_NODE_ATTR_API_LOG_ENABLE

        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t),
                                   pointer(count))
        if (rc != ifcs_ctypes.IFCS_SUCCESS) or (count.value <= 0):
            log_err("Failed to get node attr IFCS_NODE_ATTR_API_LOG_ENABLE")
            return False

        if (attr[0].value.data == ifcs_ctypes.IFCS_BOOL_TRUE):
            return True
        else:
            return False

        return False

 

    def debug_cli(self, args):
        log_dbg(1, "Debugging cli state ..")

        arg_list = args.split()
        sub_cmds = self.sub_cli_cmds
        for idx in range(2, len(arg_list)):
            if arg_list[idx] not in sub_cmds:
                log_err("Invalid command")
                return ifcs_ctypes.IFCS_INVAL
            if isinstance(sub_cmds[arg_list[idx]], dict):
                sub_cmds = sub_cmds[arg_list[idx]]
            else:
                return sub_cmds[arg_list[idx]](args)
        log_err("Invalid command")
        return ifcs_ctypes.IFCS_INVAL

    def debug_cli_show_summary(self, args):
        log_dbg(1, "Debugging cli show summary ..")
        self.cli.handle_debug_cli_show_summary()
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_cli_clear_counters(self, args):
        log_dbg(1, "Debugging cli clear counters ..")
        self.cli.handle_debug_cli_clear_counters()
        return ifcs_ctypes.IFCS_SUCCESS

 

    #=========================================================
    # Extensive help
    #=========================================================

    ifcs_help_str = """
              Usage::
                    debug ifcs all [<file>]
                    debug ifcs snapshot
                    debug ifcs <api_name>
                    debug ifcs <api_name> <id_or_handle>
                    debug ifcs <api_name> <id_or_handle> stats
                    debug ifcs <api_name> mod

              Description:
                    Dumps IFCS internal state or statistics in JSON format.
                    Use for troubleshooting. Full dumps may take a while.

              Command Options:
                    all [<file>]                   - Dump all IFCS object types.
                                                     Optional <file> also writes JSON to
                                                     that path; output is still printed
                                                     to the screen.
                    snapshot                       - Save IFCS warm-boot snapshot.
                    <api_name>                     - Dump all instances of one object
                                                     type (e.g. nexthop, route_entry).
                    <api_name> <id_or_handle>      - Dump one object by numeric id or
                                                     handle (e.g. nexthop 20480, ecmp 100).
                                                     Not supported for composite-key
                                                     objects (e.g. route_entry).
                    <api_name> <id_or_handle> stats - Dump statistics for one object
                                                     only (id or handle is required).
                    <api_name> mod                 - Dump module-level state for the
                                                     object type (not per-instance).

              Examples:
                    debug ifcs nexthop
                    debug ifcs nexthop 20480
                    debug ifcs ecmp 100
                    debug ifcs nexthop 20480 stats
                    debug ifcs devport 3 stats
                    debug ifcs all /tmp/ifcs_dump.json
    """
    cli_help_str = """
              Usage::
                    debug cli [show summary] [clear counters]
              Command Options:
                    [show summary]                 - CLI shell server information for troubleshooting
                    [clear counters]               - CLI shell server counters used for troubleshooting
    """
    device_help_str = """
              Usage::
                    debug device pen
                    debug device event
              Command Options:
                    pen                            - Pen related debug dump
                    event                          - Device event related commands
    """
    pen_help_str = """
              Usage::
                    debug device pen [-ib <ib list>] [-comp <comp-id list>]
              Command Options:
                    -ib                            - Indicates IB numbers follow
                    <ib list>                      - Single space delimited IB numbers e.g. -ib 0 1
                    -comp                          - Indicates component Id numbers follow
                    <comp-id list>                 - Single space delimited comp Id numbers e.g. -comp 1 3
                                                     Valid values are 1, 3, 5, 6, 7, 8, 16
    """
    default_help_str = """
              Usage:
                   debug ifcs all
                   debug ifcs all <file>
                   debug ifcs snapshot
                   debug ifcs <api_name>
                   debug ifcs <api_name> <id_or_handle>
                   debug ifcs <api_name> <id_or_handle> stats
                   debug ifcs <api_name> mod
                   debug cli show summary
                   debug cli clear counters
                   debug device pen
                   debug device pen -ib <ib list>
                   debug device pen -comp <compId list>
                   debug device pen -ib <ib list> -comp <comp-id list>
                   debug device pen -comp <comp-id list> -ib <ib list>
                   debug device event
                   debug device event pic_intr
    """


    def help(self, args):
        self.help_menu = {
            'ifcs': self.ifcs_help_str,
            'cli':  self.cli_help_str,
            #ifndef 
            'device': self.device_help_str,
            'pen': self.pen_help_str,
            'help': self.default_help_str,
            '?': self.default_help_str,
            #else
            'device': self.device_help_internal_str,
            'pen': self.pen_help_str,
            'decode': self.decode_help_internal_str,
            'decode-pen': self.decodepen_help_internal_str,
            'tprof': self.tprof_help_internal_str,
            'tprof-show': self.tprof_show_help_internal_str,
            'tprof-clear': self.tprof_clear_help_internal_str,
            'help': self.default_help_internal_str,
            '?': self.default_help_internal_str,
            #endif
        }
        arg_list = shlex.split(args)



        if len(arg_list) >= 2:
            if arg_list[-1] in {'help', '?'}:
                if arg_list[-2] in self.help_menu:
                    log(self.help_menu[arg_list[-2]])
                    return

        log(self.help_menu['help'])

        return
