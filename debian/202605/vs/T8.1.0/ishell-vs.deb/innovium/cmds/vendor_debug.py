
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import sys
import argparse
import itertools
import time
import json
from utils.log_utils import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.all import *
from ifcs_cmds.cli_types import *
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

# Class implements Debug state dump related commands


class DebugParser(Command):
    def __init__(self, cli):
        self.cli = cli
        self.arg_list = []
        super(DebugParser, self).__init__()

        self.sub_cmds = {
            'ifcs': self.debug_ifcs,
            'help': self.help,
            '?': self.help
        }

        # IFCS modules supported by debugparser (aligned with test YAMLs).
        self.ifcs_modules = [
            'nexthop', 'intf', 'ecc', 'l2_entry', 'route_entry',
            'devport', 'ecmp', 'lag', 'sysport', 'l2vni'
        ]
        self.help_tokens = ['help', '?']

        # Define route_entry filters for tab completion
        self.route_entry_filters = [
            'v4_host', 'v4_prefix', 'v6_host', 'v6_prefix',
            'v4_fallback', 'v6_fallback', 'srp1', 'srp2',
            'tcam_slots', 'sram_slots', 'v4_tcam_slots_narrow',
            'v6_tcam_slots_narrow', 'tcam_slots_wide',
            'v4_tcam_slots_fallback_narrow', 'v6_tcam_slots_fallback_narrow',
            'v6_tcam_slots_fallback_wide', 'sram_slots_narrow',
            'sram_slots_wide', 'sram_buckets_narrow', 'sram_buckets_wide',
            'usage', 'help', '?'
        ]

        # Define which modules support 'usage' subcommand
        self.modules_with_usage = ['nexthop', 'intf', 'ecmp', 'route_entry']

        # Define modules that support 'counters' subcommand
        self.modules_with_counters = ['devport']

        # ECMP subcommands
        self.ecmp_subcmds = ['usage', 'members', 'help', '?']

        self.show_debug_names = ['']

    def __del__(self):
        return

    def subcomplete(self, text, remline):
        """Handle tab completion for debugparser command"""
        from utils.compat_util import compat_listkeys

        cmd, remline, line = self.cli.parseline(remline)

        # Level 1: debugparser <TAB> - show top level commands
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            # User is still typing the first command: debugparser i<TAB>
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        # If cmd is not 'ifcs', we're done
        if cmd != 'ifcs':
            return []

        # Now we know cmd == 'ifcs', parse the rest
        # Split remaining line to see what module they're working with
        args = shlex.split(remline) if remline else []

        # Level 2: debugparser ifcs <TAB> - show available modules
        if len(args) == 0:
            # remline was empty or just whitespace after 'ifcs'
            return self.ifcs_modules + self.help_tokens
        elif len(args) == 1 and args[0] == text:
            # User is typing module name: debugparser ifcs ro<TAB>
            return [m for m in (self.ifcs_modules + self.help_tokens) if m.startswith(text)]

        # Level 3+: We have a module, handle module-specific completions
        if len(args) >= 1:
            module = args[0]

            # debugparser ifcs route_entry <TAB>
            if module == 'route_entry':
                if len(args) == 1:
                    # Just after module name: debugparser ifcs route_entry <TAB>
                    return self.route_entry_filters
                elif len(args) == 2 and args[1] == text:
                    # Typing filter: debugparser ifcs route_entry v<TAB>
                    return [f for f in self.route_entry_filters if f.startswith(text)]
                elif len(args) == 2 and args[1] == 'usage':
                    # debugparser ifcs route_entry usage <TAB> - show filter options
                    filter_options = [f for f in self.route_entry_filters if f not in ['usage', 'help', '?']]
                    return filter_options
                elif len(args) == 3 and args[1] == 'usage':
                    # debugparser ifcs route_entry usage v4<TAB> - filter by text
                    filter_options = [f for f in self.route_entry_filters if f not in ['usage', 'help', '?']]
                    return [f for f in filter_options if f.startswith(text)]
                elif len(args) == 2 and args[1] in self.route_entry_filters:
                    # After a valid filter: debugparser ifcs route_entry v4_host <TAB>
                    return ['usage', 'help', '?']
                elif len(args) == 3:
                    # Typing after filter: debugparser ifcs route_entry v4_host u<TAB>
                    return [opt for opt in ['usage', 'help', '?'] if opt.startswith(text)]

            # debugparser ifcs devport <TAB>
            elif module == 'devport':
                if len(args) == 1:
                    return ['counters', 'help', '?']
                elif len(args) == 2:
                    return [opt for opt in ['counters', 'help', '?'] if opt.startswith(text)]

            # debugparser ifcs ecmp <TAB>
            elif module == 'ecmp':
                if len(args) == 1:
                    return self.ecmp_subcmds
                elif len(args) == 2 and args[1] == text:
                    return [opt for opt in self.ecmp_subcmds if opt.startswith(text)]
                elif len(args) == 2 and args[1] == 'members':
                    # debugparser ifcs ecmp members <TAB>
                    return ['usage', 'help', '?']
                elif len(args) == 3 and args[1] == 'members':
                    return [opt for opt in ['usage', 'help', '?'] if opt.startswith(text)]

            # debugparser ifcs <module> <TAB> for modules with usage
            elif module in self.modules_with_usage:
                if len(args) == 1:
                    return ['usage', 'help', '?']
                elif len(args) == 2:
                    return [opt for opt in ['usage', 'help', '?'] if opt.startswith(text)]

            # Other modules that don't have subcommands
            elif module in self.ifcs_modules:
                if len(args) == 1:
                    return ['help', '?']
                elif len(args) == 2:
                    return [opt for opt in ['help', '?'] if opt.startswith(text)]

        return []

    def run_cmd(self, args):
        log_dbg(1, "In Ifcs run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in debugparser [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except (ValueError):
            log_dbg(
                1, "ValueError in debugparser [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        except Exception:
            log_dbg(
                1, "OtherError in debugparser [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL


    def debug_all_ifcs(self, args):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        test_run_id = time.strftime("%b_%d_%Y_%H%M%S", time.localtime())
        fileName = os.environ['HOME'] + '/ifcsDump_' + str(test_run_id) + '.p'
        try:
            fh = open(fileName, 'wb')
        except Exception as e:
            log_dbg(1, "File open error (", e, "): " + str(fileName))
            return

        log_dbg(1, "Writing to file " + fileName + "...")
        fh.write(json.dumps(all_state,indent=4))
        fh.close()
        return ifcs_ctypes.IFCS_SUCCESS

    def debug_modlist_ifcs(self, args, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)

    def debug_modlist_lag_ifcs(self, args, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        for entry in all_state[0]["Lag"]:
            entry['obj.handle_value'] = ifcs_ctypes.IFCS_HANDLE_VALUE(entry['obj.handle'])

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_ecmp_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                rc, state = ifcs_obj.bulk_get_all_ecmp_keys()
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        ecmp_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["Ecmp"]:
            reqd_dict = {}

            reqd_dict['ecmp_mbr_list'] = []
            reqd_dict['ecmp_id'] = ifcs_ctypes.IFCS_HANDLE_VALUE(entry)
            arr = ifcs_obj.getMembers(entry)
            for mbr in arr:
                reqd_dict['ecmp_mbr_list'].append(ifcs_ctypes.IFCS_HANDLE_VALUE(mbr))

            reqd_obj_list.append(reqd_dict)
        ecmp_dict['Ecmp'] = reqd_obj_list

        # printing for remote cli to capture stdout
        log(json.dumps(ecmp_dict,indent=4))
        return json.dumps(ecmp_dict,indent=4)


    def debug_modlist_devport_ifcs(self, args, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        devport_obj = None
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            if ifcs_obj is None:
                log_err("Failed to get ifcs object from name: {}".format(name))
                continue
            try:
                state = ifcs_obj.getAllIfcsState(args)
            except AttributeError as e:
                log_dbg(1, "Get all ifcs state for {} raised attribute error: {}".format(name, str(e)))
                state = []
            except Exception as e:
                log_err("Failed to get all ifcs state for {}: {}".format(name, str(e)))
                return ifcs_ctypes.IFCS_INVAL
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)
            if name.lower() == 'devport':
                devport_obj = ifcs_obj

        if devport_obj is not None:
            for obj_state in all_state:
                if 'Devport' not in obj_state:
                    continue
                ifcs_obj = devport_obj
                devports = obj_state['Devport']
                if not isinstance(devports, list):
                    continue
                for entry in devports:
                    if 'speed' in entry:
                        entry['speed'] = ifcs_obj.enum_to_str('speed', entry['speed'])
                    if 'fec_mode' in entry:
                        entry['fec_mode'] = ifcs_obj.enum_to_str('fec_mode', entry['fec_mode'])
                    if 'link_status' in entry:
                        entry['link_status'] = ifcs_obj.enum_to_str('link_status', entry['link_status'])
                    if 'loopback' in entry:
                        entry['loopback'] = ifcs_obj.enum_to_str('loopback', entry['loopback'])
                    if 'type' in entry:
                        entry['intf_type'] = ifcs_obj.enum_to_str('type', entry['type'])

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)

    def debug_modlist_devport_counters_ifcs(self, modules):
        log_dbg(1,'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            state = []
            try:
                rc, all_devport = ifcs_obj.bulk_get_all_devport_keys()
                for devport in all_devport:
                    statsList = {}
                    output = ifcs_obj.stats_get(devport)
                    statsList['hw_port'] = devport

                    statsList['rx_octets'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
                    statsList['rx_uc_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_UNICAST]
                    statsList['rx_mc_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_MULTICAST]
                    statsList['rx_bc_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_BROADCAST]
                    statsList['rx_mac_ctrl'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_PFC]
                    statsList['rx_drop_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_DROP]
                    statsList['rx_err_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]

                    statsList['tx_octets'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
                    statsList['tx_uc_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_UNICAST]
                    statsList['tx_mc_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_MULTICAST]
                    statsList['tx_bc_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_BROADCAST]
                    statsList['tx_mac_ctrl'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_PFC]
                    statsList['tx_drop_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_DROP]
                    statsList['tx_err_pkts'] = output[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

                    state.append(statsList)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state['DevportStats'] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_ifcs_usage(self, modules, showall=False):
        log_dbg(1, 'Generating ifcs usage state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                if name.lower() == 'nexthop':
                    output = ifcs_obj.getNexthopUsage()
                elif name.lower() == 'intf':
                    output = ifcs_obj.getIntfUsage()
                elif name.lower() == 'ecmp':
                    if 'members' in modules:
                        output = ifcs_ctypes.ifcs_usage_t()
                        ifcs_ctypes.ifcs_usage_t_init(pointer(output))
                        rc = ifcs_ctypes.ifcs_ecmp_member_usage_get(self.cli.node_id,
                                                        0,
                                                        0,
                                                        None,
                                                        pointer(output))
                        name = name + '_members'
                    else:
                        output = ifcs_obj.getEcmpUsage()
                elif name.lower() == 'route_entry':
                    state = OrderedDict()
                    output = ifcs_ctypes.ifcs_usage_t()
                    ifcs_ctypes.ifcs_usage_t_init(pointer(output))
                    attr = ifcs_ctypes.ifcs_attr_t()
                    ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)

                    route_filter = ''
                    route_entry_filters = ['v4_host', 'v4_prefix', 'v6_host', 'v6_prefix', 'v4_fallback', 'v6_fallback', \
                                           'srp1', 'srp2', 'tcam_slots', 'sram_slots', 'v4_tcam_slots_narrow', \
                                           'v6_tcam_slots_narrow', 'tcam_slots_wide', 'v4_tcam_slots_fallback_narrow', \
                                           'v6_tcam_slots_fallback_narrow', 'v6_tcam_slots_fallback_wide', \
                                           'sram_slots_narrow', 'sram_slots_wide', 'sram_buckets_narrow', \
                                           'sram_buckets_wide']
                    for val in route_entry_filters:
                        if val in modules:
                            route_filter = val
                            break

                    # Form the route key
                    ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
                    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
                    if route_filter == 'v4_host':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST)
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                    elif route_filter == 'v4_prefix':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX)
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                    elif route_filter == 'v6_host':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST)
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                    elif route_filter == 'v6_prefix':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX)
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                    elif route_filter == 'tcam_slots':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IM_USAGE_GET_TYPE_PREFIX_TCAM_SLOTS)
                    elif route_filter == 'sram_slots':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IM_USAGE_GET_TYPE_PREFIX_SRAM_SLOTS)
                    elif route_filter == 'srp2':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP2)
                    elif route_filter == 'srp1':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP1)
                    elif route_filter in ['v4_fallback', 'v6_fallback'] :
                        # Do nothing. See below.
                        pass
                    elif route_filter in ['v4_tcam_slots_narrow', 'v6_tcam_slots_narrow']:
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_NARROW)
                    elif route_filter == 'tcam_slots_wide':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_WIDE)
                    elif route_filter == 'v4_tcam_slots_fallback_narrow':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_NARROW)
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                    elif route_filter == 'v6_tcam_slots_fallback_narrow':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_NARROW)
                    elif route_filter == 'v6_tcam_slots_fallback_wide':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_WIDE)
                    elif route_filter == 'sram_slots_narrow':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_SLOTS_NARROW)
                    elif route_filter == 'sram_slots_wide':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_SLOTS_WIDE)
                    elif route_filter == 'sram_buckets_narrow':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_BUCKETS_NARROW)
                    elif route_filter == 'sram_buckets_wide':
                        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_BUCKETS_WIDE)
                    elif len(modules) == 2:
                        # This is the case where no filter is passed
                        json_dump=[]
                        route_entry_filters = ['v4_host', 'v4_prefix', 'v6_host', 'v6_prefix', 'v4_fallback', 'v6_fallback', \
                                               'srp1', 'srp2', 'tcam_slots', 'sram_slots', 'v4_tcam_slots_narrow', \
                                               'v6_tcam_slots_narrow', 'tcam_slots_wide', 'v4_tcam_slots_fallback_narrow', \
                                               'v6_tcam_slots_fallback_narrow', 'v6_tcam_slots_fallback_wide', \
                                               'sram_slots_narrow', 'sram_slots_wide', 'sram_buckets_narrow', \
                                               'sram_buckets_wide']

                        for route_filter in route_entry_filters:
                            json_output = self.debug_modlist_ifcs_usage(['route_entry', route_filter], True)
                            if json_output != None:
                                json_dump.append(json_output[0]['Route_entry'])

                        tmp = {}
                        tmp[name.capitalize()] = json_dump
                        log(json.dumps(tmp,indent=4))
                        return json.dumps(tmp,indent=4)
                    else:
                        self.debug_error(modules)
                        return

                    # As of now fallback routes donot have a v4 or v6 bifurcation as yet even though we allow the filter
                    # to be provided in the command. So we donot pass any filter in the usage command.
                    # In case we start segregating fallback routes for v6 as well, we would need to set the address family
                    # for what ever is in the filter (modules).

                    state['type'] = route_filter
                    route_key = ifcs_ctypes.ifcs_route_entry_key_t()
                    ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_key))
                    if 'v4_fallback' in modules or 'v6_fallback' in modules:
                        if 'v4_fallback' in modules:
                            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                        else:
                            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
                        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
                        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))


                        rc = ifcs_ctypes.ifcs_route_entry_usage_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        0,
                                                        None,
                                                        pointer(output))
                    elif 'tcam_slots' in modules or 'sram_slots' in modules:
                        for addr_family in [ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6]:
                            ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), addr_family)
                            ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                            ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
                            ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))

                            rc = ifcs_ctypes.ifcs_route_entry_usage_get(self.cli.node_id,
                                                            pointer(route_key),
                                                            1,
                                                            pointer(attr),
                                                            pointer(output))
                            usage_dict_key = 'v4_curr' if addr_family is ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4 else 'v6_curr'
                            state[usage_dict_key] = output.current
                    elif 'v4_tcam_slots_narrow' in modules:
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
                        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))

                        rc = ifcs_ctypes.ifcs_route_entry_usage_detail_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        1,
                                                        pointer(attr),
                                                        pointer(output))
                    elif route_filter in ['v6_tcam_slots_narrow', 'tcam_slots_wide']:
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
                        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))

                        rc = ifcs_ctypes.ifcs_route_entry_usage_detail_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        1,
                                                        pointer(attr),
                                                        pointer(output))
                    elif route_filter in ['v4_tcam_slots_fallback_narrow', 'sram_slots_narrow', \
                                          'sram_slots_wide', 'sram_buckets_narrow', 'sram_buckets_wide']:
                        # Note: Adddress family is set for v4_tcam_slots_fallback_narrow only. Other filters
                        # in this block do not need address family to be set.
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
                        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
                        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
                        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))

                        rc = ifcs_ctypes.ifcs_route_entry_usage_detail_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        1,
                                                        pointer(attr),
                                                        pointer(output))
                    elif route_filter in ['v6_tcam_slots_fallback_narrow', 'v6_tcam_slots_fallback_wide']:
                        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)
                        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
                        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
                        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))

                        rc = ifcs_ctypes.ifcs_route_entry_usage_detail_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        1,
                                                        pointer(attr),
                                                        pointer(output))
                    else:
                        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
                        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
                        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))

                        rc = ifcs_ctypes.ifcs_route_entry_usage_get(self.cli.node_id,
                                                        pointer(route_key),
                                                        1,
                                                        pointer(attr),
                                                        pointer(output))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err(
                            "Failed to get all {0} route_entry rc: {1}".format(filter_option,
                                convert_error_code_to_string(rc)))
                        return

                current_usage = output.current
                max_usage = output.max

                # For tcam_slots & sram_slots, we fill v4_curr and v6_curr above already.
                if 'tcam_slots' not in modules and 'sram_slots' not in modules:
                    state['curr'] = current_usage
                state['max'] = max_usage
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return

            if state['max'] == 0 and showall == True:
                return None

            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        # printing for remote cli to capture stdout
        if showall == True:
            return all_state
        else:
            log(json.dumps(all_state,indent=4))
            return json.dumps(all_state,indent=4)


    def debug_modlist_nexthop_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                rc, state = ifcs_obj.bulk_get_all_nexthop_keys()
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = state
            all_state.append(obj_state)

        nexthop_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["Nexthop"]:
            try:
                intf_val = ifcs_obj.getIntf(entry, True)
                local_destination_val = ifcs_obj.getLocalDestination(entry, True)
                dest_mac_val = ifcs_obj.getDestMac(entry, True)
                dest_ip_val = ifcs_obj.getDestIp(entry, True)
                no_decrement_ttl_val = ifcs_obj.getNoDecrementTtl(entry, True)
                ctc_policy_val = ifcs_obj.getCtcPolicy(entry, True)
                fwd_policy_val = ifcs_obj.getFwdPolicy(entry, True)
            except KeyError:
                einfo = "{}".format(sys.exc_info())
                log_dbg(
                    1, "KeyError in debug parser ifcs nexthop: {}, error: {}".
                    format(entry, einfo))
                if ifcs_obj.not_found_exc_msg.format(
                        self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                # Re-raise other exceptions for handling.
                raise
            reqd_dict = {}
            reqd_dict['obj.handle'] = entry
            reqd_dict['intf'] = ifcs_ctypes.IFCS_HANDLE_VALUE(intf_val)
            reqd_dict['port'] = ifcs_ctypes.IFCS_HANDLE_VALUE(local_destination_val)
            reqd_dict['dest_mac'] = dest_mac_val
            reqd_dict['dest_ip'] = dest_ip_val
            reqd_dict['no_decrement_ttl'] = no_decrement_ttl_val
            reqd_dict['index_el.index'] = ifcs_ctypes.IFCS_HANDLE_VALUE(entry)
            reqd_dict['ctc_policy'] = ctc_policy_val[-1]
            reqd_dict['fwd_policy'] = fwd_policy_val[-1]

            if ifcs_ctypes.IFCS_HANDLE_VALUE(entry) < 129:
                reqd_dict['port_type'] = 'normal'
                continue
            handle_value = local_destination_val
            if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_SYSPORT:
                sysportObj = ifcsObjs.get_ifcs_obj_from_name('sysport')
                try:
                    val = sysportObj.getDevport(handle_value, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs nexthop: {}, get devport error: {}"
                        .format(entry, einfo))
                    if sysportObj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise
                #this can be a cpu dest
                #val = ifcs_ctypes.IFCS_HANDLE_VALUE(int(handle_value))
                if val == 0:
                    reqd_dict['port_type'] = 'cpu'
                else:
                    reqd_dict['port_type'] = 'normal'
            elif ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_LAG:
                reqd_dict['port_type'] = 'lag'
            elif ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_NEXTHOP:
                reqd_dict['port_type'] = 'nexthop'
            elif ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                reqd_dict['port_type'] = 'ecmp'
            else:
                reqd_dict['port_type'] = 'normal'
            reqd_obj_list.append(reqd_dict)
        nexthop_dict['Nexthop'] = reqd_obj_list

        # printing for remote cli to capture stdout
        log(json.dumps(nexthop_dict,indent=4))
        return json.dumps(nexthop_dict,indent=4)


    def debug_modlist_ecc_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        all_state = []
        state = {}
        obj_state = {}
        try:
            ecc_node_stat = ifcs_ctypes.ifcs_ecc_node_stats_t()
            ifcs_ctypes.ifcs_node_ecc_stats(0, pointer(ecc_node_stat))
            state['TOTAL'] = ecc_node_stat.total_count
            state['TYPE_CE'] = ecc_node_stat.type_ce_count
            state['TYPE_UE'] = ecc_node_stat.type_ue_count
            state['TYPE_TREE'] = ecc_node_stat.type_tree_count
            state['TYPE_INV'] = ecc_node_stat.type_invalid_count
            state['RATELIMIT'] = ecc_node_stat.rate_limit_hit_count
            state['SW_FIXED_CE'] = ecc_node_stat.sw_fixed_ce_count
            state['SW_FIXED_UE'] = ecc_node_stat.sw_fixed_ue_count
        except Exception as e:
            if 'no attribute' in str(e):
                state = ''
            else:
                log_err(str(e))
                return
        obj_state['Ecc'] = state
        all_state.append(obj_state)

        # printing for remote cli to capture stdout
        log(json.dumps(all_state,indent=4))
        return json.dumps(all_state,indent=4)


    def debug_modlist_l2_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs l2entry state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_l2_entry = ifcs_obj.bulkGetalll2_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_l2_entry
            all_state.append(obj_state)

        l2_dict = {}
        reqd_obj_list = []
        for entry in all_state[0]["L2_entry"]:
            reqd_entry = {}

            try:
                handle_value = ifcs_obj.getEntryDest(entry, True)
                entry_fwd_policy_val = ifcs_obj.getEntryFwdPolicy(entry, True)
                entry_type_val = ifcs_obj.getEntryType(entry, True)
            except KeyError:
                einfo = "{}".format(sys.exc_info())
                log_dbg(
                    1, "KeyError in debug parser ifcs l2_entry: {}, error: {}".
                    format(entry, einfo))
                if ifcs_obj.not_found_exc_msg.format(
                        self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                # Re-raise other exceptions for handling.
                raise
            #handle_value = entry['entry_dest']
            if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_SYSPORT:
                sysport_obj = ifcsObjs.get_ifcs_obj_from_name('sysport')
                try:
                    val = sysport_obj.getDevport(handle_value, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs l2_entry: {}, get devport error: {}"
                        .format(entry, einfo))
                    if sysport_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise
                #val = sysport_obj.getDevport(entry['entry_dest'])
                #this can be a cpu dest
                #val = ifcs_ctypes.IFCS_HANDLE_VALUE(int(handle_value))
                if val == 0:
                    reqd_entry['port_type'] = 'cpu'
                else:
                    reqd_entry['port_type'] = 'normal'
            else:
                reqd_entry['port_type'] = 'normal'

            '''
            reqd_entry['l2_entry_key._dirty_mac_l2vni'] = entry['l2_entry_key._dirty_mac_l2vni']
            reqd_entry['key.mac_addr'] = entry['tl_l2_objects']['0']['key.mac_addr']
            reqd_entry['key.l2vni'] = entry['tl_l2_objects']['0']['key.l2vni']
            reqd_entry['fwd_action'] = entry['tl_l2_objects']['0']['pkt_policy.fwd_policy.fwd_action']
            reqd_entry['entry_dest'] = entry['entry_dest']
            reqd_entry['entry_type'] = entry['entry_type']
            '''
            reqd_entry['l2_entry_key._dirty_mac_l2vni'] = entry.contents._dirty_mac_l2vni
            reqd_entry['key.mac_addr'] = ifcs_obj.get_mac_addr_from_l2_entry(entry)
            l2vni_str = entry.contents.key.mac_l2vni.l2vni
            reqd_entry['key.l2vni'] = ifcs_ctypes.IFCS_HANDLE_VALUE(l2vni_str)
            reqd_entry['fwd_action'] = entry_fwd_policy_val
            reqd_entry['entry_dest'] = handle_value
            reqd_entry['entry_type'] = entry_type_val
            reqd_obj_list.append(reqd_entry)

        l2_dict["L2_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        #log(json.dumps(all_state,indent=4))
        #return json.dumps(all_state,indent=4)

        # printing for remote cli to capture stdout
        dump = json.dumps(l2_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_intf_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                rc, all_intf = ifcs_obj.bulk_get_all_intf_keys()
                intf_val_list = []
                for intf in all_intf:
                    try:
                        # need only svi and ipinip
                        intf_type = ifcs_obj.getType(intf, True)
                        if intf_type != self.cli.ifcs_ctypes.IFCS_INTF_TYPE_SVI and \
                                intf_type != self.cli.ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4:
                            continue
                        intf_val = ifcs_obj.handle_to_str(intf)
                        dir_val = ifcs_obj.getDirection(intf, True)
                        l3vni_val = ifcs_obj.getForwardingInstance(intf, True)
                        mtu_val = ifcs_obj.getMtu(intf, True)
                        l2vni_val = ifcs_obj.getTransportInstance(intf, True)
                        src_mac_val = ifcs_obj.getTransportMac(intf, True)
                        src_ip_val = ifcs_obj.getTransportIpaddr(intf, True)
                        ttl_mode = ifcs_obj.getTtlMode(intf, True)
                        ttl_value = ifcs_obj.getTtlValue(intf, True)
                    except KeyError:
                        einfo = "{}".format(sys.exc_info())
                        log_dbg(
                            1,
                            "KeyError in debug parser ifcs intf: {}, error: {}".
                            format(intf, einfo))
                        if ifcs_obj.not_found_exc_msg.format(
                                self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                            # Skip the instance as the object is not found.
                            continue
                        # Re-raise other exceptions for handling.
                        raise

                    intf_val_dict = {}
                    intf_val_dict['intf_type'] = intf_type
                    if intf != None:
                        intf_val_dict['intf_index'] = ifcs_ctypes.IFCS_HANDLE_VALUE(intf)
                    else:
                        intf_val_dict['intf_index'] = 0

                    intf_val_dict['direction'] = dir_val
                    if l3vni_val != None:
                        intf_val_dict['l3vni'] = ifcs_ctypes.IFCS_HANDLE_VALUE(l3vni_val)
                    else:
                        intf_val_dict['l3vni'] = 0

                    if l2vni_val != None:
                        intf_val_dict['l2vni'] = ifcs_ctypes.IFCS_HANDLE_VALUE(l2vni_val)
                    else:
                        intf_val_dict['l2vni'] = 0
                    intf_val_dict['mtu'] = mtu_val
                    intf_val_dict['src_mac'] = src_mac_val
                    intf_val_dict['src_ip'] = src_ip_val
                    intf_val_dict['ttl_mode'] = ttl_mode
                    intf_val_dict['ttl_value'] = ttl_value

                    intf_val_list.append(intf_val_dict)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return

        # printing for remote cli to capture stdout
        dump = json.dumps(intf_val_list,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v4_host_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            if addr_family == 0 and hex(entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4).strip('L') == '0xffffffff':
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry, True)
                    host_res_type = ifcs_obj.getHostResourceType(entry, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs route_entry: {}, v4_host error: {}"
                        .format(entry, einfo))
                    if ifcs_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise

                # Only show host entries not in TCAM. Host entries in TCAM are shown under v4_prefix
                if host_res_type == ifcs_ctypes.IFCS_ROUTE_ENTRY_HOST_RESOURCE_TYPE_TCAM:
                    continue

                if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
                reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
                reqd_entry['prefix_len'] = 32
                reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_srp1_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump for SRP1. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        ifcs_node_obj = ifcsObjs.get_ifcs_obj_from_name('node')
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []

        srp1_en = ifcs_ctypes.ifcs_bool_t()
        rc = ifcs_ctypes.im_node_ilpm_srp1_en_status(0, pointer(srp1_en))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "Failed to get SRP1 status rc: {0}".format(convert_error_code_to_string(rc)))
            return

        if not srp1_en:
            route_dict["Route_entry"] = reqd_obj_list

            # printing for remote cli to capture stdout
            dump = json.dumps(route_dict,indent=4)
            log(dump)
            return dump
        srp1_prfx_len = ifcs_node_obj.getSrp1()

        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only SRP1 entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = 0
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if srp1_en.value == ifcs_ctypes.IFCS_BOOL_TRUE and prefix_len == srp1_prfx_len:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs route_entry: {}, srp1 error: {}"
                        .format(entry, einfo))
                    if ifcs_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise
                if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_srp2_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump for SRP2. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        ifcs_node_obj = ifcsObjs.get_ifcs_obj_from_name('node')
        all_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []

        srp2_en = ifcs_ctypes.ifcs_bool_t()
        rc = ifcs_ctypes.im_node_ilpm_srp2_en_status(0, pointer(srp2_en))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "Failed to get SRP2 status rc: {0}".format(convert_error_code_to_string(rc)))
            return

        if not srp2_en:
            route_dict["Route_entry"] = reqd_obj_list

            # printing for remote cli to capture stdout
            dump = json.dumps(route_dict,indent=4)
            log(dump)
            return dump
        srp2_prfx_len = ifcs_node_obj.getSrp2()

        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only SRP2 entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = 0
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if srp2_en.value == ifcs_ctypes.IFCS_BOOL_TRUE and prefix_len == srp2_prfx_len:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs route_entry: {}, srp2 error: {}"
                        .format(entry, einfo))
                    if ifcs_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise
                if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v6_host_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                #all_route_entry = ifcs_obj.getAllroute_entry()
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v6 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = 0
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()
            if prefix_len == 128:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry, True)
                    host_res_type = ifcs_obj.getHostResourceType(entry, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs route_entry: {}, v6_host error: {}"
                        .format(entry, einfo))
                    if ifcs_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise

                # Only show v6 host entries not in TCAM. Host entries in TCAM are shown under v6_prefix
                if host_res_type == ifcs_ctypes.IFCS_ROUTE_ENTRY_HOST_RESOURCE_TYPE_TCAM:
                    continue

                if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump


    def debug_modlist_route_v4_prefix_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                #all_route_entry = ifcs_obj.getAllroute_entry()
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            if addr_family == 0:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry, True)
                    host_res_type = ifcs_obj.getHostResourceType(entry, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs route_entry: {}, v4_prefix error: {}"
                        .format(entry, einfo))
                    if ifcs_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise

                # Show v4 host entries in TCAM. Host entries not in TCAM are shown under v4_host.
                if hex(entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4).strip('L') == '0xffffffff' and \
                    host_res_type != ifcs_ctypes.IFCS_ROUTE_ENTRY_HOST_RESOURCE_TYPE_TCAM:
                    continue

                if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
                mask = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4
                mask_str = socket.inet_ntoa(struct.pack('!L', mask))
                reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
                reqd_entry['prefix_len'] = IPAddress(mask_str).netmask_bits()
                reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v6_prefix_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                #all_route_entry = ifcs_obj.getAllroute_entry()
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
                #state = ifcs_obj.getAllIfcsState()
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            #obj_state[name.capitalize()] = state
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        srp2_en = ifcs_ctypes.ifcs_bool_t()
        rc = ifcs_ctypes.im_node_ilpm_srp2_en_status(0, pointer(srp2_en))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "Failed to get SRP2 status rc: {0}".format(convert_error_code_to_string(rc)))
            return

        srp1_en = ifcs_ctypes.ifcs_bool_t()
        rc = ifcs_ctypes.im_node_ilpm_srp1_en_status(0, pointer(srp1_en))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "Failed to get SRP1 status rc: {0}".format(convert_error_code_to_string(rc)))
            return

        ifcs_node_obj = ifcsObjs.get_ifcs_obj_from_name('node')

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 host entries.
        for entry in all_state[0]["Route_entry"]:
            addr_family = entry.contents.key.ip_dest_l3vni.ip_dest.addr_family
            prefix_len = -1
            if addr_family == 1:
                mask_val = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv6
                mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
                prefix_len = IPAddress(mask).netmask_bits()

            srp_route = ifcs_ctypes.IFCS_BOOL_FALSE
            if (srp2_en.value == ifcs_ctypes.IFCS_BOOL_TRUE and prefix_len == ifcs_node_obj.getSrp2()) or \
               (srp1_en.value == ifcs_ctypes.IFCS_BOOL_TRUE and prefix_len == ifcs_node_obj.getSrp1()):
                srp_route = ifcs_ctypes.IFCS_BOOL_TRUE

            if prefix_len != -1 and not srp_route:
                reqd_entry = {}
                try:
                    handle_value = ifcs_obj.getNexthop(entry, True)
                    host_res_type = ifcs_obj.getHostResourceType(entry, True)
                except KeyError:
                    einfo = "{}".format(sys.exc_info())
                    log_dbg(
                        1,
                        "KeyError in debug parser ifcs route_entry: {}, v6_prefix error: {}"
                        .format(entry, einfo))
                    if ifcs_obj.not_found_exc_msg.format(
                            self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                        # Skip the instance as the object is not found.
                        continue
                    # Re-raise other exceptions for handling.
                    raise

                # Show v6 host entries in TCAM. Host entries not in TCAM are shown under v6_host.
                if prefix_len == 128 and host_res_type != ifcs_ctypes.IFCS_ROUTE_ENTRY_HOST_RESOURCE_TYPE_TCAM:
                    continue

                if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                    #this dest is multipath
                    reqd_entry['multipath'] = True
                else:
                    reqd_entry['multipath'] = False

                ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv6
                reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
                reqd_entry['prefix_len'] = prefix_len
                reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

                reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v4_fallback_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 fallback entries.
        for entry in all_state[0]["Route_entry"]:
            if entry.contents.key_type != ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY:
                continue

            reqd_entry = {}
            try:
                handle_value = ifcs_obj.getNexthop(entry, True)
            except KeyError:
                einfo = "{}".format(sys.exc_info())
                log_dbg(
                    1,
                    "KeyError in debug parser ifcs route_entry: {}, v4_fallback error: {}"
                    .format(entry, einfo))
                if ifcs_obj.not_found_exc_msg.format(
                        self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                # Re-raise other exceptions for handling.
                raise

            if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                #this dest is multipath
                reqd_entry['multipath'] = True
            else:
                reqd_entry['multipath'] = False

            ip_entry = entry.contents.key.ip_dest_only.ip_dest.addr.ipv4
            mask = entry.contents.key.ip_dest_only.ip_dest.mask.ipv4
            mask_str = socket.inet_ntoa(struct.pack('!L', mask))
            reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
            reqd_entry['prefix_len'] = IPAddress(mask_str).netmask_bits()
            reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)

            reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_v6_fallback_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list and store only v4 fallback entries.
        for entry in all_state[0]["Route_entry"]:
            if entry.contents.key_type != ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY:
                continue

            reqd_entry = {}
            try:
                handle_value = ifcs_obj.getNexthop(entry, True)
            except KeyError:
                einfo = "{}".format(sys.exc_info())
                log_dbg(
                    1,
                    "KeyError in debug parser ifcs route_entry: {}, v6_fallback error: {}"
                    .format(entry, einfo))
                if ifcs_obj.not_found_exc_msg.format(
                        self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                # Re-raise other exceptions for handling.
                raise

            if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                #this dest is multipath
                reqd_entry['multipath'] = True
            else:
                reqd_entry['multipath'] = False

            ip_entry = entry.contents.key.ip_dest_only.ip_dest.addr.ipv6
            mask_val = entry.contents.key.ip_dest_only.ip_dest.mask.ipv6
            mask = ifcsIP.convertIPv6TupleToIpv6DottedStr(mask_val, ':')
            reqd_entry['ip_dest'] = ifcsIP.convertIPv6TupleToIpv6DottedStr(ip_entry, ':')
            reqd_entry['prefix_len'] = IPAddress(mask).netmask_bits()
            reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)

            reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_modlist_route_entry_ifcs(self, modules):
        log_dbg(1, 'Generating ifcs state dump. This might take a while..')

        ifcsObjs = IfcsAll(self.cli)
        all_state = []
        all_pi_state = []
        ifcsObjNames = ifcsObjs.get_ifcs_obj_names()
        for name in ifcsObjNames:
            if name.lower() not in modules:
                continue
            obj_state = {}
            ifcs_obj = ifcsObjs.get_ifcs_obj_from_name(name)
            try:
                all_route_entry = ifcs_obj.bulkGetallroute_entry(batchSize=10000)
            except Exception as e:
                if 'no attribute' in str(e):
                    state = ''
                else:
                    log_err(str(e))
                    return
            obj_state[name.capitalize()] = all_route_entry
            all_state.append(obj_state)

        route_dict = {}
        reqd_obj_list = []
        import struct
        import socket
        from netaddr import IPAddress
        from utils import ifcsIP
        #go through the route_entry list
        for entry in all_state[0]["Route_entry"]:
            reqd_entry = {}
            try:
                handle_value = ifcs_obj.getNexthop(entry, True)
            except KeyError:
                einfo = "{}".format(sys.exc_info())
                log_dbg(
                    1,
                    "KeyError in debug parser ifcs route_entry: {}, error: {}".
                    format(entry, einfo))
                if ifcs_obj.not_found_exc_msg.format(
                        self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                # Re-raise other exceptions for handling.
                raise

            if ifcs_ctypes.IFCS_HANDLE_MODULE(int(handle_value)) == ifcs_ctypes.IFCS_MOD_ECMP:
                #this dest is multipath
                reqd_entry['multipath'] = True
            else:
                reqd_entry['multipath'] = False

            ip_entry = entry.contents.key.ip_dest_l3vni.ip_dest.addr.ipv4
            mask = entry.contents.key.ip_dest_l3vni.ip_dest.mask.ipv4
            mask_str = socket.inet_ntoa(struct.pack('!L', mask))
            reqd_entry['ip_dest'] = socket.inet_ntoa(struct.pack('!L', ip_entry))
            reqd_entry['prefix_len'] = IPAddress(mask_str).netmask_bits()
            reqd_entry['nexthop'] = ifcs_ctypes.IFCS_HANDLE_VALUE(handle_value)

            if entry.contents.key_type == ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY:
                reqd_entry['l3vni'] = entry.contents.key.ip_dest_l3vni.l3vni

            reqd_obj_list.append(reqd_entry)

        route_dict["Route_entry"] = reqd_obj_list

        # printing for remote cli to capture stdout
        dump = json.dumps(route_dict,indent=4)
        log(dump)
        return dump

    def debug_error(self, modules):
        log_err("Invalid command or unsupported parameters!")
        log_err(str(modules))
        return

    def debug_ifcs(self, args):
        log_dbg(1, "Debugging ifcs state ..")

        ifcsObjs = IfcsAll(self.cli)
        arg_list = args.split()

        if (len(arg_list) > 6) and (arg_list[2] not in ifcsObjs.get_ifcs_obj_names()):
            log_err("Invalid command")
            return ifcs_ctypes.IFCS_INVAL

        modules = arg_list[2:]

        if len(modules) == 0:
            # All modules
            return self.debug_all_ifcs(args)
        else:
            if 'usage' in modules:
                #just get the usage details for the module
                return self.debug_modlist_ifcs_usage(modules)
            else:
                if 'nexthop' in modules:
                    return self.debug_modlist_nexthop_ifcs(modules)
                elif 'intf' in modules:
                    return self.debug_modlist_intf_ifcs(modules)
                elif 'ecc' in modules:
                    return self.debug_modlist_ecc_ifcs(modules)
                elif 'l2_entry' in modules:
                    return self.debug_modlist_l2_entry_ifcs(modules)
                elif 'route_entry' in modules:
                    if 'v4_host' in modules:
                        return self.debug_modlist_route_v4_host_entry_ifcs(modules)
                    elif 'v4_prefix' in modules:
                        return self.debug_modlist_route_v4_prefix_entry_ifcs(modules)
                    elif 'v6_prefix' in modules:
                        return self.debug_modlist_route_v6_prefix_entry_ifcs(modules)
                    elif 'v6_host' in modules:
                        return self.debug_modlist_route_v6_host_entry_ifcs(modules)
                    elif 'srp1' in modules:
                        return self.debug_modlist_route_srp1_entry_ifcs(modules)
                    elif 'srp2' in modules:
                        return self.debug_modlist_route_srp2_entry_ifcs(modules)
                    elif 'v4_fallback' in modules:
                        return self.debug_modlist_route_v4_fallback_entry_ifcs(modules)
                    elif 'v6_fallback' in modules:
                        return self.debug_modlist_route_v6_fallback_entry_ifcs(modules)
                    elif len(modules) == 1:
                        # This is the case where no filter is passed
                        return self.debug_modlist_route_entry_ifcs(modules)
                    else:
                        return self.debug_error(modules)
                elif 'devport' in modules and 'counters' in modules:
                    return self.debug_modlist_devport_counters_ifcs(modules)
                elif 'devport' in modules:
                    return self.debug_modlist_devport_ifcs(args, modules)
                elif 'ecmp' in modules:
                    return self.debug_modlist_ecmp_ifcs(modules)
                elif 'lag' in modules:
                    return self.debug_modlist_lag_ifcs(args, modules)
                else:
                    return self.debug_modlist_ifcs(args, modules)


    def help(self, args):
        """Display help information for debugparser command"""
        from print_table import PrintTable

        table = PrintTable()
        table.set_justification('left')
        table.add_row(['DebugParser Commands', 'Description'])
        table.add_row(['debugparser ifcs <module> [options]', 'Debug IFCS module state'])
        table.add_row(['debugparser help or ?', 'Show this help text'])
        log("")
        table.print_table()
        table.reset_table()

        # Show available modules
        log("\nAvailable IFCS modules:")
        table = PrintTable()
        table.set_justification('left')
        table.add_row(['Module', 'Supported Options'])
        table.add_row(['nexthop', 'usage'])
        table.add_row(['intf', 'usage'])
        table.add_row(['ecmp', 'usage, members usage'])
        table.add_row(['route_entry', 'v4_host, v4_prefix, v6_host, v6_prefix, v4_fallback, v6_fallback, srp1, srp2, usage'])
        table.add_row(['devport', 'counters'])
        table.add_row(['lag', ''])
        table.add_row(['l2_entry', ''])
        table.add_row(['sysport', ''])
        table.add_row(['l2vni', ''])
        table.add_row(['ecc', ''])
        log("")
        table.print_table()
        table.reset_table()

        # Show route_entry usage options
        log("\nRoute_entry usage options:")
        log("  debugparser ifcs route_entry usage <filter>")
        log("  Filters: v4_host, v4_prefix, v6_host, v6_prefix,")
        log("           v4_fallback, v6_fallback, srp1, srp2,")
        log("           tcam_slots, sram_slots, v4_tcam_slots_narrow,")
        log("           v6_tcam_slots_narrow, tcam_slots_wide,")
        log("           v4_tcam_slots_fallback_narrow, v6_tcam_slots_fallback_narrow,")
        log("           v6_tcam_slots_fallback_wide, sram_slots_narrow,")
        log("           sram_slots_wide, sram_buckets_narrow, sram_buckets_wide")
        log("")

        log("\nExamples:")
        log("  debugparser ifcs route_entry usage v4_host")
        log("  debugparser ifcs route_entry v4_prefix")
        log("  debugparser ifcs nexthop usage")
        log("  debugparser ifcs devport counters")
        log("  debugparser ifcs ecmp usage")
        log("  debugparser ifcs ecmp members usage")
        log("")

        return
