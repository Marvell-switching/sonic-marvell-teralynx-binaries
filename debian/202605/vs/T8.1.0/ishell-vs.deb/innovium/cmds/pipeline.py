#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import sys
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from ifcs_cmds.all import *
from print_table import PrintTable
from pen_list import *
from pipeline import *
from pencmd import *

class Pipeline_info(Command):
    def __init__(self):
        self.def_blks = ['s1', 's2', 's3', 's4']
        self.def_stats = ['in', 'out', 'drop']

        self.stats_key = []
        for b in self.def_blks:
            for s in self.def_stats:
                self.stats_key.append(b + ' ' + s)

        self.stats_pen = OrderedDict()

        #S1
        num_pics_per_ib = ifcs_ctypes.im_node_num_eth_pics(0)
        self.stats_pen['s1 in'] = []
        for pic in range(num_pics_per_ib):
            penid = getattr(ifcs_ctypes, 'BAM_DEBUG_PIC{0}_FRM_COUNT'.format(str(pic)))
            self.stats_pen['s1 in'].append((penid, ifcs_ctypes.CNTR_F))

        self.stats_pen['s1 in'] += [(ifcs_ctypes.BAM_DEBUG_UCM_FRM_COUNT, ifcs_ctypes.CNTR_F),
                                     (ifcs_ctypes.BAM_DEBUG_RECIRC_FRM_COUNT, ifcs_ctypes.CNTR_F),
                                    ]
        self.stats_pen['s1 out'] = [(ifcs_ctypes.BAM_DEBUG_IFC_FRM_COUNT, ifcs_ctypes.CNTR_F),
                                    ]
        self.stats_pen['s1 drop'] = None

        #S2
        self.stats_pen['s2 in'] = [(ifcs_ctypes.IFC_SOP_PACKET_IN, ifcs_ctypes.COUNTER_F)]
        self.stats_pen['s2 out'] = [(ifcs_ctypes.IFC_SOP_NONDROP_PACKET_OUT, ifcs_ctypes.COUNTER_F)]
        self.stats_pen['s2 drop'] = [(ifcs_ctypes.IFC_SOP_DROP_PACKET_OUT, ifcs_ctypes.COUNTER_F)]

        #S3
        self.stats_pen['s3 in'] = [(ifcs_ctypes.DTM_DEBUG16, ifcs_ctypes.INGRESS_PKT_CNT_F)]
        self.stats_pen['s3 out'] = [(ifcs_ctypes.DTM_DEBUG13, ifcs_ctypes.EGRESS_PKT_CNT_F)]
        self.stats_pen['s3 drop'] = None

        #S4
        self.stats_pen['s4 in'] = [(ifcs_ctypes.DEBUG_EFC_SOP_IN_COUNT, ifcs_ctypes.VALUE_F)]
        self.stats_pen['s4 out'] = [(ifcs_ctypes.DEBUG_EFC_SOP_NODROP_OUT_COUNT, ifcs_ctypes.VALUE_F)]
        self.stats_pen['s4 drop'] = [(ifcs_ctypes.DEBUG_EFC_SOP_DROP_OUT_COUNT, ifcs_ctypes.VALUE_F)]


    def getStatsPenInfo(self, block, stat):
        stat_str = block.lower() + ' ' + stat.lower()
        if stat_str not in self.stats_key:
            return -1

        return (self.stats_pen[stat_str])

    def getStages(self):
        return self.def_blks

    def getStats(self):
        return self.def_stats


# Class implemets Pipe related info
class Pipeline(Command):
    def __init__(self, cli, chipStr='TL7'):
        self.pipes = []
        self.pipeline_counter_display_method = {
            'drop': self.display_drop_pipeline_stats,
            'global': self.display_global_pipeline_stats,
        }

        self.supported_operands = ['drop']
        self.cli = cli
        self.arg_list = []
        super(Pipeline, self).__init__()
        buflen = 64
        namebuf = create_string_buffer(buflen)

        #========== CONFIG ===========#
        self.stats_pen = OrderedDict()
        self.stats_pen['s1 in'] = None
        self.stats_pen['s1 out'] = (ifcs_ctypes.BAM_DEBUG_IFC_FRM_COUNT, ifcs_ctypes.CNTR_F)
        self.stats_pen['s1 drop'] = None

        self.stats_pen['s2 in'] = (ifcs_ctypes.IFC_SOP_PACKET_IN, ifcs_ctypes.COUNTER_F)
        self.stats_pen['s2 out'] = (ifcs_ctypes.IFC_SOP_NONDROP_PACKET_OUT, ifcs_ctypes.COUNTER_F)
        self.stats_pen['s2 drop'] = (ifcs_ctypes.IFC_SOP_DROP_PACKET_OUT, ifcs_ctypes.COUNTER_F)

        self.stats_pen['s3 in'] = (ifcs_ctypes.DTM_DEBUG16, ifcs_ctypes.INGRESS_PKT_CNT_F)
        self.stats_pen['s3 out'] = (ifcs_ctypes.DTM_DEBUG13, ifcs_ctypes.EGRESS_PKT_CNT_F)
        self.stats_pen['s3 drop'] = None

        self.stats_pen['s4 in'] = (ifcs_ctypes.DEBUG_EFC_SOP_IN_COUNT, ifcs_ctypes.VALUE_F)
        self.stats_pen['s4 out'] = (ifcs_ctypes.DEBUG_EFC_SOP_NODROP_OUT_COUNT, ifcs_ctypes.VALUE_F)
        self.stats_pen['s4 drop'] = (ifcs_ctypes.DEBUG_EFC_SOP_DROP_OUT_COUNT, ifcs_ctypes.VALUE_F)

        self.ppinfo = Pipeline_info()
        self.stages = self.ppinfo.getStages()
        self.stats = self.ppinfo.getStats()

        self.stages_stats = []
        for stg in self.stages:
            for stat in self.stats:
                self.stages_stats.append(stg.lower() + ' ' + stat.lower())


    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Pipe run")
        self.arg_list = shlex.split(args)


    def pipeline_counter_clear_method(self):
        for ib in range(ifcs_ctypes.IFCS_NUM_IBS(0)):
            self.clear_pipeline_stats(ib)

    def get_pipeline_stats(self, ib=0, drop=False):
        stats_value = OrderedDict()

        #========== VALUE ===========#
        stats_value['s1 in'] = 0
        stats_value['s1 out'] = 0
        stats_value['s1 drop'] = 0

        stats_value['s2 in'] = 0
        stats_value['s2 out'] = 0
        stats_value['s2 drop'] = 0

        stats_value['s3 in'] = 0
        stats_value['s3 out'] = 0
        stats_value['s3 drop'] = 0

        stats_value['s4 in'] = 0
        stats_value['s4 out'] = 0
        stats_value['s4 drop'] = 0

        pen_tentry = ifcs_ctypes.tentry_new(0, -1, -1)
        #pen = Pen(self.cli)

        try:
            for ss in self.stages_stats:
                stage = ss.split()[0]
                stat = ss.split()[1]
                pen_list = self.ppinfo.getStatsPenInfo(stage, stat)

                if pen_list != None:
                    for pen_id,field_id in pen_list:
                        pen_id = ifcs_ctypes.DEVICE_PEN_IDMAP(0)[pen_id]
                        field_id = ifcs_ctypes.DEVICE_FLD_IDMAP(0)[field_id]
                        index = 0
                        hints = 0

                        ifcs_ctypes.tentry_clear(pen_tentry)
                        rc = ifcs_ctypes.node_isn_pen_read(0, int(ib), pen_id,
                                               index, hints, pen_tentry)
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("PEN read failed " + ifcscli_util.convert_error_code_to_string(rc))
                            ifcs_ctypes.tentry_free(pen_tentry)
                            return rc

                        c_width = c_uint32(0)
                        rc = ifcs_ctypes.tentry_field_width(pen_id, field_id, pointer(c_width))
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("Failed to get Pen {0} Field {1} width. Rc {2}".\
                                    format(str(pen_id), str(field_id), str(rc)))
                            ifcs_ctypes.tentry_free(pen_tentry)
                            return rc

                        width = c_width.value
                        if (width <= 32):
                            rd_val = c_uint32(0)
                            rc = ifcs_ctypes.tentry_get_item(0, pen_id, field_id, ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                                                 pen_tentry, pointer(rd_val))
                        else:
                            #rd_val64 = (c_ubyte * 256)(0)
                            #nbytes = (width + 7) / 8
                            rd_val64 = c_uint64(0)
                            rc = ifcs_ctypes.tentry_get_item(0, pen_id, field_id, ifcs_ctypes.TENTRY_FLD_TYPE_UINT64,
                                                 pen_tentry, pointer(rd_val64))

                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("Failed to get Pen {0} Field {1} width. Rc {2}".\
                                    format(str(pen_id), str(field_id), str(rc)))
                            ifcs_ctypes.tentry_free(pen_tentry)
                            return rc

                        if (width <= 32):
                            stats_value[ss] += rd_val.value
                        else:
                            stats_value[ss] += rd_val64.value

            ifcs_ctypes.tentry_free(pen_tentry)

        except Exception as e:
            ifcs_ctypes.tentry_free(pen_tentry)
            log_err("Exception raised : {0}".format(str(e)))
            raise e

        return stats_value

    def display_global_pipeline_stats(self, args):
        log_dbg(1, "In Pipe display Global counters")
        self.arg_list = shlex.split(args)

        table = PrintTable()
        #table.set_header_size(2)
        '''
======================================================
| IB |  S1 |  S1 |  S2 |  S2 |  S3 |  S3 |  S4 |  S4 |
|    |  IN | OUT |  IN | OUT |  IN | OUT |  IN | OUT |
======================================================
|    |     |     |     |     |     |     |     |     |
|    |     |     |     |     |     |     |     |     |
======================================================

        '''
        col_names = [
            'IB',
            'S1 IN',
            'S1 OUT',
            'S2 IN',
            'S2 OUT',
            'S3 IN',
            'S3 OUT',
            'S4 IN',
            'S4 OUT',
        ]
        table.add_row(col_names)

        for ib in range(ifcs_ctypes.IFCS_NUM_IBS(0)):
            stats_value = self.get_pipeline_stats(ib=ib)

            stats_print_list = []
            stats_print_list.append(ib)

            for key in col_names[1::]:
                stats_print_list.append(stats_value[key.lower()])

            table.add_row(stats_print_list)

        table.print_table(brief=True)

 /* 

    def display_drop_pipeline_stats(self, args):
        table = PrintTable()
        #table.set_header_size(2)
        '''
==================================
| IB |  S1  |  S2  |  S3  |  S4  |
|    | DROP | DROP | DROP | DROP |
==================================
|    |      |      |      |      |
|    |      |      |      |      |
==================================

        '''

        col_names = []
        col_names.append('IB')
        for b in self.ppinfo.getStages():
            col_names.append(b.upper() + ' DROP')

        table.add_row(col_names)

        for ib in range(ifcs_ctypes.IFCS_NUM_IBS(0)):
            stats_value = self.get_pipeline_stats(ib)

            stats_print_list = []
            stats_print_list.append(ib)

            for key in col_names[1::]:
                dropStr = key.split()[0].lower() + ' drop'
                if self.stats_pen[dropStr] == None:
                    inStr = key.split()[0].lower() + ' in'
                    outStr = key.split()[0].lower() + ' out'
                    stats_drop_value = stats_value[inStr] - stats_value[outStr]
                else:
                    stats_drop_value = stats_value[dropStr]

                stats_print_list.append(stats_drop_value)

            table.add_row(stats_print_list)

        table.print_table(brief=True)

 /* 
        return

    def clear_pipeline_stats(self, ib=0):
        stats_value = OrderedDict()

        pen_tentry = ifcs_ctypes.tentry_new(0, -1, -1)
        #pen = Pen(self.cli)

        try:
            for ss in self.stages_stats:
                stage = ss.split()[0]
                stat = ss.split()[1]
                pen_list = self.ppinfo.getStatsPenInfo(stage, stat)

                if pen_list != None:
                    for pen_id,field_id in pen_list:
                        pen_id = ifcs_ctypes.DEVICE_PEN_IDMAP(0)[pen_id]
                        field_id = ifcs_ctypes.DEVICE_FLD_IDMAP(0)[field_id]
                        index = 0
                        hints = 0

                        ifcs_ctypes.tentry_clear(pen_tentry)
                        rc = ifcs_ctypes.node_isn_pen_write(0, int(ib), pen_id,
                                                index, hints, pen_tentry)
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            log_err("PEN write failed " + ifcscli_util.convert_error_code_to_string(rc))
                            ifcs_ctypes.tentry_free(pen_tentry)
                            return rc
            ifcs_ctypes.tentry_free(pen_tentry)
        except Exception as e:
            ifcs_ctypes.tentry_free(pen_tentry)
            log_err("Exception raised : {0}".format(str(e)))
            raise e
        return

    def display_drop_pipeline_stats_old(self, args):
        table = PrintTable()
        #table.set_header_size(2)
        '''
==================================
| IB |  S1  |  S2  |  S3  |  S4  |
|    | DROP | DROP | DROP | DROP |
==================================
|    |      |      |      |      |
|    |      |      |      |      |
==================================

        '''
        col_names = [
            'IB',
            'S1 DROP',
            'S2 DROP',
            'S3 DROP',
            'S4 DROP',
        ]
        table.add_row(col_names)

        for ib in range(ifcs_ctypes.IFCS_NUM_IBS(0)):
            stats_value = self.get_pipeline_stats(ib)

            stats_print_list = []
            stats_print_list.append(ib)

            for key in col_names[1::]:
                dropStr = key.split()[0].lower() + ' drop'
                if self.stats_pen[dropStr] == None:
                    inStr = key.split()[0].lower() + ' in'
                    outStr = key.split()[0].lower() + ' out'
                    stats_drop_value = stats_value[inStr] - stats_value[outStr]
                else:
                    stats_drop_value = stats_value[dropStr]

                stats_print_list.append(stats_drop_value)

            table.add_row(stats_print_list)

        table.print_table(brief=True)


        return

    def get_pipeline_stats_old(self, args, ib=0, drop=False):
        stats_value = OrderedDict()

        #========== VALUE ===========#
        stats_value['s1 in'] = 0
        stats_value['s1 out'] = 0
        stats_value['s1 drop'] = 0

        stats_value['s2 in'] = 0
        stats_value['s2 out'] = 0
        stats_value['s2 drop'] = 0

        stats_value['s3 in'] = 0
        stats_value['s3 out'] = 0
        stats_value['s3 drop'] = 0

        stats_value['s4 in'] = 0
        stats_value['s4 out'] = 0
        stats_value['s4 drop'] = 0

        pen_tentry = ifcs_ctypes.tentry_new(0, -1, -1)
        #pen = Pen(self.cli)

        try:
            for key in self.stats_pen.keys():
                if (self.stats_pen[key] != None):
                    pen_id, field_id = self.stats_pen[key]
                    pen_id = ifcs_ctypes.DEVICE_PEN_IDMAP(0)[pen_id]
                    field_id = ifcs_ctypes.DEVICE_FLD_IDMAP(0)[field_id]
                    index = 0
                    hints = 0

                    ifcs_ctypes.tentry_clear(pen_tentry)
                    rc = ifcs_ctypes.node_isn_pen_read(0, int(ib), pen_id,
                                           index, hints, pen_tentry)
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("PEN read failed " + ifcscli_util.convert_error_code_to_string(rc))
                        ifcs_ctypes.tentry_free(pen_tentry)
                        return rc

                    c_width = c_uint32(0)
                    rc = ifcs_ctypes.tentry_field_width(pen_id, field_id, pointer(c_width))
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("Failed to get Pen {0} Field {1} width. Rc {2}".\
                                format(str(pen_id), str(field_id), str(rc)))
                        ifcs_ctypes.tentry_free(pen_tentry)
                        return rc

                    width = c_width.value
                    if (width <= 32):
                        rd_val = c_uint32(0)
                        rc = ifcs_ctypes.tentry_get_item(0, pen_id, field_id, ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                                             pen_tentry, pointer(rd_val))
                    else:
                        #rd_val64 = (c_ubyte * 256)(0)
                        #nbytes = (width + 7) / 8
                        rd_val64 = c_uint64(0)
                        rc = ifcs_ctypes.tentry_get_item(0, pen_id, field_id, ifcs_ctypes.TENTRY_FLD_TYPE_UINT64,
                                             pen_tentry, pointer(rd_val64))

                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("Failed to get Pen {0} Field {1} width. Rc {2}".\
                                format(str(pen_id), str(field_id), str(rc)))
                        ifcs_ctypes.tentry_free(pen_tentry)
                        return rc
                    if (width <= 32):
                        stats_value[key] = rd_val.value
                    else:
                        stats_value[key] = rd_val64.value

            ifcs_ctypes.tentry_free(pen_tentry)
        except Exception as e:
            log_err("Exception raised : {0}".format(str(e)))
            ifcs_ctypes.tentry_free(pen_tentry)
            raise e

        return stats_value
