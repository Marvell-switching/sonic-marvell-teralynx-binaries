#-------------------------------------------------------------------------------
# Copyright (c) (2025) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you, your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
#
# T100 MPIC/AUX SerDes management CLI ("diagtest serdes mgmt ...").
#
# Unlike the TL10 variant (serdes_mgmt_tl10.py) which bit-bangs the Torrent
# SD0801 registers directly over the MPIC APB bus, T100 MPIC/AUX uses the
# MTIP MAC + N3C64GP6X2 (C64GX) COMPHY SerDes driven by L1FW.  The PRBS
# (BIST) path is implemented through IFCS devport PRBS attributes, which route
# to l1lib_port_prbs_tx_start()/rx_start() for AUX ports inside
# ii_t100_devport_pic.c.
#
# Supported commands (mirrors the TL10 mgmt CLI surface used on AUX ports):
#   diagtest serdes mgmt bist on
#   diagtest serdes mgmt --devport <dp> bist tx start [--pattern prbs31] [--rate 10g]
#   diagtest serdes mgmt --devport <dp> bist rx start [--pattern prbs31] [--rate 10g]
#   diagtest serdes mgmt --devport <dp> bist status
#   diagtest serdes mgmt --devport <dp> bist tx stop
#   diagtest serdes mgmt --devport <dp> bist rx stop
#   diagtest serdes mgmt --devport <dp> bist rx reset
#   diagtest serdes mgmt bist off
#   diagtest serdes mgmt [--devport <dp>] phy status
#   diagtest serdes mgmt [--devport <dp>] link
#
# "phy status", "phy taps" and "eyesurf" reach the MPIC/AUX 64G ComPhy
# (N3C64GP6X2) through the SerDes-type-agnostic mvHwsSerdes* wrapper layer
# (serdesType COM_PHY_N3C64GP6X2), exactly like the front-panel 224G ComPhy uses
# the same wrappers with COM_PHY_N3C224GX81PLL.  The wrappers dispatch to the
# node's MPIC (dev_type 1) FuncPtrArray and call the MCESD driver C-side; the raw
# API_N3C64GP6X2_* SDK is never exposed to Python.  "link" reads the MTIP
# PCS/MAC status registers over PCIe.
#-------------------------------------------------------------------------------

import argparse
import shlex
import sys
import traceback

from ctypes import *
from utils.compat_util import *
from verbosity import *
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
import serdes_eth_cmn
import testutil.t100_comphy_transport as mpic_xport
from testutil import pci

try:
    import ifcs_ctypes_t100 as ifcs_t100
except ImportError:
    ifcs_t100 = None

try:
    from cmdmgr import CommandError
except ImportError:
    class CommandError(Exception):
        rc = None

ifcs_ctypes = sys.modules['ifcs_ctypes']

# T100 AUX ports are served by the MPIC, whose port-state pen is MPMC_PORT_STATE
# (PMC_PORT_STATE is the PIC / front-panel pen).  Resolve the MPIC pen id first,
# falling back to PMC_* only for safety on builds that lack the MPMC set.
def _mpic_pen(base):
    if ifcs_t100 is None:
        return None
    for prefix in ('MPMC_', 'PMC_'):
        v = getattr(ifcs_t100, prefix + base, None)
        if v is not None:
            return v
    return None

_PORT_STATE_PEN = _mpic_pen('PORT_STATE')

def _t100_fsm_state_val(*names, default=None):
    # fsm_state enum-value constants are generated from the deployed fwpen. The
    # banded picmc scheme (PIC) exposes PORT_UP (=192); the T100 MPIC small-enum
    # scheme exposes PORT_LINK_ESTABLISH_E (=5).  For MPIC/AUX the constants are
    # MPMC_PORT_STATE_FSM_STATE_F_*; resolve MPMC first, then PMC, with a numeric
    # fallback so the CLI keeps working if the constant is absent.
    if ifcs_t100 is None:
        return default
    for prefix in ('MPMC_PORT_STATE_FSM_STATE_F_', 'PMC_PORT_STATE_FSM_STATE_F_'):
        for n in names:
            v = getattr(ifcs_t100, prefix + n, None)
            if v is not None:
                return v
    return default

_PORT_UP_STATE = _t100_fsm_state_val(
    'PORT_LINK_ESTABLISH_E', 'PORT_UP', default=5)

# T100 MPIC/AUX ports are fixed 10G, so default the PRBS rate accordingly.
_DEFAULT_RATE = '10g'
_DEFAULT_PATTERN = 'prbs31'
_NUM_MPIC_LANES = 2

# -----------------------------------------------------------------------------
# MTIP PCS/MAC registers (named T100 PCIe registers) used by "link" status.
#
# On T100 the MPIC path bypasses the TL10-style MPICn_ENABLE / MPICn_RX_CONFIG
# wrapper registers; L1FW programs and the hardware updates the MTIP IP
# registers directly, so we read them straight over PCIe (same access method
# TL10 uses for its MPICn_* registers via testutil.pci).  Each register offset
# is the generated ifcs_ctypes symbol, indexed per MPIC lane (0/1):
#   block_lock     : PCS<n>_MTIP_CPU_PCS_EXT_UNITS__MTIP_PORT_STATUS
#                        .LINK_STATUS_F                                  (bit 0)
#   remote_fault   : MAC<n>_MAC_UNITS__STATUS.RX_REM_FAULT_F            (bit 1)
#   local_fault    : MAC<n>_MAC_UNITS__STATUS.RX_LOC_FAULT_F            (bit 0)
# This module is only imported on T100 nodes (see serdes.py), so the T100
# ifcs_ctypes register symbols are always present when it loads.
# -----------------------------------------------------------------------------
_MTIP_PORT_STATUS_REG = (ifcs_ctypes.PCS0_MTIP_CPU_PCS_EXT_UNITS__MTIP_PORT_STATUS,
                         ifcs_ctypes.PCS1_MTIP_CPU_PCS_EXT_UNITS__MTIP_PORT_STATUS)
_MTIP_LINK_STATUS_MASK = 0x00000001     # LINK_STATUS_F (bit 0)

_MAC_UNITS_STATUS_REG = (ifcs_ctypes.MAC0_MAC_UNITS__STATUS,
                         ifcs_ctypes.MAC1_MAC_UNITS__STATUS)
_MAC_RX_LOC_FAULT_MASK = 0x00000001     # RX_LOC_FAULT_F (bit 0)
_MAC_RX_REM_FAULT_MASK = 0x00000002     # RX_REM_FAULT_F (bit 1)
# PMA RX signal-detect for MPIC/AUX ports comes from the MTIP MAC, not the
# (unused-on-T100) MPIC PMA PHY_LANE_CTRL wrapper.  MAC_UNITS__STATUS.PHY_LOS_F
# (pen/json/T100/cpu.json: mac_units__status @ 0xc10040, bit 2) is the PHY
# loss-of-signal pin brought into the MTIP MAC, so signal is present when
# PHY_LOS is 0.  This lives in the same status word already read for the faults.
_MAC_PHY_LOS_MASK = 0x00000004          # PHY_LOS_F (bit 2)

def _poly_map():
    return {
        'prbs7':  ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS7,
        'prbs9':  ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS9,
        'prbs11': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS11,
        'prbs13': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS13,
        'prbs15': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS15,
        'prbs16': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS16,
        'prbs23': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS23,
        'prbs31': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS31,
        'prbs32': ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_PRBS32,
    }

def _rate_map():
    return {
        '10g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_10_3125GBS,
        '25g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_25_78125GBS,
        '26g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_26_5625GBS,
        '27g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_27_1875GBS,
        '28g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_28_125GBS,
        '51g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_51_5625GBS,
        '53g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_53_125GBS,
        '54g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_54_375GBS,
        '56g':  ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_56_25GBS,
    }

# -----------------------------------------------------------------------------
# MPIC/AUX 64G ComPhy (N3C64GP6X2) diagnostics ("phy status" signal-detect,
# "phy taps", "eyesurf") are driven through the SerDes-type-agnostic mvHwsSerdes*
# wrapper layer with serdesType == COM_PHY_N3C64GP6X2 - exactly how the
# front-panel 224G ComPhy is driven (COM_PHY_N3C224GX81PLL) from
# "diagtest serdes eth ... hws".  The C wrappers own the raw MCESD driver
# (API_N3C64GP6X2_*); those SDK APIs are intentionally NOT exposed to ifcs_ctypes.
#
# The wrapper dispatch routes COM_PHY_N3C64GP6X2 to the node's MPIC (dev_type 1)
# FuncPtrArray (registered by mvHwsComphyN3C64GP6X2SerdesFuncsInit); the 224G
# front-panel path stays on PIC (dev_type 0).  On the MPIC ComPhy serdesNum is
# the lane (0/1) and portGroup is unused.
#
# Symbols are resolved by name with getattr so the CLI degrades gracefully
# (prints a "rebuild" hint) on an older lib built before the 64G wrappers exist.
# -----------------------------------------------------------------------------

# gtGenTypes.h NA_8BIT_SIGNED: a Tx tap left at this sentinel is skipped by
# mvHwsSerdesManualTxConfig so only the requested taps are programmed.
_TAP_NA = 0x7F

_C64GX_UNAVAIL_MSG = (
    '64G ComPhy mvHwsSerdes* wrappers unavailable in ifcs_ctypes; rebuild ifcs '
    'so the N3C64GP6X2 SerDes wrappers (serdesType COM_PHY_N3C64GP6X2) are '
    'registered, then retry')


def _hws_sym(name):
    """Resolve an ifcs_ctypes symbol (mvHwsSerdes* wrapper / enum), or None."""
    return getattr(ifcs_ctypes, name, None)


def _c64gx_serdes_type():
    """MV_HWS_SERDES_TYPE enum value for the MPIC/AUX 64G ComPhy, or None."""
    return _hws_sym('COM_PHY_N3C64GP6X2')


def hws_log_callback(buff):
    """MCESD debug sink: print each fragment as-is (the C plotter supplies the
    newlines).  Identical to serdes_eth_t100.py's hws_log_callback so the 64G
    eye renders exactly like the front-panel "serdes eth ... hws" eye."""
    log_no_newline("%s" % compat_bytesToStr(buff))


class SerdesMgmtT100(object):
    PATTERNS = ('prbs7', 'prbs9', 'prbs11', 'prbs13',
                'prbs15', 'prbs16', 'prbs23', 'prbs31', 'prbs32')
    RATES = ('10g', '25g', '26g', '27g', '28g', '51g', '53g', '54g', '56g')
    EYES = ('mid', 'top', 'bot')

    @staticmethod
    def _hex_int(x):
        if isinstance(x, str) and x[:2] == '0x':
            return int(x, 16)
        return int(x, 10)

    def __init__(self, cli):
        self.cli = cli
        self.node_id = cli.node_id
        self.devport_obj = Devport(cli)
        self.tx_pattern = {}
        self.rx_pattern = {}
        self._build_parser()

    # -------------------------------------------------------------------------
    # argparse wiring (mirrors serdes_mgmt_tl10.py bist surface)
    # -------------------------------------------------------------------------
    def _build_parser(self):
        self.parser = parser = argparse.ArgumentParser(
            prog='diagtest serdes mgmt', add_help=True)
        parser.add_argument('--devport',
            help='all, one or more comma separated AUX devport numbers')
        parser.add_argument('--lane',
            help='MPIC lane number (0 or 1), comma separated, or all')
        sub_parsers = parser.add_subparsers()

        p = sub_parsers.add_parser('help')
        p.add_argument('cmd', nargs='?', default='')
        p.set_defaults(func=self._cli_help)

        bist = sub_parsers.add_parser('bist', help='Built-in Self Test (PRBS)')
        bsub = bist.add_subparsers()

        p = bsub.add_parser('on', help='Enable BIST (no-op prep on T100 AUX)')
        p.set_defaults(func=self._bist_on)

        p = bsub.add_parser('off', help='Disable BIST')
        p.set_defaults(func=self._bist_off)

        tx = bsub.add_parser('tx', help='BIST TX generator functions')
        tx_sub = tx.add_subparsers()
        p = tx_sub.add_parser('start', help='Start TX PRBS generator')
        p.add_argument('--pattern', type=str.lower, choices=self.PATTERNS,
                       default=_DEFAULT_PATTERN)
        p.add_argument('--rate', type=str.lower, choices=self.RATES,
                       default=_DEFAULT_RATE)
        p.set_defaults(func=self._bist_tx_start)
        p = tx_sub.add_parser('stop', help='Stop TX PRBS generator')
        p.set_defaults(func=self._bist_tx_stop)

        rx = bsub.add_parser('rx', help='BIST RX checker functions')
        rx_sub = rx.add_subparsers()
        p = rx_sub.add_parser('start', help='Start RX PRBS checker')
        p.add_argument('--pattern', type=str.lower, choices=self.PATTERNS,
                       default=_DEFAULT_PATTERN)
        p.add_argument('--rate', type=str.lower, choices=self.RATES,
                       default=_DEFAULT_RATE)
        p.set_defaults(func=self._bist_rx_start)
        p = rx_sub.add_parser('stop', help='Stop RX PRBS checker')
        p.set_defaults(func=self._bist_rx_stop)
        p = rx_sub.add_parser('reset', help='Reset RX PRBS error counter')
        p.set_defaults(func=self._bist_rx_reset)

        p = bsub.add_parser('status', help='BIST status')
        p.set_defaults(func=self._bist_status)

        phy = sub_parsers.add_parser('phy', help='Physical layer functions')
        phy_sub = phy.add_subparsers()

        p = phy_sub.add_parser('status', help='Show phy status')
        p.set_defaults(func=self._phy_status)

        # TX taps (N3C64GP6X2 TXEQ: PRE/MAIN/POST) on the MPIC/AUX 64G ComPhy.
        taps = phy_sub.add_parser('taps', help='TX Taps functions')
        taps_sub = taps.add_subparsers()

        p = taps_sub.add_parser('init', help='Set all TX taps (pre/main/post)')
        p.add_argument('--pre', type=SerdesMgmtT100._hex_int, required=True)
        p.add_argument('--main', type=SerdesMgmtT100._hex_int, required=True)
        p.add_argument('--post', type=SerdesMgmtT100._hex_int, required=True)
        p.set_defaults(func=self._phy_taps_init)

        p = taps_sub.add_parser('set', help='Override one or more TX taps')
        p.add_argument('--pre', type=SerdesMgmtT100._hex_int)
        p.add_argument('--main', type=SerdesMgmtT100._hex_int)
        p.add_argument('--post', type=SerdesMgmtT100._hex_int)
        p.set_defaults(func=self._phy_taps_set)

        p = taps_sub.add_parser('get', help='Get TX taps')
        p.set_defaults(func=self._phy_taps_get)

        p = taps_sub.add_parser('clear', help='Clear TX tap override (Tx FIR force)')
        p.add_argument('--pre', action='store_true')
        p.add_argument('--main', action='store_true')
        p.add_argument('--post', action='store_true')
        p.set_defaults(func=self._phy_taps_clear)

        p = sub_parsers.add_parser('link', help='Show link status')
        p.set_defaults(func=self._link_status)

        # Full 2D eye surf via the N3C64GP6X2 EOM engine.
        p = sub_parsers.add_parser(
            'eyesurf', help='Full eye surf (MPIC/AUX 64G ComPhy EOM)')
        p.add_argument('--filename', '-f', type=str, default=None,
                       help='Save the raw eye grid to <filename>-lane<N>.csv')
        p.add_argument('--eye', type=str.lower, choices=self.EYES, default='mid',
                       help='Eye slice to sample (10G NRZ AUX uses mid)')
        p.add_argument('--min-samples', dest='min_samples',
                       type=SerdesMgmtT100._hex_int, default=100000,
                       help='Minimum bits to sample per point')
        p.add_argument('--ber', type=int, default=1,
                       help='BER threshold in nano (1 => 1e-9)')
        p.add_argument('--phase-step', dest='phase_step', type=int, default=8,
                       help='Phase step size for the plot')
        p.add_argument('--voltage-step', dest='voltage_step', type=int, default=1,
                       help='Voltage step size for the plot')
        p.add_argument('--peak', '-p', type=int, default=None,
                       help='Accepted for TL10 compatibility (unused by EOM plot)')
        p.set_defaults(func=self._eyesurf_full)

    # -------------------------------------------------------------------------
    # MPIC C64GX / L1FW lane mapping helpers
    # -------------------------------------------------------------------------
    def _lanetriple_to_label(self, lanetriple):
        _ib, _pic, laneidx = lanetriple
        return 'Lane {}'.format(laneidx)

    def _mpic_lanetriples(self):
        aux_devports = self._get_all_aux_devports()
        if not aux_devports:
            raise CommandError('No AUX devports found')
        ib, pic, _ = serdes_eth_cmn.devport_portlane_to_ib_pic_piclane(
            aux_devports[0], 0)
        return [(ib, pic, ln) for ln in range(_NUM_MPIC_LANES)]

    def _get_lane_targets(self, devport, lane, required=False):
        """Return list of (devport, portlane, lanetriple) targets."""
        if devport is not None and lane is not None:
            raise CommandError('Specify either --devport or --lane, not both')

        if devport is not None:
            targets = []
            for dp in self._get_devports(devport):
                for pl in range(self.devport_obj.getNumLanes(dp)):
                    lt = serdes_eth_cmn.devport_portlane_to_ib_pic_piclane(dp, pl)
                    targets.append((dp, pl, lt))
            return targets

        if lane is not None:
            if lane == 'all':
                if required:
                    raise CommandError(
                        'Please supply a specific --devport or --lane number')
                return [(None, lt[2], lt) for lt in self._mpic_lanetriples()]
            if isinstance(lane, int):
                lane_list = [lane]
            else:
                try:
                    lane_list = [int(l, 10) for l in str(lane).split(',')]
                except ValueError:
                    raise CommandError(
                        'Invalid lane specification {}'.format(lane))
            ib, pic, _ = serdes_eth_cmn.devport_portlane_to_ib_pic_piclane(
                self._get_all_aux_devports()[0], 0)
            return [(None, ln, (ib, pic, ln)) for ln in lane_list]

        if required:
            raise CommandError('Please specify --devport or --lane option')
        return [(None, lt[2], lt) for lt in self._mpic_lanetriples()]

    def _port_fsm_state(self, lanetriple):
        if ifcs_t100 is None:
            return None
        ib, pic, laneidx = lanetriple
        portidx = mpic_xport.serdes_idx_to_port(lanetriple)
        fields = mpic_xport.pen.read_platform_pen(
            _PORT_STATE_PEN, portidx, ib=ib, pic=pic)
        return fields[0][1]

    def _port_is_up(self, lanetriple):
        if ifcs_t100 is None:
            return False
        state = self._port_fsm_state(lanetriple)
        if state is None:
            return False
        # Banded picmc: any state at/above PORT_UP (>=190) is up/maintenance.
        # T100 MPIC small-enum: "up" is exactly PORT_LINK_ESTABLISH_E.
        if _PORT_UP_STATE >= 190:
            return state >= _PORT_UP_STATE
        return state == _PORT_UP_STATE

    def _rx_state(self, lanetriple):
        eq_state, rx_mode = mpic_xport.get_rx_state(lanetriple)
        return eq_state, rx_mode

    def _signal_detected(self, eq_state):
        return eq_state not in ('No signal', 'Disabled')

    def _signal_detected_hw(self, lanetriple):
        """Signal detect from the MPIC/AUX 64G ComPhy (N3C64GP6X2) through the
        mvHwsSerdesSignalDetectGet() wrapper (serdesType COM_PHY_N3C64GP6X2).

        The wrapper routes to the node's MPIC (dev_type 1) FuncPtrArray and calls
        API_N3C64GP6X2_GetSquelchDetect() on the C-registered MCESD device; the
        raw SDK is never touched from Python (same model as the front-panel 224G
        ComPhy).  signalDet is already the inverse of squelch, so it is returned
        directly.  Returns True (signal) / False (no signal), or None if the
        wrapper is unavailable / fails so the caller can fall back to the RX-EQ
        heuristic.
        """
        _ib, _pic, laneidx = lanetriple
        sig_get = _hws_sym('mvHwsSerdesSignalDetectGet')
        stype = _c64gx_serdes_type()
        if sig_get is None or stype is None:
            log('phy status: 64G comPhy mvHwsSerdes* wrappers unavailable; '
                'falling back to eq-state signal detect')
            return None
        try:
            signal_det = ifcs_ctypes.GT_BOOL(0)
            # mvHwsSerdesSignalDetectGet(devNum, portGroup, serdesNum=lane,
            # serdesType, *signalDet) returns GT_OK (0) on success.
            rc = sig_get(self.node_id, 0, laneidx, stype, byref(signal_det))
            if rc != 0:
                return None
            return bool(signal_det.value)
        except Exception as e:                       # noqa: BLE001
            log('phy status: mvHwsSerdesSignalDetectGet failed on {} ({}); '
                'falling back to eq-state signal detect'.format(
                    self._lanetriple_to_label(lanetriple), e))
            return None

    def _serdes_enabled_hw(self, lanetriple):
        """SerDes enable (power-up) state from the MPIC/AUX 64G ComPhy through
        the mvHwsSerdesEnableGet() wrapper (serdesType COM_PHY_N3C64GP6X2).

        The wrapper routes to the node's MPIC (dev_type 1) FuncPtrArray and reads
        the lane's TX/RX power-up pins via API_N3C64GP6X2_GetPowerTx()/GetPowerRx()
        - i.e. the SDW wrapper LANE_CONTROL_0 bits the MPIC FW programs when it
        enables the lane.  Returns True (enabled) / False (disabled), or None if
        the wrapper is unavailable / fails.
        """
        _ib, _pic, laneidx = lanetriple
        en_get = _hws_sym('mvHwsSerdesEnableGet')
        stype = _c64gx_serdes_type()
        if en_get is None or stype is None:
            return None
        try:
            enabled = ifcs_ctypes.GT_BOOL(0)
            # mvHwsSerdesEnableGet(devNum, portGroup, serdesNum=lane,
            # serdesType, *enable) returns GT_OK (0) on success.
            rc = en_get(self.node_id, 0, laneidx, stype, byref(enabled))
            if rc != 0:
                return None
            return bool(enabled.value)
        except Exception as e:                       # noqa: BLE001
            log('phy status: mvHwsSerdesEnableGet failed on {} ({})'.format(
                self._lanetriple_to_label(lanetriple), e))
            return None

    # -------------------------------------------------------------------------
    # helpers
    # -------------------------------------------------------------------------
    def _get_devports(self, devport):
        if devport is None:
            raise CommandError('Please specify --devport <num>')

        if devport == 'all':
            devports = self._get_all_aux_devports()
            if not devports:
                raise CommandError('No AUX devports found')
            return devports

        try:
            devports = [int(d, 10) for d in str(devport).split(',')]
        except ValueError:
            raise CommandError('Invalid devport specification: {}'.format(devport))

        for dp in devports:
            dp_type = self.devport_obj.getType(dp)
            if dp_type != ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX:
                raise CommandError(
                    'devport {} is not an AUX/mgmt port'.format(dp))
        return devports

    def _get_all_aux_devports(self):
        devport_list = []

        def cb(node_id, dp, attr_count, attr_list, user_data):
            attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE]
            if attr.value.u32 == ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX:
                devport_list.append(dp)

        cb_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = cb_type(cb)

        rc = ifcs_ctypes.ifcs_devport_get_all(
            self.node_id, 0, None,
            compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t),
            None, None)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err('Failed to get all AUX devports, rc={}'.format(rc))
        return sorted(devport_list)

    def _attr_set(self, dp, pairs):
        attr_count = len(pairs)
        attr_list = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        for i, (attr_id, value) in enumerate(pairs):
            attr_list[i].id = attr_id
            attr_list[i].value.u32 = value
        rc = ifcs_ctypes.ifcs_devport_attr_set(
            self.node_id, dp, attr_count,
            compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err('devport {}: attr set failed, rc={}'.format(dp, rc))
        return rc

    # -------------------------------------------------------------------------
    # command handlers
    # -------------------------------------------------------------------------
    def _cli_help(self, devport, lane, cmd=''):
        if cmd == '':
            self.parser.print_help()
            return ifcs_ctypes.IFCS_SUCCESS
        parser = self.parser._subparsers._actions[-1].choices.get(cmd)
        if parser is None:
            log_err('Unknown command: {}'.format(cmd))
            return ifcs_ctypes.IFCS_INVAL
        parser.print_help()
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_on(self, devport, lane):
        # On T100 AUX the PRBS setup is fully handled by the tx/rx start
        # commands via L1FW; there is no global power-island override to
        # toggle as on TL10. Kept for command compatibility.
        log('BIST enabled (T100 AUX): run "bist tx start" / "bist rx start" '
            'per devport')
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_off(self, devport, lane):
        log('BIST disabled: ensure per-devport "bist tx stop" / "bist rx stop" '
            'were issued')
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_tx_start(self, devport, lane, pattern, rate):
        devports = self._get_devports(devport)
        poly = _poly_map()[pattern]
        prbs_rate = _rate_map()[rate]
        for dp in devports:
            lane_mask = self.devport_obj.getLaneMask(dp)
            if self.devport_obj.getAdminState(dp) == 1:
                self.devport_obj.setAdminState(dp, 0)
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_TX_RATE, prbs_rate),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY, poly),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR, 1),
            ])
            self.tx_pattern[dp] = pattern
            log('devport {}: PRBS TX started (pattern={}, rate={})'.format(
                dp, pattern, rate))
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_tx_stop(self, devport, lane):
        devports = self._get_devports(devport)
        for dp in devports:
            lane_mask = self.devport_obj.getLaneMask(dp)
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_TX_RATE,
                 ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR_POLY,
                 ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_GENERATOR, 0),
            ])
            self.tx_pattern.pop(dp, None)
            log('devport {}: PRBS TX stopped'.format(dp))
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_rx_start(self, devport, lane, pattern, rate):
        devports = self._get_devports(devport)
        poly = _poly_map()[pattern]
        prbs_rate = _rate_map()[rate]
        for dp in devports:
            lane_mask = self.devport_obj.getLaneMask(dp)
            if self.devport_obj.getAdminState(dp) == 1:
                self.devport_obj.setAdminState(dp, 0)
            # Configure and enable the RX checker ...
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_RX_RATE, prbs_rate),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY, poly),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER, 1),
            ])
            # ... then start the comparator (begins error accumulation).
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR, 1),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
            ])
            self.rx_pattern[dp] = pattern
            log('devport {}: PRBS RX started (pattern={}, rate={})'.format(
                dp, pattern, rate))
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_rx_stop(self, devport, lane):
        devports = self._get_devports(devport)
        for dp in devports:
            lane_mask = self.devport_obj.getLaneMask(dp)
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_RX_RATE,
                 ifcs_ctypes.IFCS_DEVPORT_SERDES_PRBS_RATE_NOTCONFIGURED),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER_POLY,
                 ifcs_ctypes.IFCS_DEVPORT_SERDES_POLYNOMIAL_NOTCONFIGURED),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_CHECKER, 0),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR, 0),
            ])
            self.rx_pattern.pop(dp, None)
            log('devport {}: PRBS RX stopped'.format(dp))
        return ifcs_ctypes.IFCS_SUCCESS

    def _bist_rx_reset(self, devport, lane):
        devports = self._get_devports(devport)
        for dp in devports:
            lane_mask = self.devport_obj.getLaneMask(dp)
            # Toggle the comparator off/on to reset the error accumulation.
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR, 0),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
            ])
            self._attr_set(dp, [
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_PRBS_COMPARATOR, 1),
                (ifcs_ctypes.IFCS_DEVPORT_ATTR_LANE_MASK, lane_mask),
            ])
            log('devport {}: PRBS RX error counter reset'.format(dp))
        return ifcs_ctypes.IFCS_SUCCESS

    def _prbs_status_get_safe(self, getter, dp):
        """Best-effort PRBS status read.

        A PRBS status read can legitimately fail at the devport layer (e.g. RX
        never reached a usable state because 'bist rx start' timed out), which
        surfaces as an exception from getAttr. Swallow it and return None so
        'bist status' still renders a table instead of aborting with a
        traceback.
        """
        try:
            return getter(dp)
        except Exception as ex:
            log_dbg(1, 'prbs status read {} failed on devport {}: {}'.format(
                getattr(getter, '__name__', getter), dp, ex))
            return None

    def _bist_status(self, devport, lane):
        devports = self._get_devports(devport)

        table = PrintTable()
        table.set_justification('left')

        header_row = ['']
        tx_row = ['TX pattern']
        rx_row = ['RX pattern']
        lock_row = ['Lock']
        err_row = ['Error count']
        ber_row = ['BER']

        for dp in devports:
            num_lanes = self.devport_obj.getNumLanes(dp)
            err_count = self._prbs_status_get_safe(self.devport_obj.getPrbsErrCount2, dp)
            ber = self._prbs_status_get_safe(self.devport_obj.getPrbsBer2, dp)
            lock = self._prbs_status_get_safe(self.devport_obj.getPrbsLock, dp)

            for i in range(num_lanes):
                header_row.append('dp{}/ln{}'.format(dp, i))
                tx_row.append(self.tx_pattern.get(dp, 'off'))
                rx_row.append(self.rx_pattern.get(dp, 'off'))

                locked = bool(lock) and i < len(lock) and lock[i]
                lock_row.append('yes' if locked else 'no')

                if locked and err_count and i < len(err_count):
                    err_row.append(err_count[i])
                else:
                    err_row.append('NO LOCK' if not locked else 'N/A')

                if locked and ber and i < len(ber):
                    ber_row.append(ber[i])
                else:
                    ber_row.append('N/A')

        table.add_row(header_row)
        table.add_row(tx_row)
        table.add_row(rx_row)
        table.add_row(lock_row)
        table.add_row(err_row)
        table.add_row(ber_row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    # -------------------------------------------------------------------------
    # phy / link / eyesurf diagnostic handlers (MPIC C64GX / L1FW backend)
    # -------------------------------------------------------------------------
    def _phy_status(self, devport, lane):
        targets = self._get_lane_targets(devport, lane)
        # Signal Detect is read from the MPIC/AUX 64G comPhy via the
        # mvHwsSerdesSignalDetectGet() wrapper (serdesType COM_PHY_N3C64GP6X2;
        # see _signal_detected_hw), falling back to the host-readable RX-EQ
        # state / port FSM when the wrapper is unavailable.

        header = ['']
        speed_row = ['Speed']
        enabled_row = ['Enabled']
        signal_detect_row = ['Signal Detect']
        pcs_link_row = ['PCS Link']
        loopback_row = ['Loopback']
        tx_invert_row = ['Invert TX']
        rx_invert_row = ['Invert RX']

        for dp, portlane, lanetriple in targets:
            label = self._lanetriple_to_label(lanetriple)
            header.append(label)
            speed_row.append('10G')
            eq_state, _ = self._rx_state(lanetriple)
            port_up = self._port_is_up(lanetriple)
            en = self._serdes_enabled_hw(lanetriple)
            if en is None:
                _get_en = getattr(mpic_xport, 'get_serdes_enabled', None)
                en = _get_en(lanetriple) if _get_en is not None else None
            enabled_row.append('n/a' if en is None else ('yes' if en else 'no'))
            sig = self._signal_detected_hw(lanetriple)
            if sig is None:
                sig = self._signal_detected(eq_state)
            signal_detect_row.append('yes' if sig else 'no')
            pcs_link_row.append('up' if port_up else 'down')
            loopback_row.append('n/a')
            tx_invert_row.append('n/a')
            rx_invert_row.append('n/a')

        table = PrintTable()
        table.set_justification('left')
        table.add_row(header)
        table.add_row(speed_row)
        table.add_row(enabled_row)
        table.add_row(signal_detect_row)
        table.add_row(pcs_link_row)
        table.add_row(loopback_row)
        table.add_row(tx_invert_row)
        table.add_row(rx_invert_row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _link_status(self, devport, lane):
        targets = self._get_lane_targets(devport, lane)
        table = PrintTable()
        table.set_justification('left')
        table.add_row(['', 'Lane 0', 'Lane 1'])

        lane_data = {0: {}, 1: {}}
        for dp, portlane, lanetriple in targets:
            _, _, laneidx = lanetriple
            if laneidx not in (0, 1):
                continue
            port_up = self._port_is_up(lanetriple)
            fsm = self._port_fsm_state(lanetriple)

            # Direct PCIe reads of the MTIP PCS/MAC registers (same method TL10
            # uses for its MPICn_* registers, e.g.
            # pci.read32(ifcs_ctypes.MID_DAT32)).  MAC_UNITS__STATUS carries the
            # fault bits and PHY_LOS in one word; signal is present when PHY_LOS
            # is 0.  Fetch that register once.
            mtip_stat = pci.read32(_MTIP_PORT_STATUS_REG[laneidx])
            mac_stat = pci.read32(_MAC_UNITS_STATUS_REG[laneidx])
            lane_data[laneidx] = {
                'fsm': fsm if fsm is not None else '',
                'pma_rx_signal_detect':
                    0 if mac_stat & _MAC_PHY_LOS_MASK else 1,
                'pcs': 'up' if port_up else 'down',
                'block_lock': 1 if mtip_stat & _MTIP_LINK_STATUS_MASK else 0,
                'remote_fault': 1 if mac_stat & _MAC_RX_REM_FAULT_MASK else 0,
                'local_fault': 1 if mac_stat & _MAC_RX_LOC_FAULT_MASK else 0,
            }

        for row_name, key in (
                ('Port FSM', 'fsm'),
                ('pma_rx_signal_detect', 'pma_rx_signal_detect'),
                ('PCS Link', 'pcs'),
                ('pcs_10g_block_lock', 'block_lock'),
                ('remote_fault', 'remote_fault'),
                ('local_fault', 'local_fault')):
            row = [row_name]
            for ln in range(_NUM_MPIC_LANES):
                row.append(lane_data.get(ln, {}).get(key, ''))
            table.add_row(row)

        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    # -------------------------------------------------------------------------
    # TX taps (N3C64GP6X2 TXEQ) on the MPIC/AUX 64G ComPhy - via mvHwsSerdes*
    # -------------------------------------------------------------------------
    def _c64gx_hws(self, action, *wrapper_names):
        """Resolve the MPIC 64G serdesType + the named mvHwsSerdes* wrapper(s).

        Returns a tuple (serdesType, wrapper0, wrapper1, ...) or None (after
        logging the rebuild hint) if the serdesType enum or any wrapper is
        missing from ifcs_ctypes (older lib built before the 64G wrappers).
        """
        stype = _c64gx_serdes_type()
        wrappers = [_hws_sym(n) for n in wrapper_names]
        if stype is None or any(w is None for w in wrappers):
            log_err('{}: {}'.format(action, _C64GX_UNAVAIL_MSG))
            return None
        return (stype,) + tuple(wrappers)

    def _phy_taps_get(self, devport, lane):
        res = self._c64gx_hws('phy taps get', 'mvHwsSerdesManualTxConfigGet')
        if res is None:
            return ifcs_ctypes.IFCS_INVAL
        stype, get_cfg = res

        targets = self._get_lane_targets(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        rows = [('pre2', ['PRE2']), ('pre', ['PRE']),
                ('main', ['MAIN']), ('post', ['POST'])]
        header = ['Tap']
        for _dp, _pl, lanetriple in targets:
            _ib, _pic, laneidx = lanetriple
            header.append(self._lanetriple_to_label(lanetriple))
            unt = ifcs_ctypes.MV_HWS_SERDES_TX_CONFIG_DATA_UNT()
            # mvHwsSerdesManualTxConfigGet(devNum, portGroup, serdesNum=lane,
            # serdesType, *txConfig) -> GT_OK (0) on success.
            rc = get_cfg(self.node_id, 0, laneidx, stype, byref(unt))
            tx = unt.txComphyC64GP6X2
            vals = {'pre2': tx.pre2, 'pre': tx.pre, 'main': tx.main,
                    'post': tx.post}
            for key, row in rows:
                row.append(vals[key] if rc == 0 else 'ERR')

        table.add_row(header)
        for _key, row in rows:
            table.add_row(row)
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _phy_taps_set(self, devport, lane, pre, main, post):
        res = self._c64gx_hws('phy taps set', 'mvHwsSerdesManualTxConfig')
        if res is None:
            return ifcs_ctypes.IFCS_INVAL
        stype, set_cfg = res
        if pre is None and main is None and post is None:
            log_err('phy taps set: specify at least one of --pre/--main/--post')
            return ifcs_ctypes.IFCS_INVAL

        targets = self._get_lane_targets(devport, lane, required=True)
        for _dp, _pl, lanetriple in targets:
            _ib, _pic, laneidx = lanetriple
            unt = ifcs_ctypes.MV_HWS_SERDES_TX_CONFIG_DATA_UNT()
            tx = unt.txComphyC64GP6X2
            # Only the requested taps are programmed; the rest stay at the NA
            # sentinel so mvHwsSerdesManualTxConfig() leaves them untouched.
            tx.pre3 = _TAP_NA
            tx.pre2 = _TAP_NA
            tx.pre  = _TAP_NA if pre  is None else pre
            tx.main = _TAP_NA if main is None else main
            tx.post = _TAP_NA if post is None else post
            rc = set_cfg(self.node_id, 0, laneidx, stype, byref(unt))
            if rc != 0:
                log_err('{}: set taps failed (rc={})'.format(
                    self._lanetriple_to_label(lanetriple), rc))
            else:
                log('{}: taps set (pre={} main={} post={})'.format(
                    self._lanetriple_to_label(lanetriple),
                    'skip' if pre is None else pre,
                    'skip' if main is None else main,
                    'skip' if post is None else post))
        return ifcs_ctypes.IFCS_SUCCESS

    def _phy_taps_init(self, devport, lane, pre, main, post):
        res = self._c64gx_hws('phy taps init', 'mvHwsSerdesManualTxConfig')
        if res is None:
            return ifcs_ctypes.IFCS_INVAL
        stype, set_cfg = res

        targets = self._get_lane_targets(devport, lane, required=True)
        for _dp, _pl, lanetriple in targets:
            _ib, _pic, laneidx = lanetriple
            unt = ifcs_ctypes.MV_HWS_SERDES_TX_CONFIG_DATA_UNT()
            tx = unt.txComphyC64GP6X2
            tx.pre3 = _TAP_NA   # unused on 10G NRZ AUX
            tx.pre2 = 0         # pre2=0 for 10G NRZ AUX
            tx.pre  = pre
            tx.main = main
            tx.post = post
            rc = set_cfg(self.node_id, 0, laneidx, stype, byref(unt))
            if rc != 0:
                log_err('{}: init taps failed (rc={})'.format(
                    self._lanetriple_to_label(lanetriple), rc))
            else:
                log('{}: taps set pre={} main={} post={}'.format(
                    self._lanetriple_to_label(lanetriple), pre, main, post))
        return ifcs_ctypes.IFCS_SUCCESS

    def _phy_taps_clear(self, devport, lane, pre, main, post):
        # The N3C64GP6X2 driver releases the TX FIR force as a unit (there is no
        # per-tap override-clear like the TL10 Torrent path); the --pre/--main/
        # --post flags are accepted for CLI symmetry.
        res = self._c64gx_hws('phy taps clear',
                              'mvHwsComphyEnableDisableTxFirForce')
        if res is None:
            return ifcs_ctypes.IFCS_INVAL
        stype, fir_force = res

        targets = self._get_lane_targets(devport, lane, required=True)
        for _dp, _pl, lanetriple in targets:
            _ib, _pic, laneidx = lanetriple
            # flag=GT_FALSE (0) releases the force (taps -> trained/default);
            # the tx-config pointer is unused for the release path (NULL).
            rc = fir_force(self.node_id, 0, laneidx, stype, 0, None)
            if rc != 0:
                log_err('{}: clear taps (disable Tx FIR force) failed (rc={})'
                        .format(self._lanetriple_to_label(lanetriple), rc))
            else:
                log('{}: TX FIR force disabled (taps cleared)'.format(
                    self._lanetriple_to_label(lanetriple)))
        return ifcs_ctypes.IFCS_SUCCESS

    # -------------------------------------------------------------------------
    # eye surf (N3C64GP6X2 EOM engine) - via mvHwsSerdesEomMatrixGetByType
    # -------------------------------------------------------------------------
    def _eyesurf_full(self, devport, lane, filename, eye, min_samples, ber,
                      phase_step, voltage_step, peak):
        res = self._c64gx_hws('eyesurf', 'mvHwsSerdesEomMatrixGetByType')
        if res is None:
            return ifcs_ctypes.IFCS_INVAL
        stype, eom_get = res

        # Same mechanism as serdes_eth_t100.py cli_mvHwsSerdesEomMatrixGet: the
        # MCESD driver renders the eye through its own C plotter, emitting the
        # ASCII grid a fragment at a time via the MCESD debug sink.  Register a
        # Python sink (mvHwsMcesdLogInit) that prints each fragment (the C side
        # supplies the newlines) and deregister after the capture.
        cb = None
        if _hws_sym('mvHwsMcesdLogInit') is not None:
            cb = ifcs_ctypes.CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                                       ifcs_ctypes.c_char_p)(hws_log_callback)
        else:
            log_err('eyesurf: mvHwsMcesdLog* wrappers unavailable in ifcs_ctypes'
                    ' (rebuild ifcs); eye width/height will still be reported '
                    'but the plot cannot be rendered')

        if filename is not None:
            log('eyesurf: --filename is not used on the 64G ComPhy path (the '
                'eye is rendered inline, same as "serdes eth ... hws")')

        targets = self._get_lane_targets(devport, lane)
        for _dp, _pl, lanetriple in targets:
            _ib, _pic, laneidx = lanetriple
            label = self._lanetriple_to_label(lanetriple)
            log('{}: capturing eye (min_samples={}, ber=1e-9*{})...'
                .format(label, min_samples, ber))

            in_unt = ifcs_ctypes.MV_HWS_SERDES_EOM_IN_PARAMS_UNT()
            p = in_unt.comphyC64GP6X2EomInParams
            p.minSamples = min_samples
            p.berThreshold = ber
            p.berThresholdMax = ber
            p.eomStatsMode = 0            # full 2D sweep (all phases x voltages)
            p.phaseStepSize = phase_step
            p.voltageStepSize = voltage_step

            out_unt = ifcs_ctypes.MV_HWS_SERDES_EOM_OUT_PARAMS_UNT()

            if cb is not None:
                ifcs_ctypes.mvHwsMcesdLogInit(
                    self.node_id,
                    compat_funcPointer(
                        cb, ifcs_ctypes.MV_HWS_MCESD_LOG_USER_CB_FUNC_PTR))
            # printEn=GT_TRUE (1) makes the wrapper call EOMPlotEyeData.
            rc = eom_get(self.node_id, 0, laneidx, stype, 1,
                         byref(in_unt), byref(out_unt))
            if cb is not None:
                ifcs_ctypes.mvHwsMcesdLogDeInit(self.node_id)

            if rc != 0:
                log_err('{}: EOM eye capture failed (rc={}); a ~50% BER at the '
                        'eye center means no open eye - ensure the lane is '
                        'linked/CDR-locked and carrying traffic/PRBS'
                        .format(label, rc))
                continue

            o = out_unt.comphyC64GP6X2EomOutParams
            # Index 0 == MID eye slice (the sampled one).
            log('{}: eye width={} mUI, height={} mV, samples={}'.format(
                label, o.width_mUI[0], o.height_mV[0], o.sampleCount[0]))
        return ifcs_ctypes.IFCS_SUCCESS

    # -------------------------------------------------------------------------
    # dispatch
    # -------------------------------------------------------------------------
    def dispatch(self, args_list):
        try:
            args = self.parser.parse_args(args_list)
        except SystemExit:
            # argparse already printed the error/usage
            return ifcs_ctypes.IFCS_INVAL

        if not hasattr(args, 'func'):
            self.parser.print_help()
            return ifcs_ctypes.IFCS_INVAL

        kwargs = vars(args)
        func = kwargs.pop('func')
        log_dbg(1, 'serdes mgmt t100 args: {}'.format(kwargs))
        try:
            return func(**kwargs)
        except CommandError as cmd_err:
            log_err('{}'.format(cmd_err))
            return getattr(cmd_err, 'rc', None) or ifcs_ctypes.IFCS_INVAL
        except Exception as ex:
            log_err(str(ex))
            log(traceback.format_exc())
            return ifcs_ctypes.IFCS_INVAL

_instances = {}

def run_cmd(serdes_cmd, args):
    """
    Entry point invoked from serdes.py's mgmt() dispatcher for T100.

    serdes_cmd : the serdes.py Serdes command instance (provides .cli/.node_id)
    args       : full command string, e.g.
                 "diagtest serdes mgmt --devport 513 bist tx start --pattern prbs31"
    """
    cli = serdes_cmd.cli
    node_id = cli.node_id

    inst = _instances.get(node_id)
    if inst is None:
        inst = SerdesMgmtT100(cli)
        _instances[node_id] = inst

    # Drop the leading "diagtest serdes mgmt" tokens.
    arg_list = shlex.split(args)[3:]
    return inst.dispatch(arg_list)
