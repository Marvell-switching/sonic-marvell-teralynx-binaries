
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import sys
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from ifcs_cmds.all import *
from print_table import PrintTable
from pen_list import *

# Class implements Ifcs related commands

class Hardware(Command):
    def __init__(self, cli):
        self.hw_counter_display_method = {
            'port': self.display_port_hardware_stats,
            'ib': self.display_ib_hardware_stats,
            'partition': self.display_partition_hardware_stats,
            'queue': self.display_queue_hardware_stats,
            'global': self.display_global_hardware_stats,
        }
        self.hw_counter_clear_method = {
            'port': self.clear_port_hardware_stats,
            'ib': self.clear_ib_hardware_stats,
            'partition': self.clear_partition_hardware_stats,
            'queue': self.clear_queue_hardware_stats,
            'global': self.clear_global_hardware_stats,
        }
        self.supported_operands = ['port','ib','partition','global','queue']
        self.cli = cli
        self.arg_list = []
        super(Hardware, self).__init__()
        self.ifcs_names = ['port', 'l2vni']
        self.help_str = "ifcs:        IFCS object cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In hardware run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            rc = self.sub_cmds[self.arg_list[1]](args)
            return rc
        except (KeyError):
            log_dbg(1, "IfcsKeyError")
            self.help(args)
            return IFCS_FAIL
        except (ValueError):
            log_dbg(1, "IfcsValueError")
            self.help(args)
            return IFCS_FAIL
        except BaseException:
            log_dbg(1, "IfcsOtherError")
            self.help(args)
            return IFCS_FAIL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        log(cmd, remline, line)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper()
                    for i in self.ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.ifcs_names if i.lower().startswith(text)]

    complete_port = complete_show
    complete_ib = complete_show
    complete_queue = complete_show
    complete_partition = complete_show
    complete_global = complete_show

    def display_ib_hardware_stats(self, args):
        log_dbg(1,"In display_ib_hardware_stats: " + (str(args)))

        try:
            ib_num = args.split()[5]
        except:
            log_err("Need an ib number")
            log_err("Usage: ifcs show counters hardware ib <ib_num>")
            return

        args = {}
        args['ib'] = ib_num
        print_buf = {}
        for block, pens in compat_iteritems(per_ib_pens):
            print_buf[block] = []
            for entry in pens:
                idx_range = entry[1]
                if entry[2] == "NO":
                    args['pen_name'] = entry[0]
                elif entry[2] == "YES":
                    args['pen_name'] = entry[0] % ({'ib': ib_num})
                for idx in range(idx_range):
                    args['idx'] = idx
                    cmd = ib_pen_read_cmd % (args)
                    print_buf[block].append([args['pen_name'], cmd])
        self.print_function("IB", ib_num, print_buf)

    def display_queue_hardware_stats(self, args):
        log_dbg(1,"In display_queue_hardware_stats: " + (str(args)))

        try:
            queue = args.split()[5]
            ib_num = args.split()[7]
        except:
            log_err("Need an ib number")
            log_err("Usage: ifcs show counters hardware queue <queue-num> ib <ib_num>")
            return

        args = {}
        args['queue'] = queue
        args['ib'] = ib_num
        print_buf = {}
        for block, pens in compat_iteritems(per_queue_pens):
            print_buf[block] = []
            for entry in pens:
                idx_range = entry[1]
                if entry[2] == "NO":
                    args['pen_name'] = entry[0]
                elif entry[2] == "YES":
                    args['pen_name'] = entry[0] % ( args )
                for idx in range(idx_range):
                    args['idx'] = idx
                    cmd = ib_pen_read_cmd % (args)
                    print_buf[block].append([args['pen_name'],cmd])
        self.print_function("QUEUE", queue, print_buf)

    def display_partition_hardware_stats(self, args):
        log_dbg(1,"In display_partition_hardware_stats: " + (str(args)))

        try:
            partition = args.split()[5]
            ib_num = args.split()[7]
        except:
            log_err("Need an ib number")
            log_err("Usage: ifcs show counters hardware partition <partition_num> ib <ib_num>")
            return

        args = {}
        args['partition'] = partition
        args['ib'] = ib_num
        print_buf = {}
        for block, pens in compat_iteritems(per_partition_pens):
            print_buf[block] = []
            for entry in pens:
                idx_range = entry[1]
                if entry[2] == "NO":
                    args['pen_name'] = entry[0]
                elif entry[2] == "YES":
                    args['pen_name'] = entry[0] % ( args )
                for idx in range(idx_range):
                    args['idx'] = idx
                    cmd = ib_pen_read_cmd % (args)
                    print_buf[block].append([args['pen_name'],cmd])
        self.print_function("PARTITION", partition, print_buf)

    def display_port_hardware_stats(self, args):
        log_dbg(1,"In display_port_hardware_stats: " + (str(args)))

        try:
            port = args.split()[5]
        except:
            log_err("Need a port number")
            log_err("Usage: ifcs show counters hardware port <port-num>")
            return

        ib = c_uint32(0)
        ibp = c_uint32(0)

        ifcs_ctypes.im_devport_get_ibibp(self.cli.node_id, int(port), pointer(ib), pointer(ibp))
        args = {}
        args['port'] = port
        args['ib'] = ib.value
        print_buf = {}
        pen_buf = []

        for block, pens in compat_iteritems(per_port_pens):
            print_buf[block] = []
            for entry in pens:
                idx_range = entry[1]
                if entry[2] == "NO":
                    args['pen_name'] = entry[0]
                elif entry[2] == "YES":
                    args['pen_name'] = entry[0] % ({'ib': ib.value})
                if int(idx_range) == 1:
                    args['idx'] = int(idx_range) - 1
                else:
                    args['idx'] = int(port)
                cmd = ib_pen_read_cmd % (args)
                print_buf[block].append([args['pen_name'], cmd])
        self.print_function("PORT", port, print_buf)

    def display_global_hardware_stats(self, args):
        log_dbg(1,"In display_global_hardware_stats ")
        log("Currently not supported")

    def clear_ib_hardware_stats(self, args):
        log(args)
        log("Currently not supported")
    def clear_partition_hardware_stats(self, args):
        log(args)
        log("Currently not supported")
    def clear_queue_hardware_stats(self, args):
        log(args)
        log("Currently not supported")
    def clear_queue_hardware_stats(self, args):
        log(args)
        log("Currently not supported")
    def clear_port_hardware_stats(self, args):
        log(args)
        log("Currently not supported")
    def clear_global_hardware_stats(self, args):
        log(args)
        log("Currently not supported")

    def help(self, args):
        log(args)
        log("Currently not supported")

    def print_function(self, type, num, print_buf):
        if self.cli.redirect_fd:
            log("--------------------------------------------------")
            self.cli.redirect_fd.write("--------------------------------------------------\n")
            self.cli.redirect_fd.write(" HARDWARE STATISTICS PER {0} FOR {1}:{2}\n".format(type, type, num))
            log(" HARDWARE STATISTICS PER {0} FOR {1}:{2}".format(type, type, num))
            self.cli.redirect_fd.write("--------------------------------------------------\n")
            log("--------------------------------------------------")
            for block, pen_entries in compat_iteritems(print_buf):
                self.cli.redirect_fd.write("BLOCK : " + block.upper() + "\n")
                log("BLOCK : " + block.upper())
                self.cli.redirect_fd.write("=====\n")
                log("======")
                for entry in pen_entries:
                    self.cli.redirect_fd.write("PEN : " + entry[0] + "\n")
                    log("PEN : " + entry[0])
                    self.cli.redirect_fd.write("=====\n")
                    log("====")
                    self.cli.onecmd(entry[1])
        else:
            log("Enable file redirect. \" redirect /path/to/file/ \" ")
