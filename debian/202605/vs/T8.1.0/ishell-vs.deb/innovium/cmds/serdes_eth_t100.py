#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import argparse
import shlex
import time
import math
import numpy as np
import threading
import ifcs_ctypes as ifcs
import copy
import os
from verbosity import *
from N3C224GX81PLL_fields import lookup as reg_map_lookup
from argparse import RawTextHelpFormatter
try:
    import scipy
    import scipy.stats
    import scipy.optimize
    no_scipy = False
except:
    no_scipy = True

from utils.compat_util import *
import re,sys,traceback
import serdes_eth_cmn
import testutil.t100_comphy_transport as xport

default_isg_list = None
default_serdes_list = [0]

# Functions for "screen painting", for continuously updating output
global paint_lines_output
paint_lines_output = 0

encoding_map = {ifcs.SERDES_ENCODING_NA   : "N/A",
                ifcs.SERDES_ENCODING_NRZ  : "NRZ",
                ifcs.SERDES_ENCODING_PAM4 : "PAM4"}
enc_type_enum_to_str_dict = dict([(key, value) for key, value in encoding_map.items() if key != ifcs.SERDES_ENCODING_NA])
enc_type_str_to_enum_dict = dict([(key, value) for value, key in enc_type_enum_to_str_dict.items()])
enc_type_str_list  = list(enc_type_enum_to_str_dict.values())
enc_type_enum_list = list(enc_type_str_to_enum_dict.values())


speed_map = {ifcs.SPEED_NA     : "N/A",
             ifcs._10G         : "10G",
             ifcs._10_1376G    : "10.1376G",
             ifcs._10_3125G    : "10.3125G",
             ifcs._10_5188G    : "10.5188G",
             ifcs._25_78125G   : "25.78125G",
             ifcs._26_5625G    : "26.5625G",
             ifcs._27_1875G    : "27.1875G",
             ifcs._27_5G       : "27.5G",
             ifcs._28_05G      : "28.05G",
             ifcs._28_125G     : "28.125G",
             ifcs._50G         : "50G",
             ifcs._51_5625G_P4 : "51.5625G",
             ifcs._53_125G_P4  : "53.125G",
             ifcs._56G         : "56G",
             ifcs._56_1G_P4    : "56.1G",
             ifcs._56_25G_P4   : "56.25G",
             ifcs._57_8G_P4    : "57.8G",
             ifcs._106_25G_P4  : "106.25G",
             ifcs._112G_P4     : "112G",
             ifcs._112_2G_P4   : "112.2G",
             ifcs._112_5G_P4   : "112.5G",
             ifcs._200G_P4     : "200G",
             ifcs._212_5G_P4   : "212.5G",
             ifcs._224G_P4     : "224G",
             ifcs._113_4375G_P4: "113.4375G",
             ifcs._226_875G_P4 : "226.875G",
             ifcs._10G_AN      : "10G_AN"}


speed_enum_to_str_dict = dict([(key, value) for key, value in speed_map.items() if key != ifcs.SPEED_NA])
speed_str_to_enum_dict = dict([(key, value) for value, key in speed_enum_to_str_dict.items()])
speed_str_list  = list(speed_enum_to_str_dict.values())
speed_enum_list = list(speed_str_to_enum_dict.values())

bus_width_map = {ifcs._BUS_WIDTH_NA :  "N/A",
                 ifcs._32BIT_ON     :  "32BIT",
                 ifcs._64BIT_ON     :  "64BIT",
                 ifcs._128BIT_ON    :  "128BIT",
                 ifcs._256BIT_ON    :  "256BIT"}
bus_width_enum_to_str_dict = dict([(key, value) for key, value in bus_width_map.items() if key != ifcs._BUS_WIDTH_NA])
bus_width_str_to_enum_dict = dict([(key, value) for value, key in bus_width_enum_to_str_dict.items()])
bus_width_str_list  = list(bus_width_enum_to_str_dict.values())
bus_width_enum_list = list(bus_width_str_to_enum_dict.values())

ref_clk_map = {ifcs._REF_CLOCK_NA : "N/A",
               ifcs._25Mhz       : "25MHZ",
               ifcs._30Mhz       : "30MHZ",
               ifcs._40Mhz       : "40MHZ",
               ifcs._50Mhz       : "50MHZ",
               ifcs._62_5Mhz     : "62.5MHZ",
               ifcs._100Mhz      : "100MHZ",
               ifcs._125Mhz      : "125MHZ",
               ifcs._156_25Mhz   : "156.25MHZ",
               ifcs._212_5Mhz    : "212.5MHZ",
               ifcs._312_5Mhz    : "312.5MHZ",
              }

ref_clk_enum_to_str_dict = dict([(key, value) for key, value in ref_clk_map.items() if key != ifcs._REF_CLOCK_NA])
ref_clk_str_to_enum_dict = dict([(key, value) for value, key in ref_clk_enum_to_str_dict.items()])
ref_clk_str_list  = list(ref_clk_enum_to_str_dict.values())
ref_clk_enum_list = list(ref_clk_str_to_enum_dict.values())

ref_clk_src_enum_to_str_dict = {ifcs.PRIMARY   : "PRIMARY",
                                ifcs.SECONDARY : "SECONDARY"}
ref_clk_src_str_to_enum_dict = dict([(key, value) for value, key in ref_clk_src_enum_to_str_dict.items()])
ref_clk_src_str_list  = list(ref_clk_src_enum_to_str_dict.values())
ref_clk_src_enum_list = list(ref_clk_src_str_to_enum_dict.values())

lbmode_enum_to_str_dict = {ifcs.SERDES_LP_DISABLE   : "NONE",
                           ifcs.SERDES_LP_AN_TX_RX  : "ANALOG_TX_RX",
                           ifcs.SERDES_LP_DIG_RX_TX : "DIGITAL_RX_TX"}
lbmode_str_to_enum_dict = dict([(key, value) for value, key in lbmode_enum_to_str_dict.items()])
lbmode_str_list  = list(lbmode_enum_to_str_dict.values())
lbmode_enum_list = list(lbmode_str_to_enum_dict.values())

reset_type_enum_to_str_dict = {ifcs.SOFT_RESET      : "SOFT",
                               ifcs.RF_RESET        : "RF",
                               ifcs.CORE_RX_RESET   : "CORE_RX",
                               ifcs.CORE_TX_RESET   : "CORE_TX",
                               ifcs.CORE_TXRX_RESET : "CORE_TXRX"}
reset_type_str_to_enum_dict = dict([(key, value) for value, key in reset_type_enum_to_str_dict.items()])
reset_type_str_list  = list(reset_type_enum_to_str_dict.values())
reset_type_enum_list = list(reset_type_str_to_enum_dict.values())

preset_init_enum_to_str_dict = {ifcs.PRESET_INIT_PRESET1 : "PRESET1",
                                ifcs.PRESET_INIT_PRESET2 : "PRESET2",
                                ifcs.PRESET_INIT_PRESET3 : "PRESET3",
                                ifcs.PRESET_INIT_PRESET4 : "PRESET4",
                                ifcs.PRESET_INIT_PRESET5 : "PRESET5",
                                ifcs.PRESET_INIT_INIT    : "PRESET_INIT"}
preset_init_str_to_enum_dict = dict([(key, value) for value, key in preset_init_enum_to_str_dict.items()])
preset_init_str_list  = list(preset_init_enum_to_str_dict.values())
preset_init_enum_list = list(preset_init_str_to_enum_dict.values())

min_samples_enum_to_str_dict = {ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_3_E : "10_3_E",
                                ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_4_E : "10_4_E",
                                ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_5_E : "10_5_E",
                                ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_6_E : "10_6_E",
                                ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_7_E : "10_7_E",
                                ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_8_E : "10_8_E",
                                ifcs.MV_HWS_PORT_SERDES_MIN_SAMPLES_ORDER_10_9_E : "10_9_E"
                               }
min_samples_str_to_enum_dict = dict([(key, value) for value, key in min_samples_enum_to_str_dict.items()])
min_samples_str_list  = list(min_samples_enum_to_str_dict.values())
min_samples_enum_list = list(min_samples_str_to_enum_dict.values())

ber_threshold_enum_to_str_dict = {ifcs.MV_HWS_PORT_SERDES_BER_THRESHOLD_ORDER_10_3_E : "10_3_E",
                                  ifcs.MV_HWS_PORT_SERDES_BER_THRESHOLD_ORDER_10_4_E : "10_4_E",
                                  ifcs.MV_HWS_PORT_SERDES_BER_THRESHOLD_ORDER_10_5_E : "10_5_E",
                                  ifcs.MV_HWS_PORT_SERDES_BER_THRESHOLD_ORDER_10_6_E : "10_6_E",
                                 }
ber_threshold_str_to_enum_dict = dict([(key, value) for value, key in ber_threshold_enum_to_str_dict.items()])
ber_threshold_str_list  = list(ber_threshold_enum_to_str_dict.values())
ber_threshold_enum_list = list(ber_threshold_str_to_enum_dict.values())

prbs_enum_to_str_dict = {
                         ifcs._1T          :   "_1T",
                         ifcs._2T          :   "_2T",
                         ifcs._5T          :   "_5T",
                         ifcs._8T          :   "_8T",
                         ifcs._10T         :   "_10T",
                         ifcs.USER         :   "USER",
                         ifcs.SSPRQ        :   "SSPRQ",
                         ifcs.JITTER_K28P5 :   "JITTER_K28P5",
                         ifcs.JITTER_1T    :   "JITTER_1T",
                         ifcs.JITTER_2T    :   "JITTER_2T",
                         ifcs.JITTER_4T    :   "JITTER_4T",
                         ifcs.JITTER_5T    :   "JITTER_5T",
                         ifcs.JITTER_8T    :   "JITTER_8T",
                         ifcs.JITTER_10T   :   "JITTER_10T",
                         ifcs.PRBS7        :   "PRBS7",
                         ifcs.PRBS9        :   "PRBS9",
                         ifcs.PRBS11       :   "PRBS11",
                         ifcs.PRBS11_0     :   "PRBS11_0",
                         ifcs.PRBS11_1     :   "PRBS11_1",
                         ifcs.PRBS11_2     :   "PRBS11_2",
                         ifcs.PRBS11_3     :   "PRBS11_3",
                         ifcs.PRBS15       :   "PRBS15",
                         ifcs.PRBS16       :   "PRBS16",
                         ifcs.PRBS23       :   "PRBS23",
                         ifcs.PRBS31       :   "PRBS31",
                         ifcs.PRBS32       :   "PRBS32",
                         ifcs.PRBS13_0     :   "PRBS13_0",
                         ifcs.PRBS13_1     :   "PRBS13_1",
                         ifcs.PRBS13_2     :   "PRBS13_2",
                         ifcs.PRBS13_3     :   "PRBS13_3"}
prbs_str_to_enum_dict = dict([(key, value) for value, key in prbs_enum_to_str_dict.items()])
prbs_str_list  = list(prbs_enum_to_str_dict.values())
prbs_enum_list = list(prbs_str_to_enum_dict.values())

acq_rate_enum_to_str_dict = {ifcs.RATE_QUARTER :  "QUARTER",
                             ifcs.RATE_HALF    :  "HALF",
                             ifcs.RATE_FULL    :  "FULL",
                             ifcs.RATE_UNKNOWN :  "UNKNOWN"}
acq_rate_str_to_enum_dict = dict([(key, value) for value, key in acq_rate_enum_to_str_dict.items()])
acq_rate_str_list  = list(acq_rate_enum_to_str_dict.values())
acq_rate_enum_list = list(acq_rate_str_to_enum_dict.values())

power_level_enum_to_str_dict = {ifcs.SERDES_POWER_LEVEL_LR:  "LR",
                             ifcs.SERDES_POWER_LEVEL_MR:  "MR"}
power_level_str_to_enum_dict = dict([(key, value) for value, key in power_level_enum_to_str_dict.items()])
power_level_str_list  = list(power_level_enum_to_str_dict.values())
power_level_enum_list = list(power_level_str_to_enum_dict.values())

test_gen_mode_enum_to_str_dict = {ifcs.SERDES_NORMAL : "NORMAL",
                                  ifcs.SERDES_TEST   : "TEST"}
test_gen_mode_str_to_enum_dict = dict([(key, value) for value, key in test_gen_mode_enum_to_str_dict.items()])
test_gen_mode_str_list  = list(test_gen_mode_enum_to_str_dict.values())
test_gen_mode_enum_list = list(test_gen_mode_str_to_enum_dict.values())

test_gen_dir_enum_to_str_dict = {ifcs.RX_DIRECTION  : "RX",
                                 ifcs.TX_DIRECTION  : "TX"}
test_gen_dir_str_to_enum_dict = dict([(key, value) for value, key in test_gen_dir_enum_to_str_dict.items()])
test_gen_dir_str_list  = list(test_gen_dir_enum_to_str_dict.values())
test_gen_dir_enum_list = list(test_gen_dir_str_to_enum_dict.values())

tune_status_enum_to_str_dict = {ifcs.TUNE_PASS          : "PASS",
                                ifcs.TUNE_FAIL          : "FAIL",
                                ifcs.TUNE_NOT_COMPLITED : "NOT COMPLETED",
                                ifcs.TUNE_READY         : "READY",
                                ifcs.TUNE_NOT_READY     : "NOT READY",
                                ifcs.TUNE_RESET         : "RESET"}

fir_mode_enum_to_str_dict = {ifcs.FIR_MODE_21L_4N    : "21L_4N",
                             ifcs.FIR_MODE_21L       : "21L",
                             ifcs.FIR_MODE_4N        : "4N"}
fir_mode_str_to_enum_dict = dict([(key, value) for value, key in fir_mode_enum_to_str_dict.items()])
fir_mode_str_list = list(fir_mode_enum_to_str_dict.values())
fir_mode_enum_list = list(fir_mode_str_to_enum_dict.values())

ffe_path_enum_to_str_dict = {ifcs.FFE_DATA_PATH    : "DATA_PATH",
                             ifcs.FFE_CLOCK_PATH   : "CLOCK_PATH"}
ffe_path_str_to_enum_dict = dict([(key, value) for value, key in ffe_path_enum_to_str_dict.items()])
ffe_path_str_list = list(ffe_path_enum_to_str_dict.values())
ffe_enum_list = list(ffe_path_str_to_enum_dict.values())
ffe_tap_enum_to_str_dict = {ifcs.FFE_PRE_8     : "PRE_8",
                            ifcs.FFE_PRE_7     : "PRE_7",
                            ifcs.FFE_PRE_6     : "PRE_6",
                            ifcs.FFE_PRE_5     : "PRE_5",
                            ifcs.FFE_PRE_4     : "PRE_4",
                            ifcs.FFE_PRE_3     : "PRE_3",
                            ifcs.FFE_PRE_2     : "PRE_2",
                            ifcs.FFE_PRE_1     : "PRE_1",
                            ifcs.FFE_PST_1     : "PST_1",
                            ifcs.FFE_PST_2     : "PST_2",
                            ifcs.FFE_PST_3     : "PST_3",
                            ifcs.FFE_PST_4     : "PST_4",
                            ifcs.FFE_PST_5     : "PST_5",
                            ifcs.FFE_PST_6     : "PST_6",
                            ifcs.FFE_PST_7     : "PST_7",
                            ifcs.FFE_PST_8     : "PST_8",
                            ifcs.FFE_PST_9     : "PST_9",
                            ifcs.FFE_PST_10    : "PST_10",
                            ifcs.FFE_PST_11    : "PST_11",
                            ifcs.FFE_PST_12    : "PST_12",
                            ifcs.FFE_PST_13    : "PST_13",
                            ifcs.FFE_PST_14    : "PST_14",
                            ifcs.FFE_PST_15    : "PST_15",
                            ifcs.FFE_PST_16    : "PST_16",
                            ifcs.FFE_PST_17    : "PST_17",
                            ifcs.FFE_PST_18    : "PST_18",
                            ifcs.FFE_PST_19    : "PST_19",
                            ifcs.FFE_PST_20    : "PST_20",
                            ifcs.FFE_PST_5_RC  : "5_RC",
                            ifcs.FFE_PST_6_RC  : "6_RC",
                            ifcs.FFE_PST_7_RC  : "7_RC",
                            ifcs.FFE_PST_8_RC  : "8_RC",
                            ifcs.FFE_PST_9_RC  : "9_RC",
                            ifcs.FFE_PST_10_RC : "10_RC",
                            ifcs.FFE_PST_11_RC : "11_RC",
                            ifcs.FFE_PST_12_RC : "12_RC",
                            ifcs.FFE_PST_13_RC : "13_RC",
                            ifcs.FFE_PST_14_RC : "14_RC",
                            ifcs.FFE_PST_15_RC : "15_RC",
                            ifcs.FFE_PST_16_RC : "16_RC",
                            ifcs.FFE_PST_17_RC : "17_RC",
                            ifcs.FFE_PST_18_RC : "18_RC",
                            ifcs.FFE_PST_19_RC : "19_RC",
                            ifcs.FFE_PST_20_RC : "20_RC",
                            ifcs.FFE_PST_21_RC : "21_RC",
                            ifcs.FFE_PST_22_RC : "22_RC",
                            ifcs.FFE_PST_23_RC : "23_RC",
                            ifcs.FFE_PST_24_RC : "24_RC",
                            ifcs.FFE_PST_25_RC : "25_RC",
                            ifcs.FFE_PST_26_RC : "26_RC",
                            ifcs.FFE_PST_27_RC : "27_RC",
                            ifcs.FFE_PST_28_RC : "28_RC",
                            ifcs.FFE_PST_29_RC : "29_RC",
                            ifcs.FFE_PST_30_RC : "30_RC",
                            ifcs.FFE_PST_31_RC : "31_RC",
                            ifcs.FFE_PST_32_RC : "32_RC",
                            ifcs.FFE_PST_33_RC : "33_RC",
                            ifcs.FFE_PST_34_RC : "34_RC",
                            ifcs.FFE_PST_35_RC : "35_RC",
                            ifcs.FFE_PST_36_RC : "36_RC",
                            ifcs.FFE_PST_37_RC : "37_RC",
                            ifcs.FFE_PST_38_RC : "38_RC",
                            ifcs.FFE_PST_39_RC : "39_RC",
                            ifcs.FFE_PST_40_RC : "40_RC",
                            ifcs.FFE_PST_41_RC : "41_RC",
                            ifcs.FFE_PST_42_RC : "42_RC",
                            ifcs.FFE_PST_43_RC : "43_RC",
                            ifcs.FFE_PST_44_RC : "44_RC",
                            ifcs.FFE_PST_45_RC : "45_RC",
                            ifcs.FFE_PST_46_RC : "46_RC",
                            ifcs.FFE_PST_47_RC : "47_RC",
                            ifcs.FFE_PST_48_RC : "48_RC",
                            ifcs.FFE_PST_49_RC : "49_RC",
                            ifcs.FFE_PST_50_RC : "50_RC",
                            ifcs.FFE_PST_51_RC : "51_RC",
                            ifcs.FFE_PST_52_RC : "52_RC",
                            ifcs.FFE_GAIN      : "GAIN",
                            ifcs.FFE_BLW       : "BLW",
                            ifcs.FFE_DFE       : "DFE"}
ffe_tap_str_to_enum_dict = dict([(key, value) for value, key in ffe_tap_enum_to_str_dict.items()])
ffe_tap_str_list = list(ffe_tap_enum_to_str_dict.values())
ffe_tap_enum_list = list(ffe_tap_str_to_enum_dict.values())
fec_rsmode_str_to_enum_dict = {
    "544": ifcs.MV_HWS_SERDES_RSMODE_544,
    "528": ifcs.MV_HWS_SERDES_RSMODE_528,
}

def start_screen_paint():
    global paint_lines_output
    paint_lines_output = 0

def reset_screen_paint():
    global paint_lines_output
    sys.stdout.write("\r" + "\033[A" * paint_lines_output)
    sys.stdout.flush()
    paint_lines_output = 0

def plog(s):
    global paint_lines_output
    log(s)
    paint_lines_output += 1

def plog_no_newline(s):
    log_no_newline(s)

def hws_log_callback(buff):
    log_no_newline("%s" % compat_bytesToStr(buff))

def speedstrtoint(speed):
    if speed.upper() in speed_str_to_enum_dict.keys():
        return(speed_str_to_enum_dict[speed.upper()])
    else:
       return

# ib/pic translation to isg
def get_ib_pic_to_isg_t100_hws(ib, pic, piclane):
    isg = ifcs.im_node_pic_info_isg_num(0, ib, pic)

    if (isg >= ifcs.IFCS_DEVPORT_SERDES_GROUP_MSER0):
        isg = isg - 1
    isg = isg - 1

    return (isg, piclane)

# devport translation to isg/serdes_num
def devport_portlane_to_isg_serdes_num_t100_hws(devport, portlane):
    serdes_info = ifcs.im_serdes_info_t()
    rc = ifcs.im_devport_get_serdes_info(0, devport, portlane, ifcs.pointer(serdes_info))
    if rc != ifcs.IFCS_SUCCESS:
       log_err("Failed to get serdes info for devport %d lane %d (rc %d)\n" % (devport, portlane, rc));
       return None

    isg = serdes_info.isg
    if (isg >= ifcs.IFCS_DEVPORT_SERDES_GROUP_MSER0):
        isg = isg - 1
    isg = isg - 1

    # T100 populates tx_serdes_num/rx_serdes_num (per-lane), not serdes_num
    # (serdes_num is TL7/TL10 only and stays 0 on T100). Use the RX serdes
    # lane, matching the rest of the T100 HWS/diag datapath.
    return (isg, serdes_info.rx_serdes_num)

# helper func to keep track of / update the passed-in lane arguments and provide the current list
def get_full_lane_list_t100_hws(args):
    global default_isg_list, default_serdes_list
    if args.devport is not None and args.ib is not None:
        raise ValueError("Specify only one of --ib or --devport")
    if args.devport is not None and args.pic is not None:
        raise ValueError("Specify only one of --pic or --devport")
    if args.devport is not None and args.isg_num is not None:
        raise ValueError("Specify only one of --isg_num or --devport")
    if args.ib is not None and args.isg_num is not None:
        raise ValueError("Specify only one of --isg_num or --ib")
    if args.lane is not None and args.serdes_num is not None:
        raise ValueError("Specify only one of --lane or --serdes_num")
    if args.serdes_num is not None and args.isg_num is None:
        raise ValueError("--isg_num not specified")
    if args.ib is not None:
        max_ib = ifcs.im_node_num_ibs(0)
        if args.ib == []:   # 'all' was given
            args.ib = compat_listrange(max_ib)
        if max(args.ib) >= max_ib:
            raise ValueError("Invalid IB number, valid choice [0-%d]" % max_ib)
        serdes_eth_cmn.default_ib_list = args.ib
        serdes_eth_cmn.default_devport_list = None
        default_isg_list = None
    if args.pic is not None:
        if len(args.pic) > 0 and max(args.pic) > 7:
                raise ValueError("Invalid PIC number, valid choice [0...7]")
        serdes_eth_cmn.default_pic_list = args.pic
        if serdes_eth_cmn.default_ib_list is None:
            raise ValueError("--pic specified but no IB specified")
    if args.devport is not None:
        if args.devport == []:   # 'all' was given
            args.devport = serdes_eth_cmn.get_all_devports()
        serdes_eth_cmn.default_devport_list = args.devport
        serdes_eth_cmn.default_ib_list = None
        default_isg_list = None
    if args.isg_num is not None:
        if len(args.isg_num) == 1:
            if (args.isg_num[0]) > 63 and (args.isg_num[0]) != 255:
                raise ValueError("Invalid ISG number, valid choice [0...63] OR 255")
        if len(args.isg_num) > 1 and max(args.isg_num) > 63:
            raise ValueError("Invalid ISG number, valid choice [0...63]")
        if args.isg_num == []:   # 'all' was given
            args.isg_num = compat_listrange(64)
        default_isg_list = args.isg_num
        serdes_eth_cmn.default_ib_list = None
        serdes_eth_cmn.default_devport_list = None
    if args.serdes_num is not None:
        if len(args.isg_num) == 1 and (args.isg_num[0]) == 255:
            max_serdes_val = 511
        else:
            max_serdes_val = 7
        if len(args.serdes_num) > 0 and max(args.serdes_num) > max_serdes_val:
            raise ValueError("Invalid SerDes number, valid choice [0...%d]" % max_serdes_val)
        if any(serdes > max_serdes_val for serdes in args.serdes_num):
            raise ValueError("Invalid SerDes number, valid choice [0...%d]" % max_serdes_val)
        default_serdes_list = [serdes for serdes in args.serdes_num if serdes <= max_serdes_val]
    if args.lane is not None and len(args.lane) > 0 and max(args.lane) > 7:
        raise ValueError("Invalid lane number, valid choice [0...7]")
    if args.lane is not None:
        if any(la > 7 for la in args.lane):
            raise ValueError("Invalid lane number, valid choice [0...7]")
        serdes_eth_cmn.default_lane_list = [la for la in args.lane if la <= 7]

    serdes_eth_cmn.lane_label = {}
    serdes_eth_cmn.port_label = {}
    full_lane_list = []
    if serdes_eth_cmn.default_ib_list is not None:
        for ib in serdes_eth_cmn.default_ib_list:
            if serdes_eth_cmn.default_pic_list == []:  # i.e. 'all'
                pic_list = serdes_eth_cmn.get_all_pics(ib)
            else:
                pic_list = serdes_eth_cmn.default_pic_list
            for pic in pic_list:
                if serdes_eth_cmn.default_lane_list == []:  # i.e. 'all'
                    lane_list = compat_listrange(ifcs.im_node_picports_per_pic(0))
                else:
                    lane_list = serdes_eth_cmn.default_lane_list
                for piclane in lane_list:
                    #full_lane = (ib,pic,piclane)
                    full_lane = get_ib_pic_to_isg_t100_hws(ib, pic, piclane)
                    serdes_eth_cmn.lane_label[full_lane] = 'IB: %d PIC: %d Lane: %d' % (ib,pic,piclane)
                    serdes_eth_cmn.port_label[full_lane] = 'IB: %d PIC: %d Lane: %d' % (ib,pic,piclane)
                    full_lane_list += [full_lane]
    elif serdes_eth_cmn.default_devport_list is not None:
        for devport in serdes_eth_cmn.default_devport_list:
            if serdes_eth_cmn.default_lane_list == []:  # i.e. 'all'
                info = ifcs.im_devport_info_t()
                rc = ifcs.im_devport_info_get(0, devport, ifcs.pointer(info));
                lane_list = compat_listrange(info.pi_num_lanes)
            else:
                lane_list = serdes_eth_cmn.default_lane_list
            for portlane in lane_list:
                full_lane = devport_portlane_to_isg_serdes_num_t100_hws(devport, portlane)
                if full_lane == None:
                    return
                isg, serdes_num = full_lane
                serdes_eth_cmn.lane_label[full_lane] = 'Devport: %d PortLane %d: SerDes: %d' % (devport, portlane, serdes_num)
                serdes_eth_cmn.port_label[full_lane] = 'Devport: %d' % (devport)
                full_lane_list += [full_lane]
    else:
        for isg in default_isg_list:
            if default_serdes_list == []:  # i.e. 'all'
                if isg == 255:
                    lane_list = compat_listrange(512)
                else:
                    lane_list = compat_listrange(ifcs.im_node_picports_per_pic(0))
            else:
                lane_list = default_serdes_list
            for portlane in lane_list:
                full_lane = (isg, portlane)
                isg_label = isg
                portlane_label = portlane
                if isg == 255:
                    isg_label = portlane/8
                    portlane_label = portlane%8
                serdes_eth_cmn.lane_label[full_lane] = 'ISG: %d SerDes: %d' % (isg_label, portlane_label)
                serdes_eth_cmn.port_label[full_lane] = 'ISG: %d SerDes: %d' % (isg_label, portlane_label)
                full_lane_list += [full_lane]

    return full_lane_list

def do_for_lane_list_t100_hws(start_func, each_func, args):
    full_lane_list = get_full_lane_list_t100_hws(args)

    if full_lane_list is None:
        return

    if start_func is not None:
        start_func(full_lane_list, args)

    for full_lane in full_lane_list:
        # let the called function overwrite args without affecting other lanes
        args_subset = copy.deepcopy(args)
        try:  # 'save' arguments are open files, so don't use a deep copy, use it as-is
            args_subset.save = args.save
        except:
            pass
        args_subset.ib = None            # also, remove non-optional args
        args_subset.pic = None           # so cli_xxx can determine if no args
        args_subset.lane = None          # were passed
        args_subset.devport = None
        args_subset.func = None
        args_subset.subcmd = None
        each_func(full_lane, args_subset)

def multi_callback_t100_hws(start_func, each_func):
    """helper func to create a callback func for subcommands to manage default lanes and iterate"""
    return lambda args: do_for_lane_list_t100_hws(start_func, each_func, args)

def _build_field_name_map():
    """Build address -> field_name mapping for register dump from N3C224GX81PLL_fields.py."""
    from N3C224GX81PLL_fields import FIELDS
    field_map = {}
    for key, entry in FIELDS.items():
        addr_int = entry['addr']
        name = entry['name']
        if addr_int not in field_map:
            field_map[addr_int] = name
    return field_map

_sdw_field_name_map = None

def _get_sdw_field_name_map():
    """Return cached absolute_addr -> field_name mapping for SDW register dump."""
    global _sdw_field_name_map
    if _sdw_field_name_map is None:
        import N3C224GX81PLL_SDW_fields as n3c244g_sdw
        field_map = {}
        for key, entry in n3c244g_sdw.FIELDS.items():
            addr_int = entry['addr']
            if addr_int not in field_map:
                field_map[addr_int] = entry['name']
        _sdw_field_name_map = field_map
    return _sdw_field_name_map

def _sdw_lookup(field_name):
    """Exact lookup of an SDW field by name. Returns field dict or None."""
    import N3C224GX81PLL_SDW_fields as n3c244g_sdw
    return n3c244g_sdw.lookup(field_name)

def _sdw_search(pattern):
    """Search SDW field names using shell-style wildcards (*, ?).

    Returns list of (key, field_dict) for all matching fields.
    """
    import fnmatch
    import N3C224GX81PLL_SDW_fields as n3c244g_sdw
    pat = pattern.lower()
    results = []
    for key, entry in n3c244g_sdw.FIELDS.items():
        if fnmatch.fnmatch(key, pat) or fnmatch.fnmatch(entry['name'].lower(), pat):
            results.append((key, entry))
    return results

def cli_mvHwsComphySerdesSDWSearchField(lane, args):
    """Search SDW register field names using wildcard patterns (*, ?)."""
    pattern = args.pattern
    matches = _sdw_search(pattern)
    if not matches:
        log_err("No SDW fields matching '{}'\n".format(pattern))
        return ifcs.IFCS_INVAL

    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log("{} field(s) matching '{}':\n".format(len(matches), pattern))
    log("{:<40s} {:>8s} {:>12s} {:>6s} {:>4s} {}".format(
        "Field", "Addr", "Mask", "Width", "RW", "Description"))
    log("{:<40s} {:>8s} {:>12s} {:>6s} {:>4s} {}".format(
        "-" * 40, "-" * 8, "-" * 12, "-" * 6, "-" * 4, "-" * 30))
    for key, entry in sorted(matches, key=lambda x: x[1]['addr']):
        log("{:<40s} 0x{:04X}   0x{:08X}   {:>4d}   {:<4s} {}".format(
            entry['name'], entry['addr'], entry['mask'],
            entry['width'], entry['rw'], entry['desc']))
    return ifcs.IFCS_SUCCESS

def cli_mvHwsDumpSDWRegisters(lane, args):
    """Dump SDW registers (Common 0x0000-0x0210 and/or Lane 0x0500-0x1A00)."""
    isg_num, serdes_num = lane
    data = ifcs.GT_U32()

    lane_start_addr = 0x0500 + serdes_num * 0x300
    lane_end_addr = lane_start_addr + 0x300

    region = args.region.lower() if args.region else 'all'
    if region == 'common':
        start_addr = 0x0000
        end_addr = 0x0210
    elif region == 'lane':
        start_addr = lane_start_addr
        end_addr = lane_end_addr
    else:
        start_addr = 0x0000
        end_addr = lane_end_addr

    if args.start_addr is not None:
        start_addr = args.start_addr
    if args.end_addr is not None:
        end_addr = args.end_addr + 1

    if start_addr >= end_addr:
        log_err("Invalid address range: start_addr (0x{:x}) > end_addr (0x{:x})\n"
                .format(start_addr, end_addr - 1))
        return ifcs.IFCS_INVAL

    step = args.step

    field_map = _get_sdw_field_name_map()

    output_file = getattr(args, 'output_file', None)
    fh = None
    if output_file:
        try:
            fh = open(output_file, 'w')
        except IOError as e:
            log_err("Failed to open output file '{}': {}\n".format(output_file, e))
            return ifcs.IFCS_INVAL

    try:
        for addr_int in range(start_addr, end_addr, step):
            field_name = field_map.get(addr_int)
            if field_name is None:
                continue
            mask = 0xFFFFFFFF
            rc = ifcs.mvHwsComphySerdesSDWRegisterRead(0, isg_num, serdes_num,
                                                       addr_int, mask, ifcs.pointer(data))
            serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
            if rc != 0:
                log("0x{:04x}  - {}".format(addr_int, field_name))
                if fh:
                    fh.write("0x{:04x}  - {}\n".format(addr_int, field_name))
                continue
            log("0x{:04x}  0x{:08x} {}".format(addr_int, data.value & mask, field_name))
            if fh:
                fh.write("0x{:04x}  0x{:08x} {}\n".format(addr_int, data.value & mask, field_name))
    finally:
        if fh:
            fh.close()
            log("Dump saved to '{}'\n".format(output_file))

    return ifcs.IFCS_SUCCESS

def cli_mvHwsComphySerdesRegisterReadField(lane, args):
    isg_num, serdes_num = lane
    field_name = args.field_name.lower()
    data = ifcs.GT_U32()

    entry = reg_map_lookup(field_name)
    if entry is None:
        log_err("Field '{}' not found in N3C224GX81PLL_fields\n".format(field_name))
        return ifcs.IFCS_INVAL
    addr_int = entry['addr']
    hi_int = entry['hi_bit']
    lo_int = entry['lo_bit']
    mask = entry['mask']

    rc = ifcs.mvHwsComphySerdesRegisterRead(0, isg_num, serdes_num,
                                           addr_int, mask, ifcs.pointer(data))
    if rc != 0:
        log_err("Failed to read SerDes register rc={} addr=0x{:x} mask=0x{:x}\n"
                .format(rc, addr_int, mask))
        return rc
    field_value = (data.value & mask) >> lo_int
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log('{}:  Mask: 0x{:x} 0x{:x}'.format(args.field_name, mask, field_value))
    return ifcs.IFCS_SUCCESS

def cli_mvHwsComphySerdesRegisterWriteField(lane, args):
    isg_num, serdes_num = lane
    field_name = args.field_name.lower()

    entry = reg_map_lookup(field_name)
    if entry is None:
        log_err("Field '{}' not found in N3C224GX81PLL_fields\n".format(field_name))
        return ifcs.IFCS_INVAL
    addr_int = entry['addr']
    hi_int = entry['hi_bit']
    lo_int = entry['lo_bit']
    mask = entry['mask']

    data = (args.value << lo_int) & mask
    rc = ifcs.mvHwsComphySerdesRegisterWrite(0, isg_num, serdes_num,
                       addr_int, mask, data)
    if rc != 0:
        log_err("Failed to write SerDes register\n")
        return rc
    return ifcs.IFCS_SUCCESS

def cli_mvHwsComphySerdesSDWGetFields(lane, args):
    """Read an SDW field by exact name. Returns address, mask, and value."""
    isg_num, serdes_num = lane
    field_name = args.field_name
    data = ifcs.GT_U32()

    entry = _sdw_lookup(field_name)
    if entry is None:
        log_err("Field '{}' not found in N3C224GX81PLL_SDW_fields\n".format(field_name))
        return ifcs.IFCS_INVAL
    addr_int = entry['addr']
    lo_int = entry['lo_bit']
    mask = entry['mask']
    rc = ifcs.mvHwsComphySerdesSDWRegisterRead(0, isg_num, serdes_num,
                                           addr_int, mask, ifcs.pointer(data))
    if rc != 0:
        log_err("Failed to read SerDes SDW register rc={} addr=0x{:x} mask=0x{:x}\n"
                .format(rc, addr_int, mask));
        return rc
    field_value = (data.value & mask) >> lo_int
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log('{}:  Addr: 0x{:04x}  Mask: 0x{:x}  Value: 0x{:x}'.format(
        entry['name'], addr_int, mask, field_value))
    return ifcs.IFCS_SUCCESS

def cli_mvHwsdumpSerdesFields(lane, args):
    isg_num, serdes_num = lane
    data = ifcs.GT_U32()

    start_addr = args.start_addr
    end_addr = args.end_addr
    if start_addr is None and end_addr is None:
        start_addr = 0
        end_addr = 0xE800
    elif start_addr is None or end_addr is None:
        log_err("Both start_addr and end_addr are required when specifying address range\n")
        return ifcs.IFCS_INVAL

    if start_addr > end_addr:
        log_err("Invalid address range: start_addr > end_addr\n")
        return ifcs.IFCS_INVAL

    # Determine the iteration step for SDW register addresses.
    # Use a default of 4 (word-aligned) if not provided by the caller.
    step = getattr(args, 'step', 4)
    try:
        step = int(step)
    except (TypeError, ValueError):
        log_err("Invalid step value: {!r}. Step must be a positive integer.\n".format(step))
        return ifcs.IFCS_INVAL
    if step <= 0:
        log_err("Invalid step value: {}. Step must be a positive integer.\n".format(step))
        return ifcs.IFCS_INVAL

    # Build address -> field_name map from N3C224GX81PLL_fields.py
    field_map = _build_field_name_map()

    for addr_int in range(start_addr, end_addr + 1, step):
        mask = 0xFFFFFFFF
        rc = ifcs.mvHwsComphySerdesRegisterRead(0, isg_num, serdes_num,
                                               addr_int, mask, ifcs.pointer(data))
        field_name = field_map.get(addr_int, '-')
        serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
        if rc != 0:
            log_err("Failed to read SerDes SDW register rc={} addr=0x{:x} mask=0x{:x}\n"
                    .format(rc, addr_int, mask))
            log("0x{:x}  - {}".format(addr_int, field_name))
            continue
        log("0x{:x}  0x{:08x} {}".format(addr_int, data.value & mask, field_name))

    return ifcs.IFCS_SUCCESS

def cli_mvHwsComphyEnableDisableTxFirForce(lane, args):
    isg_num, serdes_num = lane
    flag = args.flag
    if flag == '0':
        flag = 0
    elif flag == '1':
        flag = 1
    else:
        log_err("Invalid flag\n");
        return ifcs.IFCS_INVAL

    tx_eq = ifcs.MV_HWS_SERDES_TX_CONFIG_DATA_UNT()
    tx_eq.txComphyC224GX81PLL.pre3  = args.pre3
    tx_eq.txComphyC224GX81PLL.pre2  = args.pre2
    tx_eq.txComphyC224GX81PLL.pre   = args.pre
    tx_eq.txComphyC224GX81PLL.main  = args.main
    tx_eq.txComphyC224GX81PLL.post  = args.post
    tx_eq.txComphyC224GX81PLL.post2 = args.post2
    tx_eq.txComphyC224GX81PLL.post3 = args.post3
    rc = ifcs.mvHwsComphyEnableDisableTxFirForce(0, isg_num, serdes_num, ifcs.COM_PHY_N3C224GX81PLL, flag, ifcs.pointer(tx_eq))
    if rc != 0:
        action = "disable" if flag == 0 else "enable"
        log_err("Failed to {} TxFirForce\n".format(action));
        return rc
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesScanTxNLUT(lane, args):
    isg_num, serdes_num = lane
    delay_s = args.delay if args.delay is not None else 1
    module = args.module if args.module is not None else "UNKNOWN"
    tx_fir_mode = args.tx_fir_mode
    tx_nlut_delay = args.tx_nlut_delay
    num_iter = args.iters
    thresh = args.thresh
    fine_count_max = args.fine
    rx_nlut_delay = args.rx_nlut_delay
    reset_tx_nlut = args.reset_nlut

    def clamp(value, low, high):
        return max(low, min(high, value))

    def print_nlut(title, vec):
        log(title)
        for i in range(0, len(vec), 16):
            line = vec[i:i + 16]
            log('   ' + '\t'.join(f"{int(v):3d}" for v in line))
        log('}')

    def _write_field(field_name, value):
        entry = reg_map_lookup(field_name)
        if entry is None:
            log_err("Field '{}' not found in N3C224GX81PLL_fields\n".format(field_name))
            return ifcs.IFCS_INVAL
        addr_int = entry['addr']
        lo_int = entry['lo_bit']
        mask = entry['mask']
        data = (value << lo_int) & mask
        rc = ifcs.mvHwsComphySerdesRegisterWrite(0, isg_num, serdes_num,
                                                 addr_int, mask, data)
        if rc != 0:
            log_err("Failed to write field {} rc={}\n".format(field_name, rc))
        return rc

    def _testgen_set(pattern, mode, direction):
        tg_args = argparse.Namespace(pattern=pattern, mode=mode, direction=direction)
        return cli_mvHwsSerdesTestGen(lane, tg_args)

    def _testgen_status(accumulate):
        status = ifcs.MV_HWS_SERDES_TEST_GEN_STATUS()
        prbs = prbs_str_to_enum_dict.get("PRBS31", ifcs.PRBS7)
        rc = ifcs.mvHwsSerdesTestGenStatus(
            0, isg_num, serdes_num, ifcs.COM_PHY_N3C224GX81PLL,
            prbs, accumulate, ifcs.pointer(status))
        if rc != 0:
            log_err("Failed to get test gen status\n");
            return rc, 0, 0, 0
        return rc, status.framesCntr, status.errorsCntr, status.lockStatus

    def _get_tx_nlut_vec():
        tx_nlu = ifcs.MV_HWS_TX_NLUT_BUFFER()
        rc = ifcs.mvHwsSerdesGetTxNLUT(0, isg_num, serdes_num, ifcs.pointer(tx_nlu))
        if rc != 0:
            log_err("Failed to read Tx NLU\n");
            return rc, []
        buf = tx_nlu.comphyC224GX81PLLTxNlutBufferData.bufferData
        return rc, [int(buf[i]) for i in range(len(buf))]

    def _set_tx_nlut_vec(vec):
        tx_nlut = ifcs.MV_HWS_TX_NLUT_BUFFER()
        buf = tx_nlut.comphyC224GX81PLLTxNlutBufferData.bufferData
        max_len = len(buf)
        vec_len = min(len(vec), max_len)
        for i in range(vec_len):
            buf[i] = int(vec[i])
        rc = ifcs.mvHwsSerdesSetTxNLUT(0, isg_num, serdes_num, ifcs.pointer(tx_nlut))
        if rc != 0:
            log_err("Failed to Set Tx NLU\n");
        return rc

    def _set_tx_nlut_at(idx, value, vec):
        vec[idx] = value
        return _set_tx_nlut_vec(vec)

    def _get_rx_nlutm(delay_val):
        rx_nlutm = ifcs.MV_HWS_SERDES_RX_NLUTM()
        rx_nlutm.ui = 4
        # Firmware (API_N3C224GX81PLL_GetRxNLUTM) rejects delay != 2/3 when ui != 5.
        rx_nlutm.delay = delay_val if delay_val in (2, 3) else 2
        rx_nlutm.hitMax = 15
        rx_nlutm.timeoutMs = 1000
        buf = (ifcs.MV_HWS_RX_NLUTM_BUFFER)()
        rc = ifcs.mvHwsSerdesGetRxNLUTM(0, isg_num, serdes_num, rx_nlutm, ifcs.pointer(buf))
        if rc != 0:
            log_err("Failed to Get RX NLUTM\n");
            return rc, []
        data = buf.comphyC224GX81PLLRxNlutmBufferData.bufferData
        # Firmware (API_N3C224GX81PLL_GetRxNLUTM) only populates index*group*4
        # entries; the rest of the 0x400 buffer is uninitialized garbage.
        #   ui=3 -> 1*16*4 = 64, ui=4 -> 1*64*4 = 256, ui=5 -> 4*64*4 = 1024
        index = 4 if rx_nlutm.ui == 5 else 1
        group = 16 if rx_nlutm.ui == 3 else 64
        valid = min(index * group * 4, len(data))
        return rc, [int(data[i]) for i in range(valid)]
    log("=============\t Scanning started\t ==============")

    rc = _write_field("rx_dp_dfe_to_gb_sel_lane", 1)
    if rc != 0:
        return rc
    rc = _write_field("rx_dp_dfe_to_mon_sel_lane", 1)
    if rc != 0:
        return rc
    rc = _write_field("trx_train_pass_check_rx_snr_lane[7:0]", 0x50)
    if rc != 0:
        return rc

    # Tx enable signal:
    rc = cli_mvHwsSerdesTxEnable(lane, argparse.Namespace(enable=True))
    if rc != 0:
        log_err("Error: Failed to enable TX\n")
        return rc
    # disable Rx NLUT:
    rc = cli_mvHwsSerdesSetRxNLUTEnable(lane, argparse.Namespace(state=False))
    if rc != 0:
        log_err("Error: Failed to disable RX NLUT\n")
        return rc

    if reset_tx_nlut:
        log("=============\t Resetting TX NLUT\t ==============")
        tx_nllut_vec = [0] * 128
        rc = _set_tx_nlut_vec(tx_nllut_vec)
        if rc != 0:
            log_err("Error: Failed to set TX nlut\n")
            return rc
    # Start PRBS31 TestGen (TX) and read initial BER
    log("=============\t Start PRBS31 Tx\t ==============")
    rc = _testgen_set("PRBS31", "TEST", "TX")
    if rc != 0:
        log_err("Failed to generate TX test\n")
        return rc
    time.sleep(5)

    # RX-only tune start and wait/status
    log("=============\t Start Rx Training\t ==============")
    rc = cli_mvHwsSerdesRxAutoTuneStart(lane, argparse.Namespace(training_rx=True))
    if rc != 0:
        log_err("Failed to autotune start\n")
        return rc
    time.sleep(10)
    rxStatus = ifcs.MV_HWS_AUTO_TUNE_STATUS()
    txStatus = ifcs.MV_HWS_AUTO_TUNE_STATUS()
    rc = ifcs.mvHwsSerdesAutoTuneStatus(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(rxStatus), ifcs.pointer(txStatus))
    if rc != 0:
        log_err("Failed to get autotune status\n")
        return rc

    rx_pass = (rxStatus.value == ifcs.TUNE_PASS)
    log('[INFO] AutoTuneStatus: ' + ('PASS' if rx_pass else 'NOT PASS'))
    # Start PRBS31 TestGen (TX) and read initial BER
    rc = _testgen_set("PRBS31", "TEST", "RX")
    if rc != 0:
        log_err("Failed to generate RX test\n")
        return rc
    time.sleep(1)

    # Initial BER
    rc, _bits0, _err0, _ = _testgen_status(False)
    if rc != 0:
        log_err("Failed to get generate status\n")
        return rc
    time.sleep(delay_s)
    rc, bits, errors, _ = _testgen_status(False)
    if rc != 0:
        log_err("Failed to get generate status\n")
        return rc
    init_ber = (errors / bits) if bits > 0 else float('inf')
    log("=============Initial BER Reading==============")
    log("Bits : {} \t Errors : {}  \t BER : {:.2E}".format(bits, errors, init_ber))

    init_bits = bits
    init_errors = errors

    # Configure TX FIR/NLUT
    rc = cli_mvHwsSerdesSetTxNLUTDelay(lane, argparse.Namespace(value=tx_nlut_delay))
    if rc != 0:
        log_err("Error: Set TX NLUT Delay\n")
        return rc
    rc = cli_mvHwsSerdesSetTxFirMode(lane, argparse.Namespace(mode=tx_fir_mode))
    if rc != 0:
        log_err("Error: Set TX Fir Mode\n")
        return rc
    time.sleep(1)

    # Read RXNLUTM and current TX NLUT vector (delay must be 2 or 3 when ui != 5)
    rc, rxnlutm = _get_rx_nlutm(rx_nlut_delay)
    if rc != 0:
        log_err("Error: Failed to get RX nlutm\n")
        return rc
    rc, tx_nllut_vec = _get_tx_nlut_vec()
    if rc != 0:
        log_err("Error: Failed to get TX nlut\n")
        return rc

    nlut_len = len(tx_nllut_vec)
    rx_nlut_len = len(rxnlutm)
    log("RxNlutLen : {} \t TxNlutLen : {}  ".format(rx_nlut_len, nlut_len))

    tap_en = [1] * nlut_len

    # RX direction PT normal->test (as in your comments)
    rc = _testgen_set("PRBS31", "NORMAL", "RX")
    if rc != 0:
        log_err("Error: Failed to set RX generate test\n")
        return rc
    time.sleep(1)
    rc = _testgen_set("PRBS31", "TEST", "RX")
    if rc != 0:
        log_err("Error: Failed to set RX generate test\n")
        return rc
    time.sleep(1)

    # Polarity inversion check
    invert_tx = ifcs.GT_BOOL()
    invert_rx = ifcs.GT_BOOL()
    rc = ifcs.mvHwsSerdesPolarityConfigGet(
        0, isg_num, serdes_num, ifcs.COM_PHY_N3C224GX81PLL,
        ifcs.pointer(invert_tx), ifcs.pointer(invert_rx))
    if rc != 0:
        log_err("Failed to get SerDes polarity\n");
        return rc
    invert = (invert_rx.value != invert_tx.value)
    if invert:
        log("======= Warning: Polarity Inversion active , using index conversion")

    best_ber = float('inf')
    best_tx_nllut_vec = tx_nllut_vec.copy()
    fine_counter = 0

    for k in range(1, num_iter + 1):
        rc, rxnlutm = _get_rx_nlutm(rx_nlut_delay)
        if rc != 0:
            return rc
        ######## Conversion of RXNLUTM to match TXNLUT vector length and indexing #########
        rxnlutm_converted = [0] * nlut_len
        # TX_FIR_NLUT_1BIT_UI_POS_LANE = 1 case ##
        for i in range(nlut_len):
            rxnlutm_converted[i] = rxnlutm[2*i] + rxnlutm[2*i + 1]
        rx_len = len(rxnlutm_converted)

        for i in range(nlut_len):
            j = (rx_len - 1 - i) if invert else i
            if j >= rx_len:
                continue
            val = int(rxnlutm_converted[j])
            if val > thresh:
                step = -tap_en[i] if invert else +tap_en[i]
                nv = clamp(tx_nllut_vec[i] + step, -32, 31)
                rc = _set_tx_nlut_at(i, nv, tx_nllut_vec)
                if rc != 0:
                    log_err("Failed to iset TX NLUT\n");
                    return rc
            elif val < -thresh:
                step = +tap_en[i] if invert else -tap_en[i]
                nv = clamp(tx_nllut_vec[i] + step, -32, 31)
                rc = _set_tx_nlut_at(i, nv, tx_nllut_vec)
                if rc != 0:
                    log_err("Failed to iset TX NLUT\n");
                    return rc
            else:
                tap_en[i] = 0

        print_nlut("================Current TX NLUT VECTOR==============", tx_nllut_vec)
        print_nlut("================Current tap_en[]==============", tap_en)
        print_nlut("================Current RX NLUTM VECTOR=============", rxnlutm_converted)

        # BER measure (non-accumulating read)
        _testgen_status(False)
        time.sleep(delay_s)
        _rc, bits, errors, _ = _testgen_status(False)
        if _rc != 0:
            log_err("Error: Failed to test generate status\n")
            return _rc
        ber = (errors / bits) if bits > 0 else float('inf')
        log("================BER Reading==============")
        log("Iteration : {} \t Bits : {} \t Errors : {}  \t BER : {:.2E}".format(k, bits, errors, ber))

        if ber < best_ber:
            best_ber = ber
            best_tx_nllut_vec = tx_nllut_vec.copy()

        sum_en = sum(tap_en)
        log(f"TAP ENABLE SUM :{sum_en}")
        if sum_en == 0 and fine_counter < fine_count_max:
            log("==================Coarse Training Complete==============")
            log("Fine Training:{}".format(fine_counter))
            log("Unlocking Taps once More")
            tap_en = [1] * nlut_len
            fine_counter += 1
        elif sum_en == 0 and fine_counter == fine_count_max:
            log("==========Training Complete============")
            break

    print_nlut("================Best TX NLUT VECTOR==============", best_tx_nllut_vec)

    # Apply best vector
    rc = _set_tx_nlut_vec(best_tx_nllut_vec)
    if rc != 0:
        log_err("Error: Failed to test TX NLUT \n")
        return rc

    now = int(time.time())
    export_name = f"Tx_NLUT_EXPORT_{module}_Lane_{lane}_{now}.txt"
    with open(export_name, 'w') as f:
        f.write('# TX NLUT export\n')
        f.write('NLUT = {\n')
        for i in range(0, nlut_len, 16):
            line = best_tx_nllut_vec[i:i + 16]
            f.write('   ' + '\t'.join(f"{int(v):3d}" for v in line) + '\n')
        f.write('}\n')
    log("================Best TX NLUT VECTOR Applied and exported==============")
    log("Export: {}".format(export_name))

    # Final BER
    _testgen_status(False)
    time.sleep(delay_s)
    _rc, bits, errors, _ = _testgen_status(False)
    if _rc != 0:
        log_err("Error: Failed to test TX NLUT \n")
        return _rc
    final_ber = (errors / bits) if bits > 0 else float('inf')

    log("================TX Training Complete==============")
    log("===========INITIAL BER :")
    log("Bits : {} \t Errors : {}  \t BER : {:.2E}".format(init_bits, init_errors, init_ber))
    log("=========== BER POST TXNLUT Training:")
    log("Bits : {} \t Errors : {}  \t BER : {:.2E}".format(bits, errors, final_ber))

    improvement = (init_ber / final_ber) if final_ber > 0 else float('inf')
    log("BER Improvement: {:.2E}x".format(improvement))

    # enable Rx NLUT:
    rc = cli_mvHwsSerdesSetRxNLUTEnable(lane, argparse.Namespace(state=True))
    if rc != 0:
        log_err("Error: Failed to enable RX NLUT\n")
        return rc

    rc = _testgen_set("PRBS31", "NORMAL", "RX")
    if rc != 0:
        log_err("Error: Failed to set RX generate test\n")
        return rc
    rc = _testgen_set("PRBS31", "NORMAL", "TX")
    if rc != 0:
        log_err("Error: Failed to set TX generate test\n")
        return rc

def cli_mvHwsSerdesTxEnable(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mvHwsSerdesTxEnable(0, isg_num, serdes_num, ifcs.COM_PHY_N3C224GX81PLL, args.enable)
    if rc != 0:
       log_err("Failed to set SerDes TX\n");
    return rc

def cli_mvHwsSerdesPolarityConfigGet(lane, args):
    isg_num, serdes_num = lane
    invertTx = ifcs.GT_BOOL()
    invertRx = ifcs.GT_BOOL()
    rc = ifcs.mvHwsSerdesPolarityConfigGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(invertTx), ifcs.pointer(invertRx))
    if rc != 0:
        log_err("Failed to get SerDes polarity\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(" Tx/Rx Polarity    : {}/{}".format(invertTx.value, invertRx.value))

def cli_mvHwsSerdesPolarityConfigSet(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mvHwsSerdesPolarityConfigSet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.invert_tx, args.invert_rx)
    if rc != 0:
        log_err("Failed to set SerDes polarity\n");
        return rc

def cli_mvHwsSerdesLoopbackSet(lane, args):
    isg_num, serdes_num = lane
    if args.lb_mode in lbmode_str_to_enum_dict.keys():
        lb_mode = lbmode_str_to_enum_dict[args.lb_mode]
    else:
       log_err("Invalid loopback mode\n");
       return ifcs.IFCS_INVAL

    rc = ifcs.mvHwsSerdesLoopbackSet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, lb_mode)
    if rc != 0:
        log_err("Failed to set loopback\n");
        return ifcs.IFCS_NOTFOUND

def cli_mvHwsSerdesAutoTuneStart(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mvHwsSerdesAutoTuneStart(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.training_rx, args.training_tx)
    if rc != 0:
        log_err("Failed to start Tx/Rx training\n");
        return rc

def cli_mvHwsSerdesRxAutoTuneStart(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mvHwsSerdesRxAutoTuneStart(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.training_rx)
    if rc != 0:
        if (args.training_rx):
            log_err("Failed to start Rx training\n");
        else:
            log_err("Failed to stop Rx training\n");
        return ifcs.IFCS_INVAL
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesTxAutoTuneStart(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mvHwsSerdesTxAutoTuneStart(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.training_tx)
    if rc != 0:
        if (args.training_tx):
            log_err("Failed to start Tx training\n");
        else:
            log_err("Failed to stop Tx training\n");
        return rc

def cli_mvHwsSerdesCDRLockGet(lane, args):
    isg_num, serdes_num = lane
    CDRLock = ifcs.GT_BOOL()
    rc = ifcs.mvHwsSerdesCDRLockGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(CDRLock))
    if rc != 0:
        log_err("Failed to get CDR lock status\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(" CDR Lock    : {}".format(CDRLock.value))

def cli_mvHwsSerdesSignalDetectGet(lane, args):
    isg_num, serdes_num = lane
    sig_det = ifcs.GT_BOOL()
    rc = ifcs.mvHwsSerdesSignalDetectGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(sig_det))
    if rc != 0:
        log_err("Failed to get signal detect status\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(" Signal detected    : {}".format(sig_det.value))

def cli_mvHwsSerdesSNRGet(lane, args):
    isg_num, serdes_num = lane
    snr = ifcs.GT_FLOAT64()
    rc = ifcs.mvHwsSerdesSNRGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(snr))
    if rc != 0:
        log_err("Failed to get SNR value\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(" SNR    : {}".format(snr.value))

def cli_mvHwsSerdesSBRGet(lane, args):
    isg_num, serdes_num = lane
    sbr = ifcs.MV_HWS_SERDES_SBR_BUFFER()

    rc = ifcs.mvHwsSerdesSBRGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.pre_cursor,
            args.post_cursor, ifcs.pointer(sbr))
    if rc != 0:
        log_err("Failed to get SBR\n");
        return rc

    serdes_eth_cmn.print_lane_id(lane)
    for i in range(sbr.comphyC224GX81PLLSBRBuffer.count):
        log('SBR time: %.2f    Data: %.2f' % (sbr.comphyC224GX81PLLSBRBuffer.timeData[i], sbr.comphyC224GX81PLLSBRBuffer.bufferData[i]))

def cli_mvHwsSerdesOCMGet(lane, args):
    isg_num, serdes_num = lane
    ocm = ifcs.MV_HWS_OCM_BUFFER()

    ocm.numRepetitions = args.num_repetitions
    ocm.bufferDataPtr = (ifcs.MV_HWS_OCM_BUFFER_DATA_UNT * args.num_repetitions)()

    rc = ifcs.mvHwsSerdesOCMGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.input_sel, ifcs.pointer(ocm))
    if rc != 0:
        log_err("Failed to get OCM\n")
        return rc

    serdes_eth_cmn.print_lane_id(lane)
    for i in range(args.num_repetitions):
        log('\nOCM data repetition is %d:\n' % (i + 1))
        for j in range(4096//16):
            log('%02d %02d %02d %02d %02d %02d %02d %02d %02d %02d %02d %02d %02d %02d %02d %02d ' %
                ((ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 0]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 1]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 2]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 3]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 4]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 5]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 6]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 7]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 8]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 9]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 10]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 11]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 12]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 13]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 14]),
                 (ocm.bufferDataPtr[i].comphyC224GX81PLLOcmBufferData.bufferData[(j*16) + 15])))

def cli_mvHwsSerdesEomMatrixGet(lane, args):
    isg_num, serdes_num = lane
    eomInParams  = ifcs.MV_HWS_SERDES_EOM_IN_PARAMS_UNT()
    eomOutParams = ifcs.MV_HWS_SERDES_EOM_OUT_PARAMS_UNT()

    if args.min_samples in min_samples_str_to_enum_dict.keys():
        min_samples = min_samples_str_to_enum_dict[args.min_samples]
    else:
       log_err("Invalid min samples\n");
       return ifcs.IFCS_INVAL

    if args.ber_th in ber_threshold_str_to_enum_dict.keys():
        ber_th = ber_threshold_str_to_enum_dict[args.ber_th]
    else:
       log_err("Invalid BER threshold\n");
       return ifcs.IFCS_INVAL

    if args.ber_th_max in ber_threshold_str_to_enum_dict.keys():
        ber_th_max = ber_threshold_str_to_enum_dict[args.ber_th_max]
    else:
       log_err("Invalid BER threshold\n");
       return ifcs.IFCS_INVAL

    statusPtr = ifcs.MV_HWS_SERDES_STATUS()

    rc = ifcs.mvHwsSerdesStatusGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, 0, ifcs.pointer(statusPtr))
    if rc != 0:
         log_err("EOM: Failed to get SerDes status\n");
         return rc

    rxEncoding = statusPtr.rxEncoding
    rx_speed   = statusPtr.rxSpeed

    ber_th_100g      = ["10_3_E","10_4_E","10_5_E","10_6_E"]
    min_samples_100g = ["10_3_E","10_4_E","10_5_E","10_6_E","10_7_E","10_8_E","10_9_E"]

    if rxEncoding == ifcs.SERDES_ENCODING_PAM4:
        if rx_speed == ifcs._106_25G_P4 or rx_speed == ifcs._112_5G_P4:
            if (args.ber_th not in ber_th_100g):
                log("BER threshold must be set to 10_3_E - 10_6_E for 100G SerDes speed\n")
                return ifcs.IFCS_INVAL
            if (args.ber_th_max not in ber_th_100g):
                log("BER threshold max must be set to 10_3_E - 10_6_E for 100G SerDes speed\n")
                return ifcs.IFCS_INVAL
            if (args.min_samples not in min_samples_100g):
                log("Min samples must be set to 10_3_E - 10_9_E for 100G SerDes speed\n")
                return ifcs.IFCS_INVAL

    eomInParams.comphyC224GX81PLLEomInParams.minSamples      = min_samples
    eomInParams.comphyC224GX81PLLEomInParams.berThreshold    = ber_th
    eomInParams.comphyC224GX81PLLEomInParams.eomStatsMode    = args.stats_mode
    eomInParams.comphyC224GX81PLLEomInParams.berThresholdMax = ber_th_max
    eomInParams.comphyC224GX81PLLEomInParams.phaseStepSize   = args.phase_step_sz
    eomInParams.comphyC224GX81PLLEomInParams.voltageStepSize = args.volt_step_sz

    serdes_eth_cmn.print_lane_id(lane)
    if args.print_en:
        callback_type = ifcs.CFUNCTYPE(
            ifcs.UNCHECKED(None),
            ifcs.c_char_p)
        callback = callback_type(hws_log_callback)

        ifcs.mvHwsMcesdLogInit(0, compat_funcPointer(callback, ifcs.MV_HWS_MCESD_LOG_USER_CB_FUNC_PTR))

    rc = ifcs.mvHwsSerdesEomMatrixGet(0, isg_num, serdes_num,
            args.print_en, ifcs.pointer(eomInParams), ifcs.pointer(eomOutParams))
    if args.print_en:
        ifcs.mvHwsMcesdLogDeInit(0)
    if rc != 0:
        log_err("Failed to get EOM matrix\n");
        return rc

    if rxEncoding == ifcs.SERDES_ENCODING_NA:
        log("Rx not ready\n")
        return ifcs.IFCS_DRIVER_ERROR

    if rxEncoding == ifcs.SERDES_ENCODING_NRZ:
        # For NRZ only the mid eye (index 0) is valid; the driver writes results
        # to width_mUI[N3C224GX81PLL_EYE_MID] which is index 0.
        log(" Width(mUI)          : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.width_mUI[0]))
        log(" Height(mV)          : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[0]))
        log(" Sample count        : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[0]))
        log(" Q                   : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.Q[0]))
        log(" SNR                 : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.SNR[0]))
        log(" Upper mean          : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.upperMean[0]))
        log(" Lower mean          : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.lowerMean[0]))
        log(" Upper std deviation : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.upperStdDev[0]))
        log(" Lower std deviation : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.lowerStdDev[0]))
    elif rxEncoding == ifcs.SERDES_ENCODING_PAM4:
        log(" Width(mUI)          : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.width_mUI[0],eomOutParams.comphyC224GX81PLLEomOutParams.width_mUI[1],eomOutParams.comphyC224GX81PLLEomOutParams.width_mUI[2]))
        log(" Height(mV)          : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[0],eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[1],eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[2]))
        log(" Sample count        : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[0],eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[1],eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[2]))
        log(" Q                   : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.Q[0],eomOutParams.comphyC224GX81PLLEomOutParams.Q[1],eomOutParams.comphyC224GX81PLLEomOutParams.Q[2]))
        log(" SNR                 : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.SNR[0],eomOutParams.comphyC224GX81PLLEomOutParams.SNR[1],eomOutParams.comphyC224GX81PLLEomOutParams.SNR[2]))
        log(" Upper mean          : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.upperMean[0],eomOutParams.comphyC224GX81PLLEomOutParams.upperMean[1],eomOutParams.comphyC224GX81PLLEomOutParams.upperMean[2]))
        log(" Lower mean          : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.lowerMean[0],eomOutParams.comphyC224GX81PLLEomOutParams.lowerMean[1],eomOutParams.comphyC224GX81PLLEomOutParams.lowerMean[2]))
        log(" Upper std deviation : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.upperStdDev[0],eomOutParams.comphyC224GX81PLLEomOutParams.upperStdDev[1],eomOutParams.comphyC224GX81PLLEomOutParams.upperStdDev[2]))
        log(" Lower std deviation : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.lowerStdDev[0],eomOutParams.comphyC224GX81PLLEomOutParams.lowerStdDev[1],eomOutParams.comphyC224GX81PLLEomOutParams.lowerStdDev[2]))

def cli_mvHwsSerdesEom1DMatrixGet(lane, args):
    isg_num, serdes_num = lane
    eomInParams  = ifcs.MV_HWS_SERDES_EOM_IN_PARAMS_UNT()
    eomOutParams = ifcs.MV_HWS_SERDES_EOM_OUT_PARAMS_UNT()

    if args.min_samples in min_samples_str_to_enum_dict.keys():
        min_samples = min_samples_str_to_enum_dict[args.min_samples]
    else:
       log_err("Invalid min samples\n");
       return ifcs.IFCS_INVAL

    if args.ber_th in ber_threshold_str_to_enum_dict.keys():
        ber_th = ber_threshold_str_to_enum_dict[args.ber_th]
    else:
       log_err("Invalid BER threshold\n");
       return ifcs.IFCS_INVAL

    statusPtr = ifcs.MV_HWS_SERDES_STATUS()

    rc = ifcs.mvHwsSerdesStatusGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, 0, ifcs.pointer(statusPtr))
    if rc != 0:
         log_err("EOM: Failed to get SerDes status\n");
         return rc

    rxEncoding = statusPtr.rxEncoding
    rx_speed   = statusPtr.rxSpeed

    ber_th_100g      = ["10_3_E","10_4_E","10_5_E","10_6_E"]
    min_samples_100g = ["10_3_E","10_4_E","10_5_E","10_6_E","10_7_E","10_8_E","10_9_E"]

    if rxEncoding == ifcs.SERDES_ENCODING_PAM4:
        if rx_speed == ifcs._106_25G_P4 or rx_speed == ifcs._112_5G_P4:
            if (args.ber_th not in ber_th_100g):
                log("BER threshold must be set to 10_3_E - 10_6_E for 100G SerDes speed\n")
                return ifcs.IFCS_INVAL
            if (args.min_samples not in min_samples_100g):
                log("Min samples must be set to 10_3_E - 10_9_E for 100G SerDes speed\n")
                return ifcs.IFCS_INVAL

    eomInParams.comphyC224GX81PLLEomInParams.minSamples      = min_samples
    eomInParams.comphyC224GX81PLLEomInParams.berThreshold    = ber_th

    serdes_eth_cmn.print_lane_id(lane)
    if args.print_en:
        callback_type = ifcs.CFUNCTYPE(
            ifcs.UNCHECKED(None),
            ifcs.c_char_p)
        callback = callback_type(hws_log_callback)

        ifcs.mvHwsMcesdLogInit(0, compat_funcPointer(callback, ifcs.MV_HWS_MCESD_LOG_USER_CB_FUNC_PTR))

    rc = ifcs.mvHwsSerdesEom1DMatrixGet(0, isg_num, serdes_num,
            args.print_en, ifcs.pointer(eomInParams), ifcs.pointer(eomOutParams))
    if args.print_en:
        ifcs.mvHwsMcesdLogDeInit(0)
    if rc != 0:
        log_err("Failed to get EOM matrix\n");
        return rc

    if rxEncoding == ifcs.SERDES_ENCODING_NA:
        log("Rx not ready\n")
        return ifcs.IFCS_DRIVER_ERROR

    if rxEncoding == ifcs.SERDES_ENCODING_NRZ:
        # For NRZ only the mid eye (index 0) is valid; the driver writes results
        # to width_mUI[N3C224GX81PLL_EYE_MID] which is index 0.
        log(" Height(mV)          : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[0]))
        log(" Sample count        : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[0]))
        log(" SNR                 : {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.SNR[0]))
    elif rxEncoding == ifcs.SERDES_ENCODING_PAM4:
        log(" Height(mV)          : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[0],eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[1],eomOutParams.comphyC224GX81PLLEomOutParams.height_mV[2]))
        log(" Sample count        : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[0],eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[1],eomOutParams.comphyC224GX81PLLEomOutParams.sampleCount[2]))
        log(" SNR                 : {}, {}, {}".format(eomOutParams.comphyC224GX81PLLEomOutParams.SNR[0],eomOutParams.comphyC224GX81PLLEomOutParams.SNR[1],eomOutParams.comphyC224GX81PLLEomOutParams.SNR[2]))

def cli_mvHwsSerdesEncodingTypeGet(lane, args):
    isg_num, serdes_num = lane

    txEncodingPtr = ifcs.MV_HWS_SERDES_ENCODING_TYPE()
    rxEncodingPtr = ifcs.MV_HWS_SERDES_ENCODING_TYPE()

    rc = ifcs.mvHwsSerdesEncodingTypeGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(txEncodingPtr), ifcs.pointer(rxEncodingPtr))
    if rc != 0:
        log_err("Failed to get Enc type\n");
        return rc

    serdes_eth_cmn.print_lane_id(lane)
    log(" Tx Encoding   : {}".format(encoding_map[txEncodingPtr.value]))
    log(" Rx Encoding   : {}".format(encoding_map[rxEncodingPtr.value]))

def cli_mvHwsSerdesEncodingSet(lane, args):
    isg_num, serdes_num = lane
    tx_enc_config = ifcs.MV_HWS_SERDES_ENCODING_CONFIG_STC()
    rx_enc_config = ifcs.MV_HWS_SERDES_ENCODING_CONFIG_STC()

    tx_enc_config.grayCode   = args.gray_code_tx
    tx_enc_config.msblsbSwap = args.msb_lsb_swap_tx
    tx_enc_config.preCode    = args.pre_code_tx

    rx_enc_config.grayCode   = args.gray_code_rx
    rx_enc_config.msblsbSwap = args.msb_lsb_swap_rx
    rx_enc_config.preCode    = args.pre_code_rx

    rc = ifcs.mvHwsSerdesEncodingSet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(tx_enc_config), ifcs.pointer(rx_enc_config))
    if rc != 0:
        log_err("Failed to set SerDes encoding\n");
        return rc

def cli_mvHwsSerdesPPMGet(lane, args):
    isg_num, serdes_num = lane

    ppm = ifcs.GT_32()

    rc = ifcs.mvHwsSerdesPPMGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(ppm))
    if rc != 0:
        log_err("Failed to get PPM\n");
        return rc

    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(" PPM : {}".format(ppm.value))

def cli_mvHwsSerdesPPMSet(lane, args):
    isg_num, serdes_num = lane

    rc = ifcs.mvHwsSerdesPPMSet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.ppm)
    if rc != 0:
        log_err("Failed to set PPM\n");
        return rc

def cli_mvHwsSerdesReset(lane, args):
    isg_num, serdes_num = lane
    if args.reset_type in reset_type_str_to_enum_dict.keys():
        reset_type = reset_type_str_to_enum_dict[args.reset_type]
    else:
       log_err("Invalid reset type\n");
       return ifcs.IFCS_INVAL

    rc = ifcs.mvHwsSerdesReset(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, reset_type)
    if rc != 0:
        log_err("Failed to set SerDes reset\n");
        return rc

def cli_mvHwsSerdesEncodingGet(lane, args):
    isg_num, serdes_num = lane
    tx_enc_config = ifcs.MV_HWS_SERDES_ENCODING_CONFIG_STC()
    rx_enc_config = ifcs.MV_HWS_SERDES_ENCODING_CONFIG_STC()

    rc = ifcs.mvHwsSerdesEncodingGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(tx_enc_config), ifcs.pointer(rx_enc_config))
    if rc != 0:
        log_err("Failed to get SerDes encoding\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane)
    log(" Tx/Rx Gray code     : {}/{}".format(tx_enc_config.grayCode, rx_enc_config.grayCode))
    log(" Tx/Rx MSB LSB swap  : {}/{}".format(tx_enc_config.msblsbSwap, rx_enc_config.msblsbSwap))
    log(" Tx/Rx Pre code      : {}/{}".format(tx_enc_config.preCode, rx_enc_config.preCode))

def cli_mvHwsComphySerdesRegisterRead(lane, args):
    isg_num, serdes_num = lane
    data = ifcs.GT_U32()

    cnt = 0
    if args.end_addr is not None:
        cnt = args.end_addr - args.addr
        cnt = (int)(abs(cnt/args.step))

    if cnt == 0:
        rc = ifcs.mvHwsComphySerdesRegisterRead(0, isg_num, serdes_num,
                           args.addr, args.mask, ifcs.pointer(data))
        if rc != 0:
            log_err("Failed to read SerDes register\n");
            return rc
        serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
        log('Address: 0x%04x    Mask: 0x%04x   Data: 0x%04x' % (args.addr, args.mask, data.value))
    else:
        for i in range(cnt):
            addr = args.addr + (args.step * i)
            rc = ifcs.mvHwsComphySerdesRegisterRead(0, isg_num, serdes_num,
                               addr, args.mask, ifcs.pointer(data))
            if rc != 0:
                log_err("Failed to read SerDes register\n");
                return rc
            serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
            log('Address: 0x%04x    Mask: 0x%04x   Data: 0x%04x' % (addr, args.mask, data.value))

def cli_mvHwsComphySerdesRegisterWrite(lane, args):
    isg_num, serdes_num = lane

    rc = ifcs.mvHwsComphySerdesRegisterWrite(0, isg_num, serdes_num,
                       args.addr, args.mask, args.data)
    if rc != 0:
        log_err("Failed to write SerDes register\n");
        return rc

def cli_mvHwsComphySerdesSDWRegisterRead(lane, args):
    isg_num, serdes_num = lane
    data = ifcs.GT_U32()

    rc = ifcs.mvHwsComphySerdesSDWRegisterRead(0, isg_num, serdes_num,
                       args.addr, args.mask, ifcs.pointer(data))
    if rc != 0:
        log_err("Failed to read SerDes SDW register\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log('Address: 0x%04x    Mask: 0x%04x   Data: 0x%04x' % (args.addr, args.mask, data.value))

def cli_mvHwsComphySerdesSDWRegisterWrite(lane, args):
    isg_num, serdes_num = lane

    rc = ifcs.mvHwsComphySerdesSDWRegisterWrite(0, isg_num, serdes_num,
                       args.addr, args.mask, args.data)
    if rc != 0:
        log_err("Failed to write SerDes SDW register\n");
        return rc

def cli_mvHwsSerdesSquelchThresholdSet(lane, args):
    isg_num, serdes_num = lane

    rc = ifcs.mvHwsSerdesSquelchThresholdSet(0, isg_num, serdes_num, args.threshold)
    if rc != 0:
        log_err("Failed to set squelch threshold\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(' Squelch threshold set to %d' % args.threshold)

def cli_mvHwsSerdesSquelchThresholdGet(lane, args):
    isg_num, serdes_num = lane
    data = ifcs.GT_16()

    rc = ifcs.mvHwsSerdesSquelchThresholdGet(0, isg_num, serdes_num, ifcs.pointer(data))
    if rc != 0:
        log_err("Failed to get squelch threshold\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(' Squelch threshold: %d' % data.value)

def cli_mvHwsSerdesErrorInject(lane, args):
    isg_num, serdes_num = lane

    rc = ifcs.mvHwsSerdesErrorInject(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.num_bits, 1)
    if rc != 0:
        log_err("Failed to set SerDes error inject\n");
        return rc

def cli_mvHwsSerdesManualTxConfig(lane, args):
    isg_num, serdes_num = lane
    tx_eq = ifcs.MV_HWS_SERDES_TX_CONFIG_DATA_UNT()

    tx_eq.txComphyC224GX81PLL.pre3  = args.pre3
    tx_eq.txComphyC224GX81PLL.pre2  = args.pre2
    tx_eq.txComphyC224GX81PLL.pre   = args.pre
    tx_eq.txComphyC224GX81PLL.main  = args.main
    tx_eq.txComphyC224GX81PLL.post  = args.post
    tx_eq.txComphyC224GX81PLL.post2 = args.post2
    tx_eq.txComphyC224GX81PLL.post3 = args.post3

    rc = ifcs.mvHwsSerdesManualTxConfig(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(tx_eq))
    if rc != 0:
        log_err("Failed to set SerDes TX config\n");
        return rc

def cli_mvHwsSerdesFwDownload(lane, args):
    rc = ifcs.mvHwsSerdesFwDownload(0, 0xFF,
            ifcs.COM_PHY_N3C224GX81PLL, args.fw_file)
    if rc != 0:
        log_err("Failed to download SerDes firmware\n");
        return rc

def cli_mvHwsSerdesDisplayTrainingLog(lane, args):
    isg_num, serdes_num = lane
    serdesTlogPtr = (ifcs.MV_HWS_SERDES_TLOG_ENTRY * args.log_size)()
    validEntries = ifcs.GT_U32()

    callback_type = ifcs.CFUNCTYPE(
        ifcs.UNCHECKED(None),
        ifcs.c_char_p)
    callback = callback_type(hws_log_callback)

    ifcs.mvHwsMcesdLogInit(0, compat_funcPointer(callback, ifcs.MV_HWS_MCESD_LOG_USER_CB_FUNC_PTR))

    rc = ifcs.mvHwsSerdesDisplayTrainingLog(0, isg_num, serdes_num, args.log_size, ifcs.pointer(validEntries), compat_pointer(serdesTlogPtr, ifcs.MV_HWS_SERDES_TLOG_ENTRY))
    ifcs.mvHwsMcesdLogDeInit(0)
    if rc != 0:
        log_err("Failed to display training log\n");
        return rc

# MCESD log callback for pmd-log. Suppresses the vendor driver's internal
# "API_N3C224GX81PLL_DisplayTrainingLog(lane=N)" trace line (the MCESD source is
# auto-generated and not edited here); everything else is printed as-is.
def pmd_log_callback(buff):
    s = compat_bytesToStr(buff)
    if 'DisplayTrainingLog(' in s:
        return
    log_no_newline("%s" % s)

# Map a devport + port-relative lane to its (isg, rx_serdes_num) for the PMD log.
# The SerDes link-training (PMD) log is observed on the Rx serdes; on T100 the
# Tx/Rx lane mapping can be asymmetric so rx_serdes_num is used (not serdes_num).
# Returns (isg, rx_serdes_num) or None on failure (after logging an error).
def devport_portlane_to_isg_rx_serdes_num_t100_hws(devport, portlane):
    serdes_info = ifcs.im_serdes_info_t()
    rc = ifcs.im_devport_get_serdes_info(0, devport, portlane, ifcs.pointer(serdes_info))
    if rc != ifcs.IFCS_SUCCESS:
        log_err("Failed to get serdes info for devport %d lane %d\n" % (devport, portlane))
        return None

    # The serdes-group enum is NONE=0, ISG0..ISG31=1..32, MSER0=33, ISG32..ISG64=34..66.
    # MSER0 is the management SerDes group, not a data-plane ISG; a real eth devport
    # never resolves to NONE/MSER0, so reject them instead of silently aliasing.
    isg = serdes_info.isg
    if (isg == ifcs.IFCS_DEVPORT_SERDES_GROUP_NONE or
            isg == ifcs.IFCS_DEVPORT_SERDES_GROUP_MSER0 or
            isg > ifcs.IFCS_DEVPORT_SERDES_GROUP_ISG64):
        log_err("Invalid serdes group %d for devport %d lane %d\n" % (isg, devport, portlane))
        return None

    # Same conversion as TL10_ISG_NUM_GET: -2 at/after MSER0, else -1.
    if (isg >= ifcs.IFCS_DEVPORT_SERDES_GROUP_MSER0):
        isg = isg - 1
    isg = isg - 1

    return (isg, serdes_info.rx_serdes_num)

# Port-level PMD (link training) log: takes port (devport) + lane, maps the
# port/lane to its ISG/Rx-SerDes and prints the SerDes LT log via the HWS
# DisplayTrainingLog API ("pmd log").
def cli_pmd_log_run(args):
    # Resolve sticky devport list (this is a port-level command).
    if args.devport is not None:
        if args.devport == []:   # 'all' was given
            args.devport = serdes_eth_cmn.get_all_devports()
        serdes_eth_cmn.default_devport_list = args.devport
        serdes_eth_cmn.default_ib_list = None
    devports = serdes_eth_cmn.default_devport_list
    if not devports:
        log_err("pmd-log requires --devport (port number, list, or 'all')\n")
        return ifcs.IFCS_INVAL

    # Resolve sticky lane list.
    if args.lane is not None:
        if any(la < 0 or la > 7 for la in args.lane):
            log_err("Invalid lane number, valid choice [0...7]\n")
            return ifcs.IFCS_INVAL
        serdes_eth_cmn.default_lane_list = [la for la in args.lane if 0 <= la <= 7]

    # Route MCESD training-log output to the console for the duration of the dump.
    # Use pmd_log_callback so the driver's internal API-name trace line is hidden.
    callback_type = ifcs.CFUNCTYPE(ifcs.UNCHECKED(None), ifcs.c_char_p)
    callback = callback_type(pmd_log_callback)
    ifcs.mvHwsMcesdLogInit(0, compat_funcPointer(callback, ifcs.MV_HWS_MCESD_LOG_USER_CB_FUNC_PTR))

    # HW SerDes link-training log holds up to 16 entries (see DisplayTrainingLog).
    log_size = args.log_size
    if log_size == 0 or log_size > 16:
        log_size = 10

    ret = ifcs.IFCS_SUCCESS
    for devport in devports:
        if serdes_eth_cmn.default_lane_list == []:   # i.e. 'all'
            info = ifcs.im_devport_info_t()
            rc = ifcs.im_devport_info_get(0, devport, ifcs.pointer(info))
            if rc != ifcs.IFCS_SUCCESS:
                log_err("Failed to get info for devport %d\n" % devport)
                ret = rc
                continue
            lane_list = compat_listrange(info.pi_num_lanes)
        else:
            lane_list = serdes_eth_cmn.default_lane_list
        for portlane in lane_list:
            log("Devport: %d Lane: %d  PMD (link training) log:" % (devport, portlane))
            mapped = devport_portlane_to_isg_rx_serdes_num_t100_hws(devport, portlane)
            if mapped is None:
                ret = ifcs.IFCS_INVAL
                continue
            isg_num, serdes_num = mapped
            tlog = (ifcs.MV_HWS_SERDES_TLOG_ENTRY * log_size)()
            valid_entries = ifcs.GT_U32()
            rc = ifcs.mvHwsSerdesDisplayTrainingLog(0, isg_num, serdes_num, log_size,
                    ifcs.pointer(valid_entries),
                    compat_pointer(tlog, ifcs.MV_HWS_SERDES_TLOG_ENTRY))
            if rc != 0:
                log_err("Failed to display PMD log for devport %d lane %d\n" % (devport, portlane))
                ret = ifcs.IFCS_DRIVER_ERROR

    ifcs.mvHwsMcesdLogDeInit(0)
    return ret

def cli_mvHwsSerdesSetRxNLUTEnable(lane, args):
    isg_num, serdes_num = lane
    state = args.state
    rc = ifcs.mvHwsSerdesSetRxNLUTEnable(0, isg_num, serdes_num, state)
    if rc != 0:
        log_err("Failed to Set Rx NLU enable\n");
    return rc

def cli_mvHwsSerdesGetRxNLUTEnable(lane, args):
    isg_num, serdes_num = lane
    state = ifcs.GT_U8()
    rc = ifcs.mvHwsSerdesGetRxNLUTEnable(0, isg_num, serdes_num, ifcs.pointer(state))
    if rc != 0:
        log_err("Failed to read RX NLU enable\n");
        return rc
    log(" State: {}".format(state.value))

def cli_mvHwsSerdesGetRxNLUT(lane, args):
    isg_num, serdes_num = lane
    rxNlut = ifcs.MV_HWS_RX_NLUT_BUFFER()
    rc = ifcs.mvHwsSerdesGetRxNLUT(0, isg_num, serdes_num, ifcs.pointer(rxNlut))
    if rc != 0:
        log_err("Failed to read Rx NLUT\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane)
    for i in range(64//16):
        output = ' '.join(['%02d' % rxNlut.comphyC224GX81PLLRxNlutBufferData.bufferData[(i * 16) + j] for j in range(64//16)])
        log(output)

def cli_mvHwsSerdesSetTxFirMode(lane, args):
    isg_num, serdes_num = lane

    if args.mode in fir_mode_str_to_enum_dict.keys():
        mode = fir_mode_str_to_enum_dict[args.mode]
    else:
        log_err("Invalid test gen mode\n");
        return ifcs.IFCS_INVAL

    rc = ifcs.mvHwsSerdesSetTxFirMode(0, isg_num, serdes_num, mode)
    if rc != 0:
        log_err("Failed to set TX FIR Mode\n");
        return ifcs.IFCS_INVAL
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesGetTxFirMode(lane, args):
    isg_num, serdes_num = lane
    mode = ifcs.MV_HWS_SERDES_FIR_MODE()
    rc = ifcs.mvHwsSerdesGetTxFirMode(0, isg_num, serdes_num, ifcs.pointer(mode))
    if rc != 0:
        log_err("Failed to read Tx FIR Mode\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane)
    log(" Mode: {}".format(fir_mode_enum_to_str_dict[mode.value]))

def cli_mvHwsSerdesSetTxNLUTDelay(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mvHwsSerdesSetTxNLUTDelay(0, isg_num, serdes_num, args.value)
    if rc != 0:
        log_err("Failed to Set Tx NLU Delay\n");
        return ifcs.IFCS_INVAL
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesGetTxNLUTDelay(lane, args):
    isg_num, serdes_num = lane
    delay = ifcs.GT_U8()
    rc = ifcs.mvHwsSerdesGetTxNLUTDelay(0, isg_num, serdes_num, ifcs.pointer(delay))
    if rc != 0:
        log_err("Failed to read Tx delay NLU\n");
        return rc
    log(" Value: {}".format(delay.value))

def cli_mvHwsSerdesSetTxNLUT(lane, args):
    isg_num, serdes_num = lane
    txNlut = (ifcs.MV_HWS_TX_NLUT_BUFFER)()

    # Buffer size is 0x80 (128 elements)
    if len(args.txNlut) > len(txNlut.comphyC224GX81PLLTxNlutBufferData.bufferData):
        log_err("Error: txNlut array size ({}) exceeds maximum buffer size ({})\n".format(len(args.txNlut),len(txNlut.comphyC224GX81PLLTxNlutBufferData.bufferData)))
        return -1

    for i,v in enumerate(args.txNlut):
        txNlut.comphyC224GX81PLLTxNlutBufferData.bufferData[i]=v

    rc = ifcs.mvHwsSerdesSetTxNLUT(0, isg_num, serdes_num, ifcs.pointer(txNlut))
    if rc != 0:
        log_err("Failed to Set Tx NLU\n");
        return rc

def cli_mvHwsSerdesGetTxNLUT(lane, args):
    isg_num, serdes_num = lane
    txNlu = ifcs.MV_HWS_TX_NLUT_BUFFER()
    rc = ifcs.mvHwsSerdesGetTxNLUT(0, isg_num, serdes_num, ifcs.pointer(txNlu))
    if rc != 0:
        log_err("Failed to read Tx NLU\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane)
    for i in range(128//16):
        output = ' '.join(['%02d' % txNlu.comphyC224GX81PLLTxNlutBufferData.bufferData[(i * 16) + j] for j in range(256//16)])
        log(output)

def cli_mvHwsSerdesGetRxNLUTM(lane, args):
    isg_num, serdes_num = lane
    rxNlutm = ifcs.MV_HWS_SERDES_RX_NLUTM()
    rxNlutm.ui = args.ui
    rxNlutm.delay = args.delay
    rxNlutm.hitMax = args.hitMax
    rxNlutm.timeoutMs = args.timeoutMs
    buf = (ifcs.MV_HWS_RX_NLUTM_BUFFER)()
    rc = ifcs.mvHwsSerdesGetRxNLUTM(0, isg_num, serdes_num, rxNlutm, ifcs.pointer(buf))
    if rc != 0:
        log_err("Failed to Get RX NLUTM\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane)
    data = buf.comphyC224GX81PLLRxNlutmBufferData.bufferData
    # Firmware (API_N3C224GX81PLL_GetRxNLUTM) only populates index*group*4 bytes;
    # the rest of the 0x400 buffer is uninitialized driver-stack memory (garbage).
    #   ui=3 -> 1*16*4 = 64, ui=4 -> 1*64*4 = 256, ui=5 -> 4*64*4 = 1024
    index = 4 if args.ui == 5 else 1
    group = 16 if args.ui == 3 else 64
    valid = min(index * group * 4, len(data))
    for i in range(0, valid, 16):
        output = ' '.join(['%4d' % data[j] for j in range(i, min(i + 16, valid))])
        log(output)

def cli_mvHwsSerdesGetFfeTap(lane, args):
    isg_num, serdes_num = lane
    ffe_path_info = ifcs.MV_HWS_SERDES_FFE_PATH_INFO()

    if args.path in ffe_path_str_to_enum_dict.keys():
        ffe_path_info.path= ffe_path_str_to_enum_dict[args.path]
    else:
        log_err("Invalid FFE path value\n");
        return ifcs.IFCS_INVAL

    if args.tap in ffe_tap_str_to_enum_dict.keys():
        ffe_path_info.tap = ffe_tap_str_to_enum_dict[args.tap]
    else:
        log_err("Invalid FFE TAP info value\n");
        return ifcs.IFCS_INVAL

    ffe_path_info.diffMode = args.diffMode

    tapValue = ifcs.GT_32()
    rc = ifcs.mvHwsSerdesGetFfeTap(0, isg_num, serdes_num, ffe_path_info, ifcs.pointer(tapValue))
    if rc != 0:
        log_err("Failed to read FFE Tap value\n");
        return rc;

    log(" Tap Value: {}".format(tapValue.value))

def cli_mvHwsSerdesGetRxRcFfeTaps(lane, args):
    NUM_COLS = 2

    def add_colon(elems):
        return '%-30s: %-20s' % (elems[0], elems[1])

    def print_data(elem_arr):
        out_str = ""
        for i in range(len(elem_arr)):
            if (i > 1 and (i % NUM_COLS) == 0):
                out_str += "\n"
            out_str += add_colon(elem_arr[i])
        log(out_str)

    isg_num, serdes_num = lane
    serdes_eth_cmn.print_lane_id(lane)

    buf = ifcs.MV_HWS_SERDES_RX_RC_FFE_TAPS()
    rc = ifcs.mvHwsSerdesGetRxRcFfeTaps(0, isg_num, serdes_num, ifcs.pointer(buf))
    if rc != 0:
        log_err("Failed to read RX RC FFE taps\n");
        return rc

    float_tap_out = []
    for i in range(len(buf.tap)):
        tap_label = ffe_tap_enum_to_str_dict.get(ifcs.FFE_PST_5_RC + i, "tap%d" % i)
        float_tap_out.append((tap_label, buf.tap[i]))

    log("--"*11+" RX RC FFE Taps "+"--"*11)
    print_data(float_tap_out)

def cli_mvHwsSerdesGetRcFltOpt(lane, args):
    isg_num, serdes_num = lane
    serdes_eth_cmn.print_lane_id(lane)

    buf = ifcs.MV_HWS_SERDES_RC_FLT_OPT()
    rc = ifcs.mvHwsSerdesGetRcFltOpt(0, isg_num, serdes_num, ifcs.pointer(buf))
    if rc != 0:
        log_err("Failed to read RC floating tap optimization info\n");
        return rc

    log("--"*11+" RC Floating Tap Optimization (RC_FLT_OPT) "+"--"*11)
    log('%-30s: %-20s' % ('Enable', buf.enable))
    log('%-30s: %-20s' % ('Option', buf.option))
    log('%-30s: %-20s' % ('Avg Num', buf.avgNum))
    log('%-30s: %-20s' % ('Step', buf.step))
    for i in range(len(buf.bank)):
        log('Bank %d: start=%-6s stop=%-6s best_pos=%-6s' % (
            i, buf.bank[i].startPos, buf.bank[i].stopPos, buf.bank[i].bestPos))

def cli_mwHwsComphyDisableLTTimer(lane, args):
    isg_num, serdes_num = lane
    rc = ifcs.mwHwsSerdesDisableLTTimer(0, isg_num, serdes_num, ifcs.COM_PHY_N3C224GX81PLL, args.enable)
    if rc != 0:
       log_err("Failed to set Link Training timer\n");
       return

def get_pic_port_cntr_idx(pic_port):
    return eval("xport.ifcs.PIC_PORT%d_CNTR" % pic_port)

def clear_pcs_counters(ib, pic, pic_port):
    pen_idx = get_pic_port_cntr_idx(pic_port)
    xport.pen.write_pen(pen_idx, 0, [(xport.ifcs.RX_PCS_BER_COUNT_F, 0)], ib=ib, pic=pic)

def cli_pcsber_multi_start(lanes, args):
    if not args.continuation:
        for lane in lanes:
            pic_port = xport.serdes_idx_to_port(lane)
            clear_pcs_counters(lane[0], lane[1], pic_port)

    if not args.continuous:
        for wait in range(args.time):
            time.sleep(1)
            sys.stdout.write('.') ; sys.stdout.flush()
        sys.stdout.write("\n")

def run_repaint_until_keypress(func, *args):
    def await_key_func():
        await_key_func.stopped = False
        def run():
            compat_raw_input("")
            await_key_func.stopped = True
        threading.Thread(target=run).start()
    await_key_func()
    start_screen_paint()
    while not await_key_func.stopped:
        reset_screen_paint()
        func(*args)
        time.sleep(.1)

def field_as_unsigned(f):
    if f[1] < 0:
        return f[1] + (1 << 32)
    else:
        return f[1]

def get_pcs_errs(ib, pic, pic_port):
    pen_idx = get_pic_port_cntr_idx(pic_port)
    cntr_flds = xport.pen.read_pen(pen_idx, 0, ib=ib, pic=pic)
    bins = []
    # Fields 10..25: 0..15 correctable errors
    bins = [field_as_unsigned(cntr_flds[f_idx]) for f_idx in range(10,26)]
    # Field 4: uncorrectable errors
    bins.append(field_as_unsigned(cntr_flds[4]))
    return bins

def pcsber(lane, args):
    ib, pic, laneidx = lane
    pic_port = xport.serdes_idx_to_port(lane)
    err_bins = get_pcs_errs(ib, pic, pic_port)
    sum_err_bins = sum(err_bins)

    lines_out = 0
    serdes_eth_cmn.print_port_id(lane, no_linefeed=True)

    if sum_err_bins > 0:
        uncorr_err_rate = float(err_bins[-1]) / sum(err_bins)
        # Count total number of symbol errors: sum of bins weighted by how many errors puts you in that bin:
        tot_errs = 0
        for e_idx, e_bin in enumerate(err_bins):
            tot_errs += e_idx * e_bin
        tot_err_rate = float(tot_errs) / sum(err_bins)
        plog("Uncorr Err: %5.3e (%d)  Corr Sym Errs / CW: %5.3e (%d)" % (uncorr_err_rate, err_bins[-1], tot_err_rate, tot_errs))
    else:
        plog("---")
    lines_out += 1

    if args.verbose and not args.plot:
        for i, binval in enumerate(err_bins[:-1]):
            plog("%-10s: %d" % (str(i) + ' err', binval))
            lines_out += 1
        plog("%-10s: %d" % ('uncor err', err_bins[-1]))
        lines_out += 1

    if args.plot:
        set_color_gray = "\x1b[48;5;244m"
        reset_color = '\x1b[0m'
        if sum_err_bins == 0:
            plog("No counts in bins")
            lines_out += 1
        else:
            scale = 10.0        # 10 'pixels' per decade
            log_min_scale = -8  # i.e. 1e-8 at left edge
            max_bar_length = scale * -log_min_scale
            scaled_log_bins = [0 if counts == 0 else (np.log10(counts * 1.0 / sum_err_bins) - log_min_scale) * scale for counts in err_bins]

            for i, counts in enumerate(err_bins):
                if counts == 0:
                    bar_length = 0
                else:
                    bar_length = int(((np.log10(counts * 1.0 / sum_err_bins) - log_min_scale) * scale) + 0.5)
                if args.verbose and counts > 0:
                    if counts < ((1<<32) - 1):
                        bar_text = str(counts)
                    else:
                        bar_text = "SATURATED"
                else:
                    bar_text = ""
                if len(bar_text) < bar_length:
                    bar_text += " " * (bar_length - len(bar_text))
                padding = max_bar_length - max(bar_length, len(bar_text))
                bar = set_color_gray + bar_text[:bar_length] + reset_color + bar_text[bar_length:] + " " * int(padding)
                if i < len(scaled_log_bins) - 1:
                    label = str(i)
                else:
                    label = "Uncor Err"
                plog("%-10s: %s" % (label, bar))
                lines_out += 1

def chrToInt(_val):
    char_val = ord(_val)
    if (char_val > 127):
        return(char_val - 256)
    else:
        return char_val

def strNumToInt(_val, numBits):
    _val = ord(_val)
    if (_val > (2**(numBits - 1) - 1)):
        return(_val - 2**numBits)
    else:
        return _val

class AutoTuneResults:
    def __init__(self, results):
        self.results = results

    def getTxTapsOut(self):
        txTaps = self.results.txComphyC224GX81PLL
        tx_taps_out = []
        tx_taps_out += [("Pre3", txTaps.pre3)]
        tx_taps_out += [("Pre2", txTaps.pre2)]
        tx_taps_out += [("Pre",  txTaps.pre)]
        tx_taps_out += [("Main", txTaps.main)]
        tx_taps_out += [("Post", txTaps.post)]
        tx_taps_out += [("Post2", txTaps.post2)]
        tx_taps_out += [("Post3", txTaps.post3)]
        return tx_taps_out

    def getRxOut(self,isg_num,serdes_num):
        txSpeedPtr = ifcs.MV_HWS_SERDES_SPEED()
        rxSpeedPtr = ifcs.MV_HWS_SERDES_SPEED()
        rc = ifcs.mvHwsSerdesSpeedGet(0, isg_num, serdes_num,
                ifcs.pointer(txSpeedPtr), ifcs.pointer(rxSpeedPtr))
        if rc != 0:
             log_err("Rx Out: Failed to get SerDes speed\n");
             return rc

        tuneResults = self.results
        rx_out = []
        rx_out += [("CDR locked", tuneResults.cdrLocked)]
        rx_out += [("Squelch Threshold", tuneResults.rxComphyC224GX81PLL.squelchThreshold)]
        rx_out += [("Signal squelched", tuneResults.squelched)]
        rx_out += [("SNR", tuneResults.snr)]
        if rxSpeedPtr.value == ifcs._106_25G_P4 or rxSpeedPtr.value == ifcs._112_5G_P4:
            rx_out += [("SNR Dtl", "N/A")]
        else:
            rx_out += [("SNR Dtl", tuneResults.snrDtl)]
        rx_out += [("PPM", tuneResults.ppm)]
        return rx_out

    def getCtleOut(self):
        ctle = self.results.rxComphyC224GX81PLL
        ctle_out = []
        ctle_out += [("Train R", ctle.trainR)]
        ctle_out += [("Train C", ctle.trainC)]
        ctle_out += [("Train GC", ctle.trainGc)]
        #ctle_out += [("Train Atten", ctle.trainAtten)]
        return ctle_out

    def getCdrOut(self):
        cdr = self.results.rxComphyC224GX81PLL
        cdr_out = []
        cdr_out += [("KP Frac", cdr.kpFrac)]
        cdr_out += [("KP Shift", cdr.kpShift)]
        cdr_out += [("KI Frac", cdr.kiFrac)]
        cdr_out += [("KI Shift", cdr.kiShift)]
        return cdr_out

    def getFfeDpOut(self):
        rxFfeDp = self.results.rxFfeDpComphyC224GX81PLL
        ffe_dp_out = []
        ffe_dp_out += [("Pre6", rxFfeDp.ffePre6)]
        ffe_dp_out += [("Pre5", rxFfeDp.ffePre5)]
        ffe_dp_out += [("Pre4", rxFfeDp.ffePre4)]
        ffe_dp_out += [("Pre3", rxFfeDp.ffePre3)]
        ffe_dp_out += [("Pre2", rxFfeDp.ffePre2)]
        ffe_dp_out += [("Pre1", rxFfeDp.ffePre1)]
        ffe_dp_out += [("Pst1", rxFfeDp.ffePst1)]
        ffe_dp_out += [("Pst2", rxFfeDp.ffePst2)]
        ffe_dp_out += [("Pst3", rxFfeDp.ffePst3)]
        ffe_dp_out += [("Pst4", rxFfeDp.ffePst4)]
        ffe_dp_out += [("Pst5", rxFfeDp.ffePst5)]
        ffe_dp_out += [("Pst6", rxFfeDp.ffePst6)]
        ffe_dp_out += [("Pst7", rxFfeDp.ffePst7)]
        ffe_dp_out += [("Pst8", rxFfeDp.ffePst8)]
        ffe_dp_out += [("Pst9", rxFfeDp.ffePst9)]
        ffe_dp_out += [("Pst10", rxFfeDp.ffePst10)]
        ffe_dp_out += [("Pst11", rxFfeDp.ffePst11)]
        ffe_dp_out += [("Pst12", rxFfeDp.ffePst12)]
        ffe_dp_out += [("Pst13", rxFfeDp.ffePst13)]
        ffe_dp_out += [("Pst14", rxFfeDp.ffePst14)]
        ffe_dp_out += [("Pst15", rxFfeDp.ffePst15)]
        ffe_dp_out += [("Pst16", rxFfeDp.ffePst16)]
        ffe_dp_out += [("Gain", rxFfeDp.ffeGain)]
        ffe_dp_out += [("Blw", rxFfeDp.ffeBlw)]
        ffe_dp_out += [("Dfe", rxFfeDp.ffeDfe)]
        return ffe_dp_out

class AdvancedTuneResults(AutoTuneResults):
    def __init__(self, advResults):
        super(AdvancedTuneResults, self).__init__(advResults.autoTuneResult)
        self.advResults = advResults

    def getFfeCpOut(self):
        rxFfeCp = self.advResults.rxFfeCpComphyC224GX81PLL
        ffe_cp_out = []
        ffe_cp_out += [("Pre3", rxFfeCp.ffePre3)]
        ffe_cp_out += [("Pre2", rxFfeCp.ffePre2)]
        ffe_cp_out += [("Pre1", rxFfeCp.ffePre1)]
        ffe_cp_out += [("Pst1", rxFfeCp.ffePst1)]
        ffe_cp_out += [("Pst2", rxFfeCp.ffePst2)]
        ffe_cp_out += [("Pst3", rxFfeCp.ffePst3)]
        ffe_cp_out += [("Gain", rxFfeCp.ffeGain)]
        ffe_cp_out += [("Blw", rxFfeCp.ffeBlw)]
        return ffe_cp_out

    def getAdvTuneOut(self):
        advResults = self.advResults
        adv_tune_out = []
        adv_tune_out += [("txTrainDoneLane", advResults.txTrainDoneLane)]
        adv_tune_out += [("txTrainPassLane", advResults.txTrainPassLane)]
        adv_tune_out += [("txTrainAbortLane", advResults.txTrainAbortLane)]
        adv_tune_out += [("rxTrainDoneLane", advResults.rxTrainDoneLane)]
        adv_tune_out += [("rxTrainPassLane", advResults.rxTrainPassLane)]
        adv_tune_out += [("rxTrainAbortLane", advResults.rxTrainAbortLane)]
        adv_tune_out += [("trainAbortReasonLane", advResults.trainAbortReasonLane)]
        adv_tune_out += [("timeDurationInfo0Lane", advResults.timeDurationInfo0Lane)]
        adv_tune_out += [("timeDurationInfo1Lane", advResults.timeDurationInfo1Lane)]
        adv_tune_out += [("trxTrainTimeoutLane", advResults.trxTrainTimeoutLane)]
        adv_tune_out += [("trxTrainTimerLane", advResults.trxTrainTimerLane)]
        adv_tune_out += [("rxTrainTimerLane", advResults.rxTrainTimerLane)]
        adv_tune_out += [("trxTrainTimeoutEnLane", advResults.trxTrainTimeoutEnLane)]
        adv_tune_out += [("txTrainFrameDetTimerEnableLane", advResults.txTrainFrameDetTimerEnableLane)]
        adv_tune_out += [("txtrainPatternLockLostEnLane", advResults.txtrainPatternLockLostEnLane)]
        adv_tune_out += [("mcuStatus0Lane", advResults.mcuStatus0Lane)]
        adv_tune_out += [("bgSkewCalBlindEnLane", advResults.bgSkewCalBlindEnLane)]
        adv_tune_out += [("rxSkewCalBlindEnLane", advResults.rxSkewCalBlindEnLane)]
        adv_tune_out += [("trSkewCalBlindEnLane", advResults.trSkewCalBlindEnLane)]
        adv_tune_out += [("rxAdcIfAgcEnLane", advResults.rxAdcIfAgcEnLane)]
        adv_tune_out += [("rxAdcIfAgcGainLane", advResults.rxAdcIfAgcGainLane)]
        adv_tune_out += [("trxTrainAgcEnLane", advResults.trxTrainAgcEnLane)]
        adv_tune_out += [("skewAdapt0Lane", advResults.skewAdapt0Lane)]
        adv_tune_out += [("skewAdapt1Lane", advResults.skewAdapt1Lane)]
        adv_tune_out += [("skewAdapt2Lane", advResults.skewAdapt2Lane)]
        adv_tune_out += [("skewAdapt3Lane", advResults.skewAdapt3Lane)]
        adv_tune_out += [("skewAdapt4Lane", advResults.skewAdapt4Lane)]
        adv_tune_out += [("skewAdapt5Lane", advResults.skewAdapt5Lane)]
        adv_tune_out += [("skewAdapt6Lane", advResults.skewAdapt6Lane)]
        adv_tune_out += [("skewAdapt7Lane", advResults.skewAdapt7Lane)]
        adv_tune_out += [("pinAvddSelRd", advResults.pinAvddSelRd)]
        adv_tune_out += [("intRxTrainFailLane", advResults.intRxTrainFailLane)]
        adv_tune_out += [("intTxTrainFailedLane", advResults.intTxTrainFailedLane)]
        adv_tune_out += [("rxTrainEnableRdLane", advResults.rxTrainEnableRdLane)]
        adv_tune_out += [("txTrainEnableRdLane", advResults.txTrainEnableRdLane)]
        adv_tune_out += [("rxTrainFailedLane", advResults.rxTrainFailedLane)]
        adv_tune_out += [("rxTrainCompleteLane", advResults.rxTrainCompleteLane)]
        adv_tune_out += [("pinSpdCfgRd", advResults.pinSpdCfgRd)]
        adv_tune_out += [("txE2cDccHsCalResultRdLane", advResults.txE2cDccHsCalResultRdLane)]
        adv_tune_out += [("txE2cDccHsCalTimeoutRdLane", advResults.txE2cDccHsCalTimeoutRdLane)]
        adv_tune_out += [("trxVddrTxclkCalResultExtLane", advResults.trxVddrTxclkCalResultExtLane)]
        adv_tune_out += [("trxVddrTxclkCalResultRdLane", advResults.trxVddrTxclkCalResultRdLane)]
        adv_tune_out += [("rxE2cDccCalResultRdLane", advResults.rxE2cDccCalResultRdLane)]
        adv_tune_out += [("rxAlign90CalResultLsbRdLane", advResults.rxAlign90CalResultLsbRdLane)]
        adv_tune_out += [("rxAlign90CalResultMsbRdLane", advResults.rxAlign90CalResultMsbRdLane)]
        adv_tune_out += [("impcalRxLane", advResults.impcalRxLane)]
        adv_tune_out += [("rxDtlClampingEnLane", advResults.rxDtlClampingEnLane)]
        adv_tune_out += [("dtlClampRstModeLane", advResults.dtlClampRstModeLane)]
        adv_tune_out += [("rxDtlClampingValPosLane", advResults.rxDtlClampingValPosLane)]
        adv_tune_out += [("rxDtlClampingValNegLane", advResults.rxDtlClampingValNegLane)]
        adv_tune_out += [("dtlClampingTriggeredLane", advResults.dtlClampingTriggeredLane)]
        adv_tune_out += [("trxTrainRetrailReasonLane", advResults.trxTrainRetrailReasonLane)]
        adv_tune_out += [("trxTrainRetrailMaxCountLane", advResults.trxTrainRetrailMaxCountLane)]
        adv_tune_out += [("trxTrainRetrailCountLane", advResults.trxTrainRetrailCountLane)]
        adv_tune_out += [("trxTrainRetrailReasonIter0Lane", advResults.trxTrainRetrailReasonIter0Lane)]
        adv_tune_out += [("trxTrainRetrailReasonIter1Lane", advResults.trxTrainRetrailReasonIter1Lane)]
        adv_tune_out += [("trxTrainRetrailReasonIter2Lane", advResults.trxTrainRetrailReasonIter2Lane)]
        adv_tune_out += [("trxTrainRetrailReasonIter3Lane", advResults.trxTrainRetrailReasonIter3Lane)]
        adv_tune_out += [("trxTrainRetrailReasonIter4Lane", advResults.trxTrainRetrailReasonIter4Lane)]
        adv_tune_out += [("trxTrainRetrailReasonIter5Lane", advResults.trxTrainRetrailReasonIter5Lane)]
        adv_tune_out += [("trxTrainAbortReasonLane", advResults.trxTrainAbortReasonLane)]
        adv_tune_out += [("rxTrainAdcInSatSoftAtTrainEndLane", advResults.rxTrainAdcInSatSoftAtTrainEndLane)]
        adv_tune_out += [("rxTrainAdcInSatHardAtTrainEndLane", advResults.rxTrainAdcInSatHardAtTrainEndLane)]
        return adv_tune_out

def cli_mvHwsSerdesStatusGet(lane, args):
    NUM_COLS = 2

    def add_colon(key, val, key_width, val_width):
        fmt = "%%-%ds" % key_width
        out_str = fmt % key
        xlen = len(out_str) - key_width
        if xlen > 0:
            val_width -= xlen
        fmt = ": %%-%ds" % val_width
        out_str += fmt % val
        return out_str

    def print_data(elem_arr, width=20):
        out_str = ""
        for i, elem in enumerate(elem_arr):
            if(i>1 and (i%NUM_COLS)==0):
                out_str +="\n"
            out_str += add_colon(elem[0], elem[1], width, 20)
        log(out_str)

    def listToStr(_list, glue=', '):
        return(glue.join(map(str, _list)))


    serdes_eth_cmn.print_lane_id(lane)

    isg_num, serdes_num = lane
    statusPtr = ifcs.MV_HWS_SERDES_STATUS()

    rc = ifcs.mvHwsSerdesStatusGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, args.verbose, ifcs.pointer(statusPtr))
    if rc != 0:
         log_err("Failed to get SerDes status rc: %d\n" %(rc));
         return rc

    if args.adv:
        advResultsPtr = ifcs.MV_HWS_SERDES_AUTO_TUNE_ADV_RESULTS_UNT()
        tuneResults = AdvancedTuneResults(advResultsPtr.comphyC224GX81PLLResults)
        if statusPtr.rxReady:
            rc = ifcs.mvHwsSerdesAutoTuneAdvancedResult(0, isg_num, serdes_num,
                    ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(advResultsPtr))
            if rc != 0:
                log_err("Failed to get SerDes advanced tune results\n");
                return rc
    else:
        resultsComphyPtr = ifcs.MV_HWS_SERDES_AUTO_TUNE_RESULTS_UNT()
        tuneResults = AutoTuneResults(resultsComphyPtr.comphyC224GX81PLLResults)
        if statusPtr.rxReady:
            rc = ifcs.mvHwsSerdesAutoTuneResult(0, isg_num, serdes_num,
                    ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(resultsComphyPtr))
            if rc != 0:
                log_err("Failed to get SerDes tune results\n");
                return rc

    #COMMON - PLL power, Loopback mode, MR mode, CDR lock,
    #         temperature, Acquisition rate
    cmn_out = []
    cmn_out += [["LCPLL power", statusPtr.pllPower]]
    cmn_out += [["LCPLL locked", statusPtr.cmnLocked]]
    cmn_out += [["MR mode", statusPtr.mrMode]]
    cmn_out += [["Loopback mode", lbmode_enum_to_str_dict[statusPtr.lbMode]]]
    #if args.verbose:
    cmn_out += [["Temperature", statusPtr.temperature]]
    cmn_out += [["Acquisition rate", acq_rate_enum_to_str_dict[statusPtr.acqRate]]]

    log("--"*15+" COMMON "+"--"*15)
    print_data(cmn_out)

    #TX -
    tx_out = []
    tx_out += [["Tx Encoding", encoding_map[statusPtr.txEncoding]]]
    tx_out += [["Tx speed", speed_map[statusPtr.txSpeed]]]
    tx_out += [["Tx width", bus_width_map[statusPtr.txWidth]]]
    tx_out += [["Tx ref clock", ref_clk_map[statusPtr.txFreq]]]
    tx_out += [["Tx ref clock source", ref_clk_src_enum_to_str_dict[statusPtr.txClkSel]]]
    tx_out += [["Tx polarity", statusPtr.txPolarity]]
    tx_out += [["Tx gray code", statusPtr.txGrayCode]]
    tx_out += [["Tx MSBLSB swap", statusPtr.txSwapMsbLsb]]
    tx_out += [["Tx pre code", statusPtr.txPreCode]]
    tx_out += [["Tx RPLL power", statusPtr.powerTx]]
    tx_out += [["Tx RPLL locked", statusPtr.tsLocked]]
    tx_out += [["Tx Ready", statusPtr.txReady]]
    tx_out += [["Tx output", statusPtr.txOutputEn]]
    tx_out += [["Tx Phy test enabled", statusPtr.ptTxEn]]
    tx_out += [["Tx Phy test pattern", prbs_enum_to_str_dict[statusPtr.txPattern]]]
    if statusPtr.txPattern == ifcs.USER:
        tx_out += [["Tx PRBS USER pattern", statusPtr.txUserPattern]]

    log("--"*16+" TX "+"--"*16)
    print_data(tx_out)

    #TX taps
    tx_taps_out = tuneResults.getTxTapsOut()
    log("--"*15+" Tx taps "+"--"*15)
    print_data(tx_taps_out)

    #RX -
    rx_out = []
    rx_out += [["Rx Encoding", encoding_map[statusPtr.rxEncoding]]]
    rx_out += [["Rx speed", speed_map[statusPtr.rxSpeed]]]
    rx_out += [["Rx width", bus_width_map[statusPtr.rxWidth]]]
    rx_out += [["Rx ref clock", ref_clk_map[statusPtr.rxFreq]]]
    rx_out += [["Rx ref clock source", ref_clk_src_enum_to_str_dict[statusPtr.rxClkSel]]]
    rx_out += [["Rx polarity", statusPtr.rxPolarity]]
    rx_out += [["Rx gray code", statusPtr.rxGrayCode]]
    rx_out += [["Rx MSBLSB swap", statusPtr.rxSwapMsbLsb]]
    rx_out += [["Rx pre code", statusPtr.rxPreCode]]
    rx_out += [["Rx RPLL power", statusPtr.powerRx]]
    rx_out += [["Rx RPLL locked", statusPtr.rsLocked]]
    rx_out += [["Rx Ready", statusPtr.rxReady]]
    rx_out += tuneResults.getRxOut(isg_num,serdes_num)
    rx_out += [["Rx Phy test enabled", statusPtr.ptRxEn]]
    rx_out += [["Rx Phy test pattern", prbs_enum_to_str_dict[statusPtr.rxPattern]]]
    if statusPtr.rxPattern == ifcs.USER:
        rx_out += [["Rx PRBS USER pattern", statusPtr.rxUserPattern]]
    rx_out += [["Comparator lock", statusPtr.comparatorStatsLock]]
    rx_out += [["Comparator pass", statusPtr.comparatorStatsPass]]
    rx_out += [["Comparator total bits", statusPtr.comparatorStatsTotalBits]]
    rx_out += [["Comparator total error bits", statusPtr.comparatorStatsTotalErrorBits]]
    if  statusPtr.comparatorStatsTotalBits:
        ber = "{:1.1e}".format(statusPtr.comparatorStatsTotalErrorBits / statusPtr.comparatorStatsTotalBits)
    else:
        ber = "N/A"
    rx_out += [["Comparator BER", ber]]
    log("--"*16+" RX "+"--"*16)
    print_data(rx_out)

    #CTLE -
    ctle_out = tuneResults.getCtleOut()
    log("--"*16+" CTLE "+"--"*16)
    print_data(ctle_out)

    #CDR -
    cdr_out = tuneResults.getCdrOut()
    log("--"*16+" CDR "+"--"*16)
    print_data(cdr_out)

    ffe_dp_out = tuneResults.getFfeDpOut()
    log("--"*13+" FFE (data path) "+"--"*13)
    print_data(ffe_dp_out)

    if args.adv:
        ffe_cp_out = tuneResults.getFfeCpOut()
        log("--"*13+" FFE (clock path) "+"--"*13)
        print_data(ffe_cp_out)

        adv_tune_out = tuneResults.getAdvTuneOut()
        log("--"*17+" Adv tune results "+"--"*17)
        print_data(adv_tune_out, 30)

def cli_mvHwsSerdesRxInit(lane, args):
    isg_num, serdes_num = lane

    rc = ifcs.mvHwsSerdesRxInit(0, isg_num, serdes_num,
            args.time_out)
    if rc != 0:
        log_err("SerDes RX init failed isg:%d serdes:%d\n" %(isg_num,serdes_num));
        return rc

def cli_mvHwsSerdesCmnInit(lane, args):
    isg_num, serdes_num = lane

    serdesConfig = ifcs.MV_HWS_SERDES_CMN_CONFIG_STC()

    if args.ref_clk in ref_clk_str_to_enum_dict.keys():
        ref_clk = ref_clk_str_to_enum_dict[args.ref_clk]
    else:
       log_err("Invalid ref_clk\n");
       return ifcs.IFCS_INVAL

    if args.ref_clk_src in ref_clk_src_str_to_enum_dict.keys():
        ref_clk_src = ref_clk_src_str_to_enum_dict[args.ref_clk_src]
    else:
       log_err("Invalid ref_clk_src\n");
       return ifcs.IFCS_INVAL

    serdesConfig.refClock         = ref_clk
    serdesConfig.refClockSource   = ref_clk_src

    rc = ifcs.mvHwsSerdesCmnInit(0, isg_num, serdes_num,
            ifcs.pointer(serdesConfig))
    if rc != 0:
        log_err("Failed SerDes common config isg:%d serdes:%d\n" %(isg_num,serdes_num));
        return rc

def cli_mvHwsSerdesPowerCtrl(lane, args):
    isg_num, serdes_num = lane

    serdesConfig = ifcs.MV_HWS_SERDES_CONFIG_STC()

    if args.power_up:
        if args.speed in speed_str_to_enum_dict.keys():
            speed = speed_str_to_enum_dict[args.speed]
        else:
           log_err("Invalid speed\n");
           return ifcs.IFCS_INVAL

        if args.bus_width in bus_width_str_to_enum_dict.keys():
            bus_width = bus_width_str_to_enum_dict[args.bus_width]
        else:
           log_err("Invalid bus_width\n");
           return ifcs.IFCS_INVAL

        if args.enc_type in enc_type_str_to_enum_dict.keys():
            enc_type = enc_type_str_to_enum_dict[args.enc_type]
        else:
           log_err("Invalid enc_type\n");
           return ifcs.IFCS_INVAL

        if args.power_level in power_level_str_to_enum_dict.keys():
            power_level = power_level_str_to_enum_dict[args.power_level]
        else:
           log_err("Invalid power_level\n");
           return ifcs.IFCS_INVAL

        serdesConfig.serdesType       = ifcs.COM_PHY_N3C224GX81PLL
        serdesConfig.baudRate         = speed
        serdesConfig.busWidth         = bus_width
        serdesConfig.encoding         = enc_type
        serdesConfig.powerLevel       = power_level

    rc = ifcs.mvHwsSerdesPowerCtrl(0, isg_num, serdes_num,
            args.power_up, ifcs.pointer(serdesConfig))
    if rc != 0:
        log_err("Failed to set power ctrl isg:%d serdes:%d\n" %(isg_num,serdes_num));
        return rc

def cli_mvHwsSerdesTestGen(lane, args):
    isg_num, serdes_num = lane
    if args.pattern in prbs_str_to_enum_dict.keys():
        pattern = prbs_str_to_enum_dict[args.pattern]
    else:
       log_err("Invalid test gen mode\n");
       return ifcs.IFCS_INVAL

    if args.mode in test_gen_mode_str_to_enum_dict.keys():
        mode = test_gen_mode_str_to_enum_dict[args.mode]
    else:
       log_err("Invalid test gen mode\n");
       return ifcs.IFCS_INVAL

    if args.direction in test_gen_dir_str_to_enum_dict.keys():
        direction = test_gen_dir_str_to_enum_dict[args.direction]
    else:
       log_err("Invalid test gen direction\n");
       return ifcs.IFCS_INVAL

    rc = ifcs.mvHwsSerdesTestGen(0, isg_num, serdes_num,
            pattern, ifcs.COM_PHY_N3C224GX81PLL, mode, direction)
    if rc != 0:
        log_err("Failed to set test gen\n");
        return ifcs.IFCS_INVAL
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesTestGenStatus(lane, args):
    isg_num, serdes_num = lane
    status = ifcs.MV_HWS_SERDES_TEST_GEN_STATUS()

    rc = ifcs.mvHwsSerdesTestGenStatus(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.PRBS7, args.accumulate, ifcs.pointer(status))
    if rc != 0:
        log_err("Failed to get test gen status\n");
        return ifcs.IFCS_INVAL

    if status.framesCntr:
        ber = "{:1.1e}".format(status.errorsCntr / status.framesCntr)
    else:
        ber = "N/A"

    serdes_eth_cmn.print_lane_id(lane)
    log(" Lock status        : {}".format(status.lockStatus))
    log(" Rx error bit count : {}".format(status.errorsCntr))
    log(" Rx total bit count : {}".format(status.framesCntr))
    log(" BER                : {}".format(ber))
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesAutoTuneResult(lane, args):
    NUM_COLS = 2

    def add_colon(elems):
        if len(elems[0]) > 0 or len(elems[1]) > 0:
            return '%-30s: %-20s' % (elems[0], elems[1])
        else:
            return '%-18s  %-20s' % ('','')

    def print_data(elem_arr):
        out_str = ""
        for i in range (len(elem_arr)):
            if(i>1 and (i%NUM_COLS)==0):
                out_str +="\n"
            out_str +=add_colon(elem_arr[i])
        log(out_str)

    def listToStr(_list, glue=', '):
        return(glue.join(map(str, _list)))


    serdes_eth_cmn.print_lane_id(lane)

    isg_num, serdes_num = lane
    if args.adv:
        advResultsPtr = ifcs.MV_HWS_SERDES_AUTO_TUNE_ADV_RESULTS_UNT()
        tuneResults = AdvancedTuneResults(advResultsPtr.comphyC224GX81PLLResults)
    else:
        resultsComphyPtr = ifcs.MV_HWS_SERDES_AUTO_TUNE_RESULTS_UNT()
        tuneResults = AutoTuneResults(resultsComphyPtr.comphyC224GX81PLLResults)
    resultsPtr = tuneResults.results

    if args.adv:
        rc = ifcs.mvHwsSerdesAutoTuneAdvancedResult(0, isg_num, serdes_num,
                ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(advResultsPtr))
    else:
        rc = ifcs.mvHwsSerdesAutoTuneResult(0, isg_num, serdes_num,
                ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(resultsComphyPtr))
    if rc != 0:
         log_err("Failed to get SerDes tune results\n");
         return rc
    #TX taps
    tx_taps_out = tuneResults.getTxTapsOut()
    log("--"*19+" Tx taps "+"--"*19)
    print_data(tx_taps_out)

    #RX -
    rx_out = tuneResults.getRxOut(isg_num,serdes_num)
    log("--"*20+" RX "+"--"*20)
    print_data(rx_out)

    #CTLE -
    ctle_out =tuneResults.getCtleOut()
    log("--"*20+" CTLE "+"--"*20)
    print_data(ctle_out)

    #CDR -
    cdr_out = tuneResults.getCdrOut()
    log("--"*20+" CDR "+"--"*20)
    print_data(cdr_out)

    ffe_dp_out = tuneResults.getFfeDpOut()
    log("--"*17+" FFE (data path) "+"--"*17)
    print_data(ffe_dp_out)

    txEncodingPtr = ifcs.MV_HWS_SERDES_ENCODING_TYPE()
    rxEncodingPtr = ifcs.MV_HWS_SERDES_ENCODING_TYPE()

    rc = ifcs.mvHwsSerdesEncodingTypeGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(txEncodingPtr), ifcs.pointer(rxEncodingPtr))
    if rc != 0:
        log_err("Failed to get Enc type\n");
        return rc

    if txEncodingPtr.value == ifcs.SERDES_ENCODING_NRZ:
        tx_encoding = "NRZ"
        preset_cfg = resultsPtr.preset_cfg_nrz
        preset_names = ("INIT", "PRESET1")

    elif txEncodingPtr.value == ifcs.SERDES_ENCODING_PAM4:
        tx_encoding = "PAM4"
        preset_cfg = resultsPtr.preset_cfg_pam4
        preset_names = ["PRESET{}".format(i+1) for i, _ in enumerate(preset_cfg)]

    cfg_out = []
    cfg_out += [["Preset", preset_cfg[0].preset]]
    log("--"*17+" TxKRPreset ({}) ".format(tx_encoding)+"--"*17)
    print_data(cfg_out)

    for i, cfg in enumerate(preset_cfg):
        cfg_out = []
        # TxKR presets define 5 coefficients. pre3, pre1 and post1 polarities are
        # fixed to negative; pre2 and main are positive.
        cfg_out += [["Pre3", -cfg.pre3]]
        cfg_out += [["Pre2", cfg.pre2]]
        cfg_out += [["Pre1", -cfg.pre1]]
        cfg_out += [["Main", cfg.main]]
        cfg_out += [["Post1", -cfg.post1]]
        log("--"*16+" Preset select {} ".format(preset_names[i])+"--"*16)
        print_data(cfg_out)

    #ADV - tune results
    if args.adv:
        ffe_cp_out = tuneResults.getFfeCpOut()
        log("--"*17+" FFE (clock path) "+"--"*17)
        print_data(ffe_cp_out)

        adv_tune_out = tuneResults.getAdvTuneOut()
        log("--"*17+" Adv tune results "+"--"*17)
        print_data(adv_tune_out)

def cli_mvHwsSerdesAutoTuneStatus(lane, args):
    isg_num, serdes_num = lane
    rxStatus = ifcs.MV_HWS_AUTO_TUNE_STATUS()
    txStatus = ifcs.MV_HWS_AUTO_TUNE_STATUS()

    rc = ifcs.mvHwsSerdesAutoTuneStatus(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(rxStatus), ifcs.pointer(txStatus))
    if rc != 0:
        log_err("Failed to get auto tune status\n");
        return ifcs.IFCS_INVAL

    serdes_eth_cmn.print_lane_id(lane)
    log(" Rx status    : {}".format(tune_status_enum_to_str_dict[rxStatus.value]))
    log(" Tx status    : {}".format(tune_status_enum_to_str_dict[txStatus.value]))
    return ifcs.IFCS_SUCCESS

def cli_mvHwsSerdesManualRxConfig(lane, args):
    isg_num, serdes_num = lane
    rxConfig = ifcs.MV_HWS_SERDES_RX_CONFIG_DATA_UNT()

    rxConfig.rxComphyC224GX81PLL.trainR = args.train_r
    rxConfig.rxComphyC224GX81PLL.trainC = args.train_c
    rxConfig.rxComphyC224GX81PLL.trainGc = args.train_gc
    rxConfig.rxComphyC224GX81PLL.trainAtten = args.train_atten
    rxConfig.rxComphyC224GX81PLL.kpFrac = args.kp_frac
    rxConfig.rxComphyC224GX81PLL.kpShift = args.kp_shift
    rxConfig.rxComphyC224GX81PLL.kiFrac = args.ki_frac
    rxConfig.rxComphyC224GX81PLL.kiShift = args.ki_shift
    rxConfig.rxComphyC224GX81PLL.squelchThreshold = args.squelch_th

    rc = ifcs.mvHwsSerdesManualRxConfig(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(rxConfig))
    if rc != 0:
        log_err("Failed to set Rx config\n");
        return rc

def cli_mvHwsSerdesTxPresetConfig(lane, args):
    isg_num, serdes_num = lane
    txEncodingPtr = ifcs.MV_HWS_SERDES_ENCODING_TYPE()
    rxEncodingPtr = ifcs.MV_HWS_SERDES_ENCODING_TYPE()

    rc = ifcs.mvHwsSerdesEncodingTypeGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(txEncodingPtr), ifcs.pointer(rxEncodingPtr))
    if rc != 0:
        log_err("Failed to get Enc type\n");
        return rc
    #Preset init options
    #  NRZ  - PRESET_INIT_INIT, INIT_PRESET1
    #  PAM4 - INIT_PRESET1, INIT_PRESET2, INIT_PRESET3, INIT_PRESET4, INIT_PRESET5
    nrz_preset_init = [ifcs.PRESET_INIT_INIT, ifcs.PRESET_INIT_PRESET1]
    pam4_preset_init = [ifcs.PRESET_INIT_PRESET1,ifcs.PRESET_INIT_PRESET2,ifcs.PRESET_INIT_PRESET3,ifcs.PRESET_INIT_PRESET4,ifcs.PRESET_INIT_PRESET5]

    if txEncodingPtr.value == ifcs.SERDES_ENCODING_NA:
        log("Tx not ready\n")
        return ifcs.IFCS_INVAL

    if args.preset_sel_pre3 in preset_init_str_to_enum_dict.keys():
        preset_sel_pre3 = preset_init_str_to_enum_dict[args.preset_sel_pre3]
    else:
       log_err("Invalid preset sel PRE3\n");
       return ifcs.IFCS_INVAL

    if args.preset_sel_pre2 in preset_init_str_to_enum_dict.keys():
        preset_sel_pre2 = preset_init_str_to_enum_dict[args.preset_sel_pre2]
    else:
       log_err("Invalid preset sel PRE2\n");
       return ifcs.IFCS_INVAL

    if args.preset_sel_pre in preset_init_str_to_enum_dict.keys():
        preset_sel_pre = preset_init_str_to_enum_dict[args.preset_sel_pre]
    else:
       log_err("Invalid preset sel PRE\n");
       return ifcs.IFCS_INVAL

    if args.preset_sel_main in preset_init_str_to_enum_dict.keys():
        preset_sel_main = preset_init_str_to_enum_dict[args.preset_sel_main]
    else:
       log_err("Invalid preset sel MAIN\n");
       return ifcs.IFCS_INVAL

    if args.preset_sel_post in preset_init_str_to_enum_dict.keys():
        preset_sel_post = preset_init_str_to_enum_dict[args.preset_sel_post]
    else:
       log_err("Invalid preset sel PRE3\n");
       return ifcs.IFCS_INVAL

    if txEncodingPtr.value == ifcs.SERDES_ENCODING_NRZ:
        if (preset_sel_pre3 not in nrz_preset_init):
            log("Init value error for pre3 preset sel, valid choice for NRZ - INIT, PRESET1\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_pre2 not in nrz_preset_init):
            log("Init value error for pre2 preset sel, valid choice for NRZ - INIT, PRESET1\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_pre not in nrz_preset_init):
            log("Init value error for pre preset sel, valid choice for NRZ - INIT, PRESET1\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_main not in nrz_preset_init):
            log("Init value error for main preset sel, valid choice for NRZ - INIT, PRESET1\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_post not in nrz_preset_init):
            log("Init value error for post preset sel, valid choice for NRZ - INIT, PRESET1\n")
            return ifcs.IFCS_INVAL
    elif txEncodingPtr.value == ifcs.SERDES_ENCODING_PAM4:
        if (preset_sel_pre3 not in pam4_preset_init):
            log("Init value error for pre3 preset sel, valid choice for PAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_pre2 not in pam4_preset_init):
            log("Init value error for pre2 preset sel, valid choice for PAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_pre not in pam4_preset_init):
            log("Init value error for pre preset sel, valid choice for PAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n")
            return
        if (preset_sel_main not in pam4_preset_init):
            log("Init value error for main preset sel, valid choice for PAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n")
            return ifcs.IFCS_INVAL
        if (preset_sel_post not in pam4_preset_init):
            log("Init value error for post preset sel, valid choice for PAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n")
            return ifcs.IFCS_INVAL

    txPresetConfig = ifcs.MV_HWS_SERDES_TX_PRESET_CONFIG_DATA_UNT()
    # CLI tap args map onto the C preset struct's 7-tap set. The parser exposes
    # --pre3/--pre2/--pre1 (pre-cursors), --main, and --post1 as the five taps a
    # TxKR preset programs (matching mvHwsComphyN3C224GX81PLLSerdesTxPresetConfigSet:
    # C0<-pre3, C1<-pre2, C2<-pre1, C3<-main, C4<-post1).
    txPresetConfig.txPresetComphyC224GX81PLL.pre3  = args.pre3
    txPresetConfig.txPresetComphyC224GX81PLL.pre2  = args.pre2
    txPresetConfig.txPresetComphyC224GX81PLL.pre1  = args.pre1
    txPresetConfig.txPresetComphyC224GX81PLL.main  = args.main
    txPresetConfig.txPresetComphyC224GX81PLL.post1 = args.post1

    txPresetConfig.txPresetComphyC224GX81PLL.presetSelPre3 = preset_sel_pre3
    txPresetConfig.txPresetComphyC224GX81PLL.presetSelPre2 = preset_sel_pre2
    txPresetConfig.txPresetComphyC224GX81PLL.presetSelPre  = preset_sel_pre
    txPresetConfig.txPresetComphyC224GX81PLL.presetSelMain = preset_sel_main
    txPresetConfig.txPresetComphyC224GX81PLL.presetSelPost = preset_sel_post

    if args.preset:
        preset = args.preset
    else:
        preset = 6 # default value will be set; NRZ  - 1, 2 default - 2; PAM4 - 1, 2, 3, 4, 5 default - 1
    txPresetConfig.txPresetComphyC224GX81PLL.preset = preset

    rc = ifcs.mvHwsSerdesTxPresetConfig(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(txPresetConfig))
    if rc != 0:
        log_err("Failed to set SerDes TX preset config\n");
        return rc

def cli_mvHwsSerdesTemperatureMinMaxGet(lane_list, args):
    if not args.min_max:
        return

    min_temp = ifcs.GT_FLOAT64(1000000.00)
    max_temp = ifcs.GT_FLOAT64()

    for lane in lane_list:
        isg_num, serdes_num = lane
        temp = ifcs.GT_FLOAT64()

        rc = ifcs.mvHwsSerdesTemperatureGet(0, isg_num, serdes_num,
                ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(temp))
        if rc != 0:
            log_err("Failed to get temperature\n");
            return rc
        if max_temp.value < temp.value:
            max_temp = temp
            max_temp_isg = isg_num
            max_temp_lane = serdes_num
        if min_temp.value > temp.value:
            min_temp = temp
            min_temp_isg = isg_num
            min_temp_lane = serdes_num

    log(" Min Temperature   : {} [Cold lane - ISG : {}  lane : {}]".format(min_temp.value,min_temp_isg,min_temp_lane))
    log(" Max Temperature   : {} [Hot lane  - ISG : {}  lane : {}]".format(max_temp.value,max_temp_isg,max_temp_lane))

def cli_mvHwsSerdesTemperatureGet(lane, args):
    if args.min_max:
        return

    isg_num, serdes_num = lane
    temp = ifcs.GT_FLOAT64()

    rc = ifcs.mvHwsSerdesTemperatureGet(0, isg_num, serdes_num,
            ifcs.COM_PHY_N3C224GX81PLL, ifcs.pointer(temp))
    if rc != 0:
        log_err("Failed to get temperature\n");
        return rc
    serdes_eth_cmn.print_lane_id(lane, no_linefeed=True)
    log(" Temperature   : {}".format(temp.value))

def cli_mvHwsSerdesBLERGet(lane, args):
    isg_num, serdes_num = lane
    blerData = ifcs.MV_HWS_SERDES_BLER_DATA()

    if args.mode not in fec_rsmode_str_to_enum_dict:
        log_err(" Invalid mode: {}. Expected 528 or 544.".format(args.mode))
        return ifcs.IFCS_INVAL

    mode = fec_rsmode_str_to_enum_dict[args.mode]
    rc = ifcs.mvHwsSerdesBLERGet(
        0,
        isg_num,
        serdes_num,
        args.delay_ms,
        mode,
        ifcs.pointer(blerData)
    )
    if rc != 0:
        log_err("Failed to get BLER\n")
        return rc
    serdes_eth_cmn.print_lane_id(lane)
    log(" Block Count       : {}".format(blerData.blockCount))
    log(" Block Errors      : {}".format(blerData.blockErrors))
    log(" Block Error Ratio : {:.6e}".format(blerData.blockErrorRatio))

def cli_pcsber(lane, args):
    if args.continuous:
        run_repaint_until_keypress(pcsber, lane, args)
    else:
        pcsber(lane, args)

def add_parser(parser):
    eth_t100_funcs = {
        #"firmware": (None, cli_firmware),
        #"status": (None, cli_status),
        #"config": (None, cli_config),
        #"hist": (cli_hist_multi_start, cli_hist),
        #"ber": (cli_ber_multi_start, cli_ber),
        "pcsber": (cli_pcsber_multi_start, cli_pcsber),
    }

    subparsers = serdes_eth_cmn.add_parser(parser, eth_t100_funcs, None, "COMPHY_N3C224GX81PLL")

    parser_vendor = subparsers.add_parser('hws', help='SerDes hws-specific commands')
    subparser_vendor = parser_vendor.add_subparsers()

    # Port-level PMD (link training) log dump for a given port + lane.
    parser_pmdlog = subparsers.add_parser('pmd-log',
        help='Print SerDes link training (PMD) log for a port/lane')
    parser_pmdlog.add_argument('--log_size', type=int, default=10,
        help='Number of log entries to read (Default 10, max 16)')
    parser_pmdlog.set_defaults(func=cli_pmd_log_run)

    parser_read = subparser_vendor.add_parser('mvHwsSerdesFwDownload', help='SerDes firmware download')
    parser_read.add_argument('--fw_file', type=str, default='NONE', required=True, metavar='FW_FILE_PATH', help='Firmware file')
    parser_read.set_defaults(func=serdes_eth_cmn.multi_callback(None, cli_mvHwsSerdesFwDownload))

    parser_status = subparser_vendor.add_parser('mvHwsSerdesStatusGet', help='Show status')
    parser_status.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_status.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_status.add_argument('-v', '--verbose', action='store_true')
    parser_status.add_argument('--adv', action='store_true', help=argparse.SUPPRESS)
    parser_status.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesStatusGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesPolarityConfigSet', help='Set SerDes Tx and Rx polarity')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--invert_tx', type=strtobool, default=False, metavar='INVERT_TX', help='True/False (Default:False)')
    parser_read.add_argument('--invert_rx', type=strtobool, default=False, metavar='INVERT_RX', help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesPolarityConfigSet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesPolarityConfigGet', help='Get SerDes Tx and Rx polarity')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesPolarityConfigGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesCmnInit', help='SerDes common config',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--ref_clk', type=str.upper, default='NONE', choices=ref_clk_str_list, metavar='REF_CLK', help='\n'.join(ref_clk_str_list))
    parser_read.add_argument('--ref_clk_src', type=str.upper, default='NONE', choices=ref_clk_src_str_list, metavar='REF_CLK_SRC', help='\n'.join(ref_clk_src_str_list))
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesCmnInit))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesPowerCtrl', help='Power control',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--power_up', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--speed', type=str.upper, default='NONE', choices=speed_str_list, metavar='SPEED', help='\n'.join(speed_str_list))
    parser_read.add_argument('--bus_width', type=str.upper, default='NONE', choices=bus_width_str_list, metavar='BUS_WIDTH', help='\n'.join(bus_width_str_list))
    parser_read.add_argument('--enc_type', type=str.upper, default='NONE', choices=enc_type_str_list, metavar='ENC_TYPE', help='\n'.join(enc_type_str_list))
    parser_read.add_argument('--power_level', type=str.upper, default='NONE', choices=power_level_str_list, metavar='POWER_LEVEL', help='\n'.join(power_level_str_list))
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesPowerCtrl))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesRxInit', help='Start RX init',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--time_out', type=int, default=1000, metavar='TIME_OUT', help='Time out for RX init completion in ms (Default:1000)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesRxInit))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesEncodingSet', help='Set SerDes Tx Rx encoding - gray code, swap MSB/LSB, pre code')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--gray_code_tx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--msb_lsb_swap_tx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--pre_code_tx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--gray_code_rx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--msb_lsb_swap_rx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--pre_code_rx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesEncodingSet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesEncodingGet', help='Get SerDes Tx Rx encoding - gray code, swap MSB/LSB, pre code')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesEncodingGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesLoopbackSet',
                                               help='Set SerDes loopback, DIGITAL_RX_TX loopback can only be set one lane at a time within the quad',
                                               formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--lb_mode', type=str.upper, default='NONE', choices=lbmode_str_list, metavar='LB_MODE', help='\n'.join(lbmode_str_list)+'\n(Default:NONE)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesLoopbackSet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesEncodingTypeGet', help='Get SerDes encoding type',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesEncodingTypeGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesPPMSet', help='Set PPM')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--ppm', type=int, required=True, choices=range(-32768,+32767), metavar='PPM', help='PPM value range (-32768 to +32767)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesPPMSet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesPPMGet', help='Get PPM')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesPPMGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesReset', help='SerDes reset',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--reset_type', type=str.upper, default='SOFT', choices=reset_type_str_list, metavar='RESET_TYPE', help='\n'.join(reset_type_str_list)+'\n(Default:SOFT)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesReset))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesManualTxConfig', help='TX config')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--pre3', type=int, default=127, help='TX Eq pre3 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--pre2', type=int, default=127, help='TX Eq pre2 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--pre', type=int, default=127, help='TX Eq pre (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--main', type=int, default=127, help='TX Eq main (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--post', type=int, default=127, help='TX Eq post (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--post2', type=int, default=127, help='TX Eq post2 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--post3', type=int, default=127, help='TX Eq post3 (Set 127 to skip this argument, Default:127)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesManualTxConfig))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesManualRxConfig', help='RX config',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--train_r', type=serdes_eth_cmn.Hex, default=None, required=True, help='Train R')
    parser_read.add_argument('--train_c', type=serdes_eth_cmn.Hex, default=None, required=True, help='Train C')
    parser_read.add_argument('--train_gc', type=serdes_eth_cmn.Hex, default=None, required=True, help='Train GC')
    parser_read.add_argument('--train_atten', type=serdes_eth_cmn.Hex, default=None, required=True, help='Train Atten')
    parser_read.add_argument('--kp_frac', type=serdes_eth_cmn.Hex, default=None, required=True, help='KP frac')
    parser_read.add_argument('--kp_shift', type=serdes_eth_cmn.Hex, default=None, required=True, help='KP shift')
    parser_read.add_argument('--ki_frac', type=serdes_eth_cmn.Hex, default=None, required=True, help='KI frac')
    parser_read.add_argument('--ki_shift', type=serdes_eth_cmn.Hex, default=None, required=True, help='KI shift')
    parser_read.add_argument('--squelch_th', type=int, default=None, required=True, help='Squelch thresold')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesManualRxConfig))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesTxPresetConfig', help='TX preset config',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--preset_sel_pre3', type=str.upper, default='PRESET1', choices=preset_init_str_list, metavar='PRESET_SEL_PRE3', help='NRZ - PRESET_INIT, PRESET1\nPAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n(Default:PRESET1)')
    parser_read.add_argument('--pre3', type=int, default=127, help='TX Eq pre3 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--preset_sel_pre2', type=str.upper, default='PRESET1', choices=preset_init_str_list, metavar='PRESET_SEL_PRE2', help='NRZ - PRESET_INIT, PRESET1\nPAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n(Default:PRESET1)')
    parser_read.add_argument('--pre2', type=int, default=127, help='TX Eq pre2 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--preset_sel_pre', type=str.upper, default='PRESET1', choices=preset_init_str_list, metavar='PRESET_SEL_PRE', help='NRZ - PRESET_INIT, PRESET1\nPAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n(Default:PRESET1)')
    parser_read.add_argument('--pre1', type=int, default=127, help='TX Eq pre1 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--preset_sel_main', type=str.upper, default='PRESET1', choices=preset_init_str_list, metavar='PRESET_SEL_MAIN', help='NRZ - PRESET_INIT, PRESET1\nPAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n(Default:PRESET1)')
    parser_read.add_argument('--main', type=int, default=127, help='TX Eq main (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--preset_sel_post', type=str.upper, default='PRESET1', choices=preset_init_str_list, metavar='PRESET_SEL_POST', help='NRZ - PRESET_INIT, PRESET1\nPAM4 - PRESET1, PRESET2, PRESET3, PRESET4, PRESET5\n(Default:PRESET1)')
    parser_read.add_argument('--post1', type=int, default=127, help='TX Eq post1 (Set 127 to skip this argument, Default:127)')
    parser_read.add_argument('--preset', type=serdes_eth_cmn.Hex, default=None, help='TX preset\n  NRZ  - 1, 2 (Default:2)\n  PAM4 - 1, 2, 3, 4, 5 (Default:1)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesTxPresetConfig))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesTxEnable', help='Enable/Disable Tx')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--enable', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesTxEnable))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesAutoTuneStart', help='Start Tx & Rx Training')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--training_rx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--training_tx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesAutoTuneStart))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesRxAutoTuneStart', help='Start/Stop Rx Training')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--training_rx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesRxAutoTuneStart))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesTxAutoTuneStart', help='Start/Stop Tx Training')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--training_tx', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesTxAutoTuneStart))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesAutoTuneStatus', help='Auto tune status',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesAutoTuneStatus))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesAutoTuneResult', help='Auto tune results',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--adv', type=strtobool, default=False, help=argparse.SUPPRESS)
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesAutoTuneResult))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesTestGen', help='Phy test gen',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--pattern', type=str.upper, default='PRBS7', choices=prbs_str_list, metavar='PATTERN', help='\n'.join(prbs_str_list)+'\n(Default:PRBS7)')
    parser_read.add_argument('--mode', type=str.upper, default='NORMAL', choices=test_gen_mode_str_list, metavar='MODE', help='\n'.join(test_gen_mode_str_list)+'\n(Default:NORMAL)')
    parser_read.add_argument('--direction', type=str.upper, required=True, choices=test_gen_dir_str_list, metavar='DIRECTION', help='\n'.join(test_gen_dir_str_list))
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesTestGen))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesTestGenStatus', help='Phy test gen status',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--accumulate', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesTestGenStatus))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesErrorInject', help='Injects errors into the TX data')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--num_bits', type=int, default=1, help='Number of bits (Default:1)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesErrorInject))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesTemperatureGet', help='Get SerDes temperature',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--min_max', type=strtobool, default=False, help="Get min and max temperature for the range of SerDes")
    parser_read.set_defaults(func=multi_callback_t100_hws(cli_mvHwsSerdesTemperatureMinMaxGet, cli_mvHwsSerdesTemperatureGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesBLERGet', help='Get Block Error Rate')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--delay_ms', type=int, default=1000, help='Delay in milliseconds (Default:1000)')
    parser_read.add_argument('--mode', type=str, default='544', choices=['544', '528'], help='FEC RS mode (Default:544)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesBLERGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesCDRLockGet', help='Get CDR Lock status')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesCDRLockGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSignalDetectGet', help='Get signal detect status')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSignalDetectGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSNRGet', help='Get SNR value')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSNRGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSBRGet', help='Get SBR data')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--pre_cursor', type=serdes_eth_cmn.Hex, required=True, help='Pre Cursor')
    parser_read.add_argument('--post_cursor', type=serdes_eth_cmn.Hex, required=True, help='Post Cursor')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSBRGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesOCMGet', help='Get OCM data')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--input_sel', type=serdes_eth_cmn.Hex, required=True, help='Input select')
    parser_read.add_argument('--num_repetitions', type=int, default=1, help='Input select (Default:1)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesOCMGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesEomMatrixGet', help='SerDes EOM matrix',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--print_en', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--min_samples', type=str.upper, default='10_8_E', choices=min_samples_str_list, metavar='MIN_SAMPLES', help='\n'.join(min_samples_str_list)+'\n(Default:10_8_E)\nValid values for 100G:[10_3_E - 10_9_E]')
    parser_read.add_argument('--ber_th', type=str.upper, default='10_6_E', choices=ber_threshold_str_list, metavar='BER_THRESHOLD', help='\n'.join(ber_threshold_str_list)+'\n(Default:10_6_E)\nValid values for 100G:[10_3_E - 10_6_E]')
    parser_read.add_argument('--stats_mode', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--ber_th_max', type=str.upper, default='10_6_E', choices=ber_threshold_str_list, metavar='BER_THRESHOLD_MAX', help='\n'.join(ber_threshold_str_list)+'\n (Default:10_6_E)\nValid values for 100G:[10_3_E - 10_6_E]')
    parser_read.add_argument('--phase_step_sz', type=serdes_eth_cmn.Hex, required=True, help='Phase step size')
    parser_read.add_argument('--volt_step_sz', type=serdes_eth_cmn.Hex, required=True, help='Voltage step size')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesEomMatrixGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesEom1DMatrixGet', help='SerDes 1D EOM matrix',formatter_class=RawTextHelpFormatter)
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--print_en', type=strtobool, default=False, help='True/False (Default:False)')
    parser_read.add_argument('--min_samples', type=str.upper, default='10_8_E', choices=min_samples_str_list, metavar='MIN_SAMPLES', help='\n'.join(min_samples_str_list)+'\n(Default:10_8_E)\nValid values for 100G:[10_3_E - 10_9_E]')
    parser_read.add_argument('--ber_th', type=str.upper, default='10_6_E', choices=ber_threshold_str_list, metavar='BER_THRESHOLD', help='\n'.join(ber_threshold_str_list)+'\n(Default:10_6_E)\nValid values for 100G:[10_3_E - 10_6_E]')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesEom1DMatrixGet))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesRegisterRead', help='Read SerDes register')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--addr', type=serdes_eth_cmn.Hex, required=True, help='Register address')
    parser_read.add_argument('--mask', type=serdes_eth_cmn.Hex, default=0xFFFFFFFF, help='Mask (Default:0xFFFFFFFF)')
    parser_read.add_argument('--step', type=int, default=4, help='Step size (Default:4)')
    parser_read.add_argument('--end_addr', type=serdes_eth_cmn.Hex, help='End of register address')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesRegisterRead))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesRegisterWrite', help='Write SerDes register')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--addr', type=serdes_eth_cmn.Hex, required=True, help='Register address')
    parser_read.add_argument('--mask', type=serdes_eth_cmn.Hex, default=0xFFFFFFFF, help='Mask (Default=0xFFFFFFFF)')
    parser_read.add_argument('--data', type=serdes_eth_cmn.Hex, required=True, help='Data value to be written')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesRegisterWrite))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesSDWRegisterRead', help='Read SDW SerDes register')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--addr', type=serdes_eth_cmn.Hex, required=True, help='Register address')
    parser_read.add_argument('--mask', type=serdes_eth_cmn.Hex, default=0xFFFFFFFF, help='Mask (Default:0xFFFFFFFF)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesSDWRegisterRead))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesSDWRegisterWrite', help='Write SDW SerDes register')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--addr', type=serdes_eth_cmn.Hex, required=True, help='Register address')
    parser_read.add_argument('--mask', type=serdes_eth_cmn.Hex, default=0xFFFFFFFF, help='Mask (Default=0xFFFFFFFF)')
    parser_read.add_argument('--data', type=serdes_eth_cmn.Hex, required=True, help='Data value to be written')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesSDWRegisterWrite))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSquelchThresholdSet', help='Set squelch threshold')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--threshold', type=int, required=True, help='Squelch threshold value (0-63)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSquelchThresholdSet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSquelchThresholdGet', help='Get squelch threshold')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSquelchThresholdGet))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesDisplayTrainingLog', help='Display Training Log')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--log_size', type=int, default=10, help='Log array size entries (Default 10)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesDisplayTrainingLog))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSetRxNLUTEnable', help='Read Rx NLU enable')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nalid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--state', type=strtobool, default=0, help='state is either 1-true or 0-false')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSetRxNLUTEnable))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetRxNLUTEnable', help='Read RX NLUT enable')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetRxNLUTEnable))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetRxNLUT', help='Read Tx NLUT')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetRxNLUT))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSetTxFirMode', help='Write serdes Tx FIR Mode')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--mode', type=str.upper, default='21L_4N', choices=fir_mode_str_list, metavar='MODE', help='\n'.join(fir_mode_str_list)+'\n(Default:21L_4N)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSetTxFirMode))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetTxFirMode', help='Read serdes Tx FIR Mode')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetTxFirMode))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSetTxNLUTDelay', help='Write serdes Tx NLU delay')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--value', type=int, default=0, help='NLU delay value')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSetTxNLUTDelay))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetTxNLUTDelay', help='Read TX NLU delay')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetTxNLUTDelay))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesSetTxNLUT', help='Write Tx NLU')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--txNlut', type=serdes_eth_cmn.parse_array, default=[], help='Tx NLUT buffer (comma-separated values, e.g., 1,2,3 or ranges like 0:10)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesSetTxNLUT))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetTxNLUT', help='Read TX NLU')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetTxNLUT))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetRxNLUTM', help='Read RX NLUTM')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--ui', type=int, default=4, choices=[3, 4, 5], help='UI index to read, valid values 3, 4 or 5 (Default:4)')
    parser_read.add_argument('--delay', type=int, default=2, choices=[2, 3], help='NLUTM error delay, valid values 2 or 3 (required when --ui != 5) (Default:2)')
    parser_read.add_argument('--hitMax', type=int, default=0, help='Read hitMax should be < 20')
    parser_read.add_argument('--timeoutMs', type=int, default=1000, help='NLUTM done-poll timeout/iteration count; must be > 0 (0 fails immediately) (Default:1000)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetRxNLUTM))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetFfeTap', help='Read FFE Tap value')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--path', type=str.upper, default='DATA_PATH', choices=ffe_path_str_list, metavar='PATH',
                            help='\n'.join(ffe_path_str_list)+'\n(Default:DATA_PATH)')
    parser_read.add_argument('--tap', type=str.upper, default='PRE_8', choices=ffe_tap_str_list, metavar='TAP',
                            help='\n'.join(ffe_tap_str_list)+'\n(Default:PRE_8)')
    parser_read.add_argument('--diffMode', type=int, default=0, help='Diff Mode')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetFfeTap))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetRxRcFfeTaps', help='Read all RX RC FFE tap coefficient values')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetRxRcFfeTaps))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesGetRcFltOpt', help='Read RC floating tap optimization (RC_FLT_OPT) config and per-bank result')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                            help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                            help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesGetRcFltOpt))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesRegisterReadField', help='Read serdes register field')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--field_name', type=str, required=True, help='Field name to read')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesRegisterReadField))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesRegisterWriteField', help='Write SerDes register field')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--field_name', type=str, required=True, help='Field name to write')
    parser_read.add_argument('--value', type=serdes_eth_cmn.Hex, required=True, help='Data value to be written')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesRegisterWriteField))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesSDWGetFields', help='Read SDW field')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--field_name', type=str, required=True, help='Exact SDW field name to read')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesSDWGetFields))

    parser_read = subparser_vendor.add_parser('mvHwsComphySerdesSDWSearchField',
                             help='Search SDW field names with wildcards (*, ?)')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--pattern', type=str, required=True,
                             help="Wildcard pattern to match field names (e.g., '*pll*', 'tx_train*', 'mcu_?req*')")
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphySerdesSDWSearchField))

    parser_read = subparser_vendor.add_parser('mvHwsdumpSerdesFields', help='Dump SDW register space with field names')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--start_addr', type=serdes_eth_cmn.Hex, required=False,
                             help='Start register address (inclusive); default 0x0')
    parser_read.add_argument('--end_addr', type=serdes_eth_cmn.Hex, required=False,
                             help='End register address (inclusive); default 0xE800')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsdumpSerdesFields))

    parser_read = subparser_vendor.add_parser('mvHwsDumpSDWRegisters',
                             help='Dump all SDW registers (Common 0x0000-0x0210 / Lane 0x0500-0x1A00)')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--region', type=str, default='all', choices=['common', 'lane', 'all'],
                             help="Register region: common (0x0000-0x0210), lane (0x0500-0x1A00), all (Default: all)")
    parser_read.add_argument('--start_addr', type=serdes_eth_cmn.Hex, required=False,
                             help='Start register address (overrides region default)')
    parser_read.add_argument('--end_addr', type=serdes_eth_cmn.Hex, required=False,
                             help='End register address (overrides region default)')
    parser_read.add_argument('--step', type=int, default=4, help='Address step size (Default: 4)')
    parser_read.add_argument('--output_file', type=str, default=None,
                             help='Output file path; when set dump is also written to file')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsDumpSDWRegisters))

    parser_read = subparser_vendor.add_parser('mvHwsComphyEnableDisableTxFirForce', help='Enable or Disable TxFirForce Registers')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--flag', type=str, required=True, help='Disable: 0 Enable: 1')
    parser_read.add_argument('--pre3', type=int, default=127, help='TX Eq pre3 value')
    parser_read.add_argument('--pre2', type=int, default=127, help='TX Eq pre2 value')
    parser_read.add_argument('--pre', type=int, default=127, help='TX Eq pre value')
    parser_read.add_argument('--main', type=int, default=127, help='TX Eq main value')
    parser_read.add_argument('--post', type=int, default=127, help='TX Eq post value')
    parser_read.add_argument('--post2', type=int, default=127, help='TX Eq post2 value')
    parser_read.add_argument('--post3', type=int, default=127, help='TX Eq post3 value')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsComphyEnableDisableTxFirForce))

    parser_read = subparser_vendor.add_parser('mvHwsSerdesScanTxNLUT', help='Enable or Disable TxFirForce Registers')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--lane', help='Lane/SerDes identifier (string). Map as needed to your platform.')
    parser_read.add_argument('--delay', type=int, help='Delay seconds for BER accumulation')
    parser_read.add_argument('--module', help='Module name (e.g., Innolight, Luxshare) used in export filename')
    parser_read.add_argument('--tx-fir-mode', default='21L_4N', help='TX FIR mode (e.g., 4N or 21L_4N)')
    parser_read.add_argument('--tx-nlut-delay', default=2, type=int, help='TX NLUT delay value')
    parser_read.add_argument('--iters', default=40, type=int, help='Max training iterations')
    parser_read.add_argument('--thresh', default=2, type=int, help='Threshold for RXNLUTM')
    parser_read.add_argument('--fine', default=4, type=int, help='Number of fine passes after coarse converges')
    parser_read.add_argument('--rx-nlut-delay', default=3, type=int, choices=[2, 3], help='Delay of Rx NlutM (2 or 3; required by firmware when ui != 5)')
    parser_read.add_argument('--reset-nlut', type=strtobool, default=True, help='Reset TX NLUT to zeros before training (True/False, Default:True)')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mvHwsSerdesScanTxNLUT))

    parser_read = subparser_vendor.add_parser('mwHwsComphyDisableLTTimer', help='Enable or disable Link training timer')
    parser_read.add_argument('--isg_num', type=serdes_eth_cmn.parse_list, default=None, metavar='ISG_NUM_LIST',
                             help="ISG number or list or 'all'\nValid value range 0-63 OR 255")
    parser_read.add_argument('--serdes_num', type=serdes_eth_cmn.parse_list, default=None, metavar='SERDES_NUM_LIST',
                             help="SerDes number or list or 'all'\nValid value range (0-7) when --isg_num is (0-63) OR (0-511) when --isg_num is 255")
    parser_read.add_argument('--enable', type=strtobool, required=True, help='enable or disable Link training timer')
    parser_read.set_defaults(func=multi_callback_t100_hws(None, cli_mwHwsComphyDisableLTTimer))

# for direct use from python
def run_cmd(args):
    try:
        if type(args) == str:
            arglist = args.split()
        else:
            arglist = args
        arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

        parser = argparse.ArgumentParser(prog='diagtest serdes eth')
        add_parser(parser)
        args = parser.parse_args(arglist)
        rc = args.func(args)
        if rc == None:
            rc = ifcs.IFCS_SUCCESS
        return rc
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: %s %s" % (type(ex).__name__, ex.args))
    except SystemExit:
        return ifcs.IFCS_SUCCESS
    except:
        log_dbg(1, "Error in serdes_eth_t100 run_cmd: {}".format(sys.exc_info()))
    return ifcs.IFCS_INVAL

#################################################################################
# EVB only: cmds for fwpen access to "FW".  With regular CLI, just use "pen" cmd

def fwpen_read(args):
    out = xport.mc().read_fwpen(args.name, args.idx, args.num)
    log(out)

def fwpen_write(args):
    fields = {}
    for f_arg in args.fields:
        f_name, f_str = f_arg.split("=", 2)
        f_val = int(f_str, 0)
        fields[f_name] = f_val
    xport.mc().write_fwpen(args.name, args.idx, fields)

def fwpen_modify(args):
    fields = {}
    for f_arg in args.fields:
        f_name, f_str = f_arg.split("=", 2)
        f_val = int(f_str, 0)
        fields[f_name] = f_val
    xport.mc().update_fwpen(args.name, args.idx, fields)

def run_fwpen_cmd(args):
    arglist = args.split()

    fwpen_names = [p["NAME"] for p in xport.pen_list]

    arglist = ['--help' if a == 'help' else a for a in arglist]  # replace any 'help' arguments with '--help'

    parser = argparse.ArgumentParser(prog='fwpen')
    subparser = parser.add_subparsers()
    p = subparser.add_parser('read', help='read FWPEN')
    p.add_argument('name', type=str.lower, choices=fwpen_names)
    p.add_argument('idx', type=int, default=0, nargs="?", help="fwpen index")
    p.add_argument('num', type=int, default=1, nargs="?", help="number of entries to read")
    p.set_defaults(func=fwpen_read)

    p = subparser.add_parser('write', help='write FWPEN')
    p.add_argument('name', type=str.lower, choices=fwpen_names)
    p.add_argument('idx', type=int)
    p.add_argument('fields', type=str.lower, nargs="*", help="field1=x field2=y...")
    p.set_defaults(func=fwpen_write)

    p = subparser.add_parser('modify', help='update FWPEN')
    p.add_argument('name', type=str.lower, choices=fwpen_names)
    p.add_argument('idx', type=int)
    p.add_argument('fields', type=str.lower, nargs="*", help="field1=x field2=y...")
    p.set_defaults(func=fwpen_modify)

    try:
        args = parser.parse_args(arglist)
        args.func(args)
    except ValueError as ex:
        log("Value Error: %s" % ":".join(ex.args))
    except Exception as ex:
        traceback.print_exc(file=sys.stdout)
        log("exception: %s %s" % (type(ex).__name__, ex.args))
    except:
        pass

########################################
# EVB only: standalone "CLI"

import cmd
class cmdlooper(cmd.Cmd):
    prompt = "evb> "
    def do_eth(self, arg):
        run_cmd(arg)
        return False
    def do_fwpen(self, arg):
        run_fwpen_cmd(arg)
        return False
    def do_quit(self, arg):
        return True
    def emptyline(self):
        return True

def cli():
    c = cmdlooper()
    c.cmdloop()
