
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import sys
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
try:
    ifcs_ctypes=sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

# Initialize Parameters
src_port = 1
dst_port = src_port + 1

l2vni = 0x64

def getSysportHandleFromDevPort(devPort):
    attr = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_ctypes.ifcs_devport_attr_get(0, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

def txrx_packet():
    # instantiate tx and expected packets
    pkts_tx = []
    pkts_exp = []

    i = 0
    # Transmitted Packets
    dmac ="00:01:02:03:04:05"
    pkt_fp = Teralynx(PktID=1234, PktLength=102+42+4, SrcLocalPort=i, Reserved=0)/ \
             Ether(dst=dmac) /  \
             Dot1Q(vlan=l2vni)/ \
             IP(dst="127.0.0.1")/ \
             UDP(dport=model_server.fp_port)
    pkt_fp = model_packet.pad(pkt_fp,102)
    pkts_tx.append(pkt_fp)

    # Expected Packets (update Ethernet Header Fields)
    pkt_fp = Teralynx(PktID=1234, PktLength=102+42+4, SrcLocalPort=i, Reserved=(i+1))/ \
             Ether(dst=dmac) /  \
             Dot1Q(vlan=l2vni)/ \
             IP(dst="127.0.0.1")/ \
             UDP(dport=model_server.fp_port)
    pkt_fp = model_packet.pad(pkt_fp,102)
    hexdump(pkt_fp)
    pkts_exp.append(pkt_fp)

    # overloadable function call to set up hash structure of server packet buffers
    model_server.hash_setup('SrcPort','DestPort')

    # append function call to add expected packets to server-side hash tree (parsing, dissection, processing, key generation are all automatically handled)
    for packet in pkts_exp:
        model_server.expected_packets.append(packet)

    # transmit all packets in the passed container through front panel UDP socket (agnostic of device port)
    model_server.transmit(pkts_tx)
# Class implements L2vni related command

class L2vni(Command):
    def __init__(self, cli):
        self.sub_cmds = {'create'  : self.create,
                         'delete'  : self.delete,
                         'add'     : self.add,
                         'remove'  : self.remove,
                         'basicl2' : self.basicl2,
                         'help'    : self.help,
                         '?'       : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(L2vni, self).__init__()
        self.vni_handles = {}

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def run_cmd(self, args):
        log_dbg(1, "in L2vni run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (ValueError):
            try:
                l2vni_id = int(self.arg_list[1])
                if (l2vni_id < 0 or l2vni_id >= self.num_l2vnis):
                    log_err("Valid l2vni ids are between 0 and " + str((self.num_l2vnis-1)))
                    self.help(args)
                    return
                log_dbg(1, "Setting active l2vni to " + str(l2vni_id))
                self.active_l2vni = l2vni_id
            except:
                log_err('L2vniValueTryError')
        except (KeyError):
            log_dbg(1, 'L2vniKeyError')
            self.help(args)
        except (IndexError):
            log_dbg(1, 'L2vniIndexError')
            self.help(args)
        except:
            log_dbg(1, 'L2vniOtherError')
            self.help(args)
        return

    def create(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id in self.vni_handles:
            log_err("Handle already exists")
            return

        try:
            self.vni_handles[l2vni_id] = ifcs_ctypes.ifcs_handle_t()
            rc = ifcs_ctypes.ifcs_l2vni_create(0, pointer(self.vni_handles[l2vni_id]),
                                   0, 0)
            if rc != 0:
                log_err("l2vni create failed")
                return
        except:
            log_err("Usage: l2vni create <l2vni>")
            return

    def delete(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_delete(0, self.vni_handles[l2vni_id])
            if rc != 0:
                log_err("l2vni delete failed")
                return

        except:
            log_err("Usage: l2vni delete <l2vni>")
            return

    def add(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        port = int(self.arg_list.pop(0))

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        actual_count = c_uint32()
        rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, 1, pointer(attr),
                                pointer(actual_count))
        if rc != 0:
            log_err("l2vni port_attr_get failed")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_member_add(0, self.vni_handles[l2vni_id],
                                       attr.value.handle, 0)
            if rc != 0:
                log_err("l2vni member add failed")
                return

        except:
            log_err("Usage: l2vni add <l2vni>")
            return

    def remove(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        port = int(self.arg_list.pop(0))

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        actual_count = c_uint32()
        rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, 1, pointer(attr),
                                pointer(actual_count))
        if rc != 0:
            log_err("l2vni port_attr_get")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_member_remove(0, self.vni_handles[l2vni_id],
                                          attr.value.handle)
            if rc != 0:
                log_err("l2vni member remove failed")
                return

        except:
            log_err("Usage: l2vni remove <l2vni>")
            return

    def basicl2(self, args):
        ret = ifcs_ctypes.ifcs_status_t()
        stp_hdl = ifcs_ctypes.ifcs_handle_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        attr = ifcs_ctypes.ifcs_attr_t()
        vni_attr = ifcs_ctypes.ifcs_attr_t()
        mac_addr_t = c_uint8 * 6

        ifcs_ctypes.node_model_server_dbglvl_set(0, 0, 5)
        dsp_fldlst = []
        #fldlst = []

        #fldlst = read_pen(ifcs_ctypes.DSP_L2TAG_ACTION_PROFILE, 0, dsp_fldlst)
        #log(dsp_fldlst)
        #fldlst = read_pen(ifcs_ctypes.DSP_L2TAG_ACTION_PROFILE, 1, dsp_fldlst)
        #log(fldlst)

        src_sp_hdl = getSysportHandleFromDevPort(src_port)
        src_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(src_sp_hdl)

        dst_sp_hdl = getSysportHandleFromDevPort(dst_port)
        dst_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl)

        ####### STEP0 #######
        ###### STP CONFIG #######
        stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
        ret = ifcs_ctypes.ifcs_stp_create(0, pointer(stp_hdl),
                                       0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance creation failed"

        ###### VNI CONFIG ######
        # Create VNI and add members
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(l2vni)
        ret = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI creation " + str(l2vni)

        ####### STEP1 #######
        # 1.1

        mbr1 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)
        mbr2 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        member_count = 2
        member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

        member_attr_count = 0
        member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

        member_list[0] = mbr1
        member_list[1] = mbr2

        ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                     member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                     member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr add " + str(l2vni)

        stp_attr_count = 1
        stp_attr = ifcs_ctypes.ifcs_attr_t()
        stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
        stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;
        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr1,\
                                     stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr1.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr2, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr2.value))

        # Set STP instance for created VNI
        vni_attr.id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
        vni_attr.value.handle = stp_hdl
        ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set failed"

        # 1.2
        ###### FDB Config #######
        # src_port = 1, src_mac = 00:01:02:03:04:05
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        src_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 1, 2, 3, 4, 5)
        src_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = src_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 2, dst mac = 00:05:04:03:02:01
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 5, 4, 3, 2, 1)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        #fdb2_entry_array = ifcs_ctypes.ifcs_l2entry_key_t

        #mac2_addr = mac_addr_t(5, 4, 3, 2, 1, 0)

        #fdb2_entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac2_addr, l2vni_hdl)
        #attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        #attr[0].value.handle = lag_hdl.value
        #attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        #attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        #rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(fdb2_entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        #assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create LAG FDB entry failed: rc = [" + str(rc) + "]"

        ssp_attr = ifcs_ctypes.ifcs_attr_t()
        ssp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        ssp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, src_sp_hdl, 1, pointer(ssp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"
        ####### STEP2 #######
        #txrx_packet()
      #  write_pen(ifcs_ctypes.L2_LEARN_PROFILE, 0,
      #          [(ifcs_ctypes.L2_SRC_MISS_LEARN_EN_F, 1)])
      #              (ifcs_ctypes.L2_SRC_MISS_CTC_STRENGTH_F, lrn_miss_dc.ctc_strength),
      #              (ifcs_ctypes.L2_SRC_MISS_CTC_METADATA_F, lrn_miss_dc.ctc_metadata),
      #              (ifcs_ctypes.L2_SRC_MISS_DROP_F, lrn_miss_dc.drop),
      #              (ifcs_ctypes.L2_SRC_MISS_DROP_STRENGTH_F, lrn_miss_dc.drop_strength),
      #              (ifcs_ctypes.L2_SRC_MISS_DROP_METADATA_F, lrn_miss_dc.drop_metadata)])


    def help(self, args):
        self.cli.error()
        log("Usage: \n", \
              "l2vni create <l2vni_id>    - create l2VNI\n", \
              "l2vni delete <l2vni_id>    - delete l2VNI\n", \
              "l2vni add <l2vni_id>, <sysport> - l2vni add member\n", \
              "l2vni remove <l2vni_id>     - l2vni remove member\n", \
              "l2vni help or ?           - show this text\n")
