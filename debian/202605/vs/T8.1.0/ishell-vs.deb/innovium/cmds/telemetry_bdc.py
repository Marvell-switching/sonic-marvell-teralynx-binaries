#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

import shlex
import time
import random
import copy
import argparse
import sys
import re
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from testutil import pkt
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
from utils.log_utils import raiseExpOnFail

class VizBDC(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create_instance'           : self.create_instance,
                         'delete_instance'           : self.delete_instance,
                         'help'                      : self.help,
                         '?'                         : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        self.bdc_collector_set_handle = 0
        self.bdc_collector_handle = 0
        self.bdc_visibility_sampler_handle = 0
        self.bdc_policy = None
        self.handle = 0
        self.nodeId = 0
        self.deviceType = -1
        self.switchId = -1
        self.cos_queue_ids = []
        self.sysPort = None
        self.hostifTrap = None
        self.cpu_queue_meter_cir_enable = None
        self.cpu_queue_meter_cir = None
        self.cpu_queue_meter_burst_size = None
        self.cpu_queue_num = None

    def _get_sysport_from_devport_(
            self,
            nodeId,
            dev_port,
            userHandle=None):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        rc = ifcs_ctypes.ifcs_devport_attr_get(nodeId, dev_port, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Sysport get unsuccessful")
            return rc

        rc = ifcs_ctypes.ifcs_attr_t_value_handle_get(pointer(out_attr), pointer(handle))
        if rc:
            log("Sysport handle get unsuccessful")
            return rc

        self.sysPort = int(handle.value)
        #log("BDC Collector sysport handle= " + hex(handle.value))
        return rc

    def __get_devport_type(self, nodeId, dev_port):
        # Get type of devport
        out_attr = ifcs_ctypes.ifcs_attr_t()
        rc = ifcs_ctypes.ifcs_attr_t_init(pointer(out_attr))
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(out_attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        actual_count = c_uint32()
        rc = ifcs_ctypes.IFCS_STATUS_REASON(ifcs_ctypes.ifcs_devport_attr_get(
            nodeId, dev_port, 1, pointer(out_attr), pointer(actual_count)))
        if rc != ifcs_ctypes.IFCS_SUCCESS or actual_count.value != 1:
            log("Get type attr for devport {} failed with error code {}. returned attr count {}".format(
                dev_port, rc, actual_count.value))
            return ifcs_ctypes.IFCS_INVAL, -1

        attr_id = c_uint32()
        attr_val = c_uint32()
        rc = ifcs_ctypes.ifcs_attr_t_id_get(pointer(out_attr), pointer(attr_id))
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        if attr_id.value != ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE:
            log("Get type attr for devport {} failed. returned attr id {}".format(
                dev_port, attr_id.value))
            return ifcs_ctypes.IFCS_INVAL, -1
        rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(
            pointer(out_attr), pointer(attr_val))
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        log_dbg(
            1, "BDC: Get type attr for devport {} returned type {}".format(
                dev_port, int(attr_val.value)))
        return ifcs_ctypes.IFCS_SUCCESS, int(attr_val.value)

   # build ip address from family,address
    def build_ipaddr(self, ipAddr):
       ipAddrStruct = ifcs_ctypes.ifcs_ip_address_t()
       ipAddrStruct.addr_family = 0
       ipAddrStruct.addr.ipv4 = ipAddr
       return ipAddrStruct



    def _node_bdc_enable_(
            self,
            nodeId,
            enable=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        maxAttr = int(ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if enable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_NODE_ATTR_VIZ_BDC_ENABLE
            attrList[index].value.data = enable
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_NODE_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_node_attr_set(
                    nodeId,
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            enable_str = "enable" if enable == ifcs_ctypes.IFCS_BOOL_TRUE else "disable"
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("BDC {0} in node failed rc: {1}".format(enable_str, rc))
            else:
                pass
                #log("BDC {0} in node success rc: {1}".format(enable_str, rc))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def __cpu_queue_attr_get(self, nodeId, queue_num):
        #   Get cpu queue attributes changed for restoring them later
        self.cpu_queue_meter_cir_enable = None
        self.cpu_queue_meter_cir = None
        self.cpu_queue_meter_burst_size = None

        attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
        for index in range(3):
            rc = ifcs_ctypes.ifcs_attr_t_init(
                compat_pointerAtIndex(
                    attr_list, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

        attr_count = 0
        for attr_id in [
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE,
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE,
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE]:
            rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), attr_id)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            attr_count += 1

        actual_count = c_uint32()
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_cpu_queue_attr_get(
                nodeId, queue_num, attr_count, compat_pointer(
                    attr_list, ifcs_ctypes.ifcs_attr_t), pointer(actual_count)))
        if rc != ifcs_ctypes.IFCS_SUCCESS or actual_count.value != attr_count:
            log("Get attr for cpu_queue {} failed with error code {}. returned attr count {}".format(
                queue_num, rc, actual_count.value))
        else:
            attr_id = c_uint32()
            attr_val = c_uint32()
            for index in range(3):
                rc = ifcs_ctypes.ifcs_attr_t_id_get(compat_pointerAtIndex(
                    attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_id))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
                if attr_id.value == ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE:
                    attr_val_bool = c_int()
                    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointerAtIndex(
                        attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_val_bool))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    self.cpu_queue_meter_cir_enable = int(attr_val_bool.value)
                elif attr_id.value == ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE:
                    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(
                        attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_val))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    self.cpu_queue_meter_cir = int(attr_val.value)
                elif attr_id.value == ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE:
                    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(
                        attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(attr_val))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    self.cpu_queue_meter_burst_size = int(attr_val.value)
                else:
                    assert 1 == 0
            if None in [
                    self.cpu_queue_meter_cir_enable,
                    self.cpu_queue_meter_cir,
                    self.cpu_queue_meter_burst_size]:
                assert 1 == 0
            self.cpu_queue_num = queue_num
            log_dbg(
                1,
                "BDC: Get attr for cpu_queue {} returned meter_committed_information_rate_enable {}, meter_committed_information_rate {}, meter_committed_burst_size {}".format(
                    queue_num,
                    self.cpu_queue_meter_cir_enable,
                    self.cpu_queue_meter_cir,
                    self.cpu_queue_meter_burst_size))
        return rc

    def __cpu_queue_attr_restore(self, nodeId):
        #   Restore cpu queue attributes to previous state
        if None not in [
                self.cpu_queue_meter_cir_enable,
                self.cpu_queue_meter_cir,
                self.cpu_queue_meter_burst_size,
                self.cpu_queue_num]:
            self.__cpu_queue_attr_set(
                nodeId,
                self.cpu_queue_num,
                self.cpu_queue_meter_cir_enable,
                self.cpu_queue_meter_cir,
                self.cpu_queue_meter_burst_size)
        self.cpu_queue_meter_cir_enable = None
        self.cpu_queue_meter_cir = None
        self.cpu_queue_meter_burst_size = None
        self.cpu_queue_num = None
        return

    def __cpu_queue_attr_set(
            self,
            nodeId,
            queue_num,
            meter_cir_enable,
            meter_cir,
            meter_burst_size):
        #   Set cpu queue attributes
        attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
        for index in range(3):
            rc = ifcs_ctypes.ifcs_attr_t_init(
                compat_pointerAtIndex(
                    attr_list, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

        attr_count = 0
        rc = ifcs_ctypes.ifcs_attr_t_id_set(
            compat_pointerAtIndex(
                attr_list,
                ifcs_ctypes.ifcs_attr_t,
                attr_count),
            ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE_ENABLE)
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        # Observed that when setting max value for CIR, the CPU queue policing is disabled,
        # but CIR enable field is shown as true.
        if meter_cir == 60000000:
            meter_cir_enable = False
        rc = ifcs_ctypes.ifcs_attr_t_value_data_set(
            compat_pointerAtIndex(
                attr_list,
                ifcs_ctypes.ifcs_attr_t,
                attr_count),
            ifcs_ctypes.IFCS_BOOL_TRUE if meter_cir_enable else ifcs_ctypes.IFCS_BOOL_FALSE)
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        attr_count += 1

        if meter_cir:
            rc = ifcs_ctypes.ifcs_attr_t_id_set(
                compat_pointerAtIndex(
                    attr_list,
                    ifcs_ctypes.ifcs_attr_t,
                    attr_count),
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_INFORMATION_RATE)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            rc = ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), meter_cir)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            attr_count += 1

        if meter_burst_size:
            rc = ifcs_ctypes.ifcs_attr_t_id_set(
                compat_pointerAtIndex(
                    attr_list,
                    ifcs_ctypes.ifcs_attr_t,
                    attr_count),
                ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_METER_COMMITTED_BURST_SIZE)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            rc = ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(
                attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), meter_burst_size)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            attr_count += 1

        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_cpu_queue_attr_set(
                nodeId, queue_num, attr_count, compat_pointer(
                    attr_list, ifcs_ctypes.ifcs_attr_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Set attr for cpu_queue {} failed with error code {}".format(queue_num, rc))
        else:
            log_dbg(
                1,
                "BDC: Set attr for cpu_queue {} with meter_committed_information_rate_enable {}, meter_committed_information_rate {}, meter_committed_burst_size {}".format(
                    queue_num,
                    True if meter_cir_enable else False,
                    meter_cir,
                    meter_burst_size))
        return rc

    def __host_if_trap_create(
            self,
            nodeId,
            queue_num,
            meter_cir,
            meter_burst_size):
        if meter_cir is not None:
            rc = self.__cpu_queue_attr_get(nodeId, queue_num)
            if rc:
                return rc
            rc = self.__cpu_queue_attr_set(
                nodeId, queue_num, True, meter_cir, meter_burst_size)
            if rc:
                return rc

        #   Create Host If Trap
        handle = ifcs_ctypes.ifcs_handle_t(ifcs_ctypes.IFCS_NULL_HANDLE)
        attrList = (ifcs_ctypes.ifcs_attr_t * 2)()
        for index in range(2):
            rc = ifcs_ctypes.ifcs_attr_t_init(
                compat_pointerAtIndex(
                    attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        rc = ifcs_ctypes.ifcs_attr_t_id_set(
            compat_pointerAtIndex(
                attrList,
                ifcs_ctypes.ifcs_attr_t,
                index),
            ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM)
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.ifcs_attr_t_value_cpu_queue_set(
            compat_pointerAtIndex(
                attrList,
                ifcs_ctypes.ifcs_attr_t,
                index),
            ifcs_ctypes.ifcs_cpu_queue_t(queue_num))
        assert rc == ifcs_ctypes.IFCS_SUCCESS
        index += 1

        attrCount = index
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_hostif_trap_create(
                nodeId, pointer(handle), attrCount, compat_pointer(
                    attrList, ifcs_ctypes.ifcs_attr_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("Create hostif_trap for queue_num {} failed with error code {}".format(
                queue_num, rc))
            self.__cpu_queue_attr_restore(nodeId)
        else:
            self.hostifTrap = int(handle.value)
            log_dbg(1, "BDC: Created hostif_trap {}".format(hex(self.hostifTrap)))
        return rc

    def __host_if_trap_delete(self, nodeId):
        if self.hostifTrap is not None:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_hostif_trap_delete(
                    nodeId, ifcs_ctypes.ifcs_handle_t(
                        self.hostifTrap)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Delete hostif_trap {} failed with error code {}".format(
                    hex(self.hostifTrap), rc))
            else:
                log_dbg(1, "BDC: Deleted hostif_trap {}".format(
                    hex(self.hostifTrap)))
                self.hostifTrap = None
        self.__cpu_queue_attr_restore(nodeId)
        return

    def _collector_create_(
            self,
            nodeId,
            collectorType=None,
            direction=None,
            dcdp=None,
            localDestination=None,
            vizTc=None,
            rspanDot1qTpid=None,
            rspanDot1qVlan=None,
            rspanDot1qPri=None,
            rspanDot1qCfi=None,
            destMac=None,
            srcMac=None,
            srcIpFamily=None,
            srcIp=None,
            destIpFamily=None,
            destIp=None,
            dscp=None,
            ttl=None,
            ipv4DfFlag=None,
            dot1qVlan=None,
            sessionId=None,
            truncate=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_COLLECTOR_TYPE
            attrList[index].value.u32 = collectorType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if dcdp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DCDP
            attrList[index].value.handle = dcdp
            index += 1
        if localDestination is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_LOCAL_DESTINATION
            attrList[index].value.handle = localDestination
            index += 1
        if vizTc is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_VIZ_TC
            attrList[index].value.tc = vizTc
            index += 1
        if rspanDot1qTpid is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_TPID
            attrList[index].value.u16 = rspanDot1qTpid
            index += 1
        if rspanDot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_VLAN
            attrList[index].value.u16 = rspanDot1qVlan
            index += 1
        if rspanDot1qPri is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_PRI
            attrList[index].value.u8 = rspanDot1qPri
            index += 1
        if rspanDot1qCfi is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_RSPAN_DOT1Q_CFI
            attrList[index].value.u8 = rspanDot1qCfi
            index += 1
        if destMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_MAC
            attrList[index].value.mac = destMac
            index += 1
        if srcMac is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_MAC
            attrList[index].value.mac = srcMac
            index += 1
        if srcIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SRC_IP
            attrList[index].value.ip_addr = self.build_ipaddr(srcIp)
            index += 1
        if destIp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DEST_IP
            attrList[index].value.ip_addr = self.build_ipaddr(destIp)
            index += 1
        if dscp is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DSCP
            attrList[index].value.u8 = dscp
            index += 1
        if ttl is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TTL
            attrList[index].value.u8 = ttl
            index += 1
        if ipv4DfFlag is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_IPV4_DF_FLAG
            attrList[index].value.u8 = ipv4DfFlag
            index += 1
        if dot1qVlan is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_DOT1Q_VLAN
            attrList[index].value.u16 = dot1qVlan
            index += 1
        if sessionId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_SESSION_ID
            attrList[index].value.u16 = sessionId
            index += 1
        if truncate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_ATTR_TRUNCATE
            attrList[index].value.u32 = truncate
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("BDC Collector creation failed rc: {0}".format(rc))
            else:
                self.bdc_collector_handle = int(handle.value)
                #log("BDC Collector handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _collector_set_create_(
            self,
            nodeId,
            collectorSetType=None,
            direction=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorSetType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_COLLECTOR_SET_TYPE
            attrList[index].value.u32 = collectorSetType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("BDC CollectorSet creation failed rc: {0}".format(rc))
            else:
                self.bdc_collector_set_handle = int(handle.value)
                #log("BDC CollectorSet handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _add_members_(
            self,
            collector_set_handle,
            memberList,
            attrList=None,
            memberCount=None,
            attrCount=None,
            expRc=None,
            customLog=None,
            ifcsCall=True):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            if memberList is not None:
                memberCount = len(memberList)
            else:
                memberCount = 0
        if attrCount is None:
            if attrList is not None:
                attrCount = len(attrList)
            else:
                attrCount = 0
        if not attrList:
            attrList = None
        if not ifcsCall:
            return ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_add(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t),
                attrCount,
                attrList))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("BDC CollectorSet member add failed rc: {0}".format(rc))
        else:
            pass
        #    log("BDC CollectorSet member add successful")
        return rc

    def _visibility_sampler_create_(
            self,
            nodeId,
            type=None,
            mode=None,
            probabilisticCaptureRate=None,
            microburstCaptureAvgPacketRate=None,
            microburstCaptureMaxPacketsPerBurst=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        maxAttr = int(ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if type is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_TYPE
            attrList[index].value.u32 = type
            index += 1
        if mode is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MODE
            attrList[index].value.u32 = mode
            index += 1
        if probabilisticCaptureRate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_PROBABILISTIC_CAPTURE_RATE
            attrList[index].value.u32 = probabilisticCaptureRate
            index += 1
        if microburstCaptureAvgPacketRate is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MICROBURST_CAPTURE_AVG_PACKET_RATE
            attrList[index].value.u32 = microburstCaptureAvgPacketRate
            index += 1
        if microburstCaptureMaxPacketsPerBurst is not None:
            attrList[index].id = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MICROBURST_CAPTURE_MAX_PACKETS_PER_BURST
            attrList[index].value.u32 = microburstCaptureMaxPacketsPerBurst
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_visibility_sampler_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Visibility Sampler creation failed rc: {0}".format(rc))
            else:
                self.bdc_visibility_sampler_handle = int(handle.value)
                #log("Visibility Sampler handle= " + hex(handle.value))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _bdc_policy_create_(
            self,
            collector_set_handle,
            visibility_sampler_handle,
            ifcsCall=True):

        if self.bdc_policy != None:
            log("BDC policy already exists")
            return ifcs_ctypes.IFCS_INVAL
        self.bdc_policy = ifcs_ctypes.ifcs_bdc_policy_t()

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_init(
                    pointer(self.bdc_policy)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.bdc_policy = None
                log("BDC policy creation failed rc: {0}".format(rc))
                return rc
            else:
                pass
                #log("BDC policy creation success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_collector_set_set(
                    pointer(self.bdc_policy),
                    collector_set_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Collector Set to BDC policy failed rc: {0}".format(rc))
                return rc
            else:
                pass
                #log("Adding Collector Set to BDC policy success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_visibility_sampler_set(
                    pointer(self.bdc_policy),
                    visibility_sampler_handle))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Adding Visibility Sampler to BDC policy failed rc: {0}".format(rc))
                return rc
            else:
                pass
                #log("Adding Visibility Sampler to BDC policy success rc: {0}".format(rc))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _bdc_policy_queue_id_enable_(
            self,
            nodeId,
            policy=None,
            enable=None,
            queue=[],
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        maxAttr = int(ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT) + 2
        attrList = (ifcs_ctypes.ifcs_attr_t * maxAttr)()
        for index in range(maxAttr):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if policy is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_BDC_POLICY
            attrList[index].value.bdc_policy = policy
            index += 1
        if enable is not None:
            attrList[index].id = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_BDC_ENABLE
            attrList[index].value.data = enable
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_QUEUE_ID_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_SUCCESS
            for queue_id in queue:
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_queue_id_attr_set(
                        nodeId,
                        queue_id,
                        attrCount,
                        compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    if enable == ifcs_ctypes.IFCS_BOOL_TRUE:
                        log("Setup BDC Policy on Class of Service Queue {0} and enable BDC failed: {1}".format(queue_id, rc))
                    else:
                        log("Disable BDC on Class of Service Queue {0} failed: {1}".format(queue_id, rc))
                    return rc
                else:
                    pass
                    #log("Setup BDC Policy on Class of Service Queue {0} and enable {1} BDC passed: {2}".format(queue_id, enable, rc))
            return rc
        else:
            return ifcs_ctypes.IFCS_SUCCESS

    def _remove_members_(
            self,
            collector_set_handle,
            memberList,
            memberCount=None,
            expRc=None,
            customLog=None,
            ifcsCall=True):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            memberCount = len(memberList)
        if not ifcsCall:
            return ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_remove(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("BDC CollectorSet member remove failed rc: {0}".format(rc))
        else:
            pass
            #log("BDC CollectorSet member remove successful")
        return rc

    def run_cmd(self, args):
        log_dbg(1, "in BDC run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "VizBDCKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "VizBDCValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def _parse_queue_ids_(
            self,
            queue_ids):
        # Supported formats 1 | 0,4,6 | 1-4
        try:
            queue_ids = queue_ids.strip()
            if re.match(r'^\d$', queue_ids):
                queue_ids = [queue_ids]
            elif re.match(r'^(\d,)+\d$', queue_ids):
                queue_ids = queue_ids.split(',')
            elif re.match(r'^\d-\d$', queue_ids):
                queue_ids = queue_ids.split('-')
                queue_ids = compat_listrange(int(queue_ids[0]), int(queue_ids[1]) + 1)
            else:
                return None
            return [int(x) for x in queue_ids]
        except:
            return None

    def create_instance(self, args):
        log_dbg(1, "in BDC collector instance")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='BDC Collector create', prog='config bdc create_instance', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        portOrCpuQueueArgs = parser.add_mutually_exclusive_group(required=True)
        portOrCpuQueueArgs.add_argument('-dev_port', action="store", help='Front port number', type=int)
        portOrCpuQueueArgs.add_argument('-cpu_queue', action="store", help='CPU Queue number', type=int)
        #CPU queue  arguments
        cpuQueueArgs = parser.add_argument_group('CPU Queue optional arguments')
        cpuQueueArgs.add_argument('-cpu_rate', action="store", help='Meter Committed Information Rate (CIR) on the CPU Queue (122-60000000). Units are in PPS. To disable, set this value to max value. Applicable only for CPU Queue.', required=False, type=int)
        cpuQueueArgs.add_argument('-cpu_burst_size', action="store", help="Burst size associated with the meter committed information rate token bucket (1-1000000000). Units are in packets. Guidance for specifying value: Burst size should be >= cpu_rate * node's attribute update_interval_b [in update_interval_unit_us] * (1/1000000) [in sec/us]. Applicable only for CPU Queue.", required=False, type=int)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-smac', action="store", help='Source mac. Format: AA:BB:CC:DD:EE:FF', required=True)
        requiredArgs.add_argument('-dmac', action="store", help='Destination mac. Format: AA:BB:CC:DD:EE:FF', required=True)
        parser.add_argument('-vlan', action="store", help='Vlan id (0-4095)', required=False) #optional  argument
        requiredArgs.add_argument('-sip', action="store", help='Source IPv4 address. Format: dot-decimal', required=True)
        requiredArgs.add_argument('-dip', action="store", help='Destination IPv4 address. Format: dot-decimal', required=True)
        requiredArgs.add_argument('-dscp', action="store", help='DSCP value (0-63)', required=True, type=int)
        requiredArgs.add_argument('-ttl', action="store", help='TTL value (1-255)', required=True, type=int)
        requiredArgs.add_argument('-tc', action="store", help='Traffic Class for BDC packets (0-15)', required=True, type=int)
        requiredArgs.add_argument('-df', action="store", help='Do not fragment flag in IPv4 header during BDC (0 | 1)', required=True, type=int)
        requiredArgs.add_argument('-queue', action="store", help='One or more Class of Service Queues (0-7). Specify one queue or comma separated queues  or range of queues. Examples: 1 | 0,4,6 | 1-4', required=True)
        requiredArgs.add_argument('-sampler_mode', action="store", help='Visibility Sampler mode 0(Capture All) | 1(Probabilistic Capture) | 2(Microburst Capture)', required=True, type=int, choices=compat_listrange(3), default=1)
        #Sampler  arguments
        samplerArgs = parser.add_argument_group('Visibility Sampler optional arguments')
        samplerArgs.add_argument('-capture_rate', action="store", help='Capture rate for visibility sampler expressed as 1 in every N packets, where this attribute specifies N (10-16777215). Applicable only when visibility sampler mode is Probabilistic Capture.', required=False, type=int, default=10000)
        samplerArgs.add_argument('-avg_packet_rate', action="store", help='Avg rate (packets/sec) of packets to be captured (122-100000). Applicable only when visibility sampler mode is Microburst Capture.', required=False, type=int, default=8192)
        samplerArgs.add_argument('-max_packets_per_burst', action="store", help="Maximum number of packets to be captured per microburst event (64-16384). Applicable only when visibility sampler mode is Microburst Capture. Guidance for specifying value: Value should be >= avg_packet_rate * node's attribute update_interval_c * (1/1000000). Supported values are 64, 128, 256, 512, 1K, 2K...16K", required=False, type=int, default=256)

        try:
            res = parser.parse_args(self.arg_list)
        except:
            if len(self.arg_list) == 1 and self.arg_list[0] in ['-h', '--help']:
                return 0
            log('Missing arguments or invalid arguments provided')
            return 1

        if self.bdc_collector_set_handle != 0:
            log("BDC Collector is already exist")
            return ifcs_ctypes.IFCS_INVAL
        self.cos_queue_ids = [];

        # Get dscp
        dscp = int(res.dscp)
        # Get ttl
        ttl = int(res.ttl)
        # Get dev_port
        dev_port = None
        if res.dev_port is not None:
            dev_port = int(res.dev_port)
            if res.cpu_rate is not None:
                log('Argument error: -cpu_rate is not allowed with argument -dev_port')
                return ifcs_ctypes.IFCS_INVAL
            if res.cpu_burst_size is not None:
                log('Argument error: -cpu_burst_size is not allowed with argument -dev_port')
                return ifcs_ctypes.IFCS_INVAL
        # Get cpu_queue
        cpu_queue = None
        meter_cir = None
        meter_burst_size = None
        if res.cpu_queue is not None:
            cpu_queue = int(res.cpu_queue)
            if res.cpu_rate is not None:
                meter_cir = int(res.cpu_rate)
                if meter_cir < 0:
                    log('Argument error: -cpu_rate cannot be negative')
                    return ifcs_ctypes.IFCS_INVAL
                # Don't validate range, let sdk do it
            if res.cpu_burst_size is not None:
                if meter_cir is None:
                    log('Argument error: -cpu_rate is required when -cpu_burst_size is specified')
                    return ifcs_ctypes.IFCS_INVAL
                meter_burst_size = int(res.cpu_burst_size)
                if meter_burst_size < 0:
                    log('Argument error: -cpu_burst_size cannot be negative')
                    return ifcs_ctypes.IFCS_INVAL
                # Don't validate range, let sdk do it
            if meter_cir is None:
                meter_cir = 60000
                # Set default values as it was observed that SDK does not enable CPU queue policing
                # after any user applied CPU queue policer configuration
            if meter_burst_size is None:
                # Provide a calculated value
                rate = c_uint32(meter_cir)
                burst_size = c_uint32()
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.im_cpu_queue_burst_size_get(
                        self.cli.node_id, rate, pointer(burst_size)))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("Get cpu_burst_size for cpu_rate {} failed with error code {}. Please check argument -cpu_rate".format(meter_cir, rc))
                    return ifcs_ctypes.IFCS_INVAL
                else:
                    meter_burst_size = int(burst_size.value)
                    log_dbg(
                        1, "BDC: Got cpu_burst_size {} for cpu_rate {}".format(
                            meter_burst_size, meter_cir))
        # Get traffic class
        viz_tc = int(res.tc)
        # Get IPv4 do not fragment flag
        ipv4_df_flag = int(res.df)
        # Get Class of Service Queue 1
        queue_ids = self._parse_queue_ids_(res.queue)
        if not queue_ids:
            log('Invalid value for -queue argument')
            return ifcs_ctypes.IFCS_INVAL
        self.cos_queue_ids = queue_ids;
        # Get visibility sampler mode
        try:
            sampler_mode = int(res.sampler_mode)
            sampler_mode = [ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_CAPTURE_ALL,
                            ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_PROBABILISTIC_CAPTURE,
                            ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_MICROBURST_CAPTURE][sampler_mode]
        except:
            log('Invalid value for -sampler_mode argument')
            return ifcs_ctypes.IFCS_INVAL
        # Get capture rate
        if sampler_mode == ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_PROBABILISTIC_CAPTURE:
            capture_rate = int(res.capture_rate)
        else:
            capture_rate = None
        # Get Microburst Capture mode parameters
        if sampler_mode == ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_MODE_MICROBURST_CAPTURE:
            avg_packet_rate = int(res.avg_packet_rate)
            max_packets_per_burst = int(res.max_packets_per_burst)
        else:
            avg_packet_rate = None
            max_packets_per_burst = None
        # Get src mac addr
        src_mac_flds = res.smac.split(":")
        # Prepending 0x to each element in mac addr
        src_mac_flds = ["0x"+i for i in src_mac_flds]
        src_mac = [int(i, 0) for i in src_mac_flds]
        # Convert list to tuple
        src_mac = tuple(src_mac)
        # Get Dest mac addr
        dest_mac_flds = res.dmac.split(":")
        # Prepending 0x to each element in mac addr
        dest_mac_flds = ["0x"+i for i in dest_mac_flds]
        dest_mac = [int(i, 0) for i in dest_mac_flds]
        # Convert list to tuple
        dest_mac = tuple(dest_mac)
        # Get src ip
        src_ip_l = res.sip.split(".")
        src_ip_l = [int(i, 0) for i in src_ip_l]
        # Get dest ip
        dest_ip_l = res.dip.split(".")
        dest_ip_l = [int(i, 0) for i in dest_ip_l]
        srcIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        destIpFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        # Convert IP and Mask to 32bit values
        src_ip = src_ip_l[0] << 24 | src_ip_l[1] << 16 | src_ip_l[2] << 8 | src_ip_l[3]
        dest_ip = dest_ip_l[0] << 24 | dest_ip_l[1] << 16 | dest_ip_l[2] << 8 | dest_ip_l[3]
        collectorType = ifcs_ctypes.IFCS_COLLECTOR_TYPE_BDC

        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_TYPE
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Device Type get unsuccessful")
            return rc

        self.deviceType = out_attr.value.u32

        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_SWITCH_ID
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("Switch id get unsuccessful")
            return rc

        self.switchId = out_attr.value.u32

        if dev_port is not None:
            # Get sysport
            rc, port_type = self.__get_devport_type(self.cli.node_id, dev_port)
            if rc:
                return rc
            if port_type == ifcs_ctypes.IFCS_DEVPORT_TYPE_CPU:
                log('Argument error: -dev_port cannot be a CPU devport')
                return ifcs_ctypes.IFCS_INVAL
            rc = self._get_sysport_from_devport_(self.cli.node_id, dev_port)
            if rc:
                return rc

        # self._node_bdc_enable_() cannot be successfully invoked after enabling node.
        # Enable BDC in the config.yaml file of the node by including viz_bdc_enable: "1".
        # An example is below.
        #
        # ifcs:
        #   options:
        #     log_level: "warn"
        # nodes:
        # - node_id: "0"
        #   options:
        #     sku: "configs/sku/innovium.77700.model"
        #     ecmp_hierarchical_enable: "1"
        #     viz_bdc_enable: "1"

        # Make sure BDC is enabled in node.
        actual_count = c_uint32()
        out_attr = ifcs_ctypes.ifcs_attr_t()
        out_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_VIZ_BDC_ENABLE
        rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(out_attr), pointer(actual_count))
        if rc:
            log("BDC enable flag get unsuccessful")
            return rc
        if out_attr.value.data != ifcs_ctypes.IFCS_BOOL_TRUE:
            log('BDC attribute is not enabled in node. It must be set before enabling node. The option to use in yaml is viz_bdc_enable: "1"')
            return ifcs_ctypes.IFCS_INVAL

        if cpu_queue is not None:
            # Create Host If Trap
            rc = self.__host_if_trap_create(
                self.cli.node_id, cpu_queue, meter_cir, meter_burst_size)
            if rc:
                return rc

        # Create BDC collector
        try:
            rc = self._collector_create_(self.cli.node_id, collectorType=collectorType,
                                         srcMac=src_mac, destMac=dest_mac,
                                         srcIpFamily=srcIpFamily, destIpFamily=destIpFamily,
                                         srcIp=int(src_ip), destIp=int(dest_ip),
                                         dscp=dscp, ttl=ttl, localDestination = self.sysPort if cpu_queue is None else self.hostifTrap,
                                         dot1qVlan = (int(res.vlan) & 0xFFF if res.vlan is not None else None),
                                         vizTc=viz_tc, ipv4DfFlag=ipv4_df_flag)
        except Exception as e:
            rc = ifcs_ctypes.IFCS_DRIVER_ERROR
            log(str(e))
        if rc:
            log("BDC Collector create failed rc: {0}".format(rc))
            return rc

        rc  =  self._collector_set_create_(self.cli.node_id, collectorSetType=ifcs_ctypes.IFCS_COLLECTOR_TYPE_BDC)

        if rc:
            log("BDC Collector set failed rc: {0}".format(rc))
            return rc

        rc  = self._add_members_(self.bdc_collector_set_handle, [self.bdc_collector_handle])
        if rc:
            return rc

        # Create Visibility Sampler and configure it to sample every packet
        rc  =  self._visibility_sampler_create_(self.cli.node_id,
                                                type=ifcs_ctypes.IFCS_VISIBILITY_SAMPLER_TYPE_BDC,
                                                mode=sampler_mode,
                                                probabilisticCaptureRate=capture_rate,
                                                microburstCaptureAvgPacketRate=avg_packet_rate,
                                                microburstCaptureMaxPacketsPerBurst=max_packets_per_burst)
        if rc:
            return rc

        # Create a BDC policy with the Visibility Sampler and Collector Set
        rc  =  self._bdc_policy_create_(collector_set_handle=self.bdc_collector_set_handle,
                                        visibility_sampler_handle=self.bdc_visibility_sampler_handle)
        if rc:
            return rc

        # Setup BDC Policy on Class of Service Queue 1 and enable BDC
        rc  =  self._bdc_policy_queue_id_enable_(self.cli.node_id,
                                                policy=self.bdc_policy,
                                                enable=ifcs_ctypes.IFCS_BOOL_TRUE,
                                                queue=queue_ids)
        return rc

    def _bdc_policy_delete_(
            self,
            ifcsCall=True):

        self.bdc_policy = ifcs_ctypes.ifcs_bdc_policy_t()

        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_init(
                    pointer(self.bdc_policy)))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                self.bdc_policy = None
                log("BDC policy creation failed rc: {0}".format(rc))
                return
            else:
                pass
                #log("BDC policy creation success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_collector_set_set(
                    pointer(self.bdc_policy),
                    ifcs_ctypes.IFCS_NULL_HANDLE))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Remove Collector Set from BDC policy failed rc: {0}".format(rc))
            else:
                pass
                #log("Remove Collector Set from BDC policy success rc: {0}".format(rc))

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_bdc_policy_t_visibility_sampler_set(
                    pointer(self.bdc_policy),
                    ifcs_ctypes.IFCS_NULL_HANDLE))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Remove Visibility Sampler to BDC policy failed rc: {0}".format(rc))
            else:
                pass
                #log("Remove Visibility Sampler to BDC policy success rc: {0}".format(rc))

    def _collector_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False,
            ifcsCall=True):
        if bulk is True and ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_collector_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector Delete failed')
        elif ifcsCall is True:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector Delete failed')

    def _collector_set_delete_(
            self,
            expRc=None,
            bulkHandleCount=None,
            bulkHandles=None,
            bulkStatuses=None,
            customLog=None,
            bulk=False,
            ifcsCall=True):
        if bulk is True and ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_collector_set_bulk_delete(
                    self.nodeId,
                    NULL,
                    self.bulkKeyCount,
                    pointer(bulkKeys),
                    pointer(bulkStatuses)))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector_set Delete failed')
        elif ifcsCall is True:

            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'collector_set Delete failed')

    def _visibility_sampler_delete_(
            self,
            expRc=None,
            customLog=None,
            ifcsCall=True):
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_visibility_sampler_delete(
                    self.nodeId, self.handle))
            if expRc is not None:
                assert rc == expRc, 'rc expected:{0} actual:{1}'.format(
                    expRc, rc)
            else:
                if customLog is not None:
                    raiseExpOnFail(rc, customLog)
                else:
                    raiseExpOnFail(rc, 'Visibility Sampler Delete failed')

    def delete_instance(self,args):
        self.nodeID = self.cli.node_id
        if self.bdc_policy is not None:
            # Disable the BDC on Class of Service Queue
            self._bdc_policy_queue_id_enable_(self.cli.node_id,
                                              enable=ifcs_ctypes.IFCS_BOOL_FALSE,
                                              queue=self.cos_queue_ids)
            # Remove the BDC policy from the given Class of Service
            self._bdc_policy_delete_()
            self._bdc_policy_queue_id_enable_(self.cli.node_id,
                                              policy=self.bdc_policy,
                                              queue=self.cos_queue_ids)
        self.bdc_policy = None
        self.cos_queue_ids = []
        # Delete Visibility Sampler
        if self.bdc_visibility_sampler_handle != 0:
            self.handle = self.bdc_visibility_sampler_handle
            self._visibility_sampler_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        self.bdc_visibility_sampler_handle = 0
        # Remove collector from collector set and delete collector set
        if self.bdc_collector_set_handle != 0:
            self._remove_members_(self.bdc_collector_set_handle, [self.bdc_collector_handle])
            self.handle = self.bdc_collector_set_handle
            self._collector_set_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        # Delete collector
        if self.bdc_collector_handle != 0:
            self.handle = self.bdc_collector_handle
            self._collector_delete_(expRc=ifcs_ctypes.IFCS_SUCCESS)
        self.__host_if_trap_delete(self.cli.node_id)
        self.bdc_collector_set_handle = 0
        self.bdc_collector_handle = 0
        self.handle = 0
        self.sysPort = None
        # May disable BDC in node
        # self._node_bdc_enable_() cannot be successfully invoked after enabling node.
        return 0

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create_instance', 'Create BDC instance'])
        table.add_row(['delete_instance', 'Delete BDC instance'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        telemetry_bdc_help_string = """
Usage::

    Type "config bdc <command>" followed by -h to see command's sub-options.
"""
        log(telemetry_bdc_help_string)
