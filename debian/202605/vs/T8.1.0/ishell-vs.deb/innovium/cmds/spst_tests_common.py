#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

# Common routines used in all spst tests

from ctypes import *
from utils.compat_util import *
from verbosity import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

DEVICE_ACCESS_ERROR_EXC_MSG = "Device access error detected"

# Description: Log an error message prefixed with the caller's source line number.
# Input:   fmt - printf-style format string; *args - format arguments
# Output:  None (writes to log via log_err)
def spst_log_err(fmt, *args):
    log_err("Line %d. %s" % (sys._getframe().f_back.f_lineno, fmt % args))

# Description: Raise ValueError when device access fails during an SPST operation.
# Input:   status - IFCS status code; msg - optional context string for the failing API
# Output:  None; raises ValueError on IFCS_DEVICE_ACCESS_ERROR
def spstcommon_handle_device_access_error(status, msg=''):
    status = ifcs_ctypes.IFCS_STATUS_REASON(status)
    if status == ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR:
        if msg != '':
            raise ValueError("{} in {}".format(DEVICE_ACCESS_ERROR_EXC_MSG, msg))
        else:
            raise ValueError("{}".format(DEVICE_ACCESS_ERROR_EXC_MSG))
