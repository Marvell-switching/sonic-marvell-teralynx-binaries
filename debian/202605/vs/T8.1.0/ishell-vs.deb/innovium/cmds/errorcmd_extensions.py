#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json, pprint
import copy
import datetime
import netaddr
from operator import itemgetter
from collections import OrderedDict
from ctypes import *
from pencmd import penType
from utils.compat_util import *
from verbosity import *
from testutil import penrw
import os
import sys
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

from utils.mac_util import convertMacstrtoarr

def get_pen_name(pen_id):
    ''' Return Pen name from Pen num '''

    if pen_id == -1:
        return "PEN_INVALID"

    pen_str = c_char_p(b" " * 32)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 32)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Pen:" + str(pen_id)
    return compat_bytesToStr(pen_str.value)

def _penid(penstr):
    pentype = penType(None, 0)
    # try to get pen str to id, if it fails assume try to convert integer from a string
    try:
        (penid, penname) = pentype.get_id_name_from_str(penstr)
        return penid
    except Exception as e:
        log_dbg(1, "Exception '{}'".format(e))
        return ifcs_ctypes.PEN_INVALID

def _fldid(fldstr):
    pentype = penType(None, 0)
    fldid = pentype.get_fld_id_from_str(fldstr)
    penfld_id, field_name = pentype.get_fld_id_name_from_str(fldid);
    return penfld_id

# Hash table bucket id mask
def get_hash_bidmask(pen_id):
    nbuckets = c_uint32(0)
    rc = ifcs_ctypes.im_node_get_nbuckets(0, pen_id, pointer(nbuckets))

    if rc == ifcs_ctypes.IFCS_SUCCESS:
        bidmask = nbuckets.value - 1
    else:
        bidmask = None
    return bidmask

# Is UE correction enabled? If not, do not allow UE injection
def is_ue_correction_enabled():

    actual_count = c_uint32()
    attr = ifcs_ctypes.ifcs_attr_t()
    attr.id = ifcs_ctypes.IFCS_NODE_ATTR_ECC_MULTIBIT_ERROR_CORRECTION_ENABLE
    rc = ifcs_ctypes.ifcs_node_attr_get(
        0,
        1,
        pointer(attr),
        pointer(actual_count))

    return attr.value.u32 == ifcs_ctypes.IFCS_BOOL_TRUE


def _ecc_inject_validate_l2_entry_input(args):
    """
    Parse l2_entry specific arguments from the command string.

    Supported formats:
    - errors inject ecc ib 0 ce l2_entry l2vni INT_VAL dmac MAC_ADDR
    - errors inject ecc ib 0 ce l2_entry l2vni INT_VAL smac MAC_ADDR
    - errors inject ecc ib 0 ce l2_entry key_type mac_l2vni l2vni INT_VAL dmac MAC_ADDR
    - errors inject ecc ib 0 ce l2_entry key_type mac_l2vni l2vni INT_VAL smac MAC_ADDR
    - errors inject ecc ib 0 ce l2_entry key_type mac_only mac_addr MAC_ADDR mac_mask MAC_ADDR
    - errors inject ecc ib 0 ce l2_entry key_type mac_l2iif_l2vni_id mac_addr MAC_ADDR mac_mask MAC_ADDR l2iif L2IIF_VAL l2iif_mask L2IIF_MASK l2vni_id L2VNI_ID l2vni_id_mask L2VNI_ID

    Returns:
        tuple: (isValid, data, error_msg) where data is a dict with parsed values including 'key_type'
               and error_msg is an empty string on success or an error message on failure
    """
    values = args.split()
    isValid = True
    data = {}

    # Find the index of 'l2_entry' in the command
    try:
        l2_entry_idx = values.index('l2_entry')
    except ValueError:
        return (False, {}, "Missing 'l2_entry' keyword in command")

    # Start parsing after 'l2_entry'
    remaining = values[l2_entry_idx + 1:]

    if len(remaining) == 0:
        return (False, {}, "No arguments provided after 'l2_entry'")

    # Helper function to validate MAC address format
    def validate_mac_address(mac_str):
        mac_parts = mac_str.lower().split(':')
        if len(mac_parts) != 6:
            return False
        try:
            for part in mac_parts:
                val = int(part, 16)
                if val < 0 or val > 255:
                    return False
            return True
        except ValueError:
            return False

    # Helper function to validate integer (non-negative)
    def validate_int(val_str):
        try:
            val = int(val_str, 0)
            return val >= 0
        except ValueError:
            return False

    # Helper function to validate L2VNI_ID (0 to 8191)
    def validate_l2vni_id(val_str):
        try:
            val = int(val_str, 0)
            return 0 <= val <= 8191
        except ValueError:
            return False

    # Check if first argument is 'key_type' or legacy format
    if remaining[0].lower() == 'key_type':
        # New format with explicit key_type
        if len(remaining) < 2:
            return (False, {},
                    "Missing key_type value after 'key_type' keyword")

        key_type = remaining[1].lower()
        data['key_type'] = key_type
        remaining = remaining[2:]

        if key_type == 'mac_l2vni':
            # Format: key_type mac_l2vni l2vni INT_VAL dmac|smac MAC_ADDR
            if len(remaining) < 4:
                return (False, {},
                        "Insufficient arguments for key_type mac_l2vni")

            if remaining[0].lower() != 'l2vni':
                return (False, {},
                        "Expected 'l2vni' keyword for key_type mac_l2vni")

            if not validate_int(remaining[1]):
                return (False, {},
                        "Invalid l2vni value (must be a non-negative integer)")
            data['l2vni'] = int(remaining[1])

            mac_type = remaining[2].lower()
            if mac_type not in ['dmac', 'smac']:
                return (False, {}, "Expected 'dmac' or 'smac' keyword")

            if not validate_mac_address(remaining[3]):
                return (
                    False, {},
                    "Invalid MAC address format (expected xx:xx:xx:xx:xx:xx)")
            data[mac_type] = remaining[3].lower()

        elif key_type == 'mac_only':
            # Format: key_type mac_only mac_addr MAC_ADDR mac_mask MAC_ADDR
            if len(remaining) < 4:
                return (False, {},
                        "Insufficient arguments for key_type mac_only")

            if remaining[0].lower() != 'mac_addr':
                return (False, {},
                        "Expected 'mac_addr' keyword for key_type mac_only")

            if not validate_mac_address(remaining[1]):
                return (False, {},
                        "Invalid mac_addr format (expected xx:xx:xx:xx:xx:xx)")
            data['mac_addr'] = remaining[1].lower()

            if remaining[2].lower() != 'mac_mask':
                return (False, {},
                        "Expected 'mac_mask' keyword for key_type mac_only")

            if not validate_mac_address(remaining[3]):
                return (False, {},
                        "Invalid mac_mask format (expected xx:xx:xx:xx:xx:xx)")
            data['mac_mask'] = remaining[3].lower()

        elif key_type == 'mac_l2iif_l2vni_id':
            # Format: key_type mac_l2iif_l2vni_id mac_addr MAC_ADDR mac_mask MAC_ADDR l2iif L2IIF_VAL l2iif_mask L2IIF_MASK l2vni_id L2VNI_ID l2vni_id_mask L2VNI_ID
            if len(remaining) < 12:
                return (
                    False, {},
                    "Insufficient arguments for key_type mac_l2iif_l2vni_id")

            if remaining[0].lower() != 'mac_addr':
                return (
                    False, {},
                    "Expected 'mac_addr' keyword for key_type mac_l2iif_l2vni_id"
                )

            if not validate_mac_address(remaining[1]):
                return (False, {},
                        "Invalid mac_addr format (expected xx:xx:xx:xx:xx:xx)")
            data['mac_addr'] = remaining[1].lower()

            if remaining[2].lower() != 'mac_mask':
                return (False, {}, "Expected 'mac_mask' keyword")

            if not validate_mac_address(remaining[3]):
                return (False, {},
                        "Invalid mac_mask format (expected xx:xx:xx:xx:xx:xx)")
            data['mac_mask'] = remaining[3].lower()

            if remaining[4].lower() != 'l2iif':
                return (False, {}, "Expected 'l2iif' keyword")

            if not validate_int(remaining[5]):
                return (False, {},
                        "Invalid l2iif value (must be a non-negative integer)")
            data['l2iif'] = int(remaining[5], 0)

            if remaining[6].lower() != 'l2iif_mask':
                return (False, {}, "Expected 'l2iif_mask' keyword")

            if not validate_int(remaining[7]):
                return (
                    False, {},
                    "Invalid l2iif_mask value (must be a non-negative integer)")
            data['l2iif_mask'] = int(remaining[7], 0)

            if remaining[8].lower() != 'l2vni_id':
                return (False, {}, "Expected 'l2vni_id' keyword")

            if not validate_l2vni_id(remaining[9]):
                return (False, {}, "Invalid l2vni_id value (must be 0-8191)")
            data['l2vni_id'] = int(remaining[9], 0)

            if remaining[10].lower() != 'l2vni_id_mask':
                return (False, {}, "Expected 'l2vni_id_mask' keyword")

            if not validate_l2vni_id(remaining[11]):
                return (False, {},
                        "Invalid l2vni_id_mask value (must be 0-8191)")
            data['l2vni_id_mask'] = int(remaining[11], 0)

        else:
            return (
                False, {},
                "Unsupported key_type '{}' (valid: mac_l2vni, mac_only, mac_l2iif_l2vni_id)"
                .format(key_type))

    elif remaining[0].lower() == 'l2vni':
        # Legacy format without explicit key_type: l2vni INT_VAL dmac|smac MAC_ADDR
        # Assume key_type is mac_l2vni
        data['key_type'] = 'mac_l2vni'

        if len(remaining) < 4:
            return (False, {}, "Insufficient arguments for legacy l2vni format")

        if not validate_int(remaining[1]):
            return (False, {},
                    "Invalid l2vni value (must be a non-negative integer)")
        data['l2vni'] = int(remaining[1])

        mac_type = remaining[2].lower()
        if mac_type not in ['dmac', 'smac']:
            return (False, {}, "Expected 'dmac' or 'smac' keyword")

        if not validate_mac_address(remaining[3]):
            return (False, {},
                    "Invalid MAC address format (expected xx:xx:xx:xx:xx:xx)")
        data[mac_type] = remaining[3].lower()

    else:
        return (False, {},
                "Expected 'key_type' or 'l2vni' keyword after 'l2_entry'")

    return (isValid, data, "")


# Functions that help with ECC error injection
#
def ecc_inject_validate_input(self, args):
    knownAreas = [ 'l2_entry', 'route_entry', 'nexthop', 'pktbuffer', 'pen' ]
    knownTypes = [ 'ce', 'ue' ]
    area = None
    key = None
    errType = None
    ib = None
    values = args.split()
    isValid = True
    data = {}
    err_msg = ""

    attr = ifcs_ctypes.ifcs_attr_t()
    attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_TYPE
    actual_count = c_uint32()

    rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(attr), pointer(actual_count))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to find device type (IFCS_NODE_ATTR_DEVICE_TYPE) for nodeid: %s" % str(self.cli.node_id))
        return ifcs_ctypes.IFCS_NOTFOUND

    # Determine max IBs for this device
    ibmax = ifcs_ctypes.im_node_num_ibs(self.cli.node_id)

    if len(values) < 8:
        isValid = False
    if isValid and values[0] != 'errors':
        isValid = False
    if isValid and values[1] != 'inject':
        isValid = False
    if isValid and values[2] != 'ecc':
        isValid = False
    if isValid and values[3].lower() != 'ib':
        isValid = False

    # Is the IB a valid value?
    if isValid and values[4]:
        try:
            ib = int(values[4])
            if ib < 0 or ib >= ibmax:
                ib = None
                isValid = False
        except:
            ib = None
            isValid = False

    # Is the error type we support in the knownTypes list?
    if isValid and values[5]:
        if values[5].lower() in (etype for etype in knownTypes):
            errType = values[5].lower()
        else:
            isValid = False

    # Is the area in the list of known areas?
    if isValid and values[6]:
        if values[6].lower() in (area for area in knownAreas):
            area = values[6].lower()

            if area.lower() == 'l2_entry':
                res = _ecc_inject_validate_l2_entry_input(' '.join(values))
                if not res[0]:
                    isValid = False
                    err_msg = res[2]
                else:
                    data.update(res[1])

            if area.lower() == 'route_entry':
                if values[7].lower() == 'l3vni':
                    if values[9].lower() == 'ipv4' or values[9].lower() == 'ipv6':
                        # Make sure l2vni is an integer
                        try:
                            int(values[8])
                            data['l3vni'] = int(values[8])
                            data[values[9].lower()] = values[10]
                        except:
                            isValid = False
                            err_msg = "Invalid l3vni value (must be an integer)"
                    else:
                        isValid = False
                        err_msg = "No 'ipv4' or 'ipv6' keyword"
                else:
                    isValid = False
                    err_msg = "No 'l3vni' keyword"

            if area.lower() == 'nexthop':
                if values[7].lower() == 'handle':
                    try:
                        data['handle'] = int(values[8], 0)
                    except:
                        isValid = False
                        err_msg = "Invalid handle value (must be an integer)"
                else:
                    isValid = False
                    err_msg = "No 'handle' keyword"

            if area.lower() == 'pen':
                try:
                    data['fullPen'] = values[7]
                    data['ctrlPen'] = values[8]
                    data['index']   = int(values[9], 0)
                except:
                    isValid = False
                    err_msg = "Invalid PEN or index value"
        else:
            # Is not l2_entry or route_entry or nexthop or pen
            isValid = False
            err_msg = "Unknown area '{}'".format(values[6].lower())

    return (isValid, ib, errType, area, data, err_msg)


#
# Given a PEN, index, mark that entry with an ECC error, next access to that entry
# would result in an ECC interrupt
#
def ecc_inject_errors(self, srcpen, ib=0, index=0, inject='clear', fullPen=None, ctrlPen=None, isPkt=False):

    # ECC Injection fields
    if isPkt:
        # If its pkt bffer inject request, then inject in all the 6 buffers as we don't know
        # where the packet is going to go
        ce    = [(_fldid('ECC_EN_F'), 1),
                 (_fldid('INJECT_SNGL_ERR0_F'), 1), (_fldid('INJECT_SNGL_ERR1_F'), 1), (_fldid('INJECT_SNGL_ERR2_F'), 1),
                 (_fldid('INJECT_SNGL_ERR3_F'), 1), (_fldid('INJECT_SNGL_ERR4_F'), 1), (_fldid('INJECT_SNGL_ERR5_F'), 1),
                 (_fldid('INJECT_DBL_ERR0_F'),  0), (_fldid('INJECT_DBL_ERR1_F'),  0), (_fldid('INJECT_DBL_ERR2_F'),  0),
                 (_fldid('INJECT_DBL_ERR3_F'),  0), (_fldid('INJECT_DBL_ERR4_F'),  0), (_fldid('INJECT_DBL_ERR5_F'),  0)
                ]
        ue    = [(_fldid('ECC_EN_F'), 1),
                 (_fldid('INJECT_SNGL_ERR0_F'), 0), (_fldid('INJECT_SNGL_ERR1_F'), 0), (_fldid('INJECT_SNGL_ERR2_F'), 0),
                 (_fldid('INJECT_SNGL_ERR3_F'), 0), (_fldid('INJECT_SNGL_ERR4_F'), 0), (_fldid('INJECT_SNGL_ERR5_F'), 0),
                 (_fldid('INJECT_DBL_ERR0_F'),  1), (_fldid('INJECT_DBL_ERR1_F'),  1), (_fldid('INJECT_DBL_ERR2_F'),  1),
                 (_fldid('INJECT_DBL_ERR3_F'),  1), (_fldid('INJECT_DBL_ERR4_F'),  1), (_fldid('INJECT_DBL_ERR5_F'),  1)
                ]
        clear = [(_fldid('ECC_EN_F'), 1),
                 (_fldid('INJECT_SNGL_ERR0_F'), 0), (_fldid('INJECT_SNGL_ERR1_F'), 0), (_fldid('INJECT_SNGL_ERR2_F'), 0),
                 (_fldid('INJECT_SNGL_ERR3_F'), 0), (_fldid('INJECT_SNGL_ERR4_F'), 0), (_fldid('INJECT_SNGL_ERR5_F'), 0),
                 (_fldid('INJECT_DBL_ERR0_F'),  0), (_fldid('INJECT_DBL_ERR1_F'),  0), (_fldid('INJECT_DBL_ERR2_F'),  0),
                 (_fldid('INJECT_DBL_ERR3_F'),  0), (_fldid('INJECT_DBL_ERR4_F'),  0), (_fldid('INJECT_DBL_ERR5_F'),  0)
                ]
    else:
        # Non packet buffer inject request
        ce    = [(_fldid('ECC_EN_F'), 1),(_fldid('INJECT_SNGL_ERR_F'), 1),(_fldid('INJECT_DBL_ERR_F'), 0)]
        ue    = [(_fldid('ECC_EN_F'), 1),(_fldid('INJECT_SNGL_ERR_F'), 0),(_fldid('INJECT_DBL_ERR_F'), 1)]
        clear = [(_fldid('ECC_EN_F'), 1),(_fldid('INJECT_SNGL_ERR_F'), 0),(_fldid('INJECT_DBL_ERR_F'), 0)]

    if inject == 'ce':
        ecc_injection_fields = ce
    elif inject == 'ue':
        ecc_injection_fields = ue
    elif inject == 'clear':
        ecc_injection_fields = clear

    if inject == 'ue':
        ue_enabled = None
        try:
            ue_enabled = is_ue_correction_enabled()
        except:
            log_err("Unable to get IFCS_NODE_ATTR_ECC_MULTIBIT_ERROR_CORRECTION_ENABLE value")
            return ifcs_ctypes.IFCS_NOTFOUND
        if ue_enabled == ifcs_ctypes.IFCS_BOOL_FALSE:
            log("")
            log("ERROR: ECC UE injection not allowed because ECC UE correction is not enabled")
            log("       Check IFCS_NODE_ATTR_ECC_MULTIBIT_ERROR_CORRECTION_ENABLE attribute")
            log("       for more details")
            return ifcs_ctypes.IFCS_INVAL

    attr = ifcs_ctypes.ifcs_attr_t()
    attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_TYPE
    actual_count = c_uint32()

    rc = ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, pointer(attr), pointer(actual_count))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to find device type (IFCS_NODE_ATTR_DEVICE_TYPE) for nodeid: %s" % str(self.cli.node_id))
        return ifcs_ctypes.IFCS_NOTFOUND

    if ctrlPen is None and fullPen is None:
        if attr.value.u32 == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX7_1 or \
           attr.value.u32 == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX7_2 or \
           attr.value.u32 == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX7_3:
            from TL_fullctrlpen import ecc_ctrlpen_dict as tl_ecc_ctrlpen_dict
            from TL_fullctrlpen import fullpen_dict as tl_fullpen_dict
            ctrlPen = tl_ecc_ctrlpen_dict[_penid(srcpen)]
            fullPen = get_pen_name(tl_fullpen_dict[_penid(srcpen)])
        elif attr.value.u32 == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX10_1:
            from TL10_fullctrlpen import ecc_ctrlpen_dict as tl10_ecc_ctrlpen_dict
            from TL10_fullctrlpen import fullpen_dict as tl10_fullpen_dict
            ctrlPen = tl10_ecc_ctrlpen_dict[_penid(srcpen)]
            fullPen = get_pen_name(tl10_fullpen_dict[_penid(srcpen)])
        elif attr.value.u32 == ifcs_ctypes.IFCS_DEVICE_TYPE_TERALYNX100_1:
            from T100_fullctrlpen import ecc_ctrlpen_dict as t100_ecc_ctrlpen_dict
            from T100_fullctrlpen import fullpen_dict as t100_fullpen_dict
            ctrlPen = t100_ecc_ctrlpen_dict[_penid(srcpen)]
            fullPen = get_pen_name(t100_fullpen_dict[_penid(srcpen)])
        else:
                log_err("Unknown device (IFCS_NODE_ATTR_DEVICE_TYPE) for nodeid: %s" % str(self.cli.node_id))
                return ifcs_ctypes.IFCS_NOTFOUND
        # Usage of full pen adjustment/exception
        # The adjustment is needed based on the pd_state use of 1X view
        if srcpen == 'NHOIF_1X':
            fullPen = srcpen

    if ctrlPen == None or fullPen == None:
        log_err("Failed to find control pen to inject error for: %s" % srcpen)
        return ifcs_ctypes.IFCS_NOTFOUND

    # Keep a copy of data we are not injecting into pkt buffer
    if isPkt == False:
        # read src pen at index to get content
        log_dbg(1, "Inject ECC {}: read pen {} to save content @index {}/0x{:x}"\
            .format(inject, fullPen, index, index))
        try:
            flds = penrw.read_platform_pen(_penid(fullPen), index, ib=ib)
        except Exception as e:
            log_err("Unable to get read pen='%s' at index='%d' in ib='%s'" % (fullPen, index, ib))
            log_dbg(1, "Exception '{}'".format(e))
            return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR

    # write ctrl pen to enable single/double bit ECC
    log_dbg(1, "Inject ECC {}: write ctrl pen {} to enable injection".format(inject, ctrlPen))
    penrw.write_platform_pen(ctrlPen, 0, ecc_injection_fields, ib=ib)

    # Inject error by forcing a write ONLY if its not packet buffer. In those memories,
    # the first packet that comes in will result in bad ECC in that memory
    if isPkt == False:
        # write src pen at index with content read earlier
        log_dbg(1, "Inject ECC {}: write src pen {} to inject ECC @index {}/0x{:x}"\
            .format(inject, fullPen, index, index))
        penrw.write_platform_pen(_penid(fullPen), index, flds, ib=ib)

    # write ctrl pen to enable single/double bit ECC for future updates
    log_dbg(1, "Inject ECC {}: write ctrl pen {} to disable injection".format(inject, ctrlPen))
    penrw.write_platform_pen(ctrlPen, 0, clear, ib=ib)

    # From the test, we force the ECC interrupt, skip if pkt memories, we can't read them anyways
    force_trigger = os.environ.get('SHELL_ECC_CLI_FORCE_TRIGGER')
    if force_trigger and isPkt == False:
        log_dbg(1, "Inject ECC {}: read src pen {} ib {} @{} to trigger ECC interrupt".format(inject, fullPen, ib, index))
        try:
            flds = penrw.read_platform_pen(_penid(fullPen), index, ib=ib)
            log_dbg(1, "Force trigger read success: PEN {} index {} ib {}".format(fullPen, index, ib))
        except Exception as e:
            log_dbg(1, "Force trigger read fail: PEN {} index {} ib {}".format(fullPen, index, ib))
            log_dbg(1, "Exception '{}'".format(e))
            # If we just injected a UE, the read will give a device error, don't report as failure
            if inject != 'ue':
                return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR
    return ifcs_ctypes.IFCS_SUCCESS


def _build_l2_entry_key(self, data):
    key_type = data.get('key_type')

    # Common initialization
    key_obj = ifcs_ctypes.ifcs_l2_entry_key_t()
    ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(key_obj))

    if key_type == 'mac_l2vni':
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(
            pointer(key_obj), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
        ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(key_obj),
                                                      key_obj.key.mac_l2vni)
        mac_str = data.get('dmac') or data.get('smac')
        if not mac_str:
            raise ValueError("Missing dmac or smac in data")
        mac_parts = convertMacstrtoarr(mac_str)
        mac_addr = ifcs_ctypes.ifcs_mac_t(*mac_parts)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(
            pointer(key_obj.key.mac_l2vni), pointer(mac_addr))
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(
            pointer(key_obj.key.mac_l2vni),
            ifcs_ctypes.IFCS_HANDLE_L2VNI(data['l2vni']))
        return key_obj
    elif key_type == 'mac_only':
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(
            pointer(key_obj), ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_ONLY)
        ifcs_ctypes.ifcs_l2_entry_key_t_mac_only_set(pointer(key_obj),
                                                     key_obj.key.mac_only)
        mac_parts = convertMacstrtoarr(data['mac_addr'])
        mac_addr = ifcs_ctypes.ifcs_mac_t(*mac_parts)
        ifcs_ctypes.ifcs_l2_entry_key_mac_only_t_mac_addr_set(
            pointer(key_obj.key.mac_only), pointer(mac_addr))
        mac_mask_parts = convertMacstrtoarr(data['mac_mask'])
        mac_mask = ifcs_ctypes.ifcs_mac_t(*mac_mask_parts)
        ifcs_ctypes.ifcs_l2_entry_key_mac_only_t_mac_mask_set(
            pointer(key_obj.key.mac_only), pointer(mac_mask))
        return key_obj
    elif key_type == 'mac_l2iif_l2vni_id':
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(
            pointer(key_obj),
            ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2IIF_L2VNI_ID)
        ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2iif_l2vni_id_set(
            pointer(key_obj), key_obj.key.mac_l2iif_l2vni_id)
        mac_parts = convertMacstrtoarr(data['mac_addr'])
        mac_addr = ifcs_ctypes.ifcs_mac_t(*mac_parts)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2iif_l2vni_id_t_mac_addr_set(
            pointer(key_obj.key.mac_l2iif_l2vni_id), pointer(mac_addr))
        mac_mask_parts = convertMacstrtoarr(data['mac_mask'])
        mac_mask = ifcs_ctypes.ifcs_mac_t(*mac_mask_parts)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2iif_l2vni_id_t_mac_mask_set(
            pointer(key_obj.key.mac_l2iif_l2vni_id), pointer(mac_mask))
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2iif_l2vni_id_t_l2iif_set(
            pointer(key_obj.key.mac_l2iif_l2vni_id), data['l2iif'])
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2iif_l2vni_id_t_l2iif_mask_set(
            pointer(key_obj.key.mac_l2iif_l2vni_id), data['l2iif_mask'])
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2iif_l2vni_id_t_l2vni_id_set(
            pointer(key_obj.key.mac_l2iif_l2vni_id), data['l2vni_id'])
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2iif_l2vni_id_t_l2vni_id_mask_set(
            pointer(key_obj.key.mac_l2iif_l2vni_id), data['l2vni_id_mask'])
        return key_obj
    else:
        raise ValueError("Unsupported l2_entry key_type: {}".format(key_type))


def get_device_obj_key(self, objtype):
    device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
    if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
        l2_obj = 'tl_l2_objects'
        nexthop_obj = 'tl_nexthop_objects'
        route_obj = 'tl_route_objects'
        route_ilpm_obj = 'tl_route_ilpm_objects'
    elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
        l2_obj = 'tl10_l2_objects'
        nexthop_obj = 'tl10_nexthop_objects'
        route_obj = 'tl10_route_objects'
        route_ilpm_obj = 'tl10_route_ilpm_objects'
    elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_T100:
        l2_obj = 't100_l2_objects'
        nexthop_obj = 't100_nexthop_objects'
        route_obj = 't100_route_objects'
        route_ilpm_obj = 't100_route_ilpm_objects'
    if objtype == 'l2':
        return l2_obj
    elif objtype == 'nexthop':
        return nexthop_obj
    elif objtype == 'route':
        return route_obj
    elif objtype == 'route_ilpm':
        return route_ilpm_obj
    return ''

def getl2_entry(self, data):
    l2_entry = _build_l2_entry_key(self, data)

    def myCallback(node_id, arg, attr_count, attr_list, user_data):
        key_obj = ifcs_ctypes.ifcs_l2_entry_key_t()
        memmove(pointer(key_obj), arg, sizeof(key_obj))
        l2_entry_list.append(pointer(key_obj))
    l2_entry_list = []

    callback_type = CFUNCTYPE(
        ifcs_ctypes.UNCHECKED(None),
        ifcs_ctypes.ifcs_node_id_t,
        POINTER(ifcs_ctypes.ifcs_l2_entry_key_t),
        c_uint32,
        POINTER(ifcs_ctypes.ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    try:
        rc = ifcs_ctypes.ifcs_l2_entry_get_all(
            self.cli.node_id, pointer(l2_entry), 0, None, compat_funcPointer(callback, ifcs_ctypes.ifcs_l2_entry_user_cb_t), None, None)
    except Exception as e:
        return []
    return l2_entry_list


def ecc_inject_l2(self, ibnum, errType, data):
    if data['key_type'] in ['mac_only', 'mac_l2iif_l2vni_id']:
        return ecc_inject_l2_tcam(self, ibnum, errType, data)
    elif data['key_type'] != 'mac_l2vni':
        log_err("Unsupported l2_entry key_type for ECC injection: {}".format(
            data['key_type']))
        return ifcs_ctypes.IFCS_INVAL

    isdmac = 'dmac' in data
    l2_entries = getl2_entry(self, data)
    if len(l2_entries) != 1:
        log_err("Failed to find l2_entry matching user input")
        return ifcs_ctypes.IFCS_NOTFOUND

    l2_entry = l2_entries[0]
    actual_length = c_ulonglong()
    rc = ifcs_ctypes.im_l2_entry_state_string_get(self.cli.node_id, l2_entry, None, 0, byref(actual_length))
    jsonStr = b" " * actual_length.value
    rc = ifcs_ctypes.im_l2_entry_state_string_get(self.cli.node_id, l2_entry, jsonStr, actual_length.value, byref(actual_length))
    jsonObj = json.loads(compat_bytesToStr(jsonStr))

    l2_obj = get_device_obj_key(self, 'l2')
    if isdmac == True:
        funidx = ifcs_ctypes.INDEX_TO_FID(jsonObj[l2_obj]['0']['dest_hw_index'])
        bktidx = ifcs_ctypes.INDEX_TO_BID(jsonObj[l2_obj]['0']['dest_hw_index'])
        pen = jsonObj[l2_obj]['0']['dest_pen']
        srcpen = get_pen_name(pen)
    else:
        funidx = ifcs_ctypes.INDEX_TO_FID(jsonObj[l2_obj]['0']['src_hw_index'])
        bktidx = ifcs_ctypes.INDEX_TO_BID(jsonObj[l2_obj]['0']['src_hw_index'])
        pen = jsonObj[l2_obj]['0']['src_pen']
        srcpen = get_pen_name(pen)

    index = ifcs_ctypes.HASH_TO_INDEX(funidx, bktidx, 0)    # Recreate index with slot 0
    log_dbg(1, "Injecting ECC error in: PEN:%s, bucket:%d/0x%x" % (srcpen, bktidx, bktidx))

    return ecc_inject_errors(self, srcpen, ib=int(ibnum), index=index, inject=errType)

def ecc_inject_l2_tcam(self, ibnum, errType, data):
    l2_entries = getl2_entry(self, data)
    if len(l2_entries) != 1:
        log_dbg(1, "L2 Entries found: %d" % len(l2_entries))
        log_err("Failed to find l2_entry matching user input or more than one entry found")
        return ifcs_ctypes.IFCS_NOTFOUND

    l2_entry = l2_entries[0]
    actual_length = c_ulonglong()
    rc = ifcs_ctypes.im_l2_entry_state_string_get(self.cli.node_id, l2_entry,
                                                  None, 0, byref(actual_length))
    jsonStr = b" " * actual_length.value
    rc = ifcs_ctypes.im_l2_entry_state_string_get(self.cli.node_id, l2_entry,
                                                  jsonStr, actual_length.value,
                                                  byref(actual_length))
    jsonObj = json.loads(compat_bytesToStr(jsonStr))

    l2_obj = get_device_obj_key(self, 'l2')
    dest_idx = jsonObj[l2_obj]['0']['dest_hw_index']
    pen = jsonObj[l2_obj]['0']['dest_pen']
    dest_pen = get_pen_name(pen)

    log_dbg(1, "Injecting ECC error in TCAM: PEN:%s, index:%d/0x%x" % (dest_pen, dest_idx, dest_idx))

    return ecc_inject_errors(self, dest_pen, ib=int(ibnum), index=dest_idx, inject=errType)

def getroute_entry(self, l3vni, ipFamily, ip_addr, ip_mask):

    def ifcs_route_entry_key_map_fill(l3vni, addr_family, ip, mask):
        key = ifcs_ctypes.ifcs_route_entry_key_map_t()
        key.ip_dest_l3vni.l3vni = ifcs_ctypes.IFCS_HANDLE_L3VNI(l3vni)
        key.ip_dest_l3vni.ip_dest.addr_family = addr_family
        if addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            key.ip_dest_l3vni.ip_dest.addr.ipv4 = ip
            key.ip_dest_l3vni.ip_dest.mask.ipv4 = mask
        else:
            key.ip_dest_l3vni.ip_dest.addr.ipv6 = ip
            key.ip_dest_l3vni.ip_dest.mask.ipv6 = mask
        return key

    def convertMaskLenToMaskInt(maskLen, ipFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4):
        bits = 0
        if ipFamily == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            for i in compat_xrange(32-maskLen,32):
                bits |= (1 << i)
        elif ipFamily == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6:
            for i in compat_xrange(128-maskLen, 128):
                bits |= (1 <<i)
        return bits

    route_key = ifcs_ctypes.ifcs_route_entry_key_t()
    ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_key))
    ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)

    ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))

    # Fill out the key structure
    key = ifcs_route_entry_key_map_fill(l3vni, ipFamily, ip_addr, ip_mask)
    ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), key.ip_dest_l3vni)


    # Fill out the prefix information
    ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), key.ip_dest_l3vni.ip_dest.addr_family)
    ifcs_ctypes.ifcs_ip_prefix_t_addr_set(pointer(ip_dest), pointer(key.ip_dest_l3vni.ip_dest.addr))
    ifcs_ctypes.ifcs_ip_prefix_t_mask_set(pointer(ip_dest), pointer(key.ip_dest_l3vni.ip_dest.mask))

    ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))
    ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_l3vni_set(pointer(route_key.key.ip_dest_l3vni), key.ip_dest_l3vni.l3vni)

    def myRouteCallback(node_id, arg, attr_count, attr_list, user_data):
        key_obj = ifcs_ctypes.ifcs_route_entry_key_t()
        memmove(pointer(key_obj), arg, sizeof(key_obj))
        route_entry_list.append(pointer(key_obj))
    route_entry_list = []

    callback_type = CFUNCTYPE(
        ifcs_ctypes.UNCHECKED(None),
        ifcs_ctypes.ifcs_node_id_t,
        POINTER(ifcs_ctypes.ifcs_route_entry_key_t),
        c_uint32,
        POINTER(ifcs_ctypes.ifcs_attr_t),
        POINTER(None))
    route_callback = callback_type(myRouteCallback)

    try:
        rc = ifcs_ctypes.ifcs_route_entry_get_all(
            self.cli.node_id, pointer(route_key), 0, None, compat_funcPointer(route_callback, ifcs_ctypes.ifcs_route_entry_user_cb_t), None, None)
    except Exception as e:
        return []

    return route_entry_list


def ecc_inject_route(self, ibnum, errType, data):

    l3vni = data['l3vni']
    ipv4 = False
    ip_addr = []
    ip_mask = []
    if 'ipv4' in data.keys():
        userip = data['ipv4']
        ipFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4
        try:
            ip = netaddr.IPNetwork(userip)
            ip_addr = ip.ip.value
            ip_mask = 0xFFFFFFFF
        except:
            log_err("Invalid ipv4 address value")
            return ifcs_ctypes.IFCS_INVAL
        route_entries = getroute_entry(self, l3vni, ipFamily, ip_addr, ip_mask)
    else:
        userip = data['ipv6']
        ipFamily = ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6
        try:
            ip = netaddr.IPNetwork(userip)
        except:
            log_err("Invalid ipv6 address value")
            return ifcs_ctypes.IFCS_INVAL

        # Convert words to bytes and append to array
        ip_addr = []
        for word in ip.ip.words:
            ip_addr.append(word >> 8 & 0xFF)
            ip_addr.append(word >> 0 & 0xFF)
            ip_mask.append(0xFF)
            ip_mask.append(0xFF)
        ip6Addr = (c_ubyte*len(ip_addr))()
        ip6Mask = (c_ubyte*len(ip_addr))()
        for octet in range(len(ip_addr)):
            ip6Addr[octet] = ip_addr[octet]
            ip6Mask[octet] = ip_mask[octet]
        route_entries = getroute_entry(self, l3vni, ipFamily, ip6Addr, ip6Mask)

    if len(route_entries) != 1:
        log_err("Failed to find route_entry matching user input")
        return ifcs_ctypes.IFCS_NOTFOUND

    route_entry = route_entries[0]
    actual_length = c_ulonglong()
    rc = ifcs_ctypes.im_route_entry_state_string_get(self.cli.node_id, route_entry, None, 0, byref(actual_length))
    jsonStr = b" " * actual_length.value
    rc = ifcs_ctypes.im_route_entry_state_string_get(self.cli.node_id, route_entry, jsonStr, actual_length.value, byref(actual_length))
    jsonObj = json.loads(compat_bytesToStr(jsonStr))

    attr_t = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()
    ifcs_ctypes.ifcs_attr_t_init(pointer(attr_t))

    attr_t.id = ifcs_ctypes.IFCS_NODE_ATTR_ILPM_ENABLE
    rc = ifcs_ctypes.ifcs_node_attr_get(0, 1, pointer(attr_t), pointer(actual_count))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        return rc

    if attr_t.value.data: # ILPM is enabled
        route_ilpm_obj = get_device_obj_key(self, 'route_ilpm')
        funidx = ifcs_ctypes.INDEX_TO_FID(jsonObj[route_ilpm_obj]['0']['hardware_index'])
        bktidx = ifcs_ctypes.INDEX_TO_BID(jsonObj[route_ilpm_obj]['0']['hardware_index'])
        pen = jsonObj[route_ilpm_obj]['0']['pen_name']
        srcpen = get_pen_name(pen)
    else:
        route_obj = get_device_obj_key(self, 'route')
        funidx = ifcs_ctypes.INDEX_TO_FID(jsonObj[route_obj]['0']['hardware_index'])
        bktidx = ifcs_ctypes.INDEX_TO_BID(jsonObj[route_obj]['0']['hardware_index'])
        pen = jsonObj[route_obj]['0']['pen_name']
        srcpen = get_pen_name(pen)

    index = ifcs_ctypes.HASH_TO_INDEX(funidx, bktidx, 0)    # Recreate index with slot 0
    log_dbg(1, "Injecting ECC error in: PEN:%s, bucket:%d/0x%x" % (srcpen, bktidx, bktidx))
    return ecc_inject_errors(self, srcpen, ib=int(ibnum), index=index, inject=errType)

def ecc_inject_nexthop(self, ibnum, errType, data):
    handle = ifcs_ctypes.ifcs_handle_t()
    handle.value = data['handle']

    try:
        actual_length = c_ulonglong()
        rc = ifcs_ctypes.im_nexthop_state_string_get(self.cli.node_id, handle, None, 0, byref(actual_length))
        jsonStr = b" " * actual_length.value
        rc = ifcs_ctypes.im_nexthop_state_string_get(self.cli.node_id, handle, jsonStr, actual_length.value, byref(actual_length))
        jsonObj = json.loads(compat_bytesToStr(jsonStr))

        nexthop_obj = get_device_obj_key(self, 'nexthop')
        rindex = jsonObj[nexthop_obj]['0']['hw_index']
        pen = jsonObj[nexthop_obj]['0']['efc_pen']

        srcpen = get_pen_name(pen)
    except Exception as e:
        log_dbg(1, "Exception '{}'".format(e))
        log_err("Unable to locate nexthop handle: %s" % data['handle'])
        return ifcs_ctypes.IFCS_NOTFOUND

    log_dbg(1, "Injecting ECC error in: PEN:%s, row index:%d/0x%x" % (srcpen, rindex, rindex))
    return ecc_inject_errors(self, srcpen, ib=int(ibnum), index=int(rindex), inject=errType)

# Inject error into packet buffer memory
def ecc_inject_pktbuffer(self, ibnum, errType, data):
    log_dbg(1, "data: %s" % str(data))
    try:
        ecc_inject_errors(self, srcpen=None, ib=int(ibnum), index=0, inject=errType,
            fullPen=None, ctrlPen=ifcs_ctypes.DDB_ECC_CTRL, isPkt=True)
        tine.sleep(0.001)
        ecc_inject_errors(self, srcpen=None, ib=int(ibnum), index=0, inject='clear',
            fullPen=None, ctrlPen=ifcs_ctypes.DDB_ECC_CTRL, isPkt=True)
    except Exception as e:
        log_dbg(1, "Exception '{}'".format(e))
        return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR
    return ifcs_ctypes.IFCS_SUCCESS

# Inject error into a PEN
def ecc_inject_pen(self, ibnum, errType, data):
    log_dbg(1, "data: %s" % str(data))
    fullPen = data['fullPen']
    ctrlPen = _penid(data['ctrlPen'])
    rindex  = data['index']
    try:
        srcpen = data['fullPen']
        log_dbg(1, "Injecting error in srcpen: %s" % srcpen)
        return ecc_inject_errors(self, srcpen, ib=int(ibnum), index=int(rindex), inject=errType, fullPen=fullPen, ctrlPen=ctrlPen)
    except Exception as e:
        log_dbg(1, "Exception '{}'".format(e))
        return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR
    return ifcs_ctypes.IFCS_SUCCESS

def ecc_inject_area(self, ib, errType, area, data):
    log_dbg(1, "Inject ECC Error: %d, ib=%s, errType:%s, area=%s, key=%s" % (
        self.cli.node_id, ib, errType, area, data))

    if area == 'l2_entry':
        rc = ecc_inject_l2(self, ib, errType, data)

    if area == 'route_entry':
        rc = ecc_inject_route(self, ib, errType, data)

    if area == 'nexthop':
        rc = ecc_inject_nexthop(self, ib, errType, data)

    if area == 'pkt':
        rc = ecc_inject_pkt(self, ib, errType, data)

    if area == 'pen':
        rc = ecc_inject_pen(self, ib, errType, data)

    if rc != ifcs_ctypes.IFCS_SUCCESS:
        ecc_inject_area_usage(area)
    return rc


def ecc_inject_area_usage(area_name=None):
    if area_name == 'l2_entry':
        _ecc_inject_area_usage_l2_entry()
    elif area_name == 'route_entry':
        _ecc_inject_area_usage_route_entry()
    elif area_name == 'nexthop':
        _ecc_inject_area_usage_nexthop()
    elif area_name == 'pen':
        _ecc_inject_area_usage_pen()
    else:
        _ecc_inject_area_usage_all()


def _ecc_inject_area_usage_all():
    log("")
    log("Usage: errors inject ecc ib IB_NUM {ce|ue} AREA [OPTIONS]")
    log("")
    log("Inject ECC errors (correctable or uncorrectable) into specific memory areas")
    log("")
    log("Positional arguments:")
    log("  IB_NUM              IB number")
    log("  {ce|ue}             Error type: 'ce' (correctable) or 'ue' (uncorrectable)")
    log("  AREA                Memory area to inject error into")
    log("")
    log("Areas and their options:")
    log("")
    log("  l2_entry - L2 entry table")
    log("    Legacy format (assumes key_type mac_l2vni):")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry l2vni L2VNI {dmac|smac} MAC_ADDR")
    log("")
    log("    Explicit key_type formats:")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry key_type mac_l2vni l2vni L2VNI {dmac|smac} MAC_ADDR")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry key_type mac_only mac_addr MAC_ADDR mac_mask MAC_ADDR")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry key_type mac_l2iif_l2vni_id \\")
    log("                           mac_addr MAC_ADDR mac_mask MAC_ADDR \\")
    log("                           l2iif L2IIF_HANDLE l2iif_mask L2IIF_MASK \\")
    log("                           l2vni_id L2VNI_ID l2vni_id_mask L2VNI_ID")
    log("")
    log("  route_entry - Route entry table")
    log("      errors inject ecc ib IB_NUM {ce|ue} route_entry l3vni L3VNI {ipv4|ipv6} IP_ADDR")
    log("")
    log("  nexthop - Nexthop table")
    log("      errors inject ecc ib IB_NUM {ce|ue} nexthop handle HANDLE")
    log("")
    log("  pen - Direct PEN injection")
    log("      errors inject ecc ib IB_NUM {ce|ue} pen FULL_PEN CONTROL_PEN INDEX")
    log("")
    log("Arguments:")
    log("  L2VNI               Non-negative integer value for L2 VNI")
    log("  MAC_ADDR            MAC address in format xx:xx:xx:xx:xx:xx (lowercase)")
    log("  L2IIF_HANDLE        Handle for Layer 2 ingress interface (supports hex format)")
    log("  L2IIF_MASK          Handle mask for Layer 2 ingress interface (supports hex format)")
    log("  L2VNI_ID            Integer value in range 0-8191 for Ingress L2 VNI value (supports hex format)")
    log("  L3VNI               Non-negative integer value for L3 VNI")
    log("  IP_ADDR             IPv4 or IPv6 address")
    log("  HANDLE              Nexthop handle (supports hex format)")
    log("  FULL_PEN            Full PEN name")
    log("  CONTROL_PEN         Control PEN name")
    log("  INDEX               Non-negative integer index (supports hex format)")
    log("")
    log("Examples:")
    log("  errors inject ecc ib 0 ce l2_entry l2vni 100 dmac 00:00:00:00:00:aa")
    log("  errors inject ecc ib 0 ce l2_entry key_type mac_only mac_addr aa:bb:cc:dd:ee:00 mac_mask ff:ff:ff:ff:ff:00")
    log("  errors inject ecc ib 0 ce route_entry l3vni 200 ipv4 192.168.1.1")
    log("  errors inject ecc ib 0 ce nexthop handle 0x1234")
    log("")


def _ecc_inject_area_usage_l2_entry():
    log("")
    log("Usage: errors inject ecc ib IB_NUM {ce|ue} l2_entry [OPTIONS]")
    log("")
    log("Inject ECC errors into L2 entry table")
    log("")
    log("Positional arguments:")
    log("  IB_NUM              IB number")
    log("  {ce|ue}             Error type: 'ce' (correctable) or 'ue' (uncorrectable)")
    log("")
    log("L2 entry formats:")
    log("")
    log("  Legacy format (assumes key_type mac_l2vni):")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry l2vni L2VNI {dmac|smac} MAC_ADDR")
    log("")
    log("  Explicit key_type formats:")
    log("")
    log("    mac_l2vni:")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry key_type mac_l2vni l2vni L2VNI {dmac|smac} MAC_ADDR")
    log("")
    log("    mac_only:")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry key_type mac_only mac_addr MAC_ADDR mac_mask MAC_ADDR")
    log("")
    log("    mac_l2iif_l2vni_id:")
    log("      errors inject ecc ib IB_NUM {ce|ue} l2_entry key_type mac_l2iif_l2vni_id \\")
    log("                           mac_addr MAC_ADDR mac_mask MAC_ADDR \\")
    log("                           l2iif L2IIF_HANDLE l2iif_mask L2IIF_MASK \\")
    log("                           l2vni_id L2VNI_ID l2vni_id_mask L2VNI_ID")
    log("")
    log("Arguments:")
    log("  L2VNI               Non-negative integer value for L2 VNI")
    log("  MAC_ADDR            MAC address in format xx:xx:xx:xx:xx:xx (lowercase)")
    log("  L2IIF_HANDLE        Handle for Layer 2 ingress interface (supports hex format)")
    log("  L2IIF_MASK          Handle mask for Layer 2 ingress interface (supports hex format)")
    log("  L2VNI_ID            Integer value in range 0-8191 for Ingress L2 VNI value (supports hex format)")
    log("")
    log("Examples:")
    log("  errors inject ecc ib 0 ce l2_entry l2vni 100 dmac 00:00:00:00:00:aa")
    log("  errors inject ecc ib 0 ce l2_entry key_type mac_l2vni l2vni 100 dmac 00:00:00:00:00:aa")
    log("  errors inject ecc ib 0 ce l2_entry key_type mac_only mac_addr 00:11:22:33:00:00 mac_mask ff:ff:ff:ff:00:00")
    log("  errors inject ecc ib 0 ce l2_entry key_type mac_l2iif_l2vni_id mac_addr  aa:bb:cc:01:00:00 mac_mask ff:ff:ff:ff:00:00 l2iif 0 l2iif_mask 0 l2vni_id 150 l2vni_id_mask 8191")
    log("")


def _ecc_inject_area_usage_route_entry():
    log("")
    log("Usage: errors inject ecc ib IB_NUM {ce|ue} route_entry l3vni L3VNI {ipv4|ipv6} IP_ADDR")
    log("")
    log("Inject ECC errors into route entry table")
    log("")
    log("Positional arguments:")
    log("  IB_NUM              IB number")
    log("  {ce|ue}             Error type: 'ce' (correctable) or 'ue' (uncorrectable)")
    log("  L3VNI               Non-negative integer value for L3 VNI")
    log("  {ipv4|ipv6}         IP address family")
    log("  IP_ADDR             IPv4 address (e.g., 192.168.1.1) or IPv6 address (e.g., 2001:db8::1)")
    log("")
    log("Examples:")
    log("  errors inject ecc ib 0 ce route_entry l3vni 200 ipv4 192.168.1.1")
    log("  errors inject ecc ib 0 ce route_entry l3vni 400 ipv6 2001:db8::1")
    log("")


def _ecc_inject_area_usage_nexthop():
    log("")
    log("Usage: errors inject ecc ib IB_NUM {ce|ue} nexthop handle HANDLE")
    log("")
    log("Inject ECC errors into nexthop table")
    log("")
    log("Positional arguments:")
    log("  IB_NUM              IB number")
    log("  {ce|ue}             Error type: 'ce' (correctable) or 'ue' (uncorrectable)")
    log("  HANDLE              Nexthop handle (supports hex format)")
    log("")
    log("Examples:")
    log("  errors inject ecc ib 0 ce nexthop handle 0x1234")
    log("")


def _ecc_inject_area_usage_pen():
    log("")
    log("Usage: errors inject ecc ib IB_NUM {ce|ue} pen FULL_PEN CONTROL_PEN INDEX")
    log("")
    log("Inject ECC errors directly into a PEN")
    log("")
    log("Positional arguments:")
    log("  IB_NUM              IB number")
    log("  {ce|ue}             Error type: 'ce' (correctable) or 'ue' (uncorrectable)")
    log("  FULL_PEN            Full PEN name")
    log("  CONTROL_PEN         Control PEN name")
    log("  INDEX               Non-negative integer index (supports hex format)")
    log("")
