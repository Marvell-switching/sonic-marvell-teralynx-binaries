
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
import sys
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

# Initialize Parameters
src_port = 1
dst_port = src_port + 1
dst_port2 = src_port + 2
dst_port3 = src_port + 3
dst_port4 = src_port + 4
dst_port5 = src_port + 5
dst_port6 = src_port + 6
dst_port7 = src_port + 7
dst_port8 = src_port + 8
dst_port9 = src_port + 9
dst_port10 = src_port + 10
dst_port11 = src_port + 11
dst_port12 = src_port + 12
dst_port13 = src_port + 13
dst_port14 = src_port + 14
dst_port15 = src_port + 15
dst_port16 = src_port + 16
dst_port17 = src_port + 17
dst_port18 = src_port + 18
dst_port19 = src_port + 19
dst_port20 = src_port + 20
dst_port21 = src_port + 21

l2vni = 0x64

def getSysportHandleFromDevPort(devPort):
    attr = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_ctypes.ifcs_devport_attr_get(0, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

def txrx_packet():
    # instantiate tx and expected packets
    pkts_tx = []
    pkts_exp = []

    i = 0
    # Transmitted Packets
    dmac ="00:01:02:03:04:05"
    pkt_fp = Teralynx(PktID=1234, PktLength=102+42+4, SrcLocalPort=i, Reserved=0)/ \
             Ether(dst=dmac) /  \
             Dot1Q(vlan=l2vni)/ \
             IP(dst="127.0.0.1")/ \
             UDP(dport=model_server.fp_port)
    pkt_fp = model_packet.pad(pkt_fp,102)
    pkts_tx.append(pkt_fp)

    # Expected Packets (update Ethernet Header Fields)
    pkt_fp = Teralynx(PktID=1234, PktLength=102+42+4, SrcLocalPort=i, Reserved=(i+1))/ \
             Ether(dst=dmac) /  \
             Dot1Q(vlan=l2vni)/ \
             IP(dst="127.0.0.1")/ \
             UDP(dport=model_server.fp_port)
    pkt_fp = model_packet.pad(pkt_fp,102)
    hexdump(pkt_fp)
    pkts_exp.append(pkt_fp)

    # overloadable function call to set up hash structure of server packet buffers
    model_server.hash_setup('SrcPort','DestPort')

    # append function call to add expected packets to server-side hash tree (parsing, dissection, processing, key generation are all automatically handled)
    for packet in pkts_exp:
        model_server.expected_packets.append(packet)

    # transmit all packets in the passed container through front panel UDP socket (agnostic of device port)
    model_server.transmit(pkts_tx)
# Class implements L2vni related command

class L2vni(Command):
    def __init__(self, cli):
        self.sub_cmds = {'create'  : self.create,
                         'delete'  : self.delete,
                         'add'     : self.add,
                         'remove'  : self.remove,
                         'basicl2' : self.basicl2,
                         'help'    : self.help,
                         '?'       : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(L2vni, self).__init__()
        self.vni_handles = {}

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def run_cmd(self, args):
        log_dbg(1, "in L2vni run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (ValueError):
            try:
                l2vni_id = int(self.arg_list[1])
                if (l2vni_id < 0 or l2vni_id >= self.num_l2vnis):
                    log_err("Valid l2vni ids are between 0 and " + str((self.num_l2vnis-1)))
                    self.help(args)
                    return
                log_dbg(1, "Setting active l2vni to " + str(l2vni_id))
                self.active_l2vni = l2vni_id
            except:
                log_err('L2vniValueTryError')
        except (KeyError):
            log_dbg(1, 'L2vniKeyError')
            self.help(args)
        except (IndexError):
            log_dbg(1, 'L2vniIndexError')
            self.help(args)
        except:
            log_dbg(1, 'L2vniOtherError')
            self.help(args)
        return

    def create(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id in self.vni_handles:
            log_err("Handle already exists")
            return

        try:
            self.vni_handles[l2vni_id] = ifcs_ctypes.ifcs_handle_t()
            rc = ifcs_ctypes.ifcs_l2vni_create(0, pointer(self.vni_handles[l2vni_id]),
                                   0, 0)
            if rc != 0:
                log_err("l2vni create failed")
                return
        except:
            log_err("Usage: l2vni create <l2vni>")
            return

    def delete(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_delete(0, self.vni_handles[l2vni_id])
            if rc != 0:
                log_err("l2vni delete failed")
                return

        except:
            log_err("Usage: l2vni delete <l2vni>")
            return

    def add(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        port = int(self.arg_list.pop(0))

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        actual_count = c_uint32()
        rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, 1, pointer(attr),
                                pointer(actual_count))
        if rc != 0:
            log_err("l2vni port_attr_get failed")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_member_add(0, self.vni_handles[l2vni_id],
                                       attr.value.handle, 0)
            if rc != 0:
                log_err("l2vni member add failed")
                return

        except:
            log_err("Usage: l2vni add <l2vni>")
            return

    def remove(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        l2vni_id = self.arg_list.pop(0)
        if l2vni_id not in self.vni_handles:
            log_err("Handle does not exists")
            return

        port = int(self.arg_list.pop(0))

        attr = ifcs_ctypes.ifcs_attr_t()
        attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        actual_count = c_uint32()
        rc = ifcs_ctypes.ifcs_devport_attr_get(0, port, 1, pointer(attr),
                                pointer(actual_count))
        if rc != 0:
            log_err("l2vni port_attr_get")
            return

        try:
            rc = ifcs_ctypes.ifcs_l2vni_member_remove(0, self.vni_handles[l2vni_id],
                                          attr.value.handle)
            if rc != 0:
                log_err("l2vni member remove failed")
                return

        except:
            log_err("Usage: l2vni remove <l2vni>")
            return

    def basicl2(self, args):
        ret = ifcs_ctypes.ifcs_status_t()
        stp_hdl = ifcs_ctypes.ifcs_handle_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        attr = ifcs_ctypes.ifcs_attr_t()
        vni_attr = ifcs_ctypes.ifcs_attr_t()
        mac_addr_t = c_uint8 * 6

        ifcs_ctypes.node_model_server_dbglvl_set(0, 0, 5)
        dsp_fldlst = []
        #fldlst = []

        #fldlst = read_pen(ifcs_ctypes.DSP_L2TAG_ACTION_PROFILE, 0, dsp_fldlst)
        #log(dsp_fldlst)
        #fldlst = read_pen(ifcs_ctypes.DSP_L2TAG_ACTION_PROFILE, 1, dsp_fldlst)
        #log(fldlst)

        src_sp_hdl = getSysportHandleFromDevPort(src_port)
        src_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(src_sp_hdl)

        dst_sp_hdl = getSysportHandleFromDevPort(dst_port)
        dst_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl)

        dst_sp_hdl2 = getSysportHandleFromDevPort(dst_port2)
        dst_sp2 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl2)

        dst_sp_hdl3 = getSysportHandleFromDevPort(dst_port3)
        dst_sp3 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl3)

        dst_sp_hdl4 = getSysportHandleFromDevPort(dst_port4)
        dst_sp4 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl4)

        dst_sp_hdl5 = getSysportHandleFromDevPort(dst_port5)
        dst_sp5 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl5)

        dst_sp_hdl6 = getSysportHandleFromDevPort(dst_port6)
        dst_sp6 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl6)

        dst_sp_hdl7 = getSysportHandleFromDevPort(dst_port7)
        dst_sp7 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl7)

        dst_sp_hdl8 = getSysportHandleFromDevPort(dst_port8)
        dst_sp8 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl8)

        dst_sp_hdl9 = getSysportHandleFromDevPort(dst_port9)
        dst_sp9 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl9)

        dst_sp_hdl10 = getSysportHandleFromDevPort(dst_port10)
        dst_sp10 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl10)

        dst_sp_hdl11 = getSysportHandleFromDevPort(dst_port11)
        dst_sp11 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl11)

        dst_sp_hdl12 = getSysportHandleFromDevPort(dst_port12)
        dst_sp12 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl12)

        dst_sp_hdl13 = getSysportHandleFromDevPort(dst_port13)
        dst_sp13 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl13)

        dst_sp_hdl14 = getSysportHandleFromDevPort(dst_port14)
        dst_sp14 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl14)

        dst_sp_hdl15 = getSysportHandleFromDevPort(dst_port15)
        dst_sp15 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl15)

        dst_sp_hdl16 = getSysportHandleFromDevPort(dst_port16)
        dst_sp16 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl16)

        dst_sp_hdl17 = getSysportHandleFromDevPort(dst_port17)
        dst_sp17 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl17)

        dst_sp_hdl18 = getSysportHandleFromDevPort(dst_port18)
        dst_sp18 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl18)

        dst_sp_hdl19 = getSysportHandleFromDevPort(dst_port19)
        dst_sp19 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl19)

        dst_sp_hdl20 = getSysportHandleFromDevPort(dst_port20)
        dst_sp20 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl20)

        dst_sp_hdl21 = getSysportHandleFromDevPort(dst_port21)
        dst_sp21 = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl21)

        ####### STEP0 #######
        ###### STP CONFIG #######
        stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
        ret = ifcs_ctypes.ifcs_stp_create(0, pointer(stp_hdl),
                                       0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance creation failed"

        ###### VNI CONFIG ######
        # Create VNI and add members
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(l2vni)
        ret = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI creation " + str(l2vni)

        ####### STEP1 #######
        # 1.1

        mbr1 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)
        mbr2 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)
        mbr3 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp2)
        mbr4 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp3)
        mbr5 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp4)
        mbr6 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp5)
        mbr7 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp6)
        mbr8 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp7)
        mbr9 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp8)
        mbr10 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp9)
        mbr11 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp10)
        mbr12 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp11)
        mbr13 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp12)
        mbr14 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp13)
        mbr15 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp14)
        mbr16 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp15)
        mbr17 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp16)
        mbr18 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp17)
        mbr19 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp18)
        mbr20 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp19)
        mbr21 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp20)
        mbr22 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp21)

        member_count = 22
        member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

        member_attr_count = 0
        member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

        member_list[0] = mbr1
        member_list[1] = mbr2
        member_list[2] = mbr3
        member_list[3] = mbr4
        member_list[4] = mbr5
        member_list[5] = mbr6
        member_list[6] = mbr7
        member_list[7] = mbr8
        member_list[8] = mbr9
        member_list[9] = mbr10
        member_list[10] = mbr11
        member_list[11] = mbr12
        member_list[12] = mbr13
        member_list[13] = mbr14
        member_list[14] = mbr15
        member_list[15] = mbr16
        member_list[16] = mbr17
        member_list[17] = mbr18
        member_list[18] = mbr19
        member_list[19] = mbr20
        member_list[20] = mbr21
        member_list[21] = mbr22

        ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                     member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                     member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr add " + str(l2vni)

        stp_attr_count = 1
        stp_attr = ifcs_ctypes.ifcs_attr_t()
        stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
        stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;
        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr1,\
                                     stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr1.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr2, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr2.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr3, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr3.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr4, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr4.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr5, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr5.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr6, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr6.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr7, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr7.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr8, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr8.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr9, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr9.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr10, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr10.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr11, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr11.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr12, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr12.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr13, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr13.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr14, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr14.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr15, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr15.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr16, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr16.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr17, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr17.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr18, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr18.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr19, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr19.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr20, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr20.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr21, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr21.value))

        ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbr22, stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr22.value))

        # Set STP instance for created VNI
        vni_attr.id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
        vni_attr.value.handle = stp_hdl
        ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set failed"
        # Set STP instance for created VNI
        vni_attr.id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
        vni_attr.value.handle = stp_hdl
        ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set failed"

        # 1.2
        ###### FDB Config #######
        # src_port = 1, src_mac = 00:00:00:00:00:01
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        src_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 1)
        src_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = src_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 2, dst mac = 00:00:00:00:00:02
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 2)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 3, dst mac = 00:00:00:00:00:03
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 3)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp2)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 4, dst mac = 00:00:00:00:00:04
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 4)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp3)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 5, dst mac = 00:00:00:00:00:05
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 5)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp4)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 6, dst mac = 00:00:00:00:00:06
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 6)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp5)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 7, dst mac = 00:00:00:00:00:07
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 7)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp6)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 8, dst mac = 00:00:00:00:00:08
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 8)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp7)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 9, dst mac = 00:00:00:00:00:09
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 9)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp8)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 10, dst mac = 00:00:00:00:00:10
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 10)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp9)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 11, dst mac = 00:00:00:00:00:11
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 11)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp10)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 12, dst mac = 00:00:00:00:00:12
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 12)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp11)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 13, dst mac = 00:00:00:00:00:13
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 13)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp12)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 14, dst mac = 00:00:00:00:00:14
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 14)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp13)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 15, dst mac = 00:00:00:00:00:15
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 15)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp14)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 16, dst mac = 00:00:00:00:00:16
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 16)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp15)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 17, dst mac = 00:00:00:00:00:17
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 17)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp16)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 18, dst mac = 00:00:00:00:00:18
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 18)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp17)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 19, dst mac = 00:00:00:00:00:19
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 19)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp18)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 20, dst mac = 00:00:00:00:00:20
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 20)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp19)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 21, dst mac = 00:00:00:00:00:21
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 21)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp20)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        # dst port = 22, dst mac = 00:00:00:00:00:22
        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t
        attr_count = 2
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 22)
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp21)

        l2entry_array = ifcs_ctypes.ifcs_l2entry_key_t(mac_addr, l2vni_hdl)
        attr[0].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2ENTRY_TYPE_STATIC
        rc = ifcs_ctypes.ifcs_l2entry_create(0, pointer(l2entry_array), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create FDB entry failed: rc = [" + str(rc) + "]"

        ssp_attr = ifcs_ctypes.ifcs_attr_t()
        ssp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        ssp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, src_sp_hdl, 1, pointer(ssp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl2, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl3, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl4, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl5, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl6, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl7, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl8, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl9, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl10, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl11, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl12, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl13, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl14, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl15, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl16, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl17, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl18, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl19, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl20, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

        dsp_attr = ifcs_ctypes.ifcs_attr_t()
        dsp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_VLAN_ID
        dsp_attr.value.u16 = l2vni
        ret = ifcs_ctypes.ifcs_sysport_attr_set(0, dst_sp_hdl21, 1, pointer(dsp_attr))

        assert ret == ifcs_ctypes.IFCS_SUCCESS, "DSP default PVID set failed: rc = [" + str(rc) + "]"

    def help(self, args):
        self.cli.error()
        log("Usage: \n", \
              "l2vni create <l2vni_id>    - create l2VNI\n", \
              "l2vni delete <l2vni_id>    - delete l2VNI\n", \
              "l2vni add <l2vni_id>, <sysport> - l2vni add member\n", \
              "l2vni remove <l2vni_id>     - l2vni remove member\n", \
              "l2vni help or ?           - show this text\n")
