#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
import os, glob, importlib.util

# Class implements test related commands
class PyTest(Command):
    def __init__(self, cli):
        self.sub_cmds = {'source'    : self.source,
                         'exec'      : self.execf,
                         'eval'      : self.evalf,
                         'help'      : self.help,
                         '?'         : self.help
                        }
        self.cli = cli
        self.arg_list = []
        self.modules = {}

    def run_cmd(self, args):
        log_dbg(1, "in Test run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "Context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            log_dbg(1, "TestKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "TestValueError")
            self.help(args)
        except:
            log_dbg(1, "TestOtherError")
            self.help(args)
        return

    def load_source(self, name, path):
        spec = importlib.util.spec_from_file_location(name, path)
        if spec is None or spec.loader is None:
            raise ImportError("Cannot load module {} from {}".format(name, path))

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def source(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        for path in glob.glob('test/unit_test/[!_]*.py'):
            name, ext = os.path.splitext(os.path.basename(path))
            try:
                self.load_source(name, path)
            except Exception as e:
                log(e)
                log("(test)", name, "(path)", path)
            self.modules[name] = self.load_source(name, path)

        for path in glob.glob('test/systest/[!_]*.py'):
            name, ext = os.path.splitext(os.path.basename(path))
            try:
                self.load_source(name, path)
            except Exception as e:
                log(e)
                log("(test)", name, "(path)", path)
            self.modules[name] = self.load_source(name, path)
        log("Pytest source \"test\" Loaded....")
        return

    def execf(self, args):
        try:
            srcf = self.arg_list[2]
            func = self.arg_list[3]
        except:
            log('Invalid params')
            self.help()
            return

        #Construct the method to execute
        a = 'self.modules[\'' + srcf + '\'].' + str(func)
        try:
            log(eval(a))
            eval(a)()
        except Exception as e:
            log(e)

        pass

    def evalf(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            srcf = self.arg_list.pop(0)
            func = self.arg_list.pop(0)
        except:
            log('Invalid params')
            self.help()
            return

        name, ext = os.path.splitext(os.path.basename(srcf))
        try:
            self.modules[name] = self.load_source(name, srcf)
        except Exception as e:
            log("Load exception " + e)
        log("Python test " + srcf + " loaded")


        #Construct the method to execute
        a = 'self.modules[\'' + name + '\'].' + str(func)
        try:
            log("Evaluating " + srcf + ":" + func)
            log(eval(a)())
        except Exception as e:
            log("Eval exception:")
            log(e)

        pass

    def help(self, args):
        log("Usage: \n",    \
              "pytest source                  - Source Pytest Files\n", \
              "pytest exec <test name> <func> - Execute Pytest test method\n", \
              "pytest eval <fname> <func>     - Load and execute a method\n", \
              "pytest help or ?               - show this text\n")
