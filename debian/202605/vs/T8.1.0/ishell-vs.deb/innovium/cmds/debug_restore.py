#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import os
import sys
import json
import time
try:
    import cPickle as pickle
except BaseException:
    import pickle
from ctypes import *
from ctypes import Array
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

from collections import OrderedDict
from utils.compat_util import *
from verbosity import *
from debug_encode import read_pen
import ifcscli_util


FIELD_NAME_MAX_LENGTH = 48
PEN_NAME_MAX_LENGTH = 48

#------------------------------------------
# ---- UTILS ---- #


def get_pen_info(pen_id):
    """
        Get pen info
    """
    peninfo = ifcs_ctypes.pen_t()
    ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
    return peninfo

#------------------------------------------


def get_flds_from_pen_id(pen_id):
    """
        Get fields from pen id
    """
    peninfo = get_pen_info(pen_id)
    nflds = c_uint()
    nflds.value = peninfo.num_flds
    fldinfo = (ifcs_ctypes.pen_field_t * nflds.value)()
    try:
        ifcs_ctypes.node_get_pen_fields(
            0,
            pen_id,
            pointer(peninfo),
            byref(nflds),
            compat_pointer(fldinfo, ifcs_ctypes.pen_field_t))
    except Exception as ex:
        log(type(ex).__name__, ex.args)
    return nflds, fldinfo


#------------------------------------------

def get_flds_from_peninfo(pen_id, peninfo):
    """
        Get fields from peninfo
    """
    nflds = c_uint()
    nflds.value = peninfo.num_flds
    fldinfo = (ifcs_ctypes.pen_field_t * nflds.value)()
    rc = ifcs_ctypes.node_get_pen_fields(
        0,
        pen_id,
        pointer(peninfo),
        byref(nflds),
        compat_pointer(fldinfo, ifcs_ctypes.pen_field_t))
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Get PEN Fields Failed for Pen " + str(pen_id)
    return nflds, fldinfo

#------------------------------------------


def get_fld_info(pen_id, fld):
    """
        Get field info
    """
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def get_fld_info_from_flds(nflds, fldinfo, pen_id, fld):
    """
        Get field info from fields
    """
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            return fldinfo[j]
    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def get_fld_width(nflds, fldinfo, pen_id, fld):
    """
        Get field width
    """
    fld_width = -1
    for j in range(nflds.value):
        if ((fldinfo[j].fname == fld)):
            fld_width = fldinfo[j].width
            break
    return fld_width

#------------------------------------------


def get_fld_val_from_fldlst(pen_id, fldlst, fld_id):
    """
        Get field value from field list
    """
    val = -1
    for fld in fldlst:
        if fld[0] == fld_id:
            val = fld[1]
            return val

    assert 0, "PEN " + str(pen_id) + ": Field " + str(fld) + " not found"

#------------------------------------------


def check_fld_present(pen_id, fld_id):
    """
        Check if the field is present
    """
    nflds, fldinfo = get_flds_from_pen_id(pen_id)
    for j in range(nflds.value):
        if (fldinfo[j].fname == fld_id):
            return 1
    return 0

#------------------------------------------


def convert_ctypes_array_to_list(array):
    """
        Convert ctypes list to python list
    """

    if not isinstance(array, Array):
        return array

    lst = list()
    for i in range(len(array)):
        lst.append(array[i])

    return lst

#------------------------------------------


def gen_fldlst_from_tentry(pen_id, nflds, fldinfo, entry, verbose):
    """
        Function to get field list from tentry length
    """

    fldlst = []

    for j in range(nflds.value):
        fld_str = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
        rc = ifcs_ctypes.node_get_pen_field_name(
            0, fldinfo[j].fname, fld_str, FIELD_NAME_MAX_LENGTH)
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for field id " + \
            str(fld_id)
        fld_str_val = compat_bytesToStr(fld_str.value)

        if (fldinfo[j].width <= 32):
            rd_val = c_uint(0)
            rc = ifcs_ctypes.tentry_get_item(
                0,
                pen_id,
                fldinfo[j].fname,
                ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,
                entry,
                pointer(rd_val))
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN " + \
                str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed"
            rdval = c_uint32(rd_val.value).value
            fldlst.append([fldinfo[j].fname, rdval])
            if verbose:
                log("    %s : 0x%X " % (fld_str_val, rdval))
        else:
            nbytes = compat_division((fldinfo[j].width + 7), 8)
            buf = (c_ubyte * nbytes)()
            rc = ifcs_ctypes.tentry_get_item(
                0,
                pen_id,
                fldinfo[j].fname,
                ifcs_ctypes.TENTRY_FLD_TYPE_ANY,
                entry,
                compat_pointer(buf, c_ubyte))
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN " + \
                str(pen_id) + ": Get Field " + str(fldinfo[j].fname) + " failed"
            fldlst.append([fldinfo[j].fname, buf])
            if verbose:
                log("    %s : " % (fld_str_val), [hex(i) for i in buf])

    return fldlst

#------------------------------------------


def get_fld_len(pen_id, fld_id):
    """
        Function to get field length
    """
    pen_str = c_char_p(b" " * PEN_NAME_MAX_LENGTH)
    fld_str = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)

    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, PEN_NAME_MAX_LENGTH)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    fld_info = get_fld_info(pen_id, fld_id)
    rc = ifcs_ctypes.node_get_pen_field_name(0, fld_id, fld_str, FIELD_NAME_MAX_LENGTH)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for field id " + str(fld_id)

    return fld_info.width

#------------------------------------------


def get_sfld_width(
        nflds,
        fldinfo,
        pen_id,
        pen_str,
        mfld,
        mfld_str,
        mk,
        prof,
        sfld,
        sfld_str):
    mfld_info = get_fld_info_from_flds(nflds, fldinfo, pen_id, mfld)
    if (mk == 1):
        mmk = cast(mfld_info.mk_profile, POINTER(ifcs_ctypes.mk_profile_list_t))
        for j in range(mmk[prof].num_fields):
            if (mmk[prof].fields[j].fname == sfld):
                return mmk[prof].fields[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + \
            ": Could not find field " + sfld_str.value + " in mk_id = " + str(prof)

    else:
        mepp = cast(mfld_info.ep_profile, POINTER(ifcs_ctypes.ep_profile_list_t))
        for j in range(mepp[prof].num_actions):
            if (mepp[prof].ep_profiles[j].fname == sfld):
                return mepp[prof].ep_profiles[j].width
        assert 0, "PEN " + pen_str.value + ", Field " + mfld_str.value + \
            ": Could not find field " + sfld_str.value + " in epp = " + str(prof)


#------------------------------------------

def debug_restore(fileName=None, ib_id_list=[], comp_id_list=[], internal=False, state=[]):
    """
        Function that takes an encoded file
        and converts to a human readable json.
    """

    # Check if the file exists.
    if not os.path.exists(fileName):
        log("File " + fileName + " not found")
        return

    log('Decoding the state dump {0}. This might take a while..'.format(fileName))

    # File found. Uncompress it
    cmd = "tar --no-same-owner -zxvf {}".format(fileName)
    os.system(cmd)

    # Form the fileName base
    fileName       = fileName.split(".tar.gz")[0].split('/')[-1]
    fileName_base  = fileName.split('stateDump_')[-1] + '.gz'
    fileName_untar = fileName.split('stateDump_')[-1]

    # Iterate and unzip all files corresponding to an IB
    ibs = []
    for ib in ib_id_list:
        ib_f  = str(ib) + '_' + fileName_base
        ib_f_ = str(ib) + '_' + fileName_untar

        # Check if the file exists
        if not os.path.exists(ib_f):
            continue

        # Unzip the file per ib
        try:
            cmd = "gunzip {}".format(ib_f)
            log("Unzipping state for ib {0} ..".format(str(ib)))
            os.system(cmd)
        except:
            continue

        # Restore the data per ib
        with open(ib_f_, "rb") as data:
            unpickled_data = data.read()
            if not unpickled_data:
                log("No data in file")
                return ifcs_ctypes.IFCS_INVAL

        # Close the file
        data.close()
        try:
            cmd = "rm {}".format(ib_f_)
            os.system(cmd)
        except Exception as e:
            log_err("When removing temporary file ( {} ):{}/{}".format(e, os.getcwd(), ib_f_))
            return

        # Restore the decompressed data
        state = pickle.loads(unpickled_data)

        # Form the outfile
        outFile = os.environ['HOME'] + '/stateRestore_' + ib_f_

        outFile = outFile + ".json"
        try:
            out_data = open(outFile, "w")
        except Exception as e:
            log("File Open error ( {} ):{}".format(e, outFile))
            return

        # Iterate and restore pens and fields with values
        pens = []
        for key, value in compat_iteritems(state[0]):

            is_tcam = False
            is_abb_tcam = False
            is_ilpm = False
            is_hash = False
            is_index = False
            is_indir = False
            is_pic = False

            # Get pen info
            index = int(key[0])
            pen_id = int(key[2])

            peninfo = get_pen_info(pen_id)

            if (len(comp_id_list) > 0) and (peninfo.cmpid not in comp_id_list):
                continue

            pen_name = c_char_p(b" " * PEN_NAME_MAX_LENGTH)
            rc = ifcs_ctypes.node_get_pen_name(
                0, int(pen_id), pen_name, PEN_NAME_MAX_LENGTH)
            assert rc == ifcs_ctypes.IFCS_SUCCESS, " Failed to get name for pen: " + \
                str(pen_id)
            pen_name_val = compat_bytesToStr(pen_name.value)

            # fill up a new entry
            entry = ifcs_ctypes.tentry_new(pen_id, -1, -1)
            for i in range(len(entry.contents.buf)):
                entry.contents.buf[i] = value[i]

            # Get the fields info
            nflds, fldinfo = get_flds_from_peninfo(pen_id, peninfo)
            fldlst = gen_fldlst_from_tentry(pen_id, nflds, fldinfo, entry, 0)

            # Get pen types
            if (peninfo.flags & ifcs_ctypes.PEN_TYPE_TCAM):
                is_tcam = True
            elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_ABB_TCAM):
                is_abb_tcam = True
            elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_ILPM):
                is_ilpm = True
                slot = int(key[1])
                bucket = (index - slot) >> 8
            elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_HASH):
                is_hash = True
                slot = int(key[1][0])
                bucket = int(key[1][1])
                function = (index - slot - (bucket << 8)) >> 28
            elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_INDEX or not peninfo.flags):
                is_index = True
            if (peninfo.flags & ifcs_ctypes.PEN_ACCESS_INDIR):
                is_indir = True
            if (peninfo.cmpid == 16):
                is_pic = True
                pic_index = int(key[1])
                pic_index = ((pic_index - ib) >> 4)

            # Fill up the pen fields
            pen = {}
            if is_indir and (is_tcam or is_abb_tcam):
                pen['NAME'] = pen_name_val
                pen['PENID'] = pen_id
                pen['INDEX'] = index
                pen['TYPE'] = 'TCAM'
                pen['COMP'] = peninfo.cmpid

                fldlst_print = []

                for fld_num in range(0, nflds.value):
                    field = fldlst[fld_num]
                    fld_id = field[0]
                    fld_val = field[1]

                    fld_val = convert_ctypes_array_to_list(field[1])
                    fld_name = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
                    rc = ifcs_ctypes.node_get_pen_field_name(
                        0, fld_id, fld_name, FIELD_NAME_MAX_LENGTH)
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field: " + \
                        str(fld_id)
                    fld_name_val = compat_bytesToStr(fld_name.value)

                    fld_print = {}
                    fld_print['NAME'] = fld_name_val
                    fld_print['FIELDID'] = fld_id
                    fld_print['VALUE'] = fld_val
                    fldlst_print.append(fld_print)

                pen['FIELDS'] = fldlst_print
                try:
                    tcam_index = c_uint(0)
                    tcam_index.value = index
                    rc = ifcs_ctypes.node_isn_pen_tcam_cmd(0, int(ib), pen_id, ifcs_ctypes.ISN_CMD_TCAM_WRITE, byref(tcam_index), entry)
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("node isn_pen tcam cmd write failed " + ifcscli_util.convert_error_code_to_string(rc))
                except Exception as e:
                    log("File Open error (", e, "):")
                    return

            elif is_ilpm:
                pen['NAME'] = pen_name_val
                pen['PENID'] = pen_id
                pen['INDEX'] = index
                pen['COMP'] = peninfo.cmpid
                pen['TYPE'] = "ILPM"
                pen['SLOT'] = slot
                pen['BUCKET'] = bucket

                fldlst_print = []

                for fld_num in range(0, nflds.value):
                    field = fldlst[fld_num]
                    fld_id = field[0]
                    fld_val = field[1]

                    fld_val = convert_ctypes_array_to_list(field[1])

                    fld_name = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
                    rc = ifcs_ctypes.node_get_pen_field_name(
                        0, fld_id, fld_name, FIELD_NAME_MAX_LENGTH)
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field: " + \
                        str(fld_id)
                    fld_name_val = compat_bytesToStr(fld_name.value)

                    fld_print = {}
                    fld_print['NAME'] = fld_name_val
                    fld_print['FIELDID'] = fld_id
                    fld_print['VALUE'] = fld_val
                    fldlst_print.append(fld_print)

                pen['FIELDS'] = fldlst_print
                bktmd      = c_uint(0)
                hash_index = c_uint(0)
                hash_index.value = index
                hash_cmd = ifcs_ctypes.ISN_CMD_HASH_WRITE
                try:
                    rc = ifcs_ctypes.node_isn_pen_ilpm_cmd(0, int(ib), pen_id, hash_cmd, byref(hash_index), byref(bktmd), entry)
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("node isn_pen ilpm_cmd write failed " + ifcscli_util.convert_error_code_to_string(rc))
                except Exception as e:
                    log("File Open error (", e, "):")
                    return

            elif is_hash:
                pen['NAME'] = pen_name_val
                pen['PENID'] = pen_id
                pen['INDEX'] = index
                pen['COMP'] = peninfo.cmpid
                pen['TYPE'] = "HASH"
                pen['FUNCTION'] = function
                pen['BUCKET'] = bucket
                pen['SLOT'] = slot

                fldlst_print = []

                for fld_num in range(0, nflds.value):
                    field = fldlst[fld_num]
                    fld_id = field[0]
                    fld_val = field[1]

                    fld_val = convert_ctypes_array_to_list(field[1])

                    fld_name = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
                    rc = ifcs_ctypes.node_get_pen_field_name(
                        0, fld_id, fld_name, FIELD_NAME_MAX_LENGTH)
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field: " + \
                        str(fld_id)
                    fld_name_val = compat_bytesToStr(fld_name.value)

                    fld_print = {}
                    fld_print['NAME'] = fld_name_val
                    fld_print['FIELDID'] = fld_id
                    fld_print['VALUE'] = fld_val
                    fldlst_print.append(fld_print)

                pen['FIELDS'] = fldlst_print
                bktmd      = c_uint(0)
                hash_index = c_uint(0)
                hash_index.value = index
                hash_cmd = ifcs_ctypes.ISN_CMD_HASH_WRITE
                hash_fn    = 0
                try:
                    rc = ifcs_ctypes.node_isn_pen_hash_cmd(0, int(ib), pen_id, hash_cmd, hash_fn, byref(hash_index), byref(bktmd), entry)
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("node isn_pen hash_cmd write failed " + ifcscli_util.convert_error_code_to_string(rc))
                except Exception as e:
                    log("File Open error (", e, "):")
                    return


            elif is_pic:
                pen['NAME'] = pen_name_val
                pen['PENID'] = pen_id
                pen['PIC'] = pic_index
                pen['INDEX'] = index
                pen['COMP'] = peninfo.cmpid
                pen['TYPE'] = "PIC"

                fldlst_print = []

                for fld_num in range(0, nflds.value):
                    field = fldlst[fld_num]
                    fld_id = field[0]
                    fld_val = field[1]

                    fld_val = convert_ctypes_array_to_list(field[1])

                    fld_name = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
                    rc = ifcs_ctypes.node_get_pen_field_name(
                        0, fld_id, fld_name, FIELD_NAME_MAX_LENGTH)
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field: " + \
                        str(fld_id)
                    fld_name_val = compat_bytesToStr(fld_name.value)

                    fld_print = {}
                    fld_print['NAME'] = fld_name_val
                    fld_print['FIELDID'] = fld_id
                    fld_print['VALUE'] = fld_val
                    fldlst_print.append(fld_print)

                pen['FIELDS'] = fldlst_print
                rc = ifcs_ctypes.node_isn_pen_write(0, ifcs_ctypes.PIC_IB(ib, pic_index), pen_id, index, 0, entry)
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("node isn_pen write failed " + ifcscli_util.convert_error_code_to_string(rc))

            else:
                pen['NAME'] = pen_name_val
                pen['PENID'] = pen_id
                pen['INDEX'] = index
                pen['TYPE'] = "DIRECT"
                pen['COMP'] = peninfo.cmpid

                fldlst_print = []

                for fld_num in range(0, nflds.value):
                    field = fldlst[fld_num]
                    fld_id = field[0]
                    fld_val = field[1]

                    fld_val = convert_ctypes_array_to_list(field[1])

                    fld_name = c_char_p(b" " * FIELD_NAME_MAX_LENGTH)
                    rc = ifcs_ctypes.node_get_pen_field_name(
                        0, fld_id, fld_name, FIELD_NAME_MAX_LENGTH)
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field: " + \
                        str(fld_id)
                    fld_name_val = compat_bytesToStr(fld_name.value)

                    fld_print = {}
                    fld_print['NAME'] = fld_name_val
                    fld_print['FIELDID'] = fld_id
                    fld_print['VALUE'] = fld_val
                    fldlst_print.append(fld_print)

                    pen['FIELDS'] = fldlst_print
                try:
                    rc = ifcs_ctypes.node_isn_pen_write(0, int(ib), pen_id, index, 0, entry)
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("node isn_pen write failed " + ifcscli_util.convert_error_code_to_string(rc))
                except Exception as e:
                    log("File Open error (", e, "):")
                    return


            # Fill up the pens list and free the entry
            ifcs_ctypes.tentry_free(entry)
            pens.append(pen)
            del pen

        # Fill up the ibs list with pens
        ibs.append(pens)
        del pens

    log("Writing to file " + outFile + " ..")
    json.dump(ibs, out_data, indent=4)
    out_data.close()
    return


# ------------------------------------------------------

#-----------------------------------------------------------------------


def main():
    debug()


if __name__ == "__main__":
    debug()
