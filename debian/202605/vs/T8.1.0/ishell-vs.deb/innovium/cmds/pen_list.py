#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

per_port_pens = {
    "DTM-ACM" : [
        ("dtm_ia_state_0",34,"NO"),
        ("dtm_ia_state_1",34,"NO"),
        ("dtm_ia_state_2",34,"NO"),
        ("dtm_port_discard_pkt_ib_%(ib)s",1, "YES"),
        ("dtm_port_discard_ib_%(ib)s",1,"YES"),
        ("dtm_ea_port_discard",34,"NO"),
        ("dtm_ea_port_red_discard",34,"NO"),
        ("dtm_ea_port_green_discard",34,"NO"),
        ("dtm_ea_port_yellow_discard",34,"NO"),
        ("dtm_ea_port_cnt",34,"NO"),
        ("dtm_ea_port_max_cnt",34,"NO"),
        ],
    "BAM" : [
        ("bam_debug_dia_frm_count",1,"NO"),
        ("bam_debug_dia_bad_frm_count",1,"NO"),
        ("bam_debug_dia_cell_count",1,"NO"),
        ("bam_debug_ifc_frm_count",1,"NO"),
        ("bam_debug_ifc_bad_frm_count",1,"NO"),
        ("bam_dia_supp_count",1,"NO"),
        ],
}

global_pens = {
    "IFC" : [
        ("ifc_counter_sop_packet_in", 1, "NO"),
        ("ifc_counter_sop_drop_packet_out", 1, "NO"),
        ("ifc_counter_sop_nondrop_packet_out", 1, "NO"),
        ("ifc_counter_eop_nondrop_packet_out", 1, "NO"),
        ],
    "ESB" : [
        ("pic_access_mirror_dbg", 1, "NO"),
        ("pic_access_mirror_drop_dbg", 1, "NO"),
        ("pic_access_sop_drop_dbg", 1, "NO")
        ],
}

per_ib_pens = {
    "DTM-ACM" : [
        ("dtm_ia_ib_count",1,"NO"),
        ("dtm_ia_port_empty_ib_%(ib)s",1,"YES"),
        ],
    "BAM-ACM" : [
        ("bam_ia_ib_count",1,"NO"),
        ],
    "BAM" : [
        ("bam_debug_pic%(ib)s_frm_count",1,"YES"),
        ("bam_debug_pic%(ib)s_bad_frm_count",1,"YES"),
        ("bam_debug_dia_frm_count",1,"NO"),
        ("bam_debug_dia_bad_frm_count",1,"NO"),
        ("bam_debug_dia_cell_count",1,"NO"),
        ("bam_debug_ifc_frm_count",1,"NO"),
        ("bam_debug_ifc_bad_frm_count",1,"NO"),
        ("bam_debug_recirc_frm_count",1,"NO"),
        ("bam_debug_recirc_bad_ecc_frm_count",1,"NO"),
        ("bam_debug_recirc_byte_count",1,"NO"),
        ],
    "DTM" : [
        ("dtm_acm_pkt_cnt",1,"NO"),
        ("dtm_acm_maxpkt_cnt",1,"NO"),
        ("dtm_lp_cgq_stat",6,"NO"),
        ("dtm_hp_cgq_stat0",6,"NO"),
        ("dtm_hp_cgq_stat1",6,"NO"),
        ("dtm_cgq_drop_stat",1,"NO"),
        ("dtm_drop_stat0",1,"NO"),
        ("dtm_drop_stat1",1,"NO"),
        ("dtm_power_drop_stat0",1,"NO"),
        ("dtm_power_drop_stat1",1,"NO"),
        ("dtm_debug002",1,"NO"),
        ("dtm_debug003",1,"NO"),
        ("dtm_debug004",1,"NO"),
        ("dtm_debug005",1,"NO"),
        ("dtm_debug006",1,"NO"),
        ("dtm_debug007",1,"NO"),
        ("dtm_debug008",1,"NO"),
        ("dtm_debug009",1,"NO"),
        ],
    "DIA" : [
        ("dia_pyld_queue_levels",50,"NO"),
        ("dia_ctrl_queue_levels",50,"NO"),
        ("dia_rec_cell_cntr_sibp0",1,"NO"),
        ("dia_rec_cell_cntr_sibp1",1,"NO"),
        ("dia_rec_cell_cntr_sibp2",1,"NO"),
        ("dia_rec_cell_cntr_sibp3",1,"NO"),
        ("dia_rec_cell_cntr_sibp4",1,"NO"),
        ("dia_rec_cell_cntr_sibp5",1,"NO"),
        ("dia_rec_cell_cntr_sibp6",1,"NO"),
        ("dia_rec_cell_cntr_sibp7",1,"NO"),
        ("dia_rec_cell_cntr_sibp8",1,"NO"),
        ("dia_rec_cell_cntr_sibp9",1,"NO"),
        ("dia_rec_cell_cntr_sibp10",1,"NO"),
        ("dia_rec_cell_cntr_sibp11",1,"NO"),
        ("dia_rec_cell_cntr_sibp12",1,"NO"),
        ("dia_rec_cell_cntr_sibp13",1,"NO"),
        ("dia_rec_cell_cntr_sibp14",1,"NO"),
        ("dia_rec_cell_cntr_sibp15",1,"NO"),
        ("dia_rec_cell_cntr_sibp16",1,"NO"),
        ("dia_rec_cell_cntr_sibp17",1,"NO"),
        ("dia_rec_cell_cntr_sibp18",1,"NO"),
        ("dia_rec_cell_cntr_sibp18",1,"NO"),
        ("dia_rec_cell_cntr_sibp19",1,"NO"),
        ("dia_rec_cell_cntr_sibp20",1,"NO"),
        ("dia_rec_cell_cntr_sibp21",1,"NO"),
        ("dia_rec_cell_cntr_sibp22",1,"NO"),
        ("dia_rec_cell_cntr_sibp23",1,"NO"),
        ("dia_rec_cell_cntr_sibp24",1,"NO"),
        ("dia_rec_cell_cntr_sibp25",1,"NO"),
        ("dia_rec_cell_cntr_sibp26",1,"NO"),
        ("dia_rec_cell_cntr_sibp27",1,"NO"),
        ("dia_rec_cell_cntr_sibp28",1,"NO"),
        ("dia_rec_cell_cntr_sibp29",1,"NO"),
        ("dia_rec_cell_cntr_sibp30",1,"NO"),
        ("dia_rec_cell_cntr_sibp31",1,"NO"),
        ("dia_rec_cell_cntr_sibp32",1,"NO"),
        ("dia_output_cell_cntr",1,"NO"),
        ("dia_output_pkt_cntr",1,"NO"),
        ("dia_output_pkt_w_err_cntr",1,"NO"),
        ],
}

per_partition_pens = {
    "DTM-ACM" : [
        ("dtm_ia_event_partition_shared_low_%(partition)s",1,"YES"),
        ("dtm_ia_event_partition_shared_high_%(partition)s",1,"YES"),
        ("dtm_ia_event_partition_inflight_low_%(partition)s",1,"YES"),
        ("dtm_ia_event_partition_inflight_high_%(partition)s",1,"YES"),
        ("dtm_ia_partition_count_%(partition)s",1,"YES"),
        ],
    "BAM-ACM" : [
        ("bam_ia_event_partition_shared_low_%(partition)s",1,"YES"),
        ("bam_ia_event_partition_shared_high_%(partition)s",1,"YES"),
        ("bam_ia_event_partition_inflight_low_%(partition)s",1,"YES"),
        ("bam_ia_event_partition_inflight_high_%(partition)s",1,"YES"),
        ("bam_ia_partition_count_%(partition)s",1,"YES"),
        ],
}

per_queue_pens = {
    "DTM-ACM" : [
        ("dtm_ea_state",81,"NO"),
        ("dtm_ea_stats",81,"NO"),
        ],
}

ib_pen_read_cmd='''
pen read ib %(ib)s %(pen_name)s %(idx)s
'''
