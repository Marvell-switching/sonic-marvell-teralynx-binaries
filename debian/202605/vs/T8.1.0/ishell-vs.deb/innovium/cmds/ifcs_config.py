#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import os
import sys
import importlib
import netaddr
from utils.compat_util import *
from verbosity import *
import yaml
from collections import OrderedDict
import lib.database as db_util
from utils.ifcsIP import convertIpv6InttoTuple
from utils.mac_util import get_ctype_arr
from utils.mac_util import convertMacstrtoarr

try:
    import yamlloader
except ImportError:
    try:
        import yamlordereddictloader
    except ImportError:
        log_dbg(1, "No YAML Loader found to import. ifcs config command will not work.")

try:
    import _pickle as pickle
except ImportError:
    import pickle

try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

# Store crud ops as {crud: [{api_class_name: {api_class_obj: {[instance_name: attr_val_obj], }}}], }
class KeyValueList():
    '''
    '''
    def __init__(self):
        self.key = None
        self.value = []


    def add(self, key, value):
        self.key = key
        self.value.append(value)

    def clear(self):
        self.key = None
        self.value = []

    def items(self):
        return (self.key, self.value)

class KeyValue():
    '''
    '''
    def __init__(self):
        self.key = None
        self.value = None


    def add(self, key, value):
        self.key = key
        self.value = value

    def clear(self):
        self.key = None
        self.value = None

    def items(self):
        return (self.key, self.value)

class Instance(KeyValue):
    '''
    '''
    def __init__(self):
        super().__init__()

        # Attr values that need substitution
        self.val_proc_keys = {}
        self.value_subs = {}


class Api(KeyValueList):
    '''
    '''
    def __init__(self):
        super().__init__()

class ApiName(KeyValue):
    '''
    '''
    def __init__(self):
        super().__init__()

class Crud(KeyValueList):
    '''
    '''
    def __init__(self):
        super().__init__()


class IfcsConfig():
    '''
    '''

    def __init__(self, cli):
        self.cli = cli
        self.node_id = self.cli.node_id
        self.db = None
        self.yaml_data = None
        self.obj_instances = OrderedDict()
        self.api_class_objs = OrderedDict()
        self.crud_ops_dict = OrderedDict()
        self.crud_ops = OrderedDict()

        self.darr_size = 100000


        # Created objects
        self.api_objs = OrderedDict()
        self.darr_idx = -1

        self.darr = [None] * self.darr_size

        # Get the directory where ifcs_config.py is located
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        # Now use it to construct paths relative to this file
        self.obj_db_path = os.path.join(self.script_dir, '../lib/objDB.pkl')

    def _init_module(self, args):
        self.obj_instances.clear()
        self.api_class_objs.clear()
        self.crud_ops_dict.clear()
        self.crud_ops.clear()
        self.api_objs = OrderedDict()

        try:
            # Load the object database
            log_dbg(2, "Loading Object datase pickle file")
            fd = open(self.obj_db_path, 'rb')

            self.db = pickle.load(fd)

            # ifcs module - for base types
            self.ifcs_mod_db = self.db.modules()['ifcs']

            objDB_file = ''
            file_path = args[0]
            # Load the config yaml
            log_dbg(2, "Loading user config file")
            fd = open(file_path, 'r')
            if "yamlloader" in sys.modules:
                self.yaml_data = yaml.load(
                    fd, Loader=yamlloader.ordereddict.CSafeLoader)
            else:
                self.yaml_data = yaml.load(fd,
                                           Loader=yamlordereddictloader.Loader)

            self._get_api_class_obj()
        except Exception as ex:
            log_dbg(1, "Exception in _init_module: {}".format(sys.exc_info()))
            log_err("Error initializing module: {}".format(ex))
            raise ex

    def _validate_config_yaml_member_section(self, member_part, oper, api_class,
                                             obj_inst, mbr_name):
        '''
        Validate member name schema for user provided config yaml
        '''
        log_dbg(1, "Invoking validate_schema - member name section {}...".format(mbr_name))
        # Keys under Operation -> API class name -> API class object instance -> Member name
        # Keys must be API class name(s) and optionally attribute
        obj_fields = compat_listkeys(member_part)
        min_obj_field_count = 2 if "attributes" in obj_fields else 1
        if len(obj_fields) < min_obj_field_count:
            raise TypeError(
                "Value for operation ({}) -> API Class ({}) -> Instance ({}) -> Member name ({}) must have API Class name and optionally attributes as keys"
                .format(oper, api_class, obj_inst, mbr_name))
        for obj_field in obj_fields:
            if obj_field == "attributes" and member_part[obj_field] is None:
                # attributes can be empty
                continue
            if not isinstance(member_part[obj_field], dict):
                raise TypeError(
                    "Value for operation ({}) -> API Class ({}) -> Instance ({}) -> Member name ({}) -> {} is not a Mapping/dictionary"
                    .format(
                        oper, api_class, obj_inst, mbr_name,
                        obj_field if obj_field == "attributes" else
                        "API Class ({})".format(obj_field)))

        # Operation -> API class name -> API class object instance -> Member name -> attributes is not validated further
        if "attributes" in obj_fields:
            obj_fields.remove("attributes")

        # Operation -> API class name -> API class object instance -> Member name -> API class name
        for mbr_api_class in obj_fields:  # Only one API class name though.
            # API class name is not validated
            # Operation -> API class name -> API class object instance -> Member name -> API class name -> API class object instance
            for mbr_obj_inst in member_part[mbr_api_class].keys():
                if not isinstance(member_part[mbr_api_class][mbr_obj_inst],
                                  dict):
                    raise TypeError(
                        "Value for operation ({}) -> API Class ({}) -> Instance ({}) -> Member name ({}) -> API Class ({}) -> Instance ({}) is not a Mapping/dictionary"
                        .format(oper, api_class, obj_inst, mbr_name,
                                mbr_api_class, mbr_obj_inst))
                if mbr_obj_inst in ["identifier", "attributes"]:
                    raise TypeError(
                        "Invalid instance name ({}) for operation ({}) -> API Class ({}) -> Instance ({}) -> Member name ({}) -> API Class ({})"
                        .format(mbr_obj_inst, oper, api_class, obj_inst,
                                mbr_name, mbr_api_class))

                # Keys under Operation -> API class name -> API class object instance -> Member name -> API class name -> API class object instance
                mbr_obj_fields = compat_listkeys(
                    member_part[mbr_api_class][mbr_obj_inst])
                for mbr_obj_field in mbr_obj_fields:
                    if mbr_obj_field not in ["identifier"]:
                        raise TypeError(
                            "Invalid key {} for operation ({}) -> API Class ({}) -> Instance ({}) -> Member name ({}) -> API Class ({}) -> Instance ({}). Valid key is identifier"
                            .format(mbr_obj_field, oper, api_class, obj_inst,
                                    mbr_name, mbr_api_class, mbr_obj_inst))
                # Operation -> API class name -> API class object instance -> Member name -> API class name -> API class object instance -> identifier value is not validated

    def validate_config_yaml(self, args):
        '''
        Validate schema for user provided config yaml
        '''
        log_dbg(1, "Invoking validate_schema...")
        try:
            yaml_file = args[0]
            with open(yaml_file, "r") as f:
                if "yamlloader" in sys.modules:
                    ydata = yaml.load(f,
                                      Loader=yamlloader.ordereddict.CSafeLoader)
                else:
                    ydata = yaml.load(f, Loader=yamlordereddictloader.Loader)
        except yaml.YAMLError as ye:
            log_dbg(1, "Error loading YAML file : {}".format(sys.exc_info()))
            log_err("Error loading YAML file {}: {}".format(yaml_file, ye))
            return ifcs_ctypes.IFCS_INVAL
        except Exception as e:
            log_dbg(1, "Error processing YAML file : {}".format(sys.exc_info()))
            log_err("Error processing YAML file {}: {}".format(yaml_file, e))
            return ifcs_ctypes.IFCS_INVAL

        try:
            if not isinstance(ydata, dict):
                raise TypeError("YAML document is not a Mapping/dictionary")
            # Oper
            for oper in ydata.keys():
                if oper not in ["create", "set", "delete", "member_add", "member_remove"]:
                    raise TypeError(
                        "Invalid operation {} in top level. Valid keys are create, set, delete, member_add, and member_remove"
                        .format(oper))
                if not isinstance(ydata[oper], dict):
                    raise TypeError(
                        "Value for operation ({}) is not a Mapping/dictionary".
                        format(oper))

                # Operation -> API class name
                for api_class in ydata[oper].keys():
                    # API class name is not validated
                    if not isinstance(ydata[oper][api_class], dict):
                        raise TypeError(
                            "Value for operation ({}) -> API Class ({}) is not a Mapping/dictionary"
                            .format(oper, api_class))

                    # Operation -> API class name -> API class object instance
                    for obj_inst in ydata[oper][api_class].keys():
                        if not isinstance(ydata[oper][api_class][obj_inst],
                                          dict):
                            raise TypeError(
                                "Value for operation ({}) -> API Class ({}) -> Instance ({}) is not a Mapping/dictionary"
                                .format(oper, api_class, obj_inst))
                        if obj_inst in ["identifier", "attributes"]:
                            raise TypeError(
                                "Invalid instance name ({}) for operation ({}) -> API Class ({})"
                                .format(obj_inst, oper, api_class))

                        # Keys under Operation -> API class name -> API class object instance
                        obj_fields = compat_listkeys(
                            ydata[oper][api_class][obj_inst])
                        # For member add and remove cannot validate here as member name is not validated
                        if oper not in ["member_add", "member_remove"]:
                            for obj_field in obj_fields:
                                if obj_field not in ["identifier", "attributes"]:
                                    raise TypeError(
                                        "Invalid key {} for operation ({}) -> API Class ({}) -> Instance ({}). Valid keys are identifier and attributes"
                                        .format(obj_field, oper, api_class,
                                                obj_inst))
                                # identifier is not validated
                                # Limited validation for attributes
                                if obj_field == "attributes" and ydata[oper][api_class][obj_inst][obj_field] is None:
                                    # attributes can be empty
                                    continue
                                if obj_field == "attributes" and not isinstance(ydata[oper][api_class][obj_inst][obj_field], dict):
                                    raise TypeError(
                                        "Value for operation ({}) -> API Class ({}) -> Instance ({}) -> attributes is not a Mapping/dictionary"
                                        .format(oper, api_class, obj_inst))
                        # Required keys under Operation -> API class name -> API class object instance
                        reqd_fields = {
                            "create": ["identifier"],
                            "set": ["identifier", "attributes"],
                            "delete": ["identifier"],
                            "member_add": ["identifier"],
                            "member_remove": ["identifier"]
                        }
                        for field in reqd_fields[oper]:
                            if field not in obj_fields:
                                raise TypeError(
                                    "Required key {} is missing for operation ({}) -> API Class ({}) -> Instance ({})"
                                    .format(field, oper, api_class, obj_inst))

                        # Operation -> API class name -> API class object instance -> Member name is validated
                        if oper in ["member_add", "member_remove"]:
                            for mbr_name in obj_fields:
                                if mbr_name == "identifier":
                                    # identifier value not validated
                                    continue
                                if mbr_name == "attributes":
                                    # attributes is not a valid member name
                                    raise TypeError(
                                        "Invalid Member name ({}) for operation ({}) -> API Class ({}) -> Instance ({})"
                                        .format(mbr_name, oper, api_class,
                                                obj_inst))
                                if not isinstance(ydata[oper][api_class][obj_inst][mbr_name], dict):
                                    raise TypeError(
                                        "Value for operation ({}) -> API Class ({}) -> Instance ({}) -> Member name ({}) is not a Mapping/dictionary"
                                        .format(oper, api_class, obj_inst,
                                                mbr_name))
                                self._validate_config_yaml_member_section(
                                    ydata[oper][api_class][obj_inst][mbr_name],
                                    oper, api_class, obj_inst, mbr_name)
        except TypeError as te:
            log_dbg(1, "Error validating YAML: {}".format(sys.exc_info()))
            log_err("Error validating YAML: {}".format(te))
            return ifcs_ctypes.IFCS_INVAL
        except Exception as ex:
            log_dbg(1, "Unexpected Error validating YAML: {}".format(sys.exc_info()))
            log_err("Unexpected Error validating YAML: {}".format(ex))
            return ifcs_ctypes.IFCS_INVAL
        return ifcs_ctypes.IFCS_SUCCESS

    def _toCamelCase(self, s, capFirst = False):
        s_split = s.split('_')
        out = s_split[0]
        if capFirst == True:
            out = out.capitalize()
        for elem in s_split[1:]:
            out += elem.capitalize()
        return out

    def _get_ifcs_prop_var_name(self, type):
        #if type.ref:
        #    return self.get_ifcs_prop_var_name(type.type)
        if 'ifcs_handle_t' in type.ctype:
            return "handle"
        elif 'ifcs_handle_list_t' in type.ctype:
            return "handle_list"
        elif 'ifcs_mac_t' in type.ctype:
            return "mac"
        elif 'ifcs_bool_t' in type.ctype:
            return "data"
        elif 'ifcs_ip_address_t' in type.ctype:
            return "ip_addr"
        elif 'ifcs_fwd_policy_t' in type.ctype:
            return "fwd_policy"
        elif 'ifcs_ctc_policy_t' in type.ctype:
            return "ctc_policy"
        elif 'ifcs_traffic_monitor_policy_t' in type.ctype:
            return "traffic_monitor_policy"
        elif 'ifcs_packet_action_t' in type.ctype:
            return "pkt_action"
        elif 'uint16' in type.ctype:
            return "u16"
        elif 'uint32' in type.ctype or 'uint32' in type.name or type.enum:
            return "u32"
        elif 'uint64' in type.ctype or type.enum:
            return "u64"
        elif 'uint8' in type.ctype or 'char' in type.ctype:
            return "u8"
        else:
            #return 'custom_data'
            return type.name


    def _get_prop_obj(self, attr_name, prop_obj_list):
        log_dbg(2, "_get_prop_obj ..." )

        for prop_obj in prop_obj_list:
            if attr_name == prop_obj.name:
                return prop_obj

    def _is_singleton_api_class(self, api_class_obj):
        '''
        API classes such as node and linkscan use node_id only (no handle/key).
        id-space: "no" and no key properties in codegen.
        '''
        return api_class_obj.id_space == 'no' and not api_class_obj.has_key()

    def _get_api_class_obj(self):
        log_dbg(1, "Invoking _api_class_obj...")

        for mod,mod_obj in self.db.modules().items():
            for api_obj in mod_obj.pi_objects():
                self.api_class_objs[api_obj.name] = api_obj

    def _get_key_mbr_obj(self, key_obj, name):
        '''
        Find the key member name
        '''
        log_dbg(1, "Invoking _get_key_mbr_obj...")
        name_list = name.split('.')
        if len(name_list) > 1:
            # Use until last but one
            key_names = name_list[:-1]
        for x in key_names:
            key_obj = getattr(key_obj, x)

        return (key_obj, name_list[-1])


    def _process_key_val_sub(self, api_name_obj, instance_obj, crud):
        '''
        Process any attr value substitutions
        '''
        log_dbg(1, "Invoking _process_key_val_sub...")
        api_class_obj =  self.api_class_objs[api_name_obj.key]

        try:
            for name ,val in instance_obj.val_proc_keys.items():


                key_obj = getattr(instance_obj.value[1], 'key')
                # Get the key member obj
                key_val_tup = self._get_key_mbr_obj(key_obj, name)

                handle_val = self.api_objs[val]
                setattr(key_val_tup[0], key_val_tup[1], handle_val)

        except Exception as ex:
            log_dbg(
                1,
                "Exception in _process_key_val_sub: {}".format(sys.exc_info()))
            log_err("Key value substitution failed: {}".format(ex))
            assert(0)

    def _process_mbr_val_sub(self, api_class_obj, instance_obj, crud):
        '''
        Process any attr value substitutions
        '''
        log_dbg(1, "Invoking _process_mbr_val_sub...")
        mbr_list_p_idx = 2 if self._is_singleton_api_class(api_class_obj) else 3
        for inst_name, mbr_inst_tuple in instance_obj.value_subs.items():
            mbr_inst_name = mbr_inst_tuple[0]
            crud = mbr_inst_tuple[1]
            idx = mbr_inst_tuple[2]
            if idx is None:
                match_name_str = mbr_inst_name = mbr_inst_tuple[0]
            else:
                match_name_str = inst_name
            log_dbg(2, "inst_name: {} mbr_inst_name: {}".format(inst_name, match_name_str))

            # Look up the value for mbr_inst_name - it should be a handle already created
            found = False
            for api_obj_inst_name, api_obj_inst_val in self.api_objs.items():
                if api_obj_inst_name == match_name_str:
                    log_dbg(3, "Found the handle for match_name_str: {}, handle: {}"
                            .format(match_name_str, hex(api_obj_inst_val)))
                    handle_val = api_obj_inst_val
                    found = True
                    break

            if found == False:
                log_err("Unable to find handle for instance: {}".format(match_name_str))
                assert(0)

            # If idx is None, we are dealing with API class instance
            if idx is None:
                if not self._is_singleton_api_class(api_class_obj):
                    instance_obj.value[1] = handle_val
            else:
                # If idx is not None, we are dealing with a member of an API class instance
                # Replace the appropriate member of the API class instance with the handle
                instance_obj.value[mbr_list_p_idx][idx] = handle_val


    def _process_attr_val_sub(self, api_name_obj, instance_obj, crud):
        '''
        Process any attr value substitutions
        '''
        log_dbg(1, "Invoking _process_attr_val_sub...")
        api_class_obj =  self.api_class_objs[api_name_obj.key]
        attr_list_p_idx = 2 if self._is_singleton_api_class(api_class_obj) else 3

        try:
            for prop_name ,val in instance_obj.value_subs.items():
                # Match the attr that needs value substitution
                attr_val_obj = val[0]
                prop_obj = val[1]
                name = val[2]
                log_dbg(3, "\nname: {} \n val: {}\n ".format(name, val))

                attr_name_str = "IFCS_{}_ATTR_{}".format(api_name_obj.key.upper(), prop_obj.name.upper())
                attr_id = getattr(ifcs_ctypes, attr_name_str)
                attr_list_p = instance_obj.value[attr_list_p_idx]

                found = False
                for attr in attr_list_p:
                    # Find the right attr in attr_list_p to work with
                    if attr_id == attr.id:
                        found = True
                        break
                if found == False:
                    log_err("Unable to find attr {} for api class {}".format(attr_name_str, api_name_obj.key))
                    assert(0)

                # Check if there is a corresponding dirty member to handle
                dirty_mbr_name = '_dirty_' + prop_name
                if hasattr(attr_val_obj, dirty_mbr_name):
                    # Extract the setter method name
                    set_func_str = prop_obj.type.ctype + '_' + prop_name + '_set'
                    # Use the correspoding setter method
                    set_func = getattr(ifcs_ctypes, set_func_str)

                    if name not in self.api_objs:
                        log_err("Unable to find handle for instance: {}".format(name))
                        assert(0)
                    # Set the value
                    handle_val = self.api_objs[name]
                    set_func(compat_pointer(attr_val_obj, prop_obj.type.ctype), handle_val)

                    val_type_set_str = "ifcs_attr_t_value_" + prop_obj.type.name + "_set"
                    set_attr_func = getattr(ifcs_ctypes, val_type_set_str)
                    set_attr_func(compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attr_val_obj)

                else:
                    if name not in self.api_objs:
                        log_err("Unable to find handle for instance: {}".format(name))
                        assert(0)
                    # Set the value based on key or handle type API class
                    handle_val = self.api_objs[name]
                    set_attr_func = getattr(ifcs_ctypes, 'ifcs_attr_t_value_handle_set')
                    set_attr_func(compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), handle_val)

        except Exception as ex:
            log_dbg(
                1,
                "Exception in _process_attr_val_sub: {}".format(sys.exc_info()))
            if str(ex):
                log_err("Attribute value substitution failed: {}".format(ex))
            assert(0)

    def run_cmd(self, args):
        log_dbg(1, "Invoking run_cmd...")

        if len(args) == 0:
            log_err("Missing file path")
            return ifcs_ctypes.IFCS_INVAL

        # Validate the input yaml against the schema
        rc = self.validate_config_yaml(args)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            return rc

        self._init_module(args)

        # Parse the config yaml
        try:
            self.parse_config_yaml(args)
        except Exception as ex:
            log_dbg(1,
                    "Exception in parse_config_yaml: {}".format(sys.exc_info()))
            return ifcs_ctypes.IFCS_INVAL

        #Execute crud operations
        try:
            rc = self.execute_apis()
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                return rc
        except Exception as ex:
            log_dbg(1, "Exception in execute_apis: {}".format(sys.exc_info()))
            return ifcs_ctypes.IFCS_INVAL

        log("Configuration successful")
        return rc


    def execute_apis(self):
        '''
        Run crud operations sequentially
        crud ops as {crud: [{api_class_name: {api_class_obj: {[instance_name: attr_val_obj], }}}], }
        '''
        log_dbg(1, "Invoking execute_apis...")

        try:
            for crud, crud_objs in self.crud_ops.items():

                log_dbg(2, "Crud operation: %s" % crud)

                api_name_objs = crud_objs.value

                for api_name_obj in api_name_objs:
                    instances_obj = api_name_obj.value
                    api_func_ptr = api_name_obj.value.key
                    api_class_objs = {}

                    api_class_obj =  self.api_class_objs[api_name_obj.key]
                    for instance_obj in instances_obj.value:
                        log_dbg(2, "Instance name: %s" % instance_obj.key)

                        if crud in ['member_add', 'member_remove']:
                            self._process_mbr_val_sub(api_class_obj, instance_obj, crud)
                        else:
                            # Check and process any key value substitutions
                            if len(instance_obj.val_proc_keys) > 0:
                                self._process_key_val_sub(api_name_obj, instance_obj, crud)

                            # Check and process any attr value substitutions
                            if len(instance_obj.value_subs) > 0:
                                self._process_attr_val_sub(api_name_obj, instance_obj, crud)

                        # Build function param list
                        func_param = instance_obj.value

                        # Singleton APIs have no handle param, skip handle substitution
                        if not api_class_obj.has_key() and crud in ['set'] \
                                and not self._is_singleton_api_class(api_class_obj):
                            obj_id = self.obj_instances[instance_obj.key]
                            hdl_macro_name = "IFCS_HANDLE_{}".format(api_name_obj.key.upper())
                            handle_macro = getattr(ifcs_ctypes, hdl_macro_name)
                            func_param[1] = handle_macro(obj_id)

                        # Execute the IFCS API call
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(api_func_ptr(*func_param))
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                            err_str = compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))
                            log_err("CRUD op: {} failed for api class: {} instance: {}".format(crud, api_name_obj.key, instance_obj.key))
                            log_err("IFCS_STATUS_REASON: {}".format(err_str))
                            return rc

                        log_dbg(2, "{} {} operation successful...".format(instance_obj.key, crud))
                        if crud in ['create']:
                            # Singleton APIs use node_id as obj_id since no handle is returned
                            if self._is_singleton_api_class(api_class_obj):
                                obj_id = func_param[0]
                            elif api_class_obj.has_key() and api_class_obj.key_count() > 1:

                                obj_id = func_param[1].key
                            elif api_class_obj.key_count() == 1:
                                obj_id = func_param[1]
                            else:
                                # API class is handle
                                obj_id = func_param[1].contents.value

                            self.api_objs[instance_obj.key] = obj_id

        except Exception as ex:
            log_dbg(1, "Exception in execute_apis: {}".format(sys.exc_info()))
            if str(ex):
                log_err("API execution failed: {}".format(ex))
            assert(0)

        return rc

    def _get_mbr_type(self, mbr_name, prop_type):
        '''
        Get the type for the member
        '''
        log_dbg(1, "Invoking _get_mbr_type..." )

        for mbr in prop_type.members:
            if mbr.name == mbr_name:
                return mbr.type

    def _alloc_darr(self, darr_type, count):
        if self.darr_idx >= self.darr_size:
            log_err("Dynamic array store overflow")
            assert(0)

        self.darr_idx = self.darr_idx + 1
        self.darr[self.darr_idx] = (darr_type * count)()
        return self.darr[self.darr_idx]

    def _get_struct_attr_val(self, attr_val_obj, prop_name, attr_val, prop_type, prop_obj, api_obj, instance_obj):
        '''
        Recursively set the struct members with corresponding values
        '''
        log_dbg(1, "Invoking _get_struct_attr_val..." )
        log_dbg(3, "\n prop_name: {} \n prop_type: {} \n attr_val_obj: {} \n attr_val: {}\n ".format(prop_name,prop_type.ctype, attr_val_obj, attr_val))

        # Check if dyamic arr
        if prop_type.size == '-1':
            # Allocate memory for dynamic arr
            darr_obj = getattr(attr_val_obj, prop_name)
            darr_obj.count = len(attr_val)
            darr_type = getattr(ifcs_ctypes, prop_type.type.ctype)
            darr_obj.arr = (self._alloc_darr(darr_type, darr_obj.count))

            # If array size is 1, treat it a list of len 1
            if not isinstance(attr_val, list):
                attr_val = [attr_val]

            idx = 0
            # Start processing the values for dynamic array elements - they may be struct or union and simple or nested
            for darr_val_obj in attr_val:
                for darr_val_obj_name, darr_val_obj_val in darr_val_obj.items():
                    darr_ptype = self._get_mbr_type(darr_val_obj_name, prop_type.type)
                    darr_mbr_obj = getattr(darr_obj.arr[idx], darr_val_obj_name)

                    log_dbg(3, "Dynamic arr idx: {}".format(idx))
                    self._get_struct_attr_val(darr_obj.arr[idx], darr_val_obj_name, darr_val_obj_val, darr_ptype, prop_obj, api_obj, instance_obj)

                # Move the next element of the array
                idx =  idx +1

            return

        try:
            # For struct or union types, process each member - they may be struct or union and simple or nested
            if ((isinstance(prop_type, db_util.Type) and (prop_type.struct or prop_type.union)) or \
                    (isinstance(prop_type.type, db_util.Type) and (prop_type.type.struct or prop_type.type.union))):
                for mbr_name, mbr_val in attr_val.items():

                    mbr_type = prop_type
                    if prop_type.struct or prop_type.union:
                        mbr_type = self._get_mbr_type(mbr_name, prop_type)

                    attr_obj = attr_val_obj
                    if (prop_type.union or prop_type.struct) and hasattr(attr_val_obj, prop_name):
                        attr_obj = getattr(attr_val_obj, prop_name)

                    log_dbg(4, "\n mbr_name: {} \n mbr_val: {}\n mbr_type: {}\n".format(mbr_name, mbr_val, mbr_type.ctype))
                    self._get_struct_attr_val(attr_obj, mbr_name, mbr_val, mbr_type, prop_obj, api_obj, instance_obj)

            else:

                val_type_str = self._get_ifcs_prop_var_name(prop_type)

                if val_type_str == 'handle':

                    # Split handle type and value
                    val_hdl_name = attr_val.split(':')[0]
                    val_hdl_val  = attr_val.split(':')[1]

                    if val_hdl_name in ['self']:
                        # Handle value is a ref to another object's handle created
                        # as part of this config yaml, will resolve the value later
                        instance_obj.value_subs[prop_name] = (attr_val_obj, prop_obj, val_hdl_val)
                        attr_val = ifcs_ctypes.IFCS_NULL_HANDLE

                    else:
                        # Hex or int format
                        if '0x' in val_hdl_val:
                            val_hdl_val = int(val_hdl_val, 16)
                        else:
                            val_hdl_val = int(val_hdl_val, 10)

                        hdl_var_name = "IFCS_HANDLE_{}".format(val_hdl_name.upper())
                        attr_val = getattr(ifcs_ctypes, hdl_var_name)(val_hdl_val)

                dirty_mbr_name = '_dirty_' + prop_name
                if hasattr(attr_val_obj, dirty_mbr_name):
                    # Extract the setter method name
                    set_func_str = attr_val_obj.__str__().split()[0][20:-1] + 't_' + prop_name + '_set'

                    # Use the correspoding setter method
                    set_func = getattr(ifcs_ctypes, set_func_str)

                    if isinstance(attr_val, int) or isinstance(attr_val, float) or isinstance(attr_val, bool):
                        set_func(compat_pointer(attr_val_obj, prop_obj.type.ctype), attr_val)
                    else:
                        set_func(compat_pointer(attr_val_obj, prop_obj.type.ctype), getattr(ifcs_ctypes, attr_val))

                elif isinstance(attr_val, int) or isinstance(attr_val, float) or isinstance(attr_val, bool):
                    # Set the value directly
                    setattr(attr_val_obj, prop_name, attr_val)
                else:
                    # Get the numberic value from ifcs_ctypes
                    setattr(attr_val_obj, prop_name, getattr(ifcs_ctypes, attr_val))

            #return attr_val_obj
            return

        except Exception as ex:
            log_dbg(
                1,
                "Exception in _get_struct_attr_val: {}".format(sys.exc_info()))
            if str(ex):
                log_err("struct/union processing failed: {}".format(ex))
            assert(0)


    def _get_ifcs_attr_t_val(self, instance_obj, api_class_name, attr_name, attr_val, prop_obj, api_obj, mbr_obj):
        '''
        Get the ifcs_attr_t() object with data set
        '''
        log_dbg(1, "Invoking _get_ifcs_attr_t_val..." )

        try:
            # Init the ifcs_attr_t instance
            ifcs_attr_t_inst = getattr(ifcs_ctypes, 'ifcs_attr_t')()
            ifcs_ctypes.ifcs_attr_t_init(compat_pointer(ifcs_attr_t_inst, ifcs_ctypes.ifcs_attr_t))

            # Attr type
            attr_type = prop_obj.type

            # Set the attrid
            attr_id_set_func = getattr(ifcs_ctypes, 'ifcs_attr_t_id_set')
            if mbr_obj is None:
                attr_name_str = "IFCS_{}_ATTR_{}".format(api_class_name.upper(), attr_name.upper())
            else:
                attr_name_str = "IFCS_{}_{}_ATTR_{}".format(api_class_name.upper(), mbr_obj.name.upper(), attr_name.upper())
            attr_id_val = getattr(ifcs_ctypes, attr_name_str)
            attr_id_set_func(ifcs_attr_t_inst, attr_id_val)

            # Get the func pointer for ifcs_attr_t_value_X_set()
            val_type_str = self._get_ifcs_prop_var_name(attr_type)
            val_set_func_str = "ifcs_attr_t_value_{}_set".format(val_type_str)
            attr_val_set_func = getattr(ifcs_ctypes, val_set_func_str)

            log_dbg(2, "Attr name: {} attr id {} val attr type: {}".format(prop_obj.name, attr_id_val, val_type_str))

            ifcs_attr_type = "ifcs_{}_t".format(prop_obj.type.name)
            attr_val_obj = getattr(ifcs_ctypes, ifcs_attr_type)(0)

            if prop_obj.type.struct:
                # Attr is a struct, iterate for all struct members
                self._get_struct_attr_val(attr_val_obj, attr_name, attr_val, prop_obj.type, prop_obj, api_obj, instance_obj)

                # Set the attr value in ifcs_attr_t object instance
                attr_val_set_func(compat_pointer(ifcs_attr_t_inst, ifcs_ctypes.ifcs_attr_t), compat_pointer(attr_val_obj, ifcs_attr_type))

            else:
                if attr_type.ctype in ['ifcs_handle_t']:
                    if not isinstance(attr_val, int):

                        # Split handle type and value
                        val_hdl_name = attr_val.split(':')[0]
                        val_hdl_val  = attr_val.split(':')[1]

                        if val_hdl_val == 'IFCS_NULL_HANDLE':
                            attr_val = ifcs_ctypes.IFCS_NULL_HANDLE

                        elif val_hdl_name in ['self']:
                            # Handle value is a ref to another object's handle created
                            # as part of this config yaml, will resolve the value later
                            instance_obj.value_subs[attr_name] = (attr_val_obj, prop_obj, val_hdl_val)
                            attr_val = ifcs_ctypes.IFCS_NULL_HANDLE
                        else:
                            # Hex or int format
                            if '0x' in val_hdl_val:
                                val_hdl_val = int(val_hdl_val, 16)
                            else:
                                val_hdl_val = int(val_hdl_val, 10)

                            # Get the handle object type
                            hdl_var_name = "IFCS_HANDLE_{}".format(val_hdl_name.upper())
                            attr_val = getattr(ifcs_ctypes, hdl_var_name)(val_hdl_val)
                    else:
                        # Get the handle object type
                        hdl_obj_name = prop_obj.objects[0].split(':')[1]
                        hdl_var_name = "IFCS_HANDLE_{}".format(hdl_obj_name.upper())
                        attr_val = getattr(ifcs_ctypes, hdl_var_name)(attr_val)

                elif attr_type.ctype in ['ifcs_mac_t']:
                    mac_addr = getattr(ifcs_ctypes, 'ifcs_mac_t')()
                    hex_digits = attr_val.split(":")
                    int_digits = [int(hex_digit, 16) for hex_digit in hex_digits]
                    i = 0
                    for x in (int_digits):
                        mac_addr[i] = x
                        i = i + 1

                    attr_val = mac_addr
                elif attr_type.dyn_arr:
                    # Allocate memory for dynamic arr and seet the values
                    attr_val_obj.count = len(attr_val)
                    attr_val_obj.arr = (self._alloc_darr(getattr(ifcs_ctypes, attr_type.type.ctype), attr_val_obj.count))
                    if "ifcs_string_t" in attr_type.ctype:
                        byarr = bytearray(attr_val, 'utf-8')
                        for idx, val in enumerate(attr_val):
                            attr_val_obj.arr[idx] = byarr[idx]
                    else:
                        for idx, val in enumerate(attr_val):
                            attr_val_obj.arr[idx] = getattr(ifcs_ctypes, val)


                if isinstance(attr_val, int) or isinstance(attr_val, float) or isinstance(attr_val, bool) or \
                        attr_type.ctype in ['ifcs_mac_t']:
                    # Set the value directly
                    attr_val_set_func(compat_pointer(ifcs_attr_t_inst, ifcs_ctypes.ifcs_attr_t), attr_val)
                elif isinstance(attr_val, list):
                    attr_val_set_func(compat_pointer(ifcs_attr_t_inst, ifcs_ctypes.ifcs_attr_t), compat_pointer(attr_val_obj, getattr(ifcs_ctypes, attr_type.type.ctype)))
                elif (attr_type.ctype == "ifcs_string_t"):
                    attr_val_set_func(compat_pointer(ifcs_attr_t_inst, ifcs_ctypes.ifcs_attr_t), compat_pointer(attr_val_obj, getattr(ifcs_ctypes, attr_type.ctype)))
                else:
                    # Get the numberic value from ifcs_ctypes
                    attr_val_set_func(compat_pointer(ifcs_attr_t_inst, ifcs_ctypes.ifcs_attr_t), getattr(ifcs_ctypes, attr_val))

            # return ifcs_attr_t object
            return ifcs_attr_t_inst
        except Exception as ex:
            log_dbg(
                1,
                "Exception in _get_ifcs_attr_t_val: {}".format(sys.exc_info()))
            if str(ex):
                log_err("Attribute processing failed: {}".format(ex))
            assert(0)


    def _get_func_param_list(self, instance_obj, api_class_name, attrs_dict, api_obj, mbr_obj=None):
        log_dbg(1, "Inovking _get_func_param_list..." )
        try:
            # create attr_list_p
            attr_list_p = getattr(ifcs_ctypes, 'ifcs_attr_t')(0)
            attr_count = 0
            func_param_list = []
            idx = 0
            # Single-key objects pass identifier separately; key may not be in attrs_dict
            key_val = None

            if attrs_dict is not None:
                attr_count = len(attrs_dict.items())
                attr_list_p = (getattr(ifcs_ctypes, 'ifcs_attr_t') * attr_count)()

                for attr_name, attr_val in attrs_dict.items():
                    if mbr_obj is not None:
                        prop_obj = self._get_prop_obj(attr_name, mbr_obj.properties)
                    else:
                        prop_obj = self._get_prop_obj(attr_name, self.api_class_objs[api_class_name].properties)

                    # Get the property object for this attr
                    if prop_obj == None:
                        log_err("Invalid attr {} for api class: {}".format(attr_name, self.api_class_objs[api_class_name].name))
                        assert(0)

                    # Skip the key
                    if prop_obj.key and prop_obj.name == attr_name:
                        key_val = attr_val
                        continue

                    # Get the ifcs_attr_t() object
                    ifcs_attr_t_inst = self._get_ifcs_attr_t_val(instance_obj, api_class_name, attr_name, attr_val, prop_obj, api_obj, mbr_obj)

                    # Add attr to attr_list_p
                    attr_list_p[idx] = ifcs_attr_t_inst
                    idx = idx + 1

            # Get the key/handle param for attr set
            api_class_obj =  self.api_class_objs[api_class_name]
            if api_class_obj.has_key() and api_class_obj.key_count() > 1:
                key_name = api_class_obj.key_name()
                key_type = "ifcs_{}_t".format(api_class_obj.key_type())
                api_class_id = getattr(ifcs_ctypes, key_type)()
            elif api_class_obj.key_count() == 1:
                api_class_id = key_val
            else:
                handle = getattr(ifcs_ctypes, 'ifcs_handle_t')(0)
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                api_class_id = compat_pointer(handle, ifcs_ctypes.ifcs_handle_t)

            # Build the func param list
            # node_id
            func_param_list.append(self.node_id)

            # Singleton APIs take only (node_id, attr_count, attr_list_p)
            if not self._is_singleton_api_class(api_class_obj):
                # key or handle
                if api_class_obj.has_key() and api_class_obj.key_count() > 1:
                    func_param_list.append(api_class_id)
                else:
                    func_param_list.append(api_class_id)

            # attr_count
            func_param_list.append(idx)
            # attr_list_p
            func_param_list.append(attr_list_p)

        except Exception as ex:
            log_dbg(
                1,
                "Exception in _get_func_param_list: {}".format(sys.exc_info()))
            if str(ex):
                log_err("Attribute processing failed: {}".format(ex))
            assert(0)

        return func_param_list

    def _get_key_prop_obj(self, key_mbr_name, api_class_obj):

        log_dbg(1, "Invoking _get_key_prop_obj...")
        for prop in api_class_obj.properties:
            if not prop.key:
                continue

            if prop.name == key_mbr_name:
                return prop

        log_err("Unable to find key prop {} for api class {}".format(key_mbr_name, api_class_obj_name))
        assert(0)

    def _get_mbr_type_obj(self, name, prop_obj):

        log_dbg(1, "Invoking _get_mbr_type_obj...")
        for t in prop_obj.type.members:
            if t.name == name:
                return t

        log_err("Unable to find prop {} for key {}".format(key_mbr_name, api_class_obj_name))
        assert(0)


    def _set_key_mbr_val_struct(self, name, value, key_obj, type_obj, key_prop_obj):
        log_dbg(1, "Invoking _set_key_mbr_val_struct...")

        if (isinstance(type_obj, db_util.Type) and (type_obj.struct)) or \
           (isinstance(type_obj.type, db_util.Type) and (type_obj.type.struct)):

            for mbr_name, mbr_val in value.items():
                log_dbg(2, "mbr name {} mbr val {}".format(mbr_name, mbr_val))
                mbr_type_obj = self._get_mbr_type_obj(mbr_name, type_obj)
                self._set_key_mbr_val_struct(mbr_name, mbr_val, key_obj, mbr_type_obj, key_prop_obj)

        elif (isinstance(type_obj, db_util.Type) and (type_obj.union)) or \
           (isinstance(type_obj.type, db_util.Type) and (type_obj.type.union)):

                mbr_obj = getattr(key_obj, name)
                key = compat_listkeys(value)[0]
                val = compat_listvalues(value)[0]

                # Convert IP addr string to int
                if type_obj.type.ctype in ['ifcs_ip_addr_t']:
                    if '.' in val:
                        # ipv4
                        val = int(netaddr.IPAddress(val))
                    elif ':' in val:
                        # ipv6
                        val = convertIpv6InttoTuple(int(netaddr.IPAddress(val.strip(),version=6).value))

                # Set the value
                setattr(mbr_obj, key, val)

                # Call the setter method to handle dirty bits
                func_name = key_prop_obj.type.ctype + "_" + type_obj.name + "_set"
                set_func = getattr(ifcs_ctypes, func_name)
                set_func(compat_pointer(key_obj, key_prop_obj.type.ctype), compat_pointer(mbr_obj, type_obj.type.ctype))

        else:

            # Call the setter method to handle dirty bits
            func_name = key_prop_obj.type.ctype + "_" + type_obj.name + "_set"
            set_func = getattr(ifcs_ctypes, func_name)
            set_func(compat_pointer(key_obj, key_prop_obj.type.ctype), getattr(ifcs_ctypes, value))

    def _set_key_mbr_val(self, name, value, mbr_key_obj, key_prop_obj, instance_obj, key_path_str):
        log_dbg(1, "Invoking _set_key_mbr_val...")
        for mbr_name, mbr_val in value.items():
            log_dbg(2, "mbr name {} mbr val {}".format(mbr_name, mbr_val))
            key_path_str = name + '.' + mbr_name

            mbr_type_obj = self._get_mbr_type_obj(mbr_name, key_prop_obj)
            mbr_mbr_key_obj = getattr(mbr_key_obj, mbr_name)
            if (isinstance(mbr_type_obj, db_util.Type) and mbr_type_obj.struct) or \
               (isinstance(mbr_type_obj.type, db_util.Type) and mbr_type_obj.type.struct):
                self._set_key_mbr_val_struct(mbr_name, mbr_val, mbr_mbr_key_obj, mbr_type_obj, mbr_type_obj)

                # Call the setter method to handle dirty bits
                func_name = key_prop_obj.type.ctype + "_" + mbr_name + "_set"
                set_func = getattr(ifcs_ctypes, func_name)
                set_func(compat_pointer(mbr_key_obj, key_prop_obj.type.ctype), compat_pointer(mbr_mbr_key_obj, mbr_type_obj.type.ctype))

            else:
                # Call the setter method to handle dirty bits
                if mbr_type_obj.type.ctype in ['ifcs_handle_t']:
                    if mbr_val == 0:
                        mbr_val = ifcs_ctypes.IFCS_NULL_HANDLE
                    else:
                        mbr_val_hdl_name = mbr_val.split(':')[0]
                        mbr_val_hdl_val = mbr_val.split(':')[1]

                        if mbr_val_hdl_name in ['self']:
                            # Handle value is a ref to another object's handle created
                            # as part of this config yaml, will resolve the value later
                            log_dbg(4, "key_path_str {} mbr_val_hdl_val {}".format(key_path_str, mbr_val_hdl_val))
                            instance_obj.val_proc_keys[key_path_str] = mbr_val_hdl_val
                            mbr_val = ifcs_ctypes.IFCS_NULL_HANDLE
                        else:
                            if '0x' in mbr_val_hdl_val:
                                mbr_val_hdl_val = int(mbr_val_hdl_val, 16)
                            else:
                                mbr_val_hdl_val = int(mbr_val_hdl_val, 10)

                            # Convert the value to the appropriate handle type
                            hdl_var_name = "IFCS_HANDLE_{}".format(mbr_val_hdl_name.upper())
                            mbr_val = getattr(ifcs_ctypes, hdl_var_name)(mbr_val_hdl_val)

                # Convert Mac Addr/mask string to array of 6 bytes
                elif mbr_type_obj.type.ctype in ['ifcs_mac_t']:
                    mbr_val = get_ctype_arr(convertMacstrtoarr(mbr_val))

                setattr(mbr_key_obj, mbr_name, mbr_val)
                func_name = key_prop_obj.type.ctype + "_" + mbr_name + "_set"
                set_func = getattr(ifcs_ctypes, func_name)
                set_func(compat_pointer(mbr_key_obj, key_prop_obj.type.ctype), getattr(mbr_key_obj, mbr_name))


    def _get_api_class_key(self, key_dict_obj, api_class_obj, instance_obj):

        log_dbg(1, "Invoking _get_api_class_key...")

        # Init the key
        key_name = api_class_obj.key_struct
        api_obj_key = getattr(ifcs_ctypes, key_name)()

        if api_class_obj.key_count() > 1 and api_class_obj.key_space == 'heterogeneous':
            # Init the key
            key_init_func_name = key_name + '_init'
            key_init_func = getattr(ifcs_ctypes, key_init_func_name)
            rc = key_init_func(compat_pointer(api_obj_key, key_name))

            # Set the key type
            key_type_set_func_name = key_name + '_key_type_set'
            key_type_set_func = getattr(ifcs_ctypes, key_type_set_func_name)

            #key_type_name = "IFCS_" + api_class_obj.name.upper() + '_KEY_TYPE_' + key_dict_obj['key_type'].upper()
            key_type_name = key_dict_obj['key_type']
            rc = key_type_set_func(compat_pointer(api_obj_key, key_name), getattr(ifcs_ctypes, key_type_name))

            key_obj = api_obj_key.key

            for key_mbr_name, key_mbr_val in key_dict_obj['key'].items():
                # Find the key property
                key_prop_obj = self._get_key_prop_obj(key_mbr_name, api_class_obj)
                log_dbg(2, "key_mbr_name {} type {}".format(key_mbr_name, key_prop_obj.type.ctype))

                mbr_key_obj = getattr(key_obj, key_mbr_name)
                self._set_key_mbr_val(key_mbr_name, key_mbr_val, mbr_key_obj, key_prop_obj, instance_obj, key_mbr_name)

            key_type_prefix = ('ifcs_'+ api_class_obj.key_name() + '_type_').upper()
            key_type_val_str = key_dict_obj['key_type'].replace(key_type_prefix, '').lower()
            key_set_func_name = api_class_obj.key_struct + '_'+ key_type_val_str + '_set'
            key_set_func = getattr(ifcs_ctypes, key_set_func_name)

            # Get the key val obj
            key_val_obj = getattr(key_obj, key_type_val_str)
            key_ctype_str = key_name[:-1] + key_type_val_str + '_t'
            key_ctype = getattr(ifcs_ctypes, key_ctype_str)
            key_set_func(compat_pointer(api_obj_key, key_name), key_val_obj)

        else:

            log_err("Homogenous keys TBD")
            assert(0)

        return api_obj_key

    def _mbr_crud_parse(self, crud, obj):
        """
        Parse the member crud operations - member_add and member_remove
        """
        log_dbg(1, "Invoking _mbr_crud_parse...")

        # Store crud ops as {crud: {api_class_obj: {instance_name: attr_val_obj}}}
        crud_api_obj = Crud()
        mbr_obj_instances = OrderedDict()
        try:
            for api_class_name, api_class_dict in obj.items():
                log_dbg(2, "api class: %s" % api_class_name)

                api_obj = Api()
                api_name_obj = ApiName()
                api_class_obj = self.api_class_objs[api_class_name]

                for instance_name, instance_dict in api_class_dict.items():
                    log_dbg(2, "instance name: %s" % instance_name)

                    instance_id = instance_dict.get('identifier')
                    instance_obj = Instance()
                    if isinstance(instance_id, str) and 'self:' in instance_id:
                        instance_id_name = instance_id.split(':')[1]
                        instance_id = ifcs_ctypes.IFCS_NULL_HANDLE
                        instance_obj.value_subs[instance_name] = (instance_id_name, crud, None)

                    # Check for duplicate instance names
                    if instance_name in mbr_obj_instances.keys():
                        log_err("Duplicate instance '{}' in {}/{}".format(
                            instance_name, crud, api_class_name))
                        assert (0)

                    api_hdl_name = "IFCS_HANDLE_{}".format(api_class_obj.name.upper())
                    # Singleton APIs use node_id as parent identifier, not a handle
                    if self._is_singleton_api_class(api_class_obj):
                        if instance_id is not None and instance_id != ifcs_ctypes.IFCS_NULL_HANDLE:
                            mbr_obj_instances[instance_name] = int(instance_id)
                        else:
                            mbr_obj_instances[instance_name] = self.node_id
                    else:
                        hdl_macro = getattr(ifcs_ctypes, api_hdl_name)
                        mbr_obj_instances[instance_name] = hdl_macro(instance_id)

                    # Pop the identifier key-value pair, we have saved this
                    instance_dict.pop('identifier')

                    for mbr_name, mbr_val_dict in instance_dict.items():
                        log_dbg(2, "mbr_name: %s" % mbr_name) # members

                        mbr_crud_api = "ifcs_{}_{}_{}".format(api_class_name, mbr_name, crud.split('_')[1])
                        log_dbg(2, "mbr_crud_api: %s" % mbr_crud_api)
                        api_crud_obj = getattr(ifcs_ctypes, mbr_crud_api)

                        func_param_list = []
                        func_param_list.append(self.node_id)
                        mbr_hdl_values = []
                        mbr_count = 0
                        for mbr_type_name, mbr_type_dict in mbr_val_dict.items():
                            log_dbg(2, "mbr_type_name: %s" % mbr_type_name)

                            if mbr_type_name == 'attributes':
                                # Process the member attributes
                                idx = 0
                                mbr_found = False
                                for mbr in api_class_obj.members:
                                    if mbr.name == mbr_name:
                                        mbr_obj = mbr
                                        mbr_found = True
                                        break
                                if mbr_found == False:
                                    log_err("Invalid member name %s for api class %s" % (mbr_name, api_class_name))
                                    assert(0)

                                func_param_list = self._get_func_param_list(instance_obj, api_class_name, mbr_type_dict, api_obj, mbr_obj)
                            else:
                                # Build the API class handle
                                mbr_hdl_name = "IFCS_HANDLE_{}".format(mbr_type_name.upper())
                                mbr_hdl_macro = getattr(ifcs_ctypes, mbr_hdl_name)

                                for mbr_inst_name, mbr_inst_dict in mbr_type_dict.items():
                                    log_dbg(2, "mbr_inst_name: %s" % mbr_inst_name)
                                    mbr_id_name, mbr_val = compat_listitems(mbr_inst_dict)[0]
                                    if isinstance(mbr_val, str) and 'self:' in mbr_val:
                                        mbr_val_name = mbr_val.split(':')[1]
                                        instance_obj.value_subs[mbr_val_name] = (instance_name, crud, mbr_count)
                                        mbr_val = ifcs_ctypes.IFCS_NULL_HANDLE

                                    mbr_hdl_value = mbr_hdl_macro(mbr_val)
                                    mbr_count = mbr_count + 1
                                    mbr_hdl_values.append(mbr_hdl_value)

                        # Build the member handle_list_p
                        mbr_handle_list_p = (ifcs_ctypes.ifcs_handle_t * mbr_count)()
                        for i in range(mbr_count):
                            mbr_handle_list_p[i] = mbr_hdl_values[i]
                        # Convert to the handle list pointer
                        mbr_handle_list_p = compat_pointer(mbr_handle_list_p, ifcs_ctypes.ifcs_handle_t)

                        if crud == 'member_add':
                            # Singleton APIs have no parent handle, params are (node_id, mbr_count, mbr_list, attr_count, attr_list)
                            if self._is_singleton_api_class(api_class_obj):
                                if len(func_param_list) == 3:
                                    attr_count = func_param_list[1]
                                    attr_list_p = func_param_list[2]
                                    func_param_list = [
                                        self.node_id, mbr_count,
                                        mbr_handle_list_p, attr_count,
                                        attr_list_p]
                                else:
                                    func_param_list = [
                                        self.node_id, mbr_count,
                                        mbr_handle_list_p, 0, None]
                            elif len(func_param_list) == 1:
                                # No attributes
                                func_param_list.insert(1, mbr_obj_instances[instance_name])
                            else:
                                func_param_list[1] = mbr_obj_instances[instance_name]
                            # Handle-based APIs need mbr_count and mbr_list inserted after handle
                            if not self._is_singleton_api_class(api_class_obj):
                                func_param_list.insert(2, mbr_count)
                                func_param_list.insert(3, mbr_handle_list_p)
                                # Handle case where the API class has no attrs specified in the yaml, pass attr_count = 0 and Null attr_list_p
                                if len(func_param_list) == 4:
                                    # No attributes
                                    func_param_list.append(0)
                                    func_param_list.append(None)
                        elif crud == 'member_remove':
                            # Singleton APIs have no parent handle, params are (node_id, mbr_count, mbr_list)
                            if self._is_singleton_api_class(api_class_obj):
                                func_param_list = [
                                    self.node_id, mbr_count,
                                    mbr_handle_list_p]
                            else:
                                func_param_list.append(mbr_obj_instances[instance_name])
                                func_param_list.append(mbr_count)
                                func_param_list.append(mbr_handle_list_p)
                        else:
                            log_err("Invalid member crud operation %s for instance %s" % (crud, instance_name))
                            assert(0)

                        instance_obj.add(instance_name, func_param_list)
                        api_obj.add(api_crud_obj, instance_obj)

                # End of api_class_name loop
                api_name_obj.add(api_class_name, api_obj)
                crud_api_obj.add(crud, api_name_obj)

            self.crud_ops[crud] = crud_api_obj

        except Exception as ex:
            log_dbg(1,
                    "Exception in _mbr_crud_parse: {}".format(sys.exc_info()))
            if str(ex):
                log_err("Member CRUD operation parsing failed: {}".format(ex))
            assert(0)

    def parse_config_yaml(self, args):
        '''
        Parse user provided config yaml
        '''

        log_dbg(1, "Invoking parse_config_yaml...")

        for crud, obj in self.yaml_data.items():
            log_dbg(2, "crud op: %s" % crud)
            # Store crud ops as {crud: {api_class_obj: {instance_name: attr_val_obj}}}
            crud_api_obj = Crud()

            if crud not in ['create', 'delete', 'set', 'member_add', 'member_remove']:
                log_err("Operation not valid: %s" % crud)
                assert(0)

            if crud in ['member_add', 'member_remove']:
                # Parse member crud operations
                try:
                    self._mbr_crud_parse(crud, obj)
                except Exception as ex:
                    log_dbg(
                        1, "Exception in parse_config_yaml: {}".format(
                            sys.exc_info()))
                    if str(ex):
                        log_err(
                            "Member CRUD operation parsing failed: {}".format(
                                ex))
                    assert(0)
            else:
                try:
                    for api_class_name, api_class_dict in obj.items():
                        log_dbg(2, "api class: %s" % api_class_name)

                        api_obj = Api()
                        api_name_obj = ApiName()
                        api_class_obj = self.api_class_objs[api_class_name]

                        if crud in ['set']:
                            crud_api = "ifcs_{}_attr_{}".format(api_class_name, crud)
                        else:
                            crud_api = "ifcs_{}_{}".format(api_class_name, crud)

                        try:
                            api_crud_obj = getattr(ifcs_ctypes, crud_api)
                        except AttributeError as ex:
                            log_dbg(
                                1, "Exception in parse_config_yaml: {}".format(
                                    sys.exc_info()))
                            log_err("API '{}' not found: {}".format(
                                crud_api, ex))
                            assert(0)

                        for instance_name, instance_dict in api_class_dict.items():
                            log_dbg(2, "instance name: %s" % instance_name)

                            key_obj = None

                            instance_obj = Instance()
                            # Get the instance identifier value (may be None)
                            instance_id = instance_dict.get('identifier')

                            # Check if instance is created in the current config yaml
                            if isinstance(instance_id, str) and 'self:' in instance_id:
                                instance_id_name = instance_id.split(':')[1]
                                instance_id = self.obj_instances[instance_id_name]

                            if isinstance(instance_id, str) and 'IFCS_NULL_HANDLE' in instance_id:
                                instance_id = ifcs_ctypes.IFCS_NULL_HANDLE

                            # Check for duplicate instance names
                            if instance_name in self.obj_instances.keys():
                                log_err(
                                    "Duplicate instance '{}' in {}/{}".format(
                                        instance_name, crud, api_class_name))
                                assert (0)

                            if api_class_obj.has_key() and api_class_obj.key_count() == 1 and instance_id is None:
                                log_err(
                                    "Missing identifier for single-key API class {} instance {}".format(
                                        api_class_name, instance_name))
                                assert(0)

                            # Construct the handle for the API class instance - handle based API class only
                            if instance_id is not None and not api_class_obj.has_key():
                                # Singleton APIs store node_id directly, no handle macro needed
                                if self._is_singleton_api_class(api_class_obj):
                                    if instance_id == ifcs_ctypes.IFCS_NULL_HANDLE:
                                        self.obj_instances[instance_name] = self.node_id
                                    else:
                                        self.obj_instances[instance_name] = int(instance_id)
                                # For create, pass NULL handle as is
                                elif crud in ['create'] and instance_id == ifcs_ctypes.IFCS_NULL_HANDLE:
                                    self.obj_instances[instance_name] = instance_id
                                else:
                                    api_hdl_name = "IFCS_HANDLE_{}".format(api_class_obj.name.upper())
                                    hdl_macro = getattr(ifcs_ctypes, api_hdl_name)
                                    self.obj_instances[instance_name] = hdl_macro(instance_id)
                            elif api_class_obj.has_key() and api_class_obj.key_count() == 1 and instance_id is not None:
                                # Single-key API class (e.g. synce_instance): save identifier for self: refs
                                self.obj_instances[instance_name] = instance_id
                            else:
                                self.obj_instances[instance_name] = None

                            if api_class_obj.has_key() and api_class_obj.key_count() > 1 and instance_id is not None:
                                key_obj = self._get_api_class_key(instance_id, api_class_obj, instance_obj)
                                instance_dict.pop('identifier')

                            else:
                                # Pop the identifier key-value pair, we have saved this
                                instance_dict.pop('identifier')

                            if len(instance_dict.values()) > 0:
                                attrs_dict = compat_listvalues(instance_dict)[0]
                            else:
                                attrs_dict = OrderedDict()

                            func_param_list = self._get_func_param_list(instance_obj, api_class_name, attrs_dict, api_obj)

                            # Update the id/key param for key based object
                            if api_class_obj.has_key():
                                if api_class_obj.key_count() > 1:
                                    func_param_list[1] = key_obj
                                elif instance_id is not None:
                                    # Single-key API class: identifier is the API key (e.g. synce_id)
                                    func_param_list[1] = instance_id

                            # For handle based API class and not singleton API, use the handle value if passed by user
                            if crud == 'create' and not api_class_obj.has_key() \
                                and not self._is_singleton_api_class(api_class_obj) \
                                and self.obj_instances[instance_name] is not None:
                                func_param_list[1].contents.value = self.obj_instances[instance_name]

                            # For handle based API class, use the handle value
                            if crud == 'delete':
                                if not api_class_obj.has_key():
                                    func_param_list[1] = self.obj_instances[instance_name]

                                # Only 2 params required for delete API
                                func_param_list = func_param_list[:2]

                            # Store crud ops as {crud: [{api_class_name: {api_class_obj: {[instance_name: attr_val_obj, ]}}}], }
                            instance_obj.add(instance_name, func_param_list)
                            api_obj.add(api_crud_obj, instance_obj)

                        # end of api_class_name loop
                        api_name_obj.add(api_class_name, api_obj)
                        crud_api_obj.add(crud, api_name_obj)

                    self.crud_ops[crud] = crud_api_obj

                except Exception as ex:
                    log_dbg(
                        1, "Exception in parse_config_yaml: {}".format(
                            sys.exc_info()))
                    if str(ex):
                        log_err("YAML parsing failed: {}".format(ex))
                    assert(0)
