#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import os
import sys
import socket
import select
import argparse
import errno
import time
import datetime
from threading import Thread
from ctypes import *
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from ifcs_cli import IFCS_CLI
from utils.compat_util import *
from verbosity import log, log_err, log_dbg
if COMPAT_PY2:
    from exceptions import IOError
from collections import OrderedDict, deque

g_reserved_port = 7105
g_recommended_host = 'localhost'
class InnoRemoteShell():
    def __init__(self,
                 port=None,
                 host='localhost',
                 server=None,
                 log_file_name=None,
                 flush_interval_sec=60):
        intro               = ''
        self.HOST           = host
        self.PORT           = port
        self.SERVER         = server
        # True only after this instance successfully bind()s self.SERVER (AF_UNIX).
        self._unix_path_bound = False
        self.MAX_CLIENTS    = 5
        self.clientcount    = 0
        self.active_sockets = [] * self.MAX_CLIENTS
        self.open_client_sockets = [] * self.MAX_CLIENTS
        self.cli            = IFCS_CLI(intro)
        self.cli.set_rt_env('switch')
        self.cli.set_server_mode(True)
        self.cli.set_server_object(self)
        self.cli.set_node_id(0)
        self.cli.init_cmds()
        self.no_shell_mode  = 0
        self.peak_client_count = self.clientcount
        self.peak_client_count_ts = datetime.datetime.now()
        self.client_reject_count = 0
        self.error_epipe_count = 0
        self.error_other_count = 0
        self.exception_count = 0
        # poll-based I/O multiplexing (replaces select.select() which fails when
        # any watched socket fd number is >= FD_SETSIZE/1024 in this process).
        self.poll_error_count = 0
        self.poll_consecutive_errors = 0
        self.last_poll_error_log = 0
        self.POLL_ERROR_LOG_INTERVAL = 60
        self.POLL_MAX_CONSECUTIVE_ERRORS = 10
        # Wake periodically when idle so request_stop() is noticed without client I/O.
        self.POLL_TIMEOUT_MS = 1000
        self.poll = None
        self.poll_fdmap = {}
        self._stop_requested = False
        self.MAX_ERROR_LOGS = 5
        self.error_logs = deque()
        self.log_filename = log_file_name
        self.log_file = None
        self.log_flush_interval = flush_interval_sec
        self.last_log_flush = time.time()

        if self.log_filename:
            try:
                self.log_file = open(self.log_filename, "w")
                log("Innovium shell server: Using log file {}".format(
                    self.log_filename))
            except Exception:
                log_err("Failed to create log file {}: {}".format(
                    self.log_filename, sys.exc_info()))
                # Ignore error and continue
                self.log_file = None

    def __del__(self):
        if self.log_file:
            self.log_file.close()
            self.log_file = None

    def set_noshell_mode(self, mode):
        self.no_shell_mode = mode

    def request_stop(self):
        # Used by tests and in-process callers to exit communicate() cleanly.
        self._stop_requested = True

    def setup_modules(self):
        try:
            self.cli.onecmd("setup_modules")
        except:
            server_msg = "Innovium shell server: Error in setup_modules : {}".format(sys.exc_info())
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            # re-raise the exception as server cannot continue running
            raise

    def server_log(self, msg):
        if not self.log_file:
            return
        self.log_file.write(msg)
        if self.log_flush_interval == 0:
            self.log_file.flush()
        else:
            cur_time = time.time()
            if cur_time - self.last_log_flush > self.log_flush_interval:
                self.log_file.flush()
                self.last_log_flush = cur_time

    def is_server_log_enabled(self):
        return True if self.log_file else False

    def create_inet_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            # shutdown() may fail on listening or already-closed sockets; still
            # attempt close() so rebinding the server socket is not blocked.
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except (socket.error, ValueError):
                pass
            try:
                sock.close()
            except (socket.error, ValueError):
                pass

        # Switching from Unix to inet: drop pathname ownership before inet bind.
        self._release_unix_path_if_owned()

        # Latent in the normal single-create path, but clear tracking state so a
        # repeat create_* call cannot accumulate closed sockets in poll setup.
        self.open_client_sockets = []
        self.active_sockets = []
        self.clientcount = 0

        # create the socket
        s_in = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        # set sock opt to not resue address
        s_in.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            # bind to the socket
            s_in.bind((self.HOST, self.PORT))
            server_msg = "Innovium shell server (inet): Successfully bound to port %d" % (self.PORT)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Bind failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            try:
                s_in.close()
            except (socket.error, ValueError):
                pass
            # active_sockets stays empty; communicate() returns immediately if called.
            return

        try:
            # listen to the socket
            s_in.listen(self.MAX_CLIENTS)
            server_msg = "Innovium shell server (inet): Listening for incoming shell clients"
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Listen failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            try:
                s_in.close()
            except (socket.error, ValueError):
                pass
            return

        # append socket to active_sockets list
        self.active_sockets.append(s_in)


    def create_unix_socket(self):

        for sock in self.open_client_sockets + self.active_sockets:
            # shutdown() may fail on listening or already-closed sockets; still
            # attempt close() so rebinding the server socket is not blocked.
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except (socket.error, ValueError):
                pass
            try:
                sock.close()
            except (socket.error, ValueError):
                pass

        self._release_unix_path_if_owned()

        # Latent in the normal single-create path, but clear tracking state so a
        # repeat create_* call cannot accumulate closed sockets in poll setup.
        self.open_client_sockets = []
        self.active_sockets = []
        self.clientcount = 0

        # make sure the socket doesn't already exist
        try:
            os.unlink(self.SERVER)
        except OSError as e:
            if os.path.exists(self.SERVER):
                server_msg = "Innovium shell server (ERROR): server already in use : {}".format(e)
                log(server_msg)
                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
                # Another server owns the path; we never set _unix_path_bound.
                return

        # create the socket
        s_in = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

        try:
            # bind to the socket
            s_in.bind(self.SERVER)
            server_msg = "Innovium shell server (unix): Successfully bound to server %s" % (self.SERVER)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
        except socket.error as msg:
            server_msg = 'Innovium shell server: Bind failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            try:
                s_in.close()
            except (socket.error, ValueError):
                pass
            return

        # Path exists on disk from bind(); shutdown must unlink only while this is set.
        self._unix_path_bound = True
        try:
            # listen to the socket
            s_in.listen(self.MAX_CLIENTS)
            server_msg = "Innovium shell server (unix): Listening for incoming shell clients"
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
        except socket.error as msg:
            self._unix_path_bound = False
            server_msg = 'Innovium shell server: Listen failed with error: {}'.format(msg)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            try:
                s_in.close()
            except (socket.error, ValueError):
                pass
            # bind() created the pathname; remove it since listen never succeeded.
            try:
                os.unlink(self.SERVER)
            except OSError:
                pass
            return

        # append socket to active_sockets list
        self.active_sockets.append(s_in)

    def clientthread(self, conn, addr, data_in):
        # duplicate sys.stdout
        self.cli.stdout = old_stdout = sys.stdout

        # replace sys.stdout with a string buffer
        sys.stdout = new_stdout = compat_StringIO()

        # account for third-party shells that have no prompt
        no_prompt = False

        if 'np' in data_in:
            no_prompt = True
            data_in = data_in.split("np")[0]

        try:
            # execute the incoming command
            if data_in.strip() == "serverexit":
                log("Shell server exiting")
            else:
                self.cli.onecmd(data_in)
        except:
            # retrieve the return buf
            reply = new_stdout.getvalue()

            new_stdout.close()
            # replace the original stdout
            sys.stdout = old_stdout

            # Append error message to client
            err_msg = "Error occurred when executing command : {}".format(sys.exc_info())
            reply = "{}\n{}".format(reply, err_msg)

            # Save copy for logging
            reply_copy = reply

            # encode the reply length in the response
            if not self.no_shell_mode:
                reply = str(len(reply)) + ':::' + reply
            else:
                if no_prompt:
                    reply = reply + "\n"
                else:
                    reply = reply + "\nIVM:R>"

            # send the reply and error message
            conn.sendall(compat_strToBytes(reply))

            # Log if needed
            if self.is_server_log_enabled():
                self.server_log("SHELL:: CMD:: {}\n{}\n".format(
                    data_in, reply_copy))

            # re-raise the exception so that server logs it
            raise

        # retrieve the return buf
        reply = new_stdout.getvalue()

        # Save copy for logging
        reply_copy = reply

        new_stdout.close()
        # replace the original stdout
        sys.stdout = old_stdout

        # encode the reply length in the response
        if not self.no_shell_mode:
            reply = str(len(reply)) + ':::' + reply
        else:
            if no_prompt:
                reply = reply + "\n"
            else:
                reply = reply + "IVM:R>\n"

        # send the reply
        conn.sendall(compat_strToBytes(reply))

        # Log if needed
        if self.is_server_log_enabled():
            self.server_log("SHELL:: CMD:: {}\n{}\n".format(
                data_in, reply_copy))

        # reset the no-prompt flag
        no_prompt = False

 

    def _init_poll(self):
        # Register listen sockets with poll before entering the main loop.
        self.poll = select.poll()
        self.poll_fdmap = {}
        for sock in self.active_sockets:
            self._poll_register(sock)

    def _rebuild_poll(self):
        # Re-create the poll set from tracked sockets only, dropping orphan fds
        # that could not be unregistered from the old poll object.
        self.poll = select.poll()
        self.poll_fdmap = {}
        for sock in list(self.active_sockets) + list(self.open_client_sockets):
            self._poll_register(sock)

    def _poll_register(self, sock):
        fd = sock.fileno()
        self.poll.register(sock, select.POLLIN)
        self.poll_fdmap[fd] = sock

    def _find_tracked_socket_by_fd(self, fd):
        for sock in self.active_sockets + self.open_client_sockets:
            try:
                if sock.fileno() == fd:
                    return sock
            except (ValueError, socket.error):
                continue
        return None

    def _remove_invalid_socket(self, sock):
        # Close and untrack a socket poll reported as invalid or that lost
        # its fdmap entry while still listed in active/open client sockets.
        if sock in self.active_sockets:
            # Listen socket is invalid; server cannot accept new clients.
            # request_stop() exits communicate() via _stop_requested checks.
            server_msg = ("Innovium shell server (ERROR): listen socket "
                          "invalid, stopping server")
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            self.request_stop()
        unregister_failed = self._poll_unregister(sock)
        try:
            sock.close()
        except (socket.error, ValueError):
            pass
        if sock in self.open_client_sockets:
            self.open_client_sockets.remove(sock)
            self.clientcount = max(0, self.clientcount - 1)
        if sock in self.active_sockets:
            self.active_sockets.remove(sock)
        if unregister_failed:
            self._rebuild_poll()

    def _poll_unregister(self, sock):
        fd = None
        try:
            fd = sock.fileno()
            # Closed sockets may return -1 without raising; treat as invalid so
            # we fall back to identity-based fdmap cleanup below.
            if fd < 0:
                fd = None
        except (ValueError, socket.error):
            # Socket may already be closed; fdmap cleanup below still runs.
            fd = None

        unregister_failed = False
        if self.poll is not None:
            try:
                self.poll.unregister(sock)
            except (ValueError, KeyError, socket.error):
                # fdmap is updated below, but poll may still hold the fd until rebuild.
                unregister_failed = True

        if fd is not None:
            self.poll_fdmap.pop(fd, None)
        else:
            # fileno() failed; remove any stale fdmap entries for this socket.
            stale_fds = [map_fd for map_fd, map_sock in self.poll_fdmap.items()
                         if map_sock is sock]
            for stale_fd in stale_fds:
                self.poll_fdmap.pop(stale_fd, None)

        return unregister_failed

    def _release_unix_path_if_owned(self):
        # Unlink only a pathname this instance bound (e.g. shutdown, or inet recreate).
        if self.SERVER and self._unix_path_bound:
            try:
                os.unlink(self.SERVER)
            except OSError:
                pass
            self._unix_path_bound = False

    def _shutdown_all_sockets(self):
        # Release all listen/client sockets and poll state on communicate() exit
        # (normal stop, poll fatal error, or request_stop() from another thread).
        for sock in list(self.open_client_sockets):
            self._poll_unregister(sock)
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except (socket.error, ValueError):
                pass
            try:
                sock.close()
            except (socket.error, ValueError):
                pass
        self.open_client_sockets = []
        self.clientcount = 0

        for sock in list(self.active_sockets):
            self._poll_unregister(sock)
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except (socket.error, ValueError):
                pass
            try:
                sock.close()
            except (socket.error, ValueError):
                pass
        self.active_sockets = []
        self._release_unix_path_if_owned()
        self.poll_fdmap = {}
        self.poll = None

    def _poll_wait(self):
        events = self.poll.poll(self.POLL_TIMEOUT_MS)
        read_list = []
        poll_ready_mask = (select.POLLIN | select.POLLHUP |
                           select.POLLERR | select.POLLNVAL)
        for fd, revents in events:
            if not (revents & poll_ready_mask):
                continue
            sock = self.poll_fdmap.get(fd)
            if sock is None:
                # poll still has fd registered but fdmap entry is missing, e.g.
                # after a prior unregister() failure. Resolve the tracked socket
                # by fd so we do not leave a stale listener/client in the lists.
                sock = self._find_tracked_socket_by_fd(fd)
                if sock is not None:
                    self._remove_invalid_socket(sock)
                    continue
                # Orphan poll fd with no tracked socket; drop it so poll() can
                # make forward progress. If unregister fails, rebuild poll from
                # tracked sockets instead of stopping the whole server.
                try:
                    self.poll.unregister(fd)
                    self.poll_fdmap.pop(fd, None)
                except (ValueError, KeyError, socket.error) as err:
                    server_msg = ("Innovium shell server (WARNING): could not "
                                  "unregister orphan poll fd {}: {}; "
                                  "rebuilding poll set".format(fd, err))
                    log(server_msg)
                    log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_WARN, server_msg, self)
                    self._rebuild_poll()
                continue
            if revents & select.POLLNVAL:
                # Invalid/closed fd still registered with poll; remove socket
                # from tracking lists so we do not keep retrying recv/accept.
                self._remove_invalid_socket(sock)
                continue
            read_list.append(sock)
        return read_list

    def _is_poll_multiplex_error(self, error):
        # Classify poll/register/unregister and closed-fd multiplex failures.
        # Used for _poll_wait(), listen accept(), and _poll_register() only;
        # client recv/command errors must use handle_exception(), not this helper.
        if isinstance(error, ValueError):
            msg = str(error)
            if ('filedescriptor out of range' in msg or
                    'I/O operation on closed file' in msg):
                return True
        err_no = getattr(error, 'errno', None)
        if err_no in (errno.EBADF, errno.EINVAL):
            return True
        return False

    def _handle_poll_multiplex_error(self, error):
        self.poll_error_count += 1
        self.poll_consecutive_errors += 1
        cur_time = time.time()
        # Log at most once per interval to avoid syslog/tmpfs flooding when
        # poll keeps failing on every loop iteration.
        if cur_time - self.last_poll_error_log >= self.POLL_ERROR_LOG_INTERVAL:
            self.last_poll_error_log = cur_time
            server_msg = "Innovium shell server (ERROR): poll multiplex error: {}".format(error)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            self.save_error_log("Poll multiplex error: {}".format(error))

    def _handle_poll_multiplex_exception(self, error):
        # Called when poll(), _poll_register(), or similar multiplex I/O fails.
        # Returns True when the server loop should exit (too many consecutive errors).
        self._handle_poll_multiplex_error(error)
        if self.poll_consecutive_errors >= self.POLL_MAX_CONSECUTIVE_ERRORS:
            server_msg = ("Innovium shell server (ERROR): too many poll "
                          "multiplex errors, stopping server")
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
            return True
        time.sleep(1)
        return False

    def handle_exception(self, error):
        # restore the stdout
        sys.stdout = self.cli.stdout

        # handle error
        if type(error).__name__ in ['BrokenPipeError', 'error']:
            if type(error).__name__ == 'BrokenPipeError' or error.errno == errno.EPIPE:
                self.error_epipe_count += 1
                server_msg = "Innovium shell server (INFO): client has closed the connection before write finished: {}".format(error)
                log(server_msg)
                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_INFO, server_msg, self)
            else:
                self.error_other_count += 1
                server_msg = "Innovium shell server (WARNING): {}".format(error)
                log(server_msg)
                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_WARN, server_msg, self)
        else:
            self.exception_count += 1
            server_msg = "Innovium shell server (ERROR): {}".format(error)
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)

    def communicate(self):
        # Do not clear _stop_requested here: a caller may invoke request_stop()
        # before this method's first line (thread start race). The flag is
        # cleared in finally after shutdown so a later communicate() can rerun.
        # store open shell client sockets
        self.open_client_sockets = []

        # listen in on incoming socket connections
        try:
            if not self.active_sockets:
                # create_inet_socket() / create_unix_socket() returned without
                # a listener (bind/listen failure or path already in use).
                server_msg = ("Innovium shell server (ERROR): no listen socket; "
                              "cannot start server loop")
                log(server_msg)
                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg, self)
                return
            # _init_poll() is inside try/finally so _shutdown_all_sockets() still
            # runs if poll setup fails (e.g. register error), avoiding leaked
            # listen socket fds and partial poll state.
            self._init_poll()
            while True:
                if self._stop_requested:
                    break
                # Default empty so a failed _poll_wait() does not reuse a prior read_list.
                read_list = []
                try:
                    read_list = self._poll_wait()
                except (Exception, IOError, socket.error) as e:
                    # poll() itself raised (unusual); distinct from errors in accept/recv below.
                    if self._is_poll_multiplex_error(e):
                        if self._handle_poll_multiplex_exception(e):
                            break
                        continue
                    self.save_error_log("Exception: {}".format(sys.exc_info()))
                    self.handle_exception(e)
                    continue
                self.poll_consecutive_errors = 0
                if self._stop_requested:
                    break

                # Accept, recv, or run commands for each socket _poll_wait() returned.
                stop_poll_loop = False
                for current_socket in read_list:
                    try:
                        if current_socket in self.active_sockets:
                            (new_socket, address) = current_socket.accept()

                            # if the client count exceeds max clients, send an error the client and  bail
                            if self.clientcount >= self.MAX_CLIENTS:
                                server_msg = "Innovium shell server: Max number of clients (%d) reached" % (self.MAX_CLIENTS)
                                log(server_msg)
                                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                                error_msg = "Err: Max clients-%d" % (self.MAX_CLIENTS)
                                try:
                                    new_socket.sendall(compat_strToBytes(error_msg))
                                except (socket.error, ValueError):
                                    # Client may disconnect before reading the error; still close below.
                                    pass
                                try:
                                    new_socket.close()
                                except (socket.error, ValueError):
                                    pass
                                self.client_reject_count += 1
                                self.save_error_log(
                                    "Max number of clients (%d) reached" %
                                    (self.MAX_CLIENTS))
                                continue

                            # Per-connection connect/disconnect use log_dbg, not log(),
                            # so these messages honor CLI verbosity and stay quiet by default.
                            if self.PORT:
                                server_msg = 'Innovium shell server: Accepted shell client {}:{}'.format(address[0], address[1])
                                log_dbg(1, server_msg)
                                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                            else:
                                server_msg = 'Innovium shell server: Accepted shell client'
                                log_dbg(1, server_msg)
                                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)

                            # Register before tracking so a failure does not leave
                            # an accepted socket in open_client_sockets without poll.
                            try:
                                self._poll_register(new_socket)
                            except (Exception, IOError, socket.error):
                                try:
                                    new_socket.close()
                                except (socket.error, ValueError):
                                    pass
                                raise
                            self.open_client_sockets.append(new_socket)
                            self.clientcount = self.clientcount + 1
                            if self.peak_client_count <= self.clientcount:
                                self.peak_client_count = self.clientcount
                                self.peak_client_count_ts = datetime.datetime.now()
                            if not self.no_shell_mode:
                                try:
                                    new_socket.sendall(compat_strToBytes('Success'))
                                except (socket.error, ValueError):
                                    # Client may disconnect before reading Success; still tracked until recv/close.
                                    pass
                        else:
                            # receive the cli command from the socket
                            try:
                                data = compat_bytesToStr(current_socket.recv(1024))
                            except (socket.error, OSError, ValueError):
                                # recv() failed, e.g. client reset or fd already closed.
                                data = ''
                                server_msg = "Something bad happened. Trying to close connection gracefully. error: {}".format(sys.exc_info())
                                log(server_msg)
                                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)

                            if len(data) == 0:
                                # Per-connection disconnect: log_dbg only (see above).
                                # Normal disconnect (client closed) or recv error above.
                                server_msg = "Innovium shell server: Closing client connection"
                                log_dbg(1, server_msg)
                                log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                                unregister_failed = self._poll_unregister(current_socket)
                                try:
                                    current_socket.close()
                                except (socket.error, ValueError):
                                    pass
                                self.open_client_sockets.remove(current_socket)
                                self.clientcount = max(0, self.clientcount - 1)
                                if unregister_failed:
                                    self._rebuild_poll()
                            else:
                                # Execute and return the command
                                # addr is unused by clientthread(); pass None because
                                # address is only known at accept() time.
                                self.clientthread(current_socket, None, data)
                                if data.strip() == "serverexit":
                                    # Exit via request_stop() so finally runs _shutdown_all_sockets().
                                    server_msg = "Innovium shell server: Closing client connection and exiting per request"
                                    log(server_msg)
                                    log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg, self)
                                    unregister_failed = self._poll_unregister(current_socket)
                                    try:
                                        current_socket.close()
                                    except (socket.error, ValueError):
                                        pass
                                    self.open_client_sockets.remove(current_socket)
                                    self.clientcount = max(0, self.clientcount - 1)
                                    if unregister_failed:
                                        self._rebuild_poll()
                                    self.request_stop()
                                    break
                    except (Exception, IOError, socket.error) as e:
                        if current_socket in self.open_client_sockets:
                            self.save_error_log("Exception: {}".format(sys.exc_info()))
                            self.handle_exception(e)
                        elif self._is_poll_multiplex_error(e):
                            # Listen accept() or _poll_register() after accept().
                            stop_poll_loop = self._handle_poll_multiplex_exception(e)
                            break
                        else:
                            self.save_error_log("Exception: {}".format(sys.exc_info()))
                            self.handle_exception(e)
                if stop_poll_loop:
                    break
        finally:
            # Always release sockets/poll state so the process can restart the
            # server or run other tests without leaking fds.
            self._shutdown_all_sockets()
            # Clear here (not at communicate() entry) so an early request_stop()
            # before the loop starts is not lost; allows a later communicate() rerun.
            self._stop_requested = False
            self.poll_consecutive_errors = 0

    def save_error_log(self, msg):
        if len(self.error_logs) >= self.MAX_ERROR_LOGS:
            self.error_logs.popleft()
        self.error_logs.append(str(datetime.datetime.now()) + ": " + msg)

    def socket_to_str(self, sock, server=True):
        if COMPAT_PY3:
            return str(sock)
        try:
            if server:
                obj_repr = "<fd={}, family={}, type={} proto={}, laddr={}>".format(
                    sock.fileno(), sock.family, sock.type, sock.proto, sock.getsockname())
            else:
                obj_repr = "<fd={}, family={}, type={} proto={}, laddr={}, raddr={}>".format(
                    sock.fileno(), sock.family, sock.type, sock.proto, sock.getsockname(), sock.getpeername())
        except BaseException:
            obj_repr = str(sock)
        return obj_repr

    def get_server_stats(self):
        stats = OrderedDict()
        stats["Remote client count"] = self.clientcount
        idx = 0
        for sock in self.open_client_sockets:
            stats["Open client socket #{}".format(idx)] = self.socket_to_str(sock, False)
            idx += 1
        stats["Peak remote client count"] = self.peak_client_count
        stats["Latest peak remote client time"] = str(self.peak_client_count_ts)
        idx = 0
        for sock in self.active_sockets:
            stats["Server socket #{}".format(idx)] = self.socket_to_str(sock)
            idx += 1
        stats["Clients rejected due to limit"] = self.client_reject_count
        stats["Server errno.EPIPE count"] = self.error_epipe_count
        stats["Server other errno count"] = self.error_other_count
        stats["Server exception count"] = self.exception_count
        stats["Server poll error count"] = self.poll_error_count
        idx = 0
        for msg in self.error_logs:
            stats["Server last error #{}".format(idx)] = msg
            idx += 1
        return stats

    def clear_server_stats(self):
        self.peak_client_count = self.clientcount
        self.peak_client_count_ts = datetime.datetime.now()
        self.client_reject_count = 0
        self.error_epipe_count = 0
        self.error_other_count = 0
        self.exception_count = 0
        self.poll_error_count = 0
        self.poll_consecutive_errors = 0
        self.last_poll_error_log = 0
        self.error_logs = deque()

def log_im_msg(level, msg, server_obj=None):
    if level <= ifcs_ctypes.im_log_level_get():
        ifcs_ctypes.im_log(ifcs_ctypes.IM_LOG_USER_IFCS, level, compat_strToBytes("%s CLI: %s"), ifcs_ctypes.ITC.trace_str[ifcs_ctypes.ITA_NODE], compat_strToBytes(msg))
        if server_obj and server_obj.is_server_log_enabled():
            server_obj.server_log("IFCS_LOG [{}] [NODE] CLI: {}\n".format(
                level, msg))

def config_inet_server(log_filename=None, flush_interval=60):
    # get the port
    global g_reserved_port
    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_PORT: {}".format(PORT)
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        PORT = g_reserved_port
        server_msg = "Innovium shell server: IFCS_INNO_CLI_PORT not set.. assuming default port {}".format(PORT)
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
    # Get the host. For safety, recommended to use localhost.
    try:
        HOST = os.environ['IFCS_INNO_CLI_HOST']
        if HOST in ["", "0.0.0.0", "all"]:
            HOST = ""
        server_msg = "Innovium shell server: Using host : {}".format(
            "all address" if HOST == "" else HOST)
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        HOST = g_recommended_host
        server_msg = "Innovium shell server: Using default host : {}".format(
            HOST)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
    remoteShell = InnoRemoteShell(port=PORT,
                                  host=HOST,
                                  log_file_name=log_filename,
                                  flush_interval_sec=flush_interval)
    remoteShell.create_inet_socket()
    remoteShell.setup_modules()
    remoteShell.communicate()

def config_unix_server(log_filename=None, flush_interval=60):
    # get the server address
    try:
        SERVER = os.environ['IFCS_INNO_CLI_SERVER']
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_SERVER: {}".format(SERVER)
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        server_msg = "Innovium shell server (ERROR): IFCS_INNO_CLI_SERVER not set.. defaulting to inet server"
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
        config_inet_server(log_filename, flush_interval)
        return

    try:
        NOSHELL = int(os.environ['IFCS_INNO_CLI_SERVER_NOSHELL'])
        server_msg = "Innovium shell server: Found IFCS_INNO_CLI_SERVER_NOSHELL: {}".format(NOSHELL)
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)
    except:
        NOSHELL=0
        pass

    remoteShell = InnoRemoteShell(server=SERVER,
                                  log_file_name=log_filename,
                                  flush_interval_sec=flush_interval)
    remoteShell.create_unix_socket()
    remoteShell.set_noshell_mode(NOSHELL)
    remoteShell.setup_modules()
    remoteShell.communicate()

def main(log_filename=None, flush_interval=60):
    # figure out type of server to spawn
    configure_method = 0

    config_serv_methods = {
        0  : config_inet_server,
        1  : config_inet_server,
        2  : config_unix_server,
    }

    try:
        PORT = int(os.environ['IFCS_INNO_CLI_PORT'])

        # configure the inet server
        configure_method = 1
    except:
        try:
            SERVER = os.environ['IFCS_INNO_CLI_SERVER']

            # configure unix server
            configure_method = 2
        except:
            server_msg = "Innovium shell (ERROR) : IFCS_INNO_CLI_PORT / IFCS_INNO_CLI_SERVER not set.. defaulting to INET SERVER"
            log(server_msg)
            log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_DEBUG, server_msg)

    try:
        config_serv_methods[configure_method](log_filename, flush_interval)
    except Exception as e:
        server_msg = "Innovium shell server : {}".format(e)
        log(server_msg)
        log_im_msg(ifcs_ctypes.IFCS_LOG_LEVEL_ERROR, server_msg)

if __name__ == "__main__":
    main()
