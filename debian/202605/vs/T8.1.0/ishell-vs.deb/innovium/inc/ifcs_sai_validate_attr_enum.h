
/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2026) Marvell. All rights reserved.
 * This file is auto generated. DO NOT EDIT!
 *-------------------------------------------------------------------------------------
 */
#ifndef __IFCS_SAI_VALIDATE_ATTR_ENUM_H__
#define __IFCS_SAI_VALIDATE_ATTR_ENUM_H__
#include "ifcs_sai_shim_util.h"


sai_status_t
isai_validate_acl_table_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_acl_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_acl_counter_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_acl_range_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_acl_table_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_acl_table_group_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_acl_table_chain_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ars_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ars_profile_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ars_queue_group_profile_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_bfd_session_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_bridge_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_bridge_port_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_buffer_pool_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ingress_priority_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_buffer_profile_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_counter_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_debug_counter_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_fdb_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hash_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_fine_grained_hash_field_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hostif_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hostif_table_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hostif_trap_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hostif_trap_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hostif_user_defined_trap_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_hostif_packet_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ipmc_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ipmc_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_ipmc_group_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_isolation_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_isolation_group_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_l2mc_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_l2mc_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_l2mc_group_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_lag_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_lag_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_mirror_session_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_my_mac_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_neighbor_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_next_hop_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_next_hop_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_next_hop_group_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_next_hop_group_map_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_policer_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_port_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_port_pool_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_port_connector_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_port_serdes_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_port_llr_profile_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_qos_map_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_queue_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_route_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_virtual_router_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_router_interface_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_rpf_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_rpf_group_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_samplepacket_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_scheduler_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_scheduler_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_srv6_sidlist_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_my_sid_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_stp_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_stp_port_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_switch_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_switch_tunnel_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_synce_clock_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_int_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_math_func_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_report_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_event_threshold_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_tel_type_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_transport_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_telemetry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_collector_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_event_action_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_event_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_counter_subscription_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_tel_type_flow_table_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tam_tel_type_profile_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tunnel_map_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tunnel_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tunnel_term_table_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_tunnel_map_entry_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_udf_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_udf_match_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_udf_group_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_vlan_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_vlan_member_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);

sai_status_t
isai_validate_wred_attr_enum(sai_object_id_t switch_id, uint32_t attr_count, const sai_attribute_t *attr_list_p, sai_common_api_t api_type);


#endif /* __IFCS_SAI_VALIDATE_ATTR_ENUM_H__ */
