/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_neighbor.h
 * @brief ISAI IM Include file for NEIGHBOR module
 */

#ifndef __IFCS_SAI_NEIGHBOR_H__
#define __IFCS_SAI_NEIGHBOR_H__

#define ISAI_MODULE_LOCK_NEIGHBOR 1ULL

#include "ifcs_sai_nexthop.h"
#include "ifcs_sai_routerintf.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_vlan.h"
#include "isai_im_nmgr.h"
#endif /* __IFCS_SAI_NEIGHBOR_H__ */
