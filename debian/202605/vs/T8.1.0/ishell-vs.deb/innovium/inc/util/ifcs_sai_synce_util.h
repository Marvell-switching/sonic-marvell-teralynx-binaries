/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_scheduler_util.h
 * @brief ISAI Util Include file for SCHEDULER module
 */


#ifndef __IFCS_SAI_SYNCE_UTIL_H__
#define __IFCS_SAI_SYNCE_UTIL_H__

#include "util/ifcs_sai_synce_util_dep.h"

sai_status_t
isai_im_synce_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_synce_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);


/*
 * @brief Get the synce_clock Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_synce_clock_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the synce_clock Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_synce_clock_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

#endif /* __IFCS_SAI_SYNCE_UTIL_H__ */
