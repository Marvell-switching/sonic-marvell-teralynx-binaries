/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_srv6_util.h
 * @brief ISAI Util Include file for SRV6 module
 */


#ifndef __IFCS_SAI_SRV6_UTIL_H__
#define __IFCS_SAI_SRV6_UTIL_H__

#include "util/ifcs_sai_srv6_util_dep.h"

/*
 * @brief Initializes srv6 module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_srv6_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Un-initializes srv6 module
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_srv6_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Get tunnel references in SRV6 module
 * @param [in]  tunnel_object_id - SAI Tunnel Object ID
 * @param [out] ref_count_p      - Pointer to reference count
 * @return sai_status_t
 */
extern sai_status_t
isai_im_srv6_get_tunnel_ref_count(
    sai_object_id_t tunnel_object_id,
    uint32_t       *ref_count_p);


/*
 * @brief Get the srv6_sidlist Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_srv6_sidlist_get_object_count(sai_object_id_t switch_id,
                                                   uint32_t *object_count);

/*
 * @brief Get the srv6_sidlist Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_srv6_sidlist_get_object_key(sai_object_id_t switch_id,
                                                 uint32_t *object_count,
                                                 sai_object_key_t *object_list);

/*
 * @brief Get the my_sid_entry Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_my_sid_entry_get_object_count(sai_object_id_t switch_id,
                                                   uint32_t *object_count);

/*
 * @brief Get the my_sid_entry Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_my_sid_entry_get_object_key(sai_object_id_t switch_id,
                                                 uint32_t *object_count,
                                                 sai_object_key_t *object_list);

#endif /* __IFCS_SAI_SRV6_UTIL_H__ */
