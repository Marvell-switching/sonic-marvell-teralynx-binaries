/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_lag_util.h
 * @brief ISAI Util Include file for LAG module
 */


#ifndef __IFCS_SAI_LAG_UTIL_H__
#define __IFCS_SAI_LAG_UTIL_H__

#include "util/ifcs_sai_lag_util_dep.h"

sai_status_t
isai_im_lag_set_untagged_vlan_attr_lag_db(const sai_object_id_t oid,
                                   bool                  vlan_enabled,
                                   uint16_t              untagged_vlan);

sai_status_t
isai_im_lag_get_untagged_vlan_attr_lag_db(const sai_object_id_t oid,
                                   bool                  *vlan_enabled_p,
                                   uint16_t              *untagged_vlan_p);

sai_status_t
isai_im_lag_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_lag_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_lag_add_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t  hdl,
                            uint32_t stp_hdl, uint32_t stp_port_state);

sai_status_t
isai_im_lag_update_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                        ifcs_handle_t   stp_hdl, uint32_t stp_port_state);

sai_status_t
isai_im_lag_remove_lag_db_stp_list(ifcs_node_id_t node_id, ifcs_handle_t hdl,
                            uint32_t stp_hdl);

sai_status_t
isai_im_lag_ds_get_lag_oid(ifcs_node_id_t node_id, ifcs_handle_t    lag_hdl,
                            sai_object_id_t *oid_p);
sai_status_t
isai_im_lag_ds_get_lag_hdl(sai_object_id_t  lag_oid, ifcs_handle_t  *lag_hdl_p);
sai_status_t
isai_im_lag_set_ars_enabled_attr_lag_db(const sai_object_id_t oid,
                                   bool                  ars_enabled);
sai_status_t
isai_im_lag_mem_get_weight_attr_lag_mem_db(const sai_object_id_t oid,
                                           uint32_t          *weight);
sai_status_t
isai_im_lag_ds_check_cross_dependency_on_lag(ifcs_node_id_t node_id,
                                    sai_object_id_t  lag_oid);
ifcs_status_t
isai_im_lag_member_get(ifcs_node_id_t node_id,
                       ifcs_handle_t lag,
                       uint32_t member_count,
                       ifcs_handle_t *member_list_p,
                       uint32_t *actual_member_count_p);
sai_status_t
isai_im_lag_nh_list_update(
                   ifcs_node_id_t    node_id,
                   sai_object_id_t   lag_oid,
                   ifcs_handle_t     *mem_handle_p,
                   uint32_t          mem_cnt,
                   bool              is_mem_add);

sai_status_t
isai_im_lag_afm_profile_hdl_list_get(ifcs_node_id_t      node_id,
                                      sai_object_id_t    lag_oid,
                                      sai_u32_list_t     *afm_profile_list);
sai_status_t
isai_im_lag_afm_profile_hdl_list_set(ifcs_node_id_t      node_id,
                                      sai_object_id_t    lag_oid,
                                      sai_u32_list_t     afm_profile_list);

/**
 * @brief Get tam obj bind on the lag
 *
 * @param [in] node_id       - Node ID
 * @param [in] lag_oid       - LAG OID
 * @param [in,out] tam_list  - tam obj list
 * @return sai_status_t
 */
sai_status_t
isai_im_lag_get_tam_obj_bind_on_lag(ifcs_node_id_t     node_id,
                                    sai_object_id_t    lag_oid,
                                    sai_object_list_t  *tam_list);

/*
 * @brief Get the lag Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_lag_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the lag Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_lag_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

/*
 * @brief Get the lag_member Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_lag_member_get_object_count(sai_object_id_t switch_id,
                                                 uint32_t *object_count);

/*
 * @brief Get the lag_member Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_lag_member_get_object_key(sai_object_id_t switch_id,
                                               uint32_t *object_count,
                                               sai_object_key_t *object_list);

#endif /* __IFCS_SAI_LAG_UTIL_H__ */
