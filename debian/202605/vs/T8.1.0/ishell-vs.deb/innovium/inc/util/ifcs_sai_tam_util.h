/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_tam_util.h
 * @brief ISAI Util Include file for TAM_INT module
 */


#ifndef __IFCS_SAI_TAM_UTIL_H__
#define __IFCS_SAI_TAM_UTIL_H__

#include "util/ifcs_sai_tam_util_dep.h"

/*
 * @brief  Initializes tam module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tam_init(
    sai_switch_init_info_t *sai_switch_init_info_p);
/*
 * @brief Get the IFCS tam_int handle for a given target OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_int_oid    - TAM_INT OID.
 * @param [out] tam_int_handle_p - Return pointer to tam_int handle.
 *
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tam_get_tam_int_handle(ifcs_node_id_t node_id,
                               sai_object_id_t tam_int_oid,
                               ifcs_handle_t   *tam_int_handle_p);

/*
 * @brief Get the IFCS tam_int handle for a given target OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_int_oid    - TAM_INT OID.
 * @param [out] tam_int_handle_p - Return pointer to tam_int handle.
 *
 * @return sai_status_t
 */
extern sai_status_t
isai_im_tam_create_tam_int_acl_user(ifcs_node_id_t node_id,
                               sai_object_id_t tam_int_oid,
                               ifcs_handle_t   *tam_int_handle_p);

/*
 * @brief Update ref count for a given tam int OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_int_oid    - TAM_INT OID.
 * @param [in] increment      - increment ref count
 * @param [in] delete_on_zero - delete if ref count reaches zero 
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_int_update_ref_count(ifcs_node_id_t  node_id,
                                 sai_object_id_t tam_int_oid,
                                 bool            increment,
                                 bool            delete_on_zero);

 /** @brief Update ref count for a given tam OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_oid        - TAM OID.
 * @param [in] increment      - increment ref count
 * @param [in] delete_on_zero - delete if ref count reaches zero 
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_update_ref_count(ifcs_node_id_t node_id,
                             sai_object_id_t tam_oid,
                             bool increment,
                             bool delete_on_zero);

/*
 * @brief Get the HDC policy for a given tam OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_oid        - TAM OID.
 * @param [out] tam_hdc_policy - Return pointer to tam_hdc_policy.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_hdc_policy_get(ifcs_node_id_t node_id, sai_object_id_t tam_oid,
                           ifcs_hdc_policy_t *hdc_policy);
/*
 * @brief Get the BDC policy for a given tam OID.
 * @param [in] node_id        - Node ID
 * @param [in] tam_oid        - TAM OID.
 * @param [out] tam_bdc_policy - Return pointer to tam_bdc_policy.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_bdc_policy_get(ifcs_node_id_t node_id, sai_object_id_t tam_oid,
                           ifcs_bdc_policy_t *bdc_policy);

/*
 * @brief Get the tam event type for a given tam OID.
 * @param [in] switch_oid     - Switch OID
 * @param [in] tam_oid        - TAM OID.
 * @param [out] is_event_type_mod_p - Return pointer to is_event_type_mod.
 * @param [out] event_type_p  - Return pointer to event_type.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tam_event_type_get(sai_object_id_t switch_oid, sai_object_id_t tam_oid,
                               bool *is_event_type_mod_p, uint32_t *event_type_p);

/*
 * @brief Check if TAM_telemetry_list is present for TAM object
 * @param [in] switch_oid     - Switch OID
 * @param [in] tam_oid        - TAM OID.
 * @return bool
 */
bool
isai_im_tam_is_tam_telemetry_list_available(sai_object_id_t switch_oid, sai_object_id_t tam_oid);

/*
 * @brief Check if TAM_events_list is present for TAM object
 * @param [in] switch_oid     - Switch OID
 * @param [in] tam_oid        - TAM OID.
 * @return bool
 */
bool
isai_im_tam_is_tam_event_list_available(sai_object_id_t switch_oid, sai_object_id_t tam_oid);

/*
 * @brief Check and enable Watson for the TAM OID
 * @param [in] switch_oid     - Switch OID
 * @param [in] tam_oid        - TAM OID.
 * @return bool
 */
sai_status_t
isai_im_tam_check_and_enable_watson(sai_object_id_t switch_oid, sai_object_id_t tam_oid);

/*
 * @brief Check and disable Watson for the TAM OID
 * @param [in] switch_oid     - Switch OID
 * @param [in] tam_oid        - TAM OID.
 * @return bool
 */
sai_status_t
isai_im_tam_check_and_disable_watson(sai_object_id_t switch_oid, sai_object_id_t tam_oid);

/*
 * @brief Check and enable Watson Events for the TAM OID
 * @param [in] switch_oid     - Switch OID
 * @param [in] parent_oid     - Parent Object OID.
 * @param [in] tam_oid        - TAM OID.
 * @return bool
 */
sai_status_t
isai_im_tam_check_and_enable_watson_event(sai_object_id_t switch_oid, sai_object_id_t parent_oid, sai_object_id_t tam_oid);

/*
 * @brief Check and disable Watson events for the TAM OID
 * @param [in] switch_oid     - Switch OID
 * @param [in] parent_oid     - Parent Object OID.
 * @param [in] tam_oid        - TAM OID.
 * @return bool
 */
sai_status_t
isai_im_tam_check_and_disable_watson_event(sai_object_id_t switch_oid, sai_object_id_t parent_oid, sai_object_id_t tam_oid);

/**
 * @brief Helper function to fetch TAM event details including action list and report mode
 *
 * This function iterates through the TAM_ATTR_EVENT_OBJECT_LIST from the TAM object,
 * fetches each event's action list, retrieves the report_id from each action, and
 * then fetches the report mode from the report object. It checks all reports and returns
 * true if ANY report has BULK mode, false otherwise.
 *
 * @param [in] switch_oid              - Switch OID
 * @param [in]  tam_oid                - TAM object id
 * @param [out] has_bulk_report_p      - Pointer to store true if any report mode is BULK, false otherwise
 * @param [out] has_non_bulk_report_p  - Pointer to store true if any report mode is not bulk
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_events_action_report_mode_get(sai_object_id_t switch_oid,
        sai_object_id_t tam_oid,
        bool *has_bulk_report_p,
        bool *has_non_bulk_report_p);

sai_status_t
isai_im_tam_compare_tam_list(ifcs_node_id_t node_id,
                             sai_object_list_t tam_list1,
                             sai_object_list_t tam_list2,
                             sai_object_list_t *add_list_p,
                             sai_object_list_t *rem_list_p);

/*
 * @brief Check and enable EFD for the TAM OID
 * @param [in] nodeid      - node ID
 * @param [in] parent_oid  - parent OID.
 * @param [in] tam_oid     - TAM OID.
 * @return bool
 */
sai_status_t
isai_im_tam_check_and_enable_efd(ifcs_node_id_t  node_id,
                                 sai_object_id_t parent_oid,
                                 sai_object_id_t tam_oid);

/*
 * @brief Check and disable EFD for the TAM OID
 * @param [in] node_id     - node ID
 * @param [in] parent_oid  - parent OID.
 * @param [in] tam_oid     - TAM OID.
 * @return bool
 */
sai_status_t
isai_im_tam_check_and_disable_efd(ifcs_node_id_t  node_id,
                                  sai_object_id_t parent_oid,
                                  sai_object_id_t tam_oid);

sai_status_t
isai_im_tam_configure_efd_properties(ifcs_node_id_t node_id,
                                     sai_object_id_t tam_tel_type_profile_oid,
                                     bool is_delete);

/*
 * @brief Update ref count for a given tam tel type profile OID.
 * @param [in] node_id                  - Node ID
 * @param [in] tam_tel_type_profile_oid - TAM tel type profile OID.
 * @param [in] increment                - increment ref count
 * @param [in] delete_on_zero           - delete if ref count reaches zero
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tel_type_profile_update_ref_count(ifcs_node_id_t  node_id,
                                 sai_object_id_t tam_tel_type_profile_oid,
                                 bool            increment,
                                 bool            delete_on_zero);

/*
 * @brief Delete ACL table EFD
 * @param [in] node_id                - node id
 * @param [in] pfcwd_acl_table_info_p - ii_queue_mod_pfcwd_acl_table_info_t
 * @return bool
 */
sai_status_t
isai_im_tam_efd_acl_delete(ifcs_node_id_t node_id,
                           ii_queue_mod_pfcwd_acl_table_info_t *pfcwd_acl_table_info_p);

/*
 * @brief Get the tam Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the tam Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_tam_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

/*
 * @brief Get the tam_int Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_int_get_object_count(sai_object_id_t switch_id,
                                              uint32_t *object_count);

/*
 * @brief Get the tam_int Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_tam_int_get_object_key(sai_object_id_t switch_id,
                                            uint32_t *object_count,
                                            sai_object_key_t *object_list);

/*
 * @brief Get the tam_math_func Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_math_func_get_object_count(sai_object_id_t switch_id,
                                                    uint32_t *object_count);

/*
 * @brief Get the tam_math_func Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_math_func_get_object_key(sai_object_id_t switch_id,
                                     uint32_t *object_count,
                                     sai_object_key_t *object_list);

/*
 * @brief Get the tam_report Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_report_get_object_count(sai_object_id_t switch_id,
                                                 uint32_t *object_count);

/*
 * @brief Get the tam_report Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_tam_report_get_object_key(sai_object_id_t switch_id,
                                               uint32_t *object_count,
                                               sai_object_key_t *object_list);

/*
 * @brief Get the tam_event_threshold Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_event_threshold_get_object_count(sai_object_id_t switch_id,
                                             uint32_t *object_count);

/*
 * @brief Get the tam_event_threshold Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_event_threshold_get_object_key(sai_object_id_t switch_id,
                                           uint32_t *object_count,
                                           sai_object_key_t *object_list);

/*
 * @brief Get the tam_tel_type Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_tel_type_get_object_count(sai_object_id_t switch_id,
                                                   uint32_t *object_count);

/*
 * @brief Get the tam_tel_type Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_tam_tel_type_get_object_key(sai_object_id_t switch_id,
                                                 uint32_t *object_count,
                                                 sai_object_key_t *object_list);

/*
 * @brief Get the tam_transport Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_transport_get_object_count(sai_object_id_t switch_id,
                                                    uint32_t *object_count);

/*
 * @brief Get the tam_transport Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_transport_get_object_key(sai_object_id_t switch_id,
                                     uint32_t *object_count,
                                     sai_object_key_t *object_list);

/*
 * @brief Get the tam_telemetry Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_telemetry_get_object_count(sai_object_id_t switch_id,
                                                    uint32_t *object_count);

/*
 * @brief Get the tam_telemetry Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_telemetry_get_object_key(sai_object_id_t switch_id,
                                     uint32_t *object_count,
                                     sai_object_key_t *object_list);

/*
 * @brief Get the tam_collector Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_collector_get_object_count(sai_object_id_t switch_id,
                                                    uint32_t *object_count);

/*
 * @brief Get the tam_collector Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_collector_get_object_key(sai_object_id_t switch_id,
                                     uint32_t *object_count,
                                     sai_object_key_t *object_list);

/*
 * @brief Get the tam_event_action Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_event_action_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the tam_event_action Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_event_action_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

/*
 * @brief Get the tam_event Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_tam_event_get_object_count(sai_object_id_t switch_id,
                                                uint32_t *object_count);

/*
 * @brief Get the tam_event Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_tam_event_get_object_key(sai_object_id_t switch_id,
                                              uint32_t *object_count,
                                              sai_object_key_t *object_list);

/*
 * @brief Get the tam_counter_subscription Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_counter_subscription_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the tam_counter_subscription Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_counter_subscription_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

/*
 * @brief Get the tam_tel_type_flow_table Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tel_type_flow_table_get_object_count(sai_object_id_t switch_id,
                                                 uint32_t *object_count);

/*
 * @brief Get the tam_tel_type_flow_table Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tel_type_flow_table_get_object_key(sai_object_id_t switch_id,
                                               uint32_t *object_count,
                                               sai_object_key_t *object_list);

/*
 * @brief Get the tam_tel_type_profile Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tel_type_profile_get_object_count(sai_object_id_t switch_id,
                                              uint32_t *object_count);

/*
 * @brief Get the tam_tel_type_profile Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_tam_tel_type_profile_get_object_key(sai_object_id_t switch_id,
                                            uint32_t *object_count,
                                            sai_object_key_t *object_list);

#endif /* __IFCS_SAI_TAM_UTIL_H__ */
