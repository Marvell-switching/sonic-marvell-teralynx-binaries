/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_routerintf_util.h
 * @brief ISAI Util Include file for ROUTERINTF module
 */


#ifndef __IFCS_SAI_ROUTERINTF_UTIL_H__
#define __IFCS_SAI_ROUTERINTF_UTIL_H__

#include "util/ifcs_sai_routerintf_util_dep.h"
#include "ifcs_sysport.h"
#include "ifcs_drop.h"


/*
 * @brief Initializes router interface module
 *
 * @param [in]  sai_switch_init_info_p   -  Pointer to init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Un-initializes router interface module
 *
 * @param [in]  switch_deinit_info_p  - Pointer to de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief  Initializes post routerintf module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_post_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Translates Router Interface SAI object ID to IFCS handle
 *
 * @param [in]  switch_oid    - Switch Object ID
 * @param [in]  sai_object_id - SAI object ID
 * @param [out] ifcs_handle_p - Pointer to IFCS handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);


/*
 * @brief Translates Router Interface IFCS handle to SAI object ID
 *
 * @param [in]  switch_oid   - Switch Object ID
 * @param [in]  ifcs_handle  - Router interface IFCS handle
 * @param [out] object_id_p  - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_itos_xlate_oid(
    sai_object_id_t switch_oid,
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *object_id_p);

/**
 * @brief Sets forwarding mode on port
 *
 * @param [in] node_id      - IFCS node ID
 * @param [in] sysport      - IFCS sysport handle
 * @param [in] fwd_mode     - IFCS port forwarding mode
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_set_fwd_mode_on_sysport(
    ifcs_node_id_t          node_id,
    ifcs_handle_t           sysport,
    ifcs_sysport_fwd_mode_t fwd_mode);

/*
 * @brief Creates RIF DB entry from SAI RIF attributes
 *
 * @param [in]  oid           - Router interface object ID
 * @param [in]  attr_count    - Number of SAI attributes
 * @param [in]  attr_list_p   - Pointer to list of SAI RIF attributes
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_get_db_entry(
    const sai_object_id_t oid,
    const uint32_t        attr_count,
    sai_attribute_t       *attr_list_p);

/**
 * @brief Gets the count of sub ports
 *
 * Caller provides a key to entry to be decremented.
 * If object_id exists, then the sub port count is decremented.
 *
 * @param [in]  node_id   - Node ID
 * @param [in]  port_oid  - Port object ID
 * @param [out] count_p   - sub port count
 * @return sai_status_t
 */
extern sai_status_t
isai_im_routerintf_get_sub_port_count(
    ifcs_node_id_t        node_id,
    const sai_object_id_t port_oid,
    uint32_t              *count_p);

/*
 * @brief Gets L3VNI handle given router interface object ID
 *
 * @param [in]  node_id - IFCS node ID
 * @param [in]  rif_oid - Router interface object ID
 * @param [out] l3vni_p - Pointer to L3VNI handle
 * @return sai_status_t
 */
sai_status_t
isai_im_routerintf_get_l3vni_from_oid(
    ifcs_node_id_t  node_id,
    sai_object_id_t oid,
    ifcs_handle_t   *l3vni_p);

/*
 * @brief Get VRF OID given router interface object ID
 *
 * @param [in]  node_id   - IFCS node ID
 * @param [in]  rif_oid   - Router interface object ID
 * @param [out] vrf_oid_p - Pointer to L3VNI handle
 * @return sai_status_t
 */
sai_status_t
isai_im_routerintf_get_vrfid_from_oid(
    ifcs_node_id_t  node_id,
    sai_object_id_t rif_oid,
    sai_object_id_t *vrf_oid_p);


/**
 * @brief IM layer: Update RT Loopback pkt action for LAG
 *
 * @param [in] node_id   - IFCS node ID
 * @param [in] lag_oid   - OID of LAG
 * @param [in] mem_hdl   - IFCS handle of LAG Member
 * @param [in] mem_add   - add/Removal of LAG member
 * @return sai_status_t
 */
sai_status_t
isai_im_routerintf_apply_rt_lb_pkt_act_on_lag(
    ifcs_node_id_t   node_id,
    sai_object_id_t  lag_oid,
    ifcs_handle_t    mem_hdl,
    bool             mem_add);


bool
isai_im_routerintf_is_virtual_rif(
    ifcs_node_id_t     node_id,
    sai_object_id_t    oid);

/**
 * @brief Get qmap cached oids for a given router interface from DS
 *
 * @param [in]   object_count             - Node Id
 * @param [in]   rif_hdl                  - router interface handle
 * @param [out]  qm_interface_db_entry_p  - qosmap interface DB entry pointer
 * @return sai_status_t
 */
sai_status_t
isai_im_routerintf_qmap_cache_get(ifcs_node_id_t         node_id,
                       ifcs_handle_t                     rif_hdl,
                       isai_shim_qm_interface_db_entry_t *qm_interface_db_entry_p);

/**
 * @brief Set/Cache qmap oids in DS for a given router interface
 *
 * @param [in]  object_count           - Node Id
 * @param [in]  rif_hdl                - router interface handle
 * @param [in]  qm_interface_db_entry  - qosmap interface DB entry
 * @return sai_status_t
 */
sai_status_t
isai_im_routerintf_qmap_cache_set(ifcs_node_id_t    node_id,
                  ifcs_handle_t                     rif_hdl,
                  isai_shim_qm_interface_db_entry_t qm_interface_db_entry);

/**
 * @brief Get all RIF DS handle with Qosmap
 *
 * @param [in]      node_id           - Node Id
 * @param [in/out]  rif_hdl_list_p    - router handle list pointer
 * @return sai_status_t
 */
sai_status_t
isai_im_routerintf_rif_ds_hdl_qm_get_all(ifcs_node_id_t     node_id,
                                         ifcs_handle_list_t *rif_hdl_list_p);


/*
 * @brief Get the router_interface Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_router_interface_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the router_interface Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_router_interface_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

#endif /* __IFCS_SAI_ROUTERINTF_UTIL_H__ */
