/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_switch_util_dep.h
 * @brief ISAI Util Dependency Include file for SWITCH module
 */

#ifndef __IFCS_SAI_SWITCH_UTIL_DEP_H__
#define __IFCS_SAI_SWITCH_UTIL_DEP_H__

#include "ifcs_sai_switch.h"
#include "util/ifcs_sai_acl_util.h"
#include "util/ifcs_sai_ars_util.h"
#include "util/ifcs_sai_arsprofile_util.h"
#include "util/ifcs_sai_bfd_util.h"
#include "util/ifcs_sai_bridge_util.h"
#include "util/ifcs_sai_buffer_util.h"
#include "util/ifcs_sai_counter_util.h"
#include "util/ifcs_sai_debug_counter_util.h"
#include "util/ifcs_sai_fdb_util.h"
#include "util/ifcs_sai_hash_util.h"
#include "util/ifcs_sai_hostif_util.h"
#include "util/ifcs_sai_isolation_group_util.h"
#include "util/ifcs_sai_l2mc_group_util.h"
#include "util/ifcs_sai_l2mc_util.h"
#include "util/ifcs_sai_lag_util.h"
#include "util/ifcs_sai_mirror_util.h"
#include "util/ifcs_sai_my_mac_util.h"
#include "util/ifcs_sai_neighbor_util.h"
#include "util/ifcs_sai_nexthop_util.h"
#include "util/ifcs_sai_nexthopgroup_util.h"
#include "util/ifcs_sai_port_util.h"
#include "util/ifcs_sai_qosmap_util.h"
#include "util/ifcs_sai_queue_util.h"
#include "util/ifcs_sai_route_util.h"
#include "util/ifcs_sai_router_util.h"
#include "util/ifcs_sai_routerintf_util.h"
#include "util/ifcs_sai_samplepacket_util.h"
#include "util/ifcs_sai_srv6_util.h"
#include "util/ifcs_sai_stp_util.h"
#include "util/ifcs_sai_synce_util.h"
#include "util/ifcs_sai_tam_util.h"
#include "util/ifcs_sai_tunnel_util.h"
#include "util/ifcs_sai_udf_util.h"
#include "util/ifcs_sai_vlan_util.h"
#include "util/ifcs_sai_wred_util.h"
#endif /* __IFCS_SAI_SWITCH_UTIL_DEP_H__ */
