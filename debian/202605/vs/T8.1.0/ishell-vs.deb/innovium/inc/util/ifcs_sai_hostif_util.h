/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_hostif_util.h
 * @brief util for ifcs sai module host_interface
 */


#if !defined (__IFCS_SAI_HOSTIF_UTIL_H_)
#define __IFCS_SAI_HOSTIF_UTIL_H_

#include "ifcs_sai_hostif_util_dep.h"

/*
 * @brief Returns whether a given object id of a user defined trap
 *
 * @param [in] oid_p - Pointer to SAI object ID
 * @return ifcs_handle_t
 */
bool
isai_im_hostif_user_defined_trap_is_oid(const sai_object_id_t *const oid_p);



sai_status_t
isai_im_hostif_init(ifcs_node_id_t         node_id,
                    sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_hostif_post_init(ifcs_node_id_t         node_id,
                    sai_switch_init_info_t *sai_switch_init_info_p);
sai_status_t
isai_im_hostif_deinit(ifcs_node_id_t           node_id,
                      sai_switch_deinit_info_t *sai_switch_deinit_info_p);

sai_status_t
isai_im_hostif_register_rx_callback(ifcs_node_id_t node_id);

ifcs_handle_t
isai_im_hostif_get_acl_table(ifcs_node_id_t node_id);

sai_status_t
isai_im_hostif_set_hostif_trap_group(ifcs_node_id_t        node_id,
                                     sai_object_id_t       trap_group_oid,
                                     const sai_attribute_t *attr_list_p);

/**
 * Get IB for the monitor/DCDP based on the bind object of type TRAP
 * As of not used only for samplepacket trap, but can be extended to any
 * trap in future
 */
sai_status_t
isai_im_hostif_get_trap_monitor_ib(ifcs_node_id_t  node_id,
                                   sai_object_id_t trap_oid,
                                   uint8_t         *ib_p);

sai_status_t
isai_im_hostif_user_defined_trap_get_info(
    ifcs_node_id_t                                node_id,
    sai_object_id_t                               udt_oid,
    ifcs_sai_shim_hostif_user_defined_trap_info_t *udt_info_p);

/**
 * @brief Decrement hostif UDT DS ref_count for ACL entries binding USER_TRAP_ID.
 * @param [in] node_id - IFCS node id
 * @param [in] udt_oid - Hostif user-defined trap OID
 * @return sai_status_t
 *
 * Ref counting is not performed for Route, FDB, L2MC, IPMC, or SRv6 (for
 * performance). These inc/dec helpers are used only by the ACL shim to adjust
 * ref_count for CoPP USER_TRAP on ACEs.
 */
sai_status_t
isai_im_hostif_user_defined_trap_dec_ref_cnt(ifcs_node_id_t  node_id,
                                             sai_object_id_t udt_oid);

/**
 * @brief Increment hostif UDT DS ref_count for ACL entries binding USER_TRAP_ID.
 * @param [in] node_id - IFCS node id
 * @param [in] udt_oid - Hostif user-defined trap OID
 * @return sai_status_t
 *
 * Ref counting is not performed for Route, FDB, L2MC, IPMC, or SRv6 (for
 * performance). These inc/dec helpers are used only by the ACL shim to adjust
 * ref_count for CoPP USER_TRAP on ACEs.
 */
sai_status_t
isai_im_hostif_user_defined_trap_inc_ref_cnt(ifcs_node_id_t  node_id,
                                             sai_object_id_t udt_oid);

sai_status_t
isai_im_hostif_fdb_miss_packet_action_get(
    sai_object_id_t         switch_oid,
    sai_shim_fdb_pkt_type_t pkt_type,
    sai_packet_action_t     *action);

sai_status_t
isai_im_hostif_fdb_miss_packet_action_set(
    sai_object_id_t         switch_oid,
    sai_shim_fdb_pkt_type_t pkt_type,
    sai_packet_action_t     action);

sai_status_t
isai_im_hostif_get_ifcs_trap_for_ip2me(ifcs_node_id_t node_id,
                                       ifcs_handle_t  *trap_handle_p);

/**
 * @brief Get trap action from hostif trap type.
 *
 * @param [in] node_id           - Node Id
 * @param [in] trap_type         - HostIf trap type
 * @param [in,out] trap_action_p - HostIf action.
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_get_trap_action_from_trap_type(ifcs_node_id_t  node_id,
                                              uint32_t trap_type,
                                              sai_packet_action_t *trap_action_p);

sai_status_t
isai_im_hostif_get_netdev_vlan_tag_action(ifcs_node_id_t  node_id,
                                          sai_object_id_t port_oid,
                                          uint32_t        *vlan_tag_action_p);

sai_status_t
isai_im_hostif_set_netdev_vlan_tag_action(ifcs_node_id_t  node_id,
                                          sai_object_id_t port_oid,
                                          uint32_t        vlan_tag_action);


sai_status_t
isai_im_hostif_trap_group_policer_get_stats(
    sai_object_id_t             trap_group_oid,
    uint32_t                    number_of_counters,
    ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p,
    uint64_t                    *ifcs_counters_p);

sai_status_t
isai_im_hostif_trap_group_policer_clear_stats(
    sai_object_id_t             trap_group_oid,
    uint32_t                    number_of_counters,
    ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p);

sai_status_t
isai_im_hostif_trap_get_stats(
    sai_object_id_t             trap_oid,
    uint32_t                    number_of_counters,
    ifcs_acl_counter_stats_id_t *counter_ids_p,
    uint64_t                    *counters_p);

sai_status_t
isai_im_hostif_trap_clear_stats(
    sai_object_id_t             trap_oid,
    uint32_t                    number_of_counters,
    ifcs_acl_counter_stats_id_t *ifcs_counter_ids_p);


sai_status_t
isai_im_hostif_get_udt_on_trap_group(
    ifcs_node_id_t    node_id,
    sai_object_id_t   udt_oid,
    sai_object_list_t *udt_oid_list_p);

sai_status_t
isai_im_hostif_get_trap_group_pkt_size(
    ifcs_node_id_t    node_id,
    sai_object_id_t   trap_group_oid,
    uint32_t          *pkt_size);

sai_status_t
isai_im_hostif_get_trap_handle(ifcs_node_id_t           node_id,
                               uint32_t                 trap_type,
                               ifcs_handle_t            *trap_hdl);

sai_status_t
isai_im_hostif_user_defined_trap_get_policer(
    ifcs_node_id_t                                node_id,
    sai_object_id_t                               udt_oid,
    sai_object_id_t                              *policer_oid_p);

sai_status_t
isai_im_hostif_trap_group_get_queue_id(sai_object_id_t          hostif_tg_oid,
                                       sai_attribute_value_t    *val);
/**
 * @brief Enable Mirror on drop feature at switch level
 *
 * @param [in] switch_oid       - Switch oid
 * @param [in] tam_oid          - Tam object id
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_enable_mod(sai_object_id_t   switch_oid, sai_object_id_t tam_oid);

/**
 * @brief Disable Mirror on drop feature at switch level
 *
 * @param [in] switch_oid       - Switch oid
 * @param [in] tam_oid          - Tam object id
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_disable_mod(sai_object_id_t   switch_oid, sai_object_id_t tam_oid);

/**
 * @brief Enable Buffer drops for Mirror on drop feature at switch level
 *
 * @param [in] node_id          - Ifcs node id
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_mod_enable_bdc(ifcs_node_id_t    node_id);

/**
 * @brief Add ACEs to match on this port for hostif trap's  with
 * exclude_port_list when needed
 *
 * @param [in] node_id       - ifcs node id
 * @param [in] sysport_hdl   - sysport handle
 * @param [in] new_port      - true: New port create, false: port deleted
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_trap_port_update_list(ifcs_node_id_t node_id,
                                     sai_object_id_t  port_oid,
                                     bool           new_port);

/**
 * @brief Setup Policer ACE for samplepacket_trap if required
 *
 * @param [in] switch_oid          - switch oid
 * @param [in] collector_hdl       - sFlow collector handle
 * @param [in] direction           - attr id to represent ingress or egress
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_policer_ace_for_samplepacket_trap(sai_object_id_t switch_oid,
                                                        ifcs_handle_t   collector_hdl,
                                                        sai_attr_id_t   direction);

/**
 * @brief Get Packet Trim ACE priority 
 *
 * @param [in] node_id          - Ifcs node id
 * @param [out] pkt_trim_priority_p - Pointer to store the packet trim priority
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_get_packet_trim_ace_priority(ifcs_node_id_t node_id,                                                 
                   uint32_t       *pkt_trim_priority_p);

/**
 * @brief Create an AR redirect ARC ACE on the CoPP table for all IBs.
 *
 * Installs, per ingress block, an ACE that matches destination MAC, ether type
 * and the PSM enable bit and applies the AR_REDIRECT_ARC action so that PSM
 * packets are redirected to the ARC block. Valid only on T100 when the CoPP
 * table was initialised with the PSM_ENABLE match and AR_REDIRECT_ARC action.
 *
 * @param [in] node_id    - Ifcs node id
 * @param [in] dmac       - Destination MAC to match
 * @param [in] ether_type - Ether type to match
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_create_ar_redirect_copp_ace(ifcs_node_id_t  node_id,
                                           const sai_mac_t dmac,
                                           uint16_t        ether_type);

/**
 * @brief Remove the AR redirect ARC ACE from the CoPP table for all IBs.
 *
 * Removes the per-IB ACEs installed by
 * isai_im_hostif_create_ar_redirect_copp_ace and deletes the associated ACE,
 * match and action handles.
 *
 * @param [in] node_id - Ifcs node id
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_remove_ar_redirect_copp_ace(ifcs_node_id_t node_id);


/*
 * @brief Get the hostif Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_hostif_get_object_count(sai_object_id_t switch_id,
                                             uint32_t *object_count);

/*
 * @brief Get the hostif Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_hostif_get_object_key(sai_object_id_t switch_id,
                                           uint32_t *object_count,
                                           sai_object_key_t *object_list);

/*
 * @brief Get the hostif_table_entry Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_table_entry_get_object_count(sai_object_id_t switch_id,
                                            uint32_t *object_count);

/*
 * @brief Get the hostif_table_entry Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_table_entry_get_object_key(sai_object_id_t switch_id,
                                          uint32_t *object_count,
                                          sai_object_key_t *object_list);

/*
 * @brief Get the hostif_trap_group Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_trap_group_get_object_count(sai_object_id_t switch_id,
                                           uint32_t *object_count);

/*
 * @brief Get the hostif_trap_group Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_trap_group_get_object_key(sai_object_id_t switch_id,
                                         uint32_t *object_count,
                                         sai_object_key_t *object_list);

/*
 * @brief Get the hostif_trap Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_hostif_trap_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the hostif_trap Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_hostif_trap_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

/*
 * @brief Get the hostif_user_defined_trap Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_user_defined_trap_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the hostif_user_defined_trap Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_user_defined_trap_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

/*
 * @brief Get the hostif_packet Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_hostif_packet_get_object_count(sai_object_id_t switch_id,
                                                    uint32_t *object_count);

/*
 * @brief Get the hostif_packet Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_hostif_packet_get_object_key(sai_object_id_t switch_id,
                                     uint32_t *object_count,
                                     sai_object_key_t *object_list);

#endif /* __IFCS_SAI_HOSTIF_UTIL_H__ */
