/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_neighbor_util_dep.h
 * @brief ISAI Util Dependency Include file for NEIGHBOR module
 */

#ifndef __IFCS_SAI_NEIGHBOR_UTIL_DEP_H__
#define __IFCS_SAI_NEIGHBOR_UTIL_DEP_H__

#include "ifcs_sai_neighbor.h"
#include "util/ifcs_sai_nexthop_util.h"
#include "util/ifcs_sai_routerintf_util.h"
#include "util/ifcs_sai_switch_util.h"
#include "util/ifcs_sai_vlan_util.h"
#endif /* __IFCS_SAI_NEIGHBOR_UTIL_DEP_H__ */
