/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_ars_profile_util.h
 * @brief ISAI Util Include file for ARSPROFILE module
 */


#ifndef __IFCS_SAI_ARSPROFILE_UTIL_H__
#define __IFCS_SAI_ARSPROFILE_UTIL_H__

#include "util/ifcs_sai_arsprofile_util_dep.h"



/**
 * @brief Initializes ARS Profile module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_profile_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes ARS Profile module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_profile_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/**
 * @brief Retrieves the threshold attributes for a given ARS profile.
 *
 * @param node_id The ID of the node.
 * @param ars_profile_oid The object ID of the ARS profile.
 * @param threshold_p A pointer to the threshold attributes structure.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_profile_get_threshold_attributes(ifcs_node_id_t node_id,
                                            sai_object_id_t ars_profile_oid,
                                            ars_config_thresholds_t *threshold_p);

/**
 * @brief Retrieves the attributes for a given ARS profile.
 *
 * @param switch_id The object ID of the switch.
 * @param ars_profile_id The object ID of the ARS profile.
 * @param attr_count The number of attributes to retrieve.
 * @param attr_list_p Pointer to an array of attribute structures.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_profile_get_attribute(sai_object_id_t switch_id,
                                  sai_object_id_t ars_profile_id,
                                  uint32_t attr_count,
                                  sai_attribute_t *attr_list_p);

/*
 * @brief Create the default AR queue group in IFCS using the switch ARS profile
 *
 * Gets the ARS profile attached at switch and builds a default AR queue group
 * spanning all queue ids. The resulting IFCS handle is stored in
 * switch_db_info.ars_global_info.default_ar_group_hdl.
 *
 * @param [in] switch_id - SAI switch object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_profile_create_default_ar_queue_group(sai_object_id_t switch_id);

/*
 * @brief Delete the default AR queue group from IFCS
 *
 * Deletes the default AR queue group stored in
 * switch_db_info.ars_global_info.default_ar_group_hdl and clears the handle.
 *
 * @param [in] switch_id - SAI switch object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_profile_delete_default_ar_queue_group(sai_object_id_t switch_id);

/*
 * @brief Verify the ars_queue_group_profile indices in the system
 *
 * Verifies the total count of ars_queue_group_profile objects and checks that
 * their CUSTOM_INDEX values are contiguous starting from 0 (for a total of N
 * profiles the indices must be exactly {0, 1, ..., N-1}).
 *
 * @param [in] switch_id - SAI switch object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_queue_group_profile_verify_indices(sai_object_id_t switch_id);

/*
 * @brief Get the ars_profile Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_ars_profile_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the ars_profile Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_ars_profile_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

#endif /* __IFCS_SAI_ARSPROFILE_UTIL_H__ */