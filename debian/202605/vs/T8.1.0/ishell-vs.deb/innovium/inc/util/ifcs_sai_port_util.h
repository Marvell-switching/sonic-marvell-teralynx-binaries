/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_port_util.h
 * @brief ISAI Util Include file for PORT module
 */


#ifndef __IFCS_SAI_PORT_UTIL_H__
#define __IFCS_SAI_PORT_UTIL_H__

#include "util/ifcs_sai_port_util_dep.h"

sai_status_t
isai_im_port_get_all_oids(ifcs_node_id_t      node_id,
                          ifcs_sai_shim_oid_t *all_oids_p,
                          uint32_t            *num_ports_p);

sai_status_t
isai_im_port_set_mirror_oid_in_db(ifcs_node_id_t      node_id,
                            ifcs_handle_t       sysport_hdl,
                            sai_object_id_t     mirror_oid);

ifcs_status_t
isai_im_port_devport_attr_get(
    ifcs_node_id_t    node_id,
    ifcs_devport_t    devport,
    ifcs_attr_id_t    ifcs_attr_id,
    ifcs_attr_t *val_p);

/*
 * @brief Get the Port Queue List
 *
 * @param [in]     port_id     - SAI port object ID
 * @param [in,out] attr_p      - port attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_port_qos_queue_list_get(sai_object_id_t port_id,
                                  sai_attribute_t *attr_p);

/*
 * @brief return true if a given devport is CPU port.
 *
 * @param[in] node_id
 * @param[in] devport
 * @return bool
 */
sai_status_t
isai_im_port_is_cpu_devport(
    ifcs_node_id_t node_id,
    ifcs_devport_t devport, bool *is_devport_p);

/*
 * @brief return true if a given devport is RECIRC port.
 *
 * @param[in] node_id
 * @param[in] devport
 * @return bool
 */

sai_status_t
isai_im_port_is_recirc_devport(
    ifcs_node_id_t node_id,
    ifcs_devport_t devport, bool *is_devport_p);

/*
 * @brief Notification from IFCS for devport link status
 *
 * @param node_id
 * @param user_data_p
 * @param linkscan_event_info_p
 * @return
 */
void
isai_im_port_linkscan_event_notify_callback(ifcs_node_id_t             node_id,
                                        void                       *user_data_p,
                                        ifcs_linkscan_event_info_t *linkscan_event_info_p);

/*
 * @brief Translates port IFCS handle to SAI object ID
 *
 * @param [in]  ifcs_handle - System port IFCS handle
 * @param [out] object_id_p - Pointer to SAI object ID
 * @return sai_status_t
 */
sai_status_t
isai_im_port_ifcs_to_sai_translate_object_id(ifcs_node_id_t node_id,
                                    ifcs_handle_t   ifcs_handle,
                                     sai_object_id_t *object_id_p);

/*
 * @brief Get port info from OID
 *
 * @param [in]     port_id   - SAI port object ID
 * @param [in]     port_info_p - Valid Memory to store object (will return same pointer
 *                               if found)
 * @return index, -1 if does not exist
 */
sai_port_info_t *
isai_im_port_find_port_info_by_oid(ifcs_node_id_t node_id,
                              sai_object_id_t port_id,
                              sai_port_info_t *port_info_p);

/*
 * @brief Get port info from devport
 *
 * @param [in]     port_id   - SAI port object ID
 * @return index, -1 if does not exist
 */
sai_port_info_t *
isai_im_port_find_port_info_by_devport(ifcs_node_id_t node_id, uint32_t devport,
                                        sai_port_info_t * port_info_p);

/*
 * @brief Get port info from sysport
 *
 * @param [in]     port_id   - SAI port object ID
 * @return index, -1 if does not exist
 */
sai_port_info_t *
isai_im_port_find_port_info_by_sysport(ifcs_node_id_t node_id,
                                        ifcs_handle_t sysport,
                                        sai_port_info_t *port_info_p);

sai_status_t
isai_im_port_update_db_entry(ifcs_node_id_t node_id, uint32_t devport,
                                      sai_port_info_t *port_info_p);

/*
 * @brief Get port oid from node_id, devport
 *
 * @param[in] node id - switch id
 * @param[in] devport - devport hdl
 * @param[out] oid_p - pointer to OID to be returned.
 */
sai_status_t
isai_im_port_get_oid(ifcs_node_id_t  node_id, ifcs_devport_t  devport,
                       sai_object_id_t    *p_oid);

/*
 * @brief Get the Admin State
 *
 * @param [in]     port_id   - SAI port object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_port_admin_state_get(ifcs_node_id_t node_id,
                             sai_object_id_t port_id,
                             sai_attribute_t *attr_p);

/*
 * Routine Description:
 *
 *   Change port admin state
 *
 * Arguments:
 *     [in] ifcs_node   - node
 *     [in] ifcs_handle - sysport
 *     [in] ifcs_bool   - admin_state
 *
 * Return Values:
 *   SAI_STATUS_SUCCESS on success
 *   Failure status code on error
 */
sai_status_t
isai_im_port_set_admin_state(ifcs_node_id_t node_id,
                                        ifcs_handle_t  sysport,
                                        ifcs_bool_t    admin_state);
sai_status_t
isai_im_port_get_admin_state(ifcs_node_id_t node_id,
                          sai_object_id_t port_object_id,
                          bool *admin_state_p);

sai_object_id_t
isai_im_port_get_oid_of_devport(ifcs_node_id_t node_id,
        uint32_t devport);

sai_status_t
isai_im_port_is_aux_by_devport(
                          ifcs_node_id_t node_id,
                          ifcs_devport_t devport,
                          bool *is_aux_port);

/*
 * @brief Get the number of ports (ETH) in a node
 *
 * @param node_id
 * @param include_system_ports(ETH, AUX & CPU)
 * @return Number of ports
 */
sai_status_t
isai_im_port_get_count(ifcs_node_id_t node_id,
                       bool           include_system_ports,
                       uint32_t       *port_count);


/*
 * @brief Get the ports list (ETH) for a node
 *
 * @param[in] node_id
 * @param include_system_ports(ETH, AUX & CPU)
 * @param[in, out] num_ports (give max size as input)
 * @param [out] port_list list of object ID of ports
 * @return SAI status
 */
sai_status_t
isai_im_port_get_port_list(ifcs_node_id_t  node_id,
                           bool            include_system_ports,
                           uint32_t        *num_ports,
                           sai_object_id_t *port_list);

/*
 * @brief Set port hostif name to isai_ds port
 *
 */
sai_status_t
isai_im_port_set_hostif_name(ifcs_node_id_t node_id, ifcs_devport_t devport,
                                        char *name);
sai_status_t
isai_im_port_get_datapath_ready(sai_object_id_t switch_oid, sai_object_id_t *port_oid);
/*
 * @brief Get the Port priority_group List
 *
 * @param [in]     port_id     - SAI port object ID
 * @param [in,out] attr_p      - port attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_port_qos_priority_group_list_get(ifcs_node_id_t node_id,
                                         sai_object_id_t port_id,
                                         sai_attribute_t *attr_p);

sai_status_t
isai_im_port_datapath_setup(sai_object_id_t switch_oid);

sai_status_t
isai_im_port_datapath_setup_for_sdk_dp_config_mode(sai_object_id_t switch_oid);

sai_status_t
isai_im_port_level_datapath_setup_for_sdk_dp_config_mode(sai_object_id_t switch_oid,
                                  sai_object_id_t port_oid);

sai_status_t
isai_im_port_level_datapath_setup(sai_object_id_t switch_oid,
                                  sai_object_id_t port_oid);

sai_status_t
isai_im_port_level_datapath_init_done(sai_object_id_t port_oid,
                                      bool            *init_done);

sai_status_t
isai_im_port_get_ib_ibp (ifcs_node_id_t node_id,
                            sai_object_id_t port_oid,
                            uint8_t *ib_p,
                            uint32_t *ibp_p);

/**
 * @brief set attributes for a given samplepacket on all ports wherever it is used
 *
 * @param [in] samplepacket_object_id - samplepacket object_id
 * @param [in] attr_list_p            - Attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_port_samplepacket_ifcs_policy_update(ifcs_node_id_t node_id,
                                             sai_object_id_t samplepacket_object_id,
                                             const sai_attribute_t *attr_list_p);

/*
 * @brief Create all ports during Initialization
 *
 * @param [in] switch_id        - Switch object id
 * @return sai_status_t
 */
sai_status_t
isai_im_port_init(sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Delete all ports during switch Shutdown
 *
 * @param [in] switch_deinit_info_p   - printer to switch_deinit_info[switch_id, node_id, restart type etc…]
 * @return sai_status_t
 */
sai_status_t
isai_im_port_deinit(sai_switch_deinit_info_t  *switch_deinit_info_p);

sai_status_t
isai_im_port_get_stats_switch(sai_object_id_t         switch_id,
                               uint32_t                number_of_counters,
                               const sai_switch_stat_t *counter_ids,
                               uint64_t                *counters);
sai_status_t
isai_im_port_clear_stats_switch(sai_object_id_t         switch_id,
                               uint32_t                number_of_counters,
                               const sai_switch_stat_t *counter_ids);

sai_status_t
isai_im_port_pfc_ingress_acl_deinit(ifcs_node_id_t  node_id);

/*
 * @brief initialzes the static counter ids array
 */
sai_status_t
isai_im_port_init_counter_ids(sai_object_id_t switch_id);

sai_status_t
isai_im_port_init_counter_ids(sai_object_id_t switch_id);

/* from switch */
sai_status_t
isai_im_port_platform_lib_init(ifcs_node_id_t  node_id, char *platform_library);

sai_status_t
isai_im_port_platform_pre_init(ifcs_node_id_t  node_id);

sai_status_t
isai_im_port_platform_init(ifcs_node_id_t node_id);

sai_status_t
isai_im_port_platform_post_init(ifcs_node_id_t  node_id);

sai_status_t
isai_im_port_platform_pre_deinit(ifcs_node_id_t node_id, bool restart_warm);

sai_status_t
isai_im_port_platform_post_deinit(ifcs_node_id_t node_id, bool restart_warm);

sai_status_t
isai_im_port_set_policer_action(ifcs_node_id_t        node_id,
                                sai_object_id_t       port_oid,
                                const sai_attribute_t *attr_list_p);
/*
 * @brief IM call to deinit port module related stuff before the actual deinit.
 * For example, bulk port notification thread
 *
 * @param[in] switch_deinit_info_p - Pointer to switch deinit info
 * @return sai_status_t
 */
sai_status_t
isai_im_port_pre_deinit(sai_switch_deinit_info_t  *switch_deinit_info_p);

/*
 * @brief IM call to clear the bulk port status DS for the specific node id
 *
 * @param[in] node_id - IFCS node id
 * @return void
 */
void
isai_im_port_bpn_clear_status(ifcs_node_id_t  node_id);

/*
 * @brief IM call to enable Mirror on drop feature port policer drops
 *          configured via port_policer or storm_control policer
 * @param[in] node_id       - ifcs node_id
 * @param[in] trap_handle   - Mirror on drop hostif trap handle
 * @param[in] enable        - enable/disable mod drops
 * @return sai_status_t
*/
sai_status_t
isai_im_port_mod_policer_enable(ifcs_node_id_t  node_id,
                                ifcs_handle_t   trap_handle,
                                bool            enable);

sai_status_t
isai_im_port_watson_ref_count_get(ifcs_node_id_t node_id,
                                  sai_object_id_t port_id,
                                  uint32_t *ref_count_p);

sai_status_t
isai_im_port_watson_ref_count_set(ifcs_node_id_t node_id,
                                  sai_object_id_t port_id,
                                  uint32_t ref_count);
/*
 * @brief Get the Port Scheduler Group count
 *
 * @param [in]     port_id     - SAI port object ID
 * @param [in,out] attr_p      - port attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_port_get_number_of_scheduler_groups(sai_object_id_t port_id,
                                            sai_attribute_t *attr_p);

/*
 * @brief Get the ports isg ace list
 *
 * @param [in]     node_id     - node id
 * @param [in]     port_id     - SAI port object ID
 * @param [in]     ace_list    - Ace list
 * @return sai_status_t
 */
sai_status_t
isai_im_port_isg_ace_list_get(ifcs_node_id_t      node_id,
                              sai_object_id_t     port_oid,
                              sai_u32_list_t      *ace_list);
/*
 * @brief Set the ports isg ace list
 *
 * @param [in]     node_id     - node id
 * @param [in]     port_id     - SAI port object ID
 * @param [in]     ace_list    - Ace list
 * @return sai_status_t
 */
sai_status_t
isai_im_port_isg_ace_list_set(ifcs_node_id_t      node_id,
                              sai_object_id_t     port_oid,
                              sai_u32_list_t      ace_list);
/**
 * @brief Get isg oid from port Ds
 *
 * @param [in] node_id         - Node id
 * @param [in] port_oid        - Port object id
 * @param [in] isg_oid_p       - Pointer to hold isg oid
 * @return sai_status_t
 */
sai_status_t
isai_im_port_get_isg(ifcs_node_id_t      node_id,
                     sai_object_id_t     port_oid,
                     sai_object_id_t     *isg_oid_p);
/**
 * @brief Get the HW Lane List for Port Object
 *
 * @param [in]     port_id     - SAI port object ID
 * @param [in,out] attr_p      - port attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_port_shim_port_hw_lane_list_get(sai_object_id_t port_id,
                                        sai_attribute_t *attr_p);

/**
 * @brief Set the Ingr Post fwd User Cookie for Port Object
 *
 * @param [in]     port_id     - SAI port object ID
 * @param [in,out] attr_p      - port attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_port_sysport_ingress_post_fwd_user_cookie_set(sai_object_id_t port_id,
                                  uint8_t cookie);
/**
 * @brief Get the SAI Lane number to IB Num Mapping
 *
 * @param[in]      node_id          - node id
 * @param [in]     sai_start_lane   - SAI Start Lane
 * @param [out]    ib_num - IB Number
 * @return sai_status_t
 */
sai_status_t
isai_im_port_sai_lane_to_ib_num_get(ifcs_node_id_t node_id,
                                    uint32_t sai_start_lane, uint8_t *ib_num);

/**
 * @brief Set the switch Hash-offset
 *
 * @param node_id          - node_id.
 * @param hash_offset      - configured offset
 * @param is_ecmp          - ECMP/LAG
 * @return sai_status_t
 */
sai_status_t
isai_im_port_set_hash_offset(ifcs_node_id_t node_id,
                             uint8_t        hash_offset,
                             bool           is_ecmp);

sai_status_t
isai_im_port_set_ecmp_entropy_select_all(ifcs_node_id_t node_id,
                                         sai_hash_algorithm_t sai_algo);

sai_status_t
isai_im_port_set_lag_entropy_select_all(ifcs_node_id_t node_id,
                                        sai_hash_algorithm_t sai_algo);

/**
 * @brief Set the ARS threshold attribute
 *
 * @param node_id The ID of the node.
 * @param ars_attr The ARS configuration attribute to set.
 * @param ars_conf_threshold Pointer to the ARS configuration thresholds structure.
 * @return sai_status_t
 */
sai_status_t
isai_im_port_set_ars_thresold_attr(ifcs_node_id_t node_id,
                                   ars_config_attr_t ars_attr,
                                   ars_config_thresholds_t *ars_conf_threshold);

/**
 * @brief Set the ARS configuration and threshold attributes
 * @param node_id The ID of the node.
 * @param ars_conf_threshold Pointer to the ARS configuration thresholds structure.
 * @return sai_status_t
 */
sai_status_t
isai_im_port_set_ars_config_and_threshold(ifcs_node_id_t node_id,
                                          ars_config_thresholds_t *ars_conf_threshold);

/**
 * @brief Replay the stored per-port ARS mode to hardware
 *
 * Invoked when AR MOD Global gets enabled in IFCS, to push the ARS mode
 * stored in the iSAI DS to hardware for every ARS-enabled port.
 *
 * @param node_id The ID of the node.
 * @return sai_status_t
 */
sai_status_t
isai_im_port_replay_ars_mode(ifcs_node_id_t node_id);
/* Apply Serdes parameters on the hw */
sai_status_t
isai_im_port_apply_serdes_parms_on_hw(ifcs_node_id_t node_id,
                               sai_port_info_t *port_info_p,
                               uint32_t ifcs_attr_count,
                               ifcs_attr_t *ifcs_attr);
sai_status_t
isai_im_port_afm_profile_hdl_list_set(ifcs_node_id_t      node_id,
                                      sai_object_id_t     port_oid,
                                      sai_u32_list_t      afm_profile_list);
sai_status_t
isai_im_port_afm_profile_hdl_list_get(ifcs_node_id_t      node_id,
                                      sai_object_id_t     port_oid,
                                      sai_u32_list_t      *afm_profile_list);
/*
 * @param [in] node_id       - Node ID
 * @param [in] port_oid      - Port OID
 * @param [in,out] tam_list  - tam obj list
 * @return sai_status_t
 */
sai_status_t
isai_im_port_get_tam_obj_bind_on_port(ifcs_node_id_t     node_id,
                                      sai_object_id_t    port_oid,
                                      sai_object_list_t  *tam_list);

/*
 * @brief Get the port Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_port_get_object_count(sai_object_id_t switch_id,
                                           uint32_t *object_count);

/*
 * @brief Get the port Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_port_get_object_key(sai_object_id_t switch_id,
                                         uint32_t *object_count,
                                         sai_object_key_t *object_list);

/*
 * @brief Get the port_pool Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_port_pool_get_object_count(sai_object_id_t switch_id,
                                                uint32_t *object_count);

/*
 * @brief Get the port_pool Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_port_pool_get_object_key(sai_object_id_t switch_id,
                                              uint32_t *object_count,
                                              sai_object_key_t *object_list);

/*
 * @brief Get the port_connector Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_port_connector_get_object_count(sai_object_id_t switch_id,
                                                     uint32_t *object_count);

/*
 * @brief Get the port_connector Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_port_connector_get_object_key(sai_object_id_t switch_id,
                                      uint32_t *object_count,
                                      sai_object_key_t *object_list);

/*
 * @brief Get the port_serdes Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_port_serdes_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the port_serdes Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_port_serdes_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

/*
 * @brief Get the port_llr_profile Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_port_llr_profile_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the port_llr_profile Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_port_llr_profile_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

/*
 * @brief Initialize PFC WD threshold limits from IFCS capability
 *
 * @param [in] node_id - IFCS node identifier
 * @return sai_status_t
 */
sai_status_t
isai_im_port_pfc_wd_thres_capability_init(ifcs_node_id_t node_id);

/*
 * @brief Get PFC WD detection threshold range (min/max in ms)
 *
 * @param [in]  node_id - IFCS node identifier
 * @param [out] min_p   - minimum detection threshold
 * @param [out] max_p   - maximum detection threshold
 * @return sai_status_t
 */
sai_status_t
isai_im_port_pfc_wd_det_thres_range_get(ifcs_node_id_t node_id,
                                        uint32_t *min_p,
                                        uint32_t *max_p);

/*
 * @brief Get PFC WD restoration threshold range (min/max in ms)
 *
 * @param [in]  node_id - IFCS node identifier
 * @param [out] min_p   - minimum restoration threshold
 * @param [out] max_p   - maximum restoration threshold
 * @return sai_status_t
 */
sai_status_t
isai_im_port_pfc_wd_res_thres_range_get(ifcs_node_id_t node_id,
                                        uint32_t *min_p,
                                        uint32_t *max_p);
#endif /* __IFCS_SAI_PORT_UTIL_H__ */
