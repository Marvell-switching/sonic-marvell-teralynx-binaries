/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_queue_util.h
 * @brief ISAI Util Include file for QUEUE module
 */


#ifndef __IFCS_SAI_QUEUE_UTIL_H__
#define __IFCS_SAI_QUEUE_UTIL_H__

#include "util/ifcs_sai_queue_util_dep.h"


sai_status_t
isai_im_queue_remove(sai_object_id_t queue_object_id);

sai_status_t
isai_im_queue_default_attr(isai_shim_qos_info_t *obj_p,
                           sai_object_id_t      id);

sai_status_t
isai_im_queue_update_pfc_wd_egress_ace_for_port(sai_object_id_t queue_object_id,
                                                bool            ace_enable);

/**
 * @brief Apply PFC WD detection/recovery (DLDR) configuration for a queue.
 *
 * Runs ifcs_sai_shim_queue_apply_pfc_wd_dldr_config() under the queue module lock.
 *
 * @param[in] node_id          IFCS node identifier
 * @param[in] devport          Devport for the queue
 * @param[in] queue_object_id  Queue SAI object ID
 * @param[in] enable           Enable or disable DLDR on the devport
 *
 * @return #SAI_STATUS_SUCCESS on success, or an appropriate SAI error status
 */
sai_status_t
isai_im_queue_apply_pfc_wd_dldr_config(ifcs_node_id_t  node_id,
                                       ifcs_devport_t  devport,
                                       sai_object_id_t queue_object_id,
                                       bool            enable);

sai_status_t
isai_im_queue_default_attr_fill(ifcs_node_id_t       node_id,
                                isai_shim_qos_info_t *obj_p);

sai_status_t
isai_im_queue_flood_control_enable_get(sai_object_id_t queue_object_id,
                                       bool            *is_enable_p);

sai_status_t
isai_im_queue_get_fp_stats(sai_object_id_t        queue_id,
                           uint32_t               number_of_counters,
                           const sai_queue_stat_t *counter_ids,
                           uint64_t               *counters);

/**
 * @brief Resolve queue classification (FP / CPU / AUX) for a queue OID.
 *
 * Runs ifcs_sai_shim_queue_type_get() under the queue module lock
 * (ISAI_MOD_LOCK_REGION(sai_switch_id_query(queue_object_id))).
 *
 * @param[in]  queue_object_id  Queue SAI object ID.
 * @param[out] queue_type_p     Resolved \c switch_queue_type_t for the queue.
 *
 * @return #SAI_STATUS_SUCCESS on success, or an appropriate SAI error status.
 */
sai_status_t
isai_im_queue_get_type(sai_object_id_t       queue_object_id,
                       switch_queue_type_t  *queue_type_p);

/**
 * @brief IM wrapper: queue scheduler profile sanity checks (module lock + shim).
 *
 * Delegates to ifcs_sai_shim_queue_scheduler_sanity_check() while holding the
 * queue module lock (ISAI_MOD_LOCK_REGION(sai_switch_id_query(queue_object_id))).
 * Resolves queue type and, for applicable queues, fills devport weighted scheduling
 * mode, current queue scheduler profile, and port-wide WRR/DWRR counts for the
 * shim’s mismatch checks.
 *
 * @param[in]  queue_object_id              Queue OID under validation.
 * @param[in]  node_id                      IFCS node for the queue.
 * @param[in]  attr_list_p                  Attribute list; must include the queue
 *                                          scheduler profile attribute being evaluated
 *                                          (typically \c SAI_QUEUE_ATTR_SCHEDULER_PROFILE_ID).
 * @param[out] queue_type_p                 Resolved queue classification.
 * @param[out] port_oid_p                   Port OID for the queue’s devport.
 * @param[out] devport_p                    IFCS devport derived from @a port_oid_p.
 * @param[out] weighted_sched_mode_attr_p  Filled \c IFCS_DEVPORT_ATTR_WEIGHTED_SCHEDULING_MODE.
 * @param[out] prev_attr_p                  Current \c SAI_QUEUE_ATTR_SCHEDULER_PROFILE_ID value.
 * @param[out] curr_queue_sched_type_p      Scheduler type currently on the queue (0 if none).
 * @param[out] dwrr_sched_count_p           DWRR scheduler count on the port’s queues.
 * @param[out] wrr_sched_count_p            WRR scheduler count on the port’s queues.
 * @param[out] ds_scheduler_type_p          Scheduling type of the new scheduler profile in
 *                                          @a attr_list_p.
 *
 * @return #SAI_STATUS_SUCCESS on success (including cases where only \a queue_type_p
 *         is updated for non FP/CPU/AUX paths, per shim behavior), or an appropriate
 *         SAI error status.
 */
sai_status_t
isai_im_queue_scheduler_sanity_check(
    sai_object_id_t          queue_object_id,
    ifcs_node_id_t           node_id,
    const sai_attribute_t   *attr_list_p,
    switch_queue_type_t     *queue_type_p,
    sai_object_id_t         *port_oid_p,
    ifcs_devport_t          *devport_p,
    ifcs_attr_t             *weighted_sched_mode_attr_p,
    sai_attribute_t         *prev_attr_p,
    uint32_t                *curr_queue_sched_type_p,
    uint32_t                *dwrr_sched_count_p,
    uint32_t                *wrr_sched_count_p,
    uint32_t                *ds_scheduler_type_p);

/**
 * @brief Initializes queue module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_queue_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes queue module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_queue_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Validate if port scheduler mode aligns with Queue scheduler count
 *
 * @param [in]     port_id   - SAI Switch object ID
 * @param [in]     node_id   - NodeID
 * @param [in]     devport   - devport
 * @return sai_status_t
 */
sai_status_t
isai_im_queue_validate_scheduler_config_port(sai_object_id_t portOid,
                                             ifcs_node_id_t node_id,
                                             ifcs_devport_t  devport);

/**
 * @brief Get tam obj bind on the queue
 *
 * @param [in] node_id       - Node ID
 * @param [in] queue_oid     - Queue OID
 * @param [in,out] tam_list  - tam obj list
 * @return sai_status_t
 */
sai_status_t
isai_im_queue_get_tam_obj_bind_on_queue(ifcs_node_id_t     node_id,
                                        sai_object_id_t    queue_oid,
                                        sai_object_list_t  *tam_list);
#endif /* __IFCS_SAI_QUEUE_UTIL_H__ */
