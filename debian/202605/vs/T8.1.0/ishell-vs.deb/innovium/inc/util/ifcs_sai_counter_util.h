/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_counter_util.h
 * @brief ISAI Util Include file for Counter module
 */


#ifndef __IFCS_SAI_COUNTER_UTIL_H__
#define __IFCS_SAI_COUNTER_UTIL_H__

#include "util/ifcs_sai_counter_util_dep.h"
#include "ifcs_sysport.h"

sai_status_t
isai_im_counter_init(sai_switch_init_info_t * sai_switch_init_info_p);

sai_status_t
isai_im_counter_alloc_flex_pool_counter_with_id(ifcs_node_id_t    node_id,
                                                ifcs_handle_t     flex_counter_hdl);
/**
 * @brief Allocate a flex counter (by handle) from the egress nexthop flex pool;
 *        the pool is created on first use.
 * @param[in] node_id          - IFCS Node ID
 * @param[in] flex_counter_hdl - Flex counter handle to allocate
 * @return sai_status_t
 */
sai_status_t
isai_im_counter_alloc_nexthop_flex_pool_counter_with_id(ifcs_node_id_t node_id,
                                                ifcs_handle_t     flex_counter_hdl);
/**
 * @brief Free the egress nexthop flex pool once its last counter is released.
 * @param[in] node_id          - IFCS Node ID
 * @return sai_status_t
 */
sai_status_t
isai_im_counter_free_nexthop_flex_pool_if_unused(ifcs_node_id_t node_id);
/**
 * @brief Reserve a shim-internal nexthop flex counter (e.g. EVPN-MH P2P BUM).
 * @param[in]  node_id                - IFCS Node ID
 * @param[out] internal_counter_oid_p - Reserved shim-internal counter OID
 * @return sai_status_t
 */
sai_status_t
isai_im_counter_reserve_internal_nexthop_flex_counter(ifcs_node_id_t node_id,
                                        sai_object_id_t *internal_counter_oid_p);
/**
 * @brief Free a shim-internal nexthop flex counter previously reserved.
 * @param[in] node_id              - IFCS Node ID
 * @param[in] internal_counter_oid - Shim-internal counter OID to free
 * @return sai_status_t
 */
sai_status_t
isai_im_counter_free_internal_nexthop_flex_counter(ifcs_node_id_t node_id,
                                        sai_object_id_t internal_counter_oid);
/**
 * @brief Read (or clear) the packets/bytes of a shim-internal nexthop flex
 *        counter.
 * @param[in]  node_id              - IFCS Node ID
 * @param[in]  internal_counter_oid - Shim-internal counter OID
 * @param[out] pkts_p               - Packet count (may be NULL)
 * @param[out] bytes_p              - Byte count (may be NULL)
 * @param[in]  is_clear             - true to clear, false to read
 * @return sai_status_t
 */
sai_status_t
isai_im_counter_read_internal_nexthop_flex_counter(ifcs_node_id_t node_id,
                                        sai_object_id_t internal_counter_oid,
                                        uint64_t        *pkts_p,
                                        uint64_t        *bytes_p,
                                        bool            is_clear);

sai_status_t
isai_im_counter_free_flex_pool_counter_with_id(ifcs_node_id_t    node_id,
                                               ifcs_handle_t     flex_counter_hdl);
/*
 * Routine Description:
 *   Attach/Detach Bindpoint Oid to Counter Oid
 *
 * Arguments:
 *    [in] node_id            - IFCS node_id
 *    [in] counter_oid        - Object Id of Counter
 *    [in] bindpoint_obj_id   - Object Id of bindpoint
 *    [in] counter_ids        - specifies the array of counter ids
 *    [in] is_attach          - 1-Attach , 0-Detach
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */
sai_status_t
isai_im_counter_attach_sai_object(ifcs_node_id_t    node_id,
                                  sai_object_id_t   counter_oid,
                                  sai_object_id_t   bindpoint_obj_id,
                                  bool              is_attach);

/*
 * Routine Description:
 *   Check if the counter is optimized.
 *   Counter is considered optimized if the Nos sets the object type during counter create, 
 *   OID format will be different since this information is embedded in the SAI counter Oid
 *
 * Arguments:
 *    [in]  node_id            - IFCS node_id
 *    [in]  handle             - Handle to the counter
 *    [out] is_optimized       - 0-Not Optimized, 1-Optimized
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */
sai_status_t
isai_im_counter_is_counter_optimized(ifcs_node_id_t        node_id,
                                     ifcs_handle_t         handle,
                                     bool *is_optimized);

#endif /* __IFCS_SAI_COUNTER_UTIL_H__ */

/*
 * @brief Get the counter Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_counter_get_object_count(sai_object_id_t switch_id,
                                              uint32_t *object_count);

/*
 * @brief Get the counter Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_counter_get_object_key(sai_object_id_t switch_id,
                                            uint32_t *object_count,
                                            sai_object_key_t *object_list);


