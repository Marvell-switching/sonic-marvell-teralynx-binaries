/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_samplepacket_util.h
 * @brief ISAI Util Include file for SAMPLEPACKET module
 */


#ifndef __IFCS_SAI_SAMPLEPACKET_UTIL_H__
#define __IFCS_SAI_SAMPLEPACKET_UTIL_H__

#include "util/ifcs_sai_samplepacket_util_dep.h"



/*
 * @brief Initializes samplepacket module
 *
 * @param [in]     switch_id   - SAI switch object ID
 * @param [in]  sai_switch_init_info_p   - SAI db info pointer
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_init(sai_object_id_t        switch_id,
                          sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Un-initializes samplepacket module
 *
 * @param [in]     switch_id   - SAI switch object ID
 * @param [in]  switch_deinit_info_p   - reset info[switch_id, node_id, restart_type etc..]
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_deinit(sai_object_id_t          switch_id,
                            sai_switch_deinit_info_t *switch_deinit_info_p);


/*
 * @brief Create the default SDK resources for sflow
 *
 * @param [in]     switch_id   - SAI switch object ID
 * @param [in]     direction   - SAI Port attr id for direction
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_setup_default_slow_path_sdk_resources(
        sai_object_id_t      switch_id,
        sai_attr_id_t        direction);

/*
 * @brief Get the Ingress Samplepacket session
 *
 * @param [in]     switch_id   - SAI switch object ID
 * @param [in]     port_id   - SAI port object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_get_ingress_samplepacket_enable(sai_object_id_t switch_id,
                                                     sai_object_id_t port_id,
                                                     sai_attribute_t *attr_p);

/*
 * @brief Set the Ingress Samplepacket session
 *
 * @param [in]     port_info_p   - SAI port info entry pointer
 * @param [in]     ifcs_traffic_monitor_policy_t_p   - IFCS policy
 * @param [in,out] attr_p        - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_set_ingress_samplepacket_enable(
    sai_object_id_t      switch_id,
    sai_port_info_t *port_info_p,
    ifcs_traffic_monitor_policy_t *traffic_monitor_policy_p,
    sai_attribute_t      *attr_p);


/*
 * @brief Get the egress Samplepacket session
 *
 * @param [in]     switch_id   - SAI switch object ID
 * @param [in]     port_id   - SAI port object ID
 * @param [in,out] attr_p      - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_get_egress_samplepacket_enable(sai_object_id_t switch_id,
                                                    sai_object_id_t port_id,
                                                    sai_attribute_t *attr_p);


/*
 * @brief set the egress Samplepacket session
 *
 * @param [in]     switch_id     - SAI switch object ID
 * @param [in]     port_info_p   - SAI port info pointer
 * @param [in]     ifcs_traffic_monitor_policy_t_p   - IFCS policy
 * @param [in,out] attr_p        - switch attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_set_egress_samplepacket_enable(
    sai_object_id_t      switch_id,
    sai_port_info_t *port_info_p,
    ifcs_traffic_monitor_policy_t *traffic_monitor_policy_p,
    sai_attribute_t      *attr_p);

/*
 * @brief Get the Samplepacket session attributes
 *
 * @param [in]     switch_id          - SAI switch object ID
 * @param [in]     samplepacket_oid   - SAI port object ID
 * @param [in]     attr_count         - Number of attributes
 * @param [in,out] attr_list_p        - Attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_samplepacket_get_samplepacket(sai_object_id_t switch_id,
                                      sai_object_id_t samplepacket_oid,
                                      uint32_t        attr_count,
                                      sai_attribute_t *attr_list_p);



/*
 * @brief Get the samplepacket Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_samplepacket_get_object_count(sai_object_id_t switch_id,
                                                   uint32_t *object_count);

/*
 * @brief Get the samplepacket Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_samplepacket_get_object_key(sai_object_id_t switch_id,
                                                 uint32_t *object_count,
                                                 sai_object_key_t *object_list);

#endif /* __IFCS_SAI_SAMPLEPACKET_UTIL_H__ */
