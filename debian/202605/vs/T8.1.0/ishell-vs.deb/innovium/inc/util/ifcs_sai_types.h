/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_types.h
 * @brief ISAI Util Include file for ACL module
 */


#ifndef __IFCS_SAI_TYPES_H__
#define __IFCS_SAI_TYPES_H__

#include "ifcs_node.h"
#include "ifcs_devport.h"
#include "ifcs_bam.h"
#include "ifcs_dtm.h"
#include "ifcs_node.h"
#include "ifcs_traffic_monitor.h"
#include "ifcs_isai_ds.h"
#include "ifcs_isai_ds_switch.h"
#include "ifcs_isai_ds_tunnel.h"
#include "ifcs_sai_shim_util_id_alloc.h"
#include "ifcs_sai_shim_util_cookie_mgr.h"
#include "ifcs_acl.h"
#include "ifcs_sai_shim_qosmap_wb.h"
#include "ifcs_isai_ds_synce.h"
#include "ifcs_isai_ds_bfd.h"

#define ISAI_RIF_STAT_SCALE_IN (4096)
#define ISAI_RIF_STAT_SCALE_EG (4096)

#define ISAI_NEXT_HOP_GROUP_TYPE         (0)
#define ISAI_NEXT_HOP_GROUP_NO_OF_SLOTS  (8)

/* below value is derived from saitypes.h sai_attribute_value_t.char datatype defination */
#define LABEL_MAX_LEN   32

#define ISAI_MAX_TRAP_NAME_SIZE    (100)
/* No iSAI includes are allowed */

/****************************
 * Vlan
 ***************************/
#define IFCS_SAI_DEFAULT_VLAN_ID    1

#define ISAI_VLAN_MAX_LEARN_ADDRS    (0xffffffff)

#define NUM_VLANS           (4096)

#define PP_DC_MAX_INGRESS_AVL 8
#define PP_DC_MAX_EGRESS_AVL 4
/* IFCS SAI Shim OID Structure */
typedef struct ifcs_sai_shim_oid_s {
    ifcs_handle_t isai_ds_hdl;  ///< IFCS handle of the object
    uint16_t      unused;       ///< Always set to 0
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_shim_oid_t;

typedef struct ifcs_sai_shim_oid_2_s {
    /*
     * Current ifcs-handle is constructed in below way
     *  | 7-bits (Module)| 4-bits (API class) | 21-bits (Value)|
     *
     *  Currently, IFCS is using only 16-bits of value.
     *  Planning to use upper 3-bits to encode sub-type in hdl
     *  Lower-32 bits in OID looks like below.
     *
     * | 7- bits(Mod) | 4-bits (API) | 3-bits(subtype) | 18-bits(value)|
     *
     */
#define   ISAI_OID_SUBTYPE_LEN    18
#define   ISAI_OID_SUBTYPE_MASK   (7 << ISAI_OID_SUBTYPE_LEN)

    ifcs_handle_t ifcs_hdl;     ///< IFCS handle of the object
    uint16_t      unused:16;    ///< Always set to 0
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_shim_oid_2_t;

typedef struct _sai_shim_vlan_mem_info_s {
    ifcs_handle_t   l2vni_hdl;
    ifcs_handle_t   port_hdl;
    ifcs_handle_t   mc_dest;
    sai_object_id_t vlan_oid;
    sai_object_id_t bp_oid;
    ifcs_handle_t   nh_handle;
} sai_shim_vlan_mem_info_t;
#define ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT    8
#define MAX_NUM_SERDES_LANES_PER_PORT   8
#define MAX_NUM_SPEEDS                  10
#define MAX_NUM_FEC_MODES               4
#define ISAI_SERES_SPEED_25G            25
#define ISAI_SERES_SPEED_50G            50
#define ISAI_SERES_SPEED_100G           100

#define ISAI_QOS_BIND_MAX    (128 * 8)     /* Max binds of a qos object;
                                            * for eg. a scheduler can be at most attached to
                                            * num_devports X num_queues_per_devport */
#define ISAI_QOS_ATTR_MAX    256           /* Max attrs */

#define ISAI_BASE_BUFFER_POOL_INDEX       0x0FC7

#define IFCS_SAI_MAX_IBS    8                  ///< Maximum IBs per Node
#define IFCS_SAI_MAX_ETH_IB_PORTS    64        ///< Maximum eth ib ports per IB(such that indexing with ib_port works in this struct
#define IFCS_SAI_MAX_AUX_PORTS           2 // TL7, TL10
#define IFCS_SAI_MAX_CPU_PORTS           1 // TL7, TL10
#define IFCS_SAI_MAX_RECIRC_PORTS    IFCS_SAI_MAX_IBS
#define IFCS_SAI_MAX_PORTS_PER_NODE  \
       ((IFCS_SAI_MAX_IBS*IFCS_SAI_MAX_ETH_IB_PORTS) + \
       IFCS_SAI_MAX_CPU_PORTS + IFCS_SAI_MAX_RECIRC_PORTS + \
       IFCS_SAI_MAX_AUX_PORTS)

#define MAX_NUM_CPU_QUEUES                                   48

/* Different device may have different number of queues for Recirc/Aux/FP Ports
 * Defining 2 macros for each. One for maximum from all device for memory allocation
 * Other for getting device specific value. */
#define ISAI_MAX_NUM_RECIRC_QUEUES_PER_PORT                  8
#define ISAI_NUM_RECIRC_QUEUES_PER_PORT                      8

#define ISAI_MAX_NUM_AUX_QUEUES_PER_PORT                     12
#define ISAI_NUM_AUX_QUEUES_PER_PORT(node_id) \
       (isai_get_supported_aux_queues(node_id))

#define ISAI_MAX_NUM_FP_QUEUES_PER_PORT                      12
#define ISAI_NUM_FP_QUEUES_PER_PORT(node_id) \
       (isai_get_supported_fp_queues(node_id))

#define ISAI_MAX_SUPPORTED_TRAFFIC_CLASS(node_id) \
       (isai_get_supported_tc(node_id))

#define INVALID_PS_ID              -1 // IFCS supports ps id 0-4 (device dependent)

#define ISAI_SHIM_MAX_NUM_LOSSLESS_TC (4)

#define ISAI_MAX_KV_PAIR_VALUE_STR_LEN   512

/* ACL Port Group Related typedefs */
#define ISAI_ACL_PG_BIT_WIDTH    4
#define ISAI_ACL_PG_MAX_COUNT    (1 << ISAI_ACL_PG_BIT_WIDTH)
#define ISAI_ACL_PG_BIT_OFFSET_WIDTH 7
#define ISAI_ACL_PG_BIT_OFFSET_VAL(offset) (1 << offset)
#define IFCS_SAI_ACL_PG_GRP_DEFAULT_NUM    (ISAI_ACL_PG_MAX_COUNT - 1)
#define IFCS_SAI_ACL_PG_GRP_DEFAULT_OFFSET (0)
#define IFCS_SAI_MAX_PORTS_PER_IB (IFCS_SAI_MAX_ETH_IB_PORTS + IFCS_SAI_MAX_AUX_PORTS + \
        IFCS_SAI_MAX_CPU_PORTS + IFCS_SAI_MAX_RECIRC_PORTS)

/* ACL Shim Port Group Info List Structure */
typedef struct _sai_shim_acl_pg_info_s {
    /* Is Entry Valid */
    bool is_valid;
    /* SAI Port OID */
    sai_object_id_t port_oid;
    /* Sysport Handle */
    ifcs_handle_t sysport_hdl;
    /* IB Number */
    ifcs_uint32_t ib_number;
    /* Port Group Number */
    ifcs_uint32_t pg_number;
    /* Port Group Offset */
    ifcs_uint32_t pg_offset;
    /* Is PG Lane Entry Updated */
    bool lane_pg_entry_updated;
    /* Is PG Sysport Entry Created */
    bool sysport_pg_entry_created;
} sai_shim_acl_pg_info_t;

typedef struct _sai__sai_shim_acl_pg_info_list_s
{
    uint32_t count;
    sai_shim_acl_pg_info_t *arr;
} sai_shim_acl_pg_info_list_t;

typedef struct _sai_shim_acl_unique_pg_info_s {
  ifcs_uint32_t pg_number;
  ifcs_uint32_t offset;
} sai_shim_acl_unique_pg_info_t;

typedef struct _sai_shim_acl_unique_pg_info_list_s
{
    uint32_t count;
    sai_shim_acl_unique_pg_info_t *arr;
} sai_shim_acl_unique_pg_info_list_t;

/* Datapath related typedefs and defines - thread-safe*/

/* 1518 bytes is the mtu hence for all platforms, the reserved
 * bytes must be 1518 bytes so it is best to define these
 * in bytes rather than in cells */
#define CPU_QUEUE_RESERVED_Q0_47_BYTES     1518.0
#define RECIRC_QUEUE_RESERVED_Q0_8_BYTES   1518.0
#define AUX_QUEUE_RESERVED_Q0_Q7_BYTES     1518.0

#define INGRESS_PG_RESERVED_PG1_BYTES    1518.0
#define INGRESS_PG_RESERVED_PG2_BYTES    1518.0

#define BAM_QUEUE_BIT_POSITION_ON_IPG_HANDLE 0
#define IPPS_CM_BIT_POSITION_ON_IPG_HANDLE   1
#define QUEUE_BIT_POSITION_ON_QUEUE_HANDLE   0

#define ISAI_SHIM_LOSSLESS_TC1 (3)
#define ISAI_SHIM_LOSSLESS_TC2 (4)

/* Priority of Rules:
 * PFC WD Rules >  Flood Control Rules Routed >   Flood Control Rules Switched > HDC Workaround Rules
 * In IFCS, lower the priority number indicates higher priority
 */
#define ISAI_DATAPATH_PFD_WD_ACE_PRIORITY  1
#define ISAI_DATAPATH_PFD_FLOOD_CONTROL_ROUTED_ACE_PRIORITY 2
#define ISAI_DATAPATH_PFD_FLOOD_CONTROL_SWITCHED_ACE_PRIORITY 3
#define ISAI_BP_ISG_ACE_PRIORITY       4
#define ISAI_PORT_ISG_ACE_PRIORITY       4
#define ISAI_RIF_LOOPBACK_ACE_PRIORITY 5
#define ISAI_MIRROR_POLICER_ACE_PRIO  (5)

/* Packet trimming feature constatns, Packet trimming ACL tables are seperate acl_tables */
#define ISAI_DEFAULT_TRIM_SIZE  224 /* bytes for TL10 */
#define PKT_TRM_EG_GBL_ACE_PRIO 100
#define PKT_TRM_EG_GBL_UPD_ACE_PRIO 101
#define PKT_TRM_EG_PORT_ACE_PRIO 1
#define PKT_TRM_IN_PRIO          1

/* ECN stats ACE need to have lowest priority compared */
#define ISAI_ECN_STATS_ACE_PRIORITY    6
#define ISAI_EFD_FEATURE_PRIORITY      7

#define ISAI_BFD_HW_LKP_TTL_ACE_PRIORITY 7

#define ISAI_PFC_FLOOD_CTRL_L3_ACE_PRIO(x)  x
#define ISAI_PFC_FLOOD_CTRL_L2_ACE_PRIO(x)  (x+1)

 /*  */

#define ITERATE_IB_START(node_id, ib, ifcs_rc, sai_rc, cleanup) \
{\
    uint32_t actual_attr_count = 0;\
    for(ib = 0; ib < g_switch_num_ibs; ib++) {\
        ifcs_attr_t local_ifcs_attr;\
        ifcs_attr_t_init(&local_ifcs_attr);\
        ifcs_attr_t_id_set(&local_ifcs_attr, IFCS_IB_ATTR_MAX_ETH_PORTS);\
        ifcs_rc = ifcs_ib_attr_get(node_id, ib, 1, &local_ifcs_attr, &actual_attr_count);\
        if(IFCS_STATUS_REASON(ifcs_rc) == IFCS_NOTFOUND) {\
            continue;\
        }\
        if(ifcs_rc != IFCS_SUCCESS || (actual_attr_count == 0)) {\
            sai_rc = ifcs_to_sai_translate_status(ifcs_rc);\
            goto cleanup;\
        }

#define ITERATE_IB_END     } \
}

 /*  */

#define ITERATE_DTM_IB_START(node_id, ib) \
{\
    UNUSED(node_id);\
    for(ib = 0; ib < g_switch_num_ibs; ib++) {\
        if (g_switch_active_dtm_ibs_bm[ib] == false) {\
            continue;\
        }\

#define ITERATE_DTM_IB_END     } \
}


/* BAM assumptions */
#define ISAI_RECIRC_AUX_LOSSLESS_RESERVED_SIZE_BYTES   1518.0
#define BAM_QUEUE_RESERVED_SIZE_IN_BYTES         1518.0
#define BAM_QUEUE_DEFAULT_SHARED_DYNAMIC_THRESHOLD_FACTOR   IFCS_DTL_FACTOR_TWO
#define AVG_RES_PER_LOSSY_BAM_QUEUE_BYTES           1518.0
#define AVG_RES_PER_LOSSLESS_BAM_QUEUE_BYTES        1518.0
#define MAX_NUM_LOSSLESS_BAM_QUEUES                 4

#define BAM_BUFFER_PART_DEFAULT_LL_LINK_LEN_PROF     IFCS_LL_INFLIGHT_LINK_LENGTH_PROFILE_V_LONG
#define BAM_BUFFER_PART_DEFAULT_LL_TUNING_FACTOR     100
#define BAM_BUFFER_PART_DEFAULT_LL_OVERSUB_FACTOR_TH 200
#define BAM_BUFFER_PART_DEFAULT_LL_SHARED_PART_PERCENT  40

#define DTM_BUFFER_PART_DEFAULT_LL_TUNING_FACTOR     100

/*
 * Used to mark the BAM/DTM lossless inflight tuning factor as "not
 * explicitly configured by the user". Used to let the explicit tuning factor
 * knobs (IVM_SAI_DP_PARAM_B_1_LL_1 / IVM_SAI_DP_PARAM_D_0_LL_1) take priority
 * over the XOFF auto-tune knob (IVM_SAI_DP_PARAM_D_1). Resolved to the static
 * default before the tuning factors are consumed.
 */
#define ISAI_LL_INFLIGHT_TUNING_FACTOR_UNSET         0xFFFFFFFFu

#define BAM_QUEUE_DEFAULT_WDRR_WEIGHT                   1

/******* TL CONSTANTS *******/
#define NUM_CG_QUEUES_TL              6

/******* K2 CONSTANTS *******/
#define NUM_CG_QUEUES_K2              2

/******* TL10 CONSTANTS *******/
#define NUM_CG_QUEUES_TL10            8




#define ISAI_ACL_EGRESS_TABLE_PRIO_MAX           7
#define ISAI_ACL_TABLE_MAX_PRIORITY              15
#define ISAI_ACL_TABLE_PRE_INGRESS_MIN_PRIORITY  10
#define ISAI_ACL_TABLE_PRE_INGRESS_MAX_PRIORITY  15

#define IFCS_GET_ISAI_SHIM_COUNTER_OBJ_TYPE(value)  \
    ( ((value) >> 25) & 0x7Fu )

#define IFCS_IS_64BIT_VALUE_BITS_SET(value)  \
    ( ((value) & 0xFE00000000ULL) == 0xFE00000000ULL )

typedef struct _sai_shim_lag_mem_info_s {
    ifcs_handle_t   lag_hdl;
    ifcs_handle_t   port_hdl;
} sai_shim_lag_mem_info_t;
/*
 * The following are declared as globals as they do not change after
 * boot time and so they need not be retreived from IFCS every time
 * isai code needs it.
 * These globals are initialized in ifcs_sai_datapath_globals_init
 */
extern int8_t  g_pgindex_to_ps_id_mapping[ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT];

extern uint32_t g_watson_queueid_ref_count_list[ISAI_MAX_NUM_FP_QUEUES_PER_PORT];

typedef enum switch_queue_type_s {
    SWITCH_QUEUE_TYPE_INVALID = -1,
    SWITCH_QUEUE_TYPE_CPU = 0,
    SWITCH_QUEUE_TYPE_AUX = 1,
    SWITCH_QUEUE_TYPE_RECIRC = 2,
    SWITCH_QUEUE_TYPE_FP = 3,
    SWITCH_QUEUE_TYPE_CG = 4
} switch_queue_type_t;

typedef struct sai_switch_queue_info_s {
    uint32_t reserved_size;                   // Reserved Size of the queues in cells or bytes
    uint32_t uc_dtl;                          // Dynamic threshold limit factor for UC traffic
    uint32_t nonuc_dtl;                       // Dynamic threshold limit factor for non UC traffic
    uint32_t uc_shared_buffer_max_limit;      // max limit for the queue on access to
                                              // actual shared buffer access for UC traffic=
                                              //       Max(uc_shared_buffer_max_limit,
                                              //               shared space determined by uc_dtl)
    uint32_t nonuc_shared_buffer_max_limit;   // max limit for the queue on access to
                                              // actual shared buffer access for non UC traffic =
                                              //       Max(nonuc_shared_buffer_max_limit,
                                              //               shared space determined by uc_dtl)
    uint32_t resume_offset;
    uint32_t user_entered_values_flag;
    bool reserved_size_in_bytes_flag;         // Flag to indicate whether reserved size
                                              // is in bytes or cells
} isai_switch_queue_info_t;

typedef struct _sai_switch_notification_s {
    sai_switch_state_change_notification_fn on_switch_state_change;
    sai_fdb_event_notification_fn           on_fdb_event;
    sai_port_state_change_notification_fn   on_port_state_change;
    sai_switch_shutdown_request_notification_fn          on_switch_shutdown_request;
    sai_packet_event_notification_fn        on_packet_event;
    sai_tam_event_notification_fn           on_tam_event;
    sai_bfd_session_state_change_notification_fn on_bfd_session_state_event;
    sai_switch_asic_sdk_health_event_notification_fn  on_switch_asic_sdk_health_event;
    sai_queue_pfc_deadlock_notification_fn  on_pfc_dl_event;
} sai_switch_notification_t;

/*
 * Reserved size values passed in the by user via ivm.sai.datapath.config.yaml
 * These values are used in datapath setup while creating DTM and BAM buffer
 * partitions. We are getting these values from a config file so that the user,
 * if needed can tune these values and this also makes ISAI datapath code
 * chip independent.
 */
typedef struct isai_switch_ib_reserved_sizes_s {
    /* All lossy */
    uint32_t dtm_all_lossy_default_size; // PARAM_P0_1_LS
    uint32_t dtm_all_lossy_non_fp_size;  // PARAM_P0_1_ALS
    uint32_t bam_all_lossy_size;         // PARAM_P0_0_LS

    /* Lossy, lossless combination */
    uint32_t dtm_lossy_default_size; // PARAM_P1_1_LS
    uint32_t dtm_lossy_non_fp_size;  // PARAM_P1_1_ALS
    uint32_t dtm_ll_default_size;    // PARAM_P1_1_LL
    uint32_t dtm_ll_non_fp_size;     // PARAM_P1_1_ALL
    uint32_t bam_lossy_size;         // PARAM_P1_0_LS
    uint32_t bam_ll_size;            // PARAM_P1_0_LL
} isai_switch_ib_reserved_sizes_t;

typedef struct isai_bam_queue_config_s {
    uint32_t threshold_mode;
    uint32_t threshold_value;
} isai_bam_queue_config_t;

typedef struct isai_switch_bam_queue_config_s {
    isai_bam_queue_config_t ll_bam_queue;
    isai_bam_queue_config_t lossy_bam_queue;
} isai_switch_bam_queue_config_t;

typedef struct isai_switch_bam_buffer_part_config_s {
    uint32_t ll_inflight_link_length_prof;
    uint32_t ll_inflight_tuning_factor;
    uint32_t ll_oversub_factor_th;
    uint32_t ll_shared_part_percent;
} isai_switch_bam_buffer_part_config_t;

typedef struct isai_switch_dtm_buffer_part_config_s {
    uint32_t ll_inflight_tuning_factor;
} isai_switch_dtm_buffer_part_config_t;

typedef struct hostif_trap_type_pkt_sz_s {
    uint32_t trap_type;
    uint32_t pkt_sz;
    struct hostif_trap_type_pkt_sz_s *next;
} hostif_trap_type_pkt_sz_t;

typedef struct isai_switch_hostif_trap_config_s {
    uint32_t trap_type_packet_size_count;
    hostif_trap_type_pkt_sz_t *trap_type_cfg;
} isai_switch_hostif_trap_config_t;

typedef struct isai_shim_mod_info_s {
    bool        mod_enable;
    bool        mod_configured;
    uint32_t        mod_cpu_queue;
    ifcs_handle_t   mod_route_trap;
    ifcs_handle_t   mod_fdb_trap;
    ifcs_handle_t   mod_acl_trap;
    ifcs_handle_t   mod_policer_trap;
    ifcs_handle_t   mod_bdc_trap;
    ifcs_handle_t   bdc_collector_hdl;
    ifcs_handle_t   bdc_cs_hdl;
    ifcs_handle_t   bdc_viz_hdl;
    bool            bdc_enable;
} isai_shim_mod_info_t;

typedef struct _isai_tunstat_resources_s {
    int32_t    ingress_size;
    int32_t    egress_size;
    uint32_t    ingress_configured:1;
    uint32_t    egress_configured:1;
} isai_tunstat_resources_t;

/* Structure to hold the ACL table resources count */
typedef struct _isai_acl_tbl_resources_s {
    int32_t    num_entries;
    int32_t    num_counters;
    int32_t    num_meters;
} isai_acl_tbl_resources_t;

/* Structure to hold the ACL table resources count */
typedef struct _isai_acl_based_feature_parameters_s {
    int32_t    enable;
    int32_t    ace_priority;
} isai_acl_based_feature_parameters_t;

/*
 * Extended parameter block for port storm control ONLY.
 *
 * IMPORTANT (warmboot): isai_acl_based_feature_parameters_t above is embedded in
 * several feature parameter blocks that participate in warmboot; growing that
 * struct would change its size/layout and break warm upgrade. So port storm
 * control - which needs a third field - uses this separate, dedicated type
 * instead of extending the shared one.
 *
 * The config key SAI_KEY_NEED_ACL_FOR_PORT_STORM_CONTROL (IVM_SAI_PARAM_A005F)
 * is a comma separated list "enable[,acl_priority[,param1]]" parsed by
 * isai_config_parse_acl_based_feature_parameters_extended():
 *   enable       - token0. 0 => native (non-ACL, TL10+) storm control,
 *                          1 => legacy ACL based storm control.
 *   acl_priority - token1. When ACL based, the requested IFCS ACL table
 *                          priority (1..15). ISAI_ACL_BASED_FEATURE_PARAM_DEF_VAL
 *                          (-1, "unset") => auto-assign a free priority.
 *   param1       - token2. Feature-specific third parameter:
 *                    - port_storm_control_parameters: native packet-type mapping
 *                      variant (see ISAI_PORT_STORM_CTRL_NATIVE_*).
 *                    - pfc_wd_egr_acl_parameters: SDK_PFC_WD_ENABLE (IVM A0044).
 *
 * The index enum isai_acl_based_feature_parameters_extended_idx_t below MUST
 * stay in lock-step with this field order (the parser uses it as the token index).
 */
typedef struct _isai_acl_based_feature_parameters_extended_s {
    int32_t    enable;
    int32_t    acl_priority;
    uint32_t   param1;
} isai_acl_based_feature_parameters_extended_t;

#define ISAI_SAI_PFC_WD_ENABLED(sw_db) \
    ((sw_db).pfc_wd_egr_acl_parameters.param1 == 1)

#define ISAI_ACL_TBL_RESOURCE_DEF_VAL    (-1)
#define ISAI_ACL_BASED_FEATURE_PARAM_DEF_VAL  (-1)

/* Port storm-control (SAI_KEY_NEED_ACL_FOR_PORT_STORM_CONTROL) parameter helpers.
 * The config is a comma separated list mapped onto
 * isai_acl_based_feature_parameters_extended_t:
 *   token0 (enable)      : 0 -> native (non-ACL) storm control, 1 -> legacy ACL based
 *   token1 (acl_priority): when ACL based, the ACL table priority (1..15)
 *   token2 (param1)      : native packet-type mapping behavior selector, one of
 *                          ISAI_PORT_STORM_CTRL_NATIVE_{SAI,SONIC}_BEHAVIOR below.
 *
 * param1 native packet-type -> storm-control offset mapping behaviors:
 *   ISAI_PORT_STORM_CTRL_NATIVE_SAI_BEHAVIOR   (default; config "0"/"0,0"/"0,0,0")
 *       - SAI-standard mapping: the flood policer also governs unknown IP/L2
 *         multicast; the multicast policer governs known IP/L2 multicast.
 *   ISAI_PORT_STORM_CTRL_NATIVE_SONIC_BEHAVIOR (config "0,0,1")
 *       - SONiC-style mapping: the flood policer governs unknown unicast only;
 *         the multicast policer governs unknown IP/L2 multicast.
 */
#define ISAI_PORT_STORM_CTRL_ACL_TBL_PRIO_MIN      1
#define ISAI_PORT_STORM_CTRL_ACL_TBL_PRIO_MAX      15
#define ISAI_PORT_STORM_CTRL_NATIVE_SAI_BEHAVIOR   0
#define ISAI_PORT_STORM_CTRL_NATIVE_SONIC_BEHAVIOR 1

/* Enum to indicate the member sequence for
 * isai_acl_tbl_resources_t structure. This is
 * expected to be inline with the structure. */
typedef enum _isai_acl_tbl_resources_e {
    ISAI_ACL_TBL_RESOURCE_START,
    ISAI_ACL_TBL_RESOURCE_ENTRIES = ISAI_ACL_TBL_RESOURCE_START,
    ISAI_ACL_TBL_RESOURCE_COUNTERS,
    ISAI_ACL_TBL_RESOURCE_METERS,
    ISAI_ACL_TBL_RESOURCE_END = ISAI_ACL_TBL_RESOURCE_METERS
} isai_acl_tbl_resources_idx_t;


typedef enum _isai_out_pp_drop_reasons_e {
    SAI_OUT_PP_DROP_REASON_START,
    SAI_OUT_PP_DROP_REASON_ISOLATION_GROUP = SAI_OUT_PP_DROP_REASON_START,
    SAI_OUT_PP_DROP_REASON_ACL,
    SAI_OUT_PP_DROP_REASON_END
} isai_out_pp_drop_reasons_t;


typedef enum _isai_in_drop_reasons_e {
    SAI_IN_PP_DROP_REASON_START,
    SAI_IN_PP_DROP_REASON_FDB_UC_DISCARD = SAI_IN_PP_DROP_REASON_START,
    SAI_IN_PP_DROP_REASON_TTL,
    SAI_IN_PP_DROP_REASON_ACL,
    SAI_IN_PP_DROP_REASON_BLACKHOLE_ROUTE,
    SAI_IN_PP_DROP_REASON_UC_DIP_MC_DMAC,
    SAI_IN_PP_DROP_REASON_DIP_LINK_LOCAL,
    SAI_IN_PP_DROP_REASON_SIP_LINK_LOCAL,
    SAI_IN_PP_DROP_REASON_DIP_LOOPBACK,
    SAI_IN_PP_DROP_REASON_SIP_CLASS_E,
    SAI_IN_PP_DROP_REASON_END
} isai_in_drop_reasons_t;

extern ifcs_u32_list_t g_ing_drop_reason_to_counter_list;
extern ifcs_u32_list_t g_eg_drop_reason_to_counter_list;
extern ifcs_u32_list_t g_ing_user_dc_hdl;
extern ifcs_u32_list_t g_eg_user_dc_hdl;

/* Enum to indicate the member sequence for
 * isai_acl_tbl_resources_t structure. This is
 * expected to be inline with the structure. */
typedef enum _isai_acl_based_feature_parameters_e {
    ISAI_ACL_BASED_FEATURE_PARAM_START,
    ISAI_ACL_BASED_FEATURE_PARAM_ENABLE = ISAI_ACL_BASED_FEATURE_PARAM_START,
    ISAI_ACL_BASED_FEATURE_PARAM_ACE_PRIORITY,
    ISAI_ACL_BASED_FEATURE_PARAM_END = ISAI_ACL_BASED_FEATURE_PARAM_ACE_PRIORITY
} isai_acl_based_feature_parameters_idx_t;

/*
 * Token/field index for isai_acl_based_feature_parameters_extended_t (port
 * storm control). Order MUST match the struct field order exactly:
 *   [0] ENABLE       -> enable
 *   [1] ACL_PRIORITY -> acl_priority
 *   [2] PARAM1       -> param1
 * _START/_END bound the parser walk loop (inclusive).
 */
/* Enum for isai_acl_based_feature_parameters_extended_t; must match field order. */
typedef enum _isai_acl_based_feature_parameters_extended_e {
    ISAI_ACL_BASED_FEATURE_EXT_PARAM_START,
    ISAI_ACL_BASED_FEATURE_EXT_PARAM_ENABLE = ISAI_ACL_BASED_FEATURE_EXT_PARAM_START,
    ISAI_ACL_BASED_FEATURE_EXT_PARAM_ACL_PRIORITY,
    ISAI_ACL_BASED_FEATURE_EXT_PARAM_PARAM1,
    ISAI_ACL_BASED_FEATURE_EXT_PARAM_END = ISAI_ACL_BASED_FEATURE_EXT_PARAM_PARAM1
} isai_acl_based_feature_parameters_extended_idx_t;

/* Structure to hold the ACL Port Group read from the config file
 */
typedef struct isai_acl_pg_config_s {
    uint32_t mode;
    uint32_t lane_num[ISAI_ACL_PG_MAX_COUNT * IFCS_SAI_MAX_IBS][IFCS_SAI_MAX_PORTS_PER_NODE];
    uint32_t lane_count[ISAI_ACL_PG_MAX_COUNT * IFCS_SAI_MAX_IBS];
} isai_acl_pg_config_t;


/* Structure to hold the policer rate precision type for each bindpoints
 * It supports below types,
 * IFCS_ACL_METER_PRECISION_TYPE_FLOOR (Default)
 * IFCS_ACL_METER_PRECISION_TYPE_ROUND */
typedef struct _isai_policer_rate_precision_s {
    bool    mirror_policer_rate_precision;
    bool    copp_policer_rate_precision;
    bool    sflow_policer_rate_precision;
    bool    stormctl_policer_rate_precision;
    bool    acl_policer_rate_precision;
} isai_policer_rate_precision_t;

/* Enum to indicate the member sequence for
 * isai_policer_rate_precision_t structure. This is
 * expected to be inline with the structure. */
typedef enum _isai_policer_rate_precision_e {
    ISAI_POLICER_RATE_START,
    ISAI_POLICER_RATE_MIRROR = ISAI_POLICER_RATE_START,
    ISAI_POLICER_RATE_COPP,
    ISAI_POLICER_RATE_SFLOW,
    ISAI_POLICER_RATE_STORMCTL,
    ISAI_POLICER_RATE_ACL,
    ISAI_POLICER_RATE_END = ISAI_POLICER_RATE_ACL
} isai_policer_rate_precision_idx_t;

typedef struct _isai_switch_hash_ds_s {
    uint32_t                 ecmp_hash_seed;
    sai_hash_algorithm_t     ecmp_hash_algo;
    uint8_t                  ecmp_hash_offset;
    bool                     ecmp_symmetric_hash;
    uint8_t                  lag_hash_offset;
    uint32_t                 lag_hash_seed;
    sai_hash_algorithm_t     lag_hash_algo;
    bool                     lag_symmetric_hash;
}isai_switch_hash_ds_t;


typedef struct pkt_trm_info_s {
    ifcs_handle_t   in_acl_tbl_hdl;
    ifcs_handle_t   eg_acl_tbl_hdl;
    ifcs_handle_t   in_acl_hdls[IFCS_SAI_MAX_IBS]; /* Ingress ACL table is node scoped */
    ifcs_handle_t   eg_acl_hdls[IFCS_SAI_MAX_IBS]; /*Egress ACL table is per IB*/
    ifcs_handle_t   in_match_profile_hdl;
    ifcs_handle_t   in_action_profile_hdl;
    ifcs_handle_t   eg_action_profile_hdl;
    ifcs_handle_t   eg_match_profile_hdl;
    ifcs_handle_t   comparator_grp_hdl;
    ifcs_handle_t   comparator_hdl;
    uint32_t        ref_count;
} pkt_trim_info_t;

typedef struct ars_global_info_s {
    bool     configure_ar;           /* AR can be configured */
    bool     queue_groups_configured; /* ARS queue group profiles are configured */
    uint32_t queue_group_count;      /* Number of ARS queue group profiles configured */
    bool     ar_mod_global_enabled;  /* AR MOD Global is enabled in IFCS */
    isai_id_alloc_t *local_ars_id_alloc; /* Allocator for local ARS destination ids */
    uint32_t ars_nhg_count;          /* Number of ARS NHG profiles created */
    ifcs_handle_t default_ar_group_hdl; /* Default AR queue group handle (all queues) */
} ars_global_info_t;

#define ISAI_NEXTHOP_FLEX_POOL_MODE_FWD_ONLY      0  /* count forwarded only (default) */
#define ISAI_NEXTHOP_FLEX_POOL_MODE_FWD_AND_DROP  1  /* count forwarded and dropped */

/* Egress nexthop flex pool (A0092) configuration */
typedef struct _isai_nexthop_flex_pool_config_s {
    uint32_t size;         /* pool size */
    uint32_t counter_mode; /* ISAI_NEXTHOP_FLEX_POOL_MODE_* */
} isai_nexthop_flex_pool_config_t;

typedef struct _switch_db_info_s {
    bool                      is_created;
    sai_switch_profile_id_t   profile_id;
    sai_switch_notification_t notification_callbacks;
    uint32_t                  route_table_size;
    uint32_t                  neighbor_table_size;
    sai_mac_t                 device_mac;
    bool                      restart_warm;
    bool                      uninit_data_plane_on_removal;
    pthread_t                 *p_shell_pthread;
    bool                      bdc_enable;
    uint32_t                  sai_queue_type;
    bool                      hdc_enable;
    bool                      ipv6_ingress_mirror_enable;
    bool                      ipv6_egress_mirror_enable;
    uint32_t                  pfc_eacl_table_depth_enc_val;
    uint32_t                  mirror_sample_rate;
    int32_t                   nrz_ports_sig_detect_mode_tl7;
    uint32_t                  rif_stat_scale_in;
    uint32_t                  rif_stat_scale_eg;
    uint32_t                  rif_mac_mode;
    uint32_t                  pfcwd_eg_acl_counter_entries;
    isai_switch_queue_info_t cpu_queue[MAX_NUM_CPU_QUEUES];
    isai_switch_queue_info_t aux_queue[ISAI_MAX_NUM_AUX_QUEUES_PER_PORT];
    isai_switch_queue_info_t recirc_queue[ISAI_MAX_NUM_RECIRC_QUEUES_PER_PORT];
    char                            dp_config_file[
        ISAI_MAX_KV_PAIR_VALUE_STR_LEN];
    isai_switch_ib_reserved_sizes_t reserved_sizes[IFCS_SAI_MAX_IBS];
    char                      uds_path_name[ISAI_MAX_KV_PAIR_VALUE_STR_LEN];
    bool bam_queue_stat_present[IFCS_BAM_QUEUE_STATS_ID_ALL];
    bool check_bam_queue_stats;
    bool ipps_cm_stat_present[IFCS_IPPS_CM_STATS_ID_ALL];
    bool check_ipps_cm_stats;
    uint32_t max_ports_per_ib;
    uint32_t next_hop_group_type;
    uint32_t next_hop_group_no_of_slots;
    uint32_t reserved_ing_acl_priorities_bmp;
    uint32_t reserved_egr_acl_priorities_bmp;
    uint32_t cpu_sp_fwd_mode;
    bool     cpu_netdev_rif_create_enable;
    uint32_t mcast_snoop_capability;
    bool     pre_ingress_acl_allow_dst_ipv6;
    bool     pre_ingress_acl_disable_stats;
    bool     defvr_fallback_enable;
    isai_switch_bam_queue_config_t bam_queue_config;
    isai_switch_bam_buffer_part_config_t ll_bam_buffer_part_config[IFCS_SAI_MAX_IBS];
    isai_switch_dtm_buffer_part_config_t ll_dtm_buffer_part_config[IFCS_SAI_MAX_IBS];
    bool       ll_inflight_xoff_auto_tune;
    uint32_t   ptf_drop_counter_l2l3_flag;
 /*  */
    bool dc_acl_drop_control_enable;
    uint32_t forward_flex_pool_size;
    isai_nexthop_flex_pool_config_t nexthop_flex_pool_config;
    uint32_t nexthop_counter_eligible_mask;
    bool acl_match_ipv6_traffic_class;
    isai_switch_hostif_trap_config_t hostif_trap_config;
    /** YAML IVM_SAI_PARAM_A0084: per-VLAN hostif trap enhancement (default false). */
    bool                      per_vlan_hostif_trap_enhanced;
    bool is_capab_query_custom_stat;
    int isai_logging_mode;
    uint32_t   max_port_and_storm_policers_per_ib;
    bool       multi_bit_error_check; /* 0 - Disable(default), 1 - Enable */
    bool    acl_match_ing_l2vni_id;
    bool    acl_match_sysport_only;
    bool acl_ip_type_disallow_arp;
    int  acl_ingress_l3_tbl_size;
    uint32_t   route_to_rif_hostif_trap;
    bool fdb_flush_bulk_notif;
    uint32_t   host_route_preference;
    bool    copp_node_rate_limiter;
    bool       port_speed_4_lane;
    uint32_t    bpn_wait_time;
    int32_t     bpn_thread_prio;
    int32_t     bpn_sched_policy;
    bool        evpn_vxlan_custom_enable;
    bool        evpn_vlan_bcast_flood_group_ctrl;
    bool            ingress_sflow_truncate;
    isai_shim_mod_info_t    mod_info;
    isai_acl_tbl_resources_t    acl_egr_l3_v4_tbl_resource;
    isai_acl_tbl_resources_t    acl_egr_l3_v6_tbl_resource;
    isai_acl_tbl_resources_t    acl_ingr_l3_v4_tbl_resource;
    isai_acl_tbl_resources_t    acl_ingr_l3_v6_tbl_resource;
    isai_acl_tbl_resources_t    acl_ingr_v4_flowstat_tbl_resource;
    isai_acl_tbl_resources_t    acl_egr_v4_flowstat_tbl_resource;
    isai_acl_tbl_resources_t    acl_ars_disable_tbl_resource;
    isai_acl_tbl_resources_t    acl_exact_match_tbl_resource;
    bool        hostif_trap_exclude_list_meter_type;
    uint32_t    hostif_exclude_port_match_count;
    isai_tunstat_resources_t    l3_tunstat_resource;
    isai_tunstat_resources_t    l2_tunstat_resource;
    uint32_t                    bam_queue_wred_weight_lossless;
    uint32_t                    bam_queue_wred_weight_lossy;
    uint8_t                     number_of_queues_per_port;
    bool                        enable_mirror_on_gre;
    uint32_t                    vxlan_tunnel_term_mode;
    isai_acl_based_feature_parameters_extended_t pfc_wd_egr_acl_parameters;
    isai_acl_based_feature_parameters_t pfc_fc_egr_acl_parameters;
    isai_acl_based_feature_parameters_t rif_loopback_drop_egr_acl_parameters;
    isai_acl_based_feature_parameters_t bridge_port_isg_egr_acl_parameters;
    isai_acl_based_feature_parameters_t mirror_egr_acl_parameters;
    isai_acl_based_feature_parameters_t sflow_egr_acl_parameters;
    isai_acl_based_feature_parameters_t ecn_stats_enable_on_pfcwd_tbl;
    isai_acl_tbl_resources_t    hostif_acl_tbl_resource;
    bool                        create_decap_dscp_acl;
    int32_t                     decap_dscp_acl_tbl_priority;
    uint32_t                    allow_multi_nh_ars;
    uint8_t                     unresolved_nbr_action;
    isai_policer_rate_precision_t policer_rate_precision;
    bool                        is_switch_remove_in_progress;
    bool                        isai_bypass_deinit;
    bool                        drop_on_svi_rif_unresolve;
    bool                        evpn_mh_p2p;

    bool                        fastreset_in_progress;
    uint32_t                    vlan_metadata_resource;
    uint32_t                    rif_metadata_resource_ingress;
    uint32_t                    rif_metadata_resource_egress;
    bool                        common_lossless_lossy_enabled;
    bool                        init_hash_with_sdk_defaults;
    bool                        is_hash_init_done_with_defaults;
    bool                        ipg_stats_ing_acl_table_enable;
    bool                        ipmc_rpf_fail_trap_enable;
    bool                        pbr_no_drop_override;
    isai_acl_based_feature_parameters_t protected_port_isg_egr_acl_parameters;
    isai_acl_based_feature_parameters_t bfd_hw_lkp_ttl_egr_acl_parameters;
    bool                        rif_out_err_pkt_stats;
    char                        acl_config_file[
        ISAI_MAX_KV_PAIR_VALUE_STR_LEN];
    isai_acl_pg_config_t acl_pg_cfg;
    /* Port storm control behaviour, parsed from the IVM config key
     * SAI_KEY_NEED_ACL_FOR_PORT_STORM_CONTROL ("enable[,acl_priority[,param1]]").
     * Replaces the earlier boolean acl_based_port_storm_control: enable==1 is
     * the old "true" (legacy ACL path); enable==0 is native storm control and
     * additionally carries the packet-type mapping variant in param1, and
     * (when the ACL path is taken) the explicit ACL table priority in
     * acl_priority. Uses the dedicated extended type (NOT the shared
     * isai_acl_based_feature_parameters_t) to avoid changing that shared,
     * warmboot-embedded struct's layout. */
    isai_acl_based_feature_parameters_extended_t port_storm_control_parameters;
    uint32_t                    acl_ingress_neighbor_metadata; //0-Egress, 1-Ingress, 2-Ingress & Egress
    bool                        tc_to_q_multicast_present;
    isai_switch_hash_ds_t       hash_ds;
    ifcs_bool_t                 hecmp_enabled;
    pkt_trim_info_t             pkt_trim_info;
    bool                        enable_packet_trim_in_acl_counter;
    bool                        packet_trim_copp_table_enable;

    uint32_t                    enable_hashing_on_vxlan_inner_fields;
    ifcs_bool_t                 srv6_enabled;
    /* srv6_active set to true if atleast one my_sid_entry created, false otherwise */
    ifcs_bool_t                 srv6_active;
    bool                        ipv6_vxlan_enable;
    isai_acl_based_feature_parameters_t efd_feature_parameters;
    uint32_t                    max_l2vni_stats;
    sai_object_id_t             default_vlan_oid;
    sai_object_id_t             default_vrf_oid;
    ifcs_handle_t               default_vlan_rif_handle;
    uint32_t                    switch_max_learned_addresses;
    bool                        switch_max_learned_addresses_cfg_present;
    /** SAI-visible value for SAI_SWITCH_ATTR_MAX_LEARNED_ADDRESSES (0 = unlimited). */
    uint32_t                    switch_max_learned_addresses_sai_mirror;
    bool                        switch_max_learned_addresses_sai_mirror_valid;
    /*
     * Snapshot of IFCS_NODE_ATTR_L2_ENTRY_MAX_LEARN_COUNT from node attr GET
     * before SAI first programs the knob (used to map SAI unlimited to IFCS).
     */
    uint32_t                    switch_ifcs_l2_max_learn_baseline;
    bool                        switch_ifcs_l2_max_learn_baseline_valid;
    bool                        fboss_enable;
    /*
     * fdb_mac_move_as_age_and_learn false - default behaviour
     * true - In some Nos(fboss) when mac moves, a mac age request is sent on Old port
     *         on which mac was learnt, followed by mac learn request on the new port
     *         on which the mac moved to.
     */
    bool                        fdb_mac_move_as_age_and_learn;

    bool                        force_meter_as_shaper_on_cpu_queues;
    bool                        evpn_mh_vlan_df_enable;
    /*
     * IVM_SAI_PARAM_A0080 / SAI_KEY_UDT_STRICT_MODE
     *
     * IVM_SAI_PARAM_A0080 : False - hybrid mode
     * In this mode, we prefer to use UDT oid for trapping packets to CPU.
     * But if the UDT oid is not set, we fallback to the global trap handle.
     * note that: this is not a SAI compliant mode.
     * Note: bydefault we are in hybrid mode.
     *
     * IVM_SAI_PARAM_A0080 : true - strict mode
     *
     * we only trap the packet to CPU if a valid UDt is configured.
     * i.e Even if the packet action is TRAP, COPY, or LOG, we will not
     * trap the packet to CPU if the UDT oid is NULL or not set.
     */
    bool                        udt_strict_mode;
    bool                        disable_ifcs_stats_polling;
    bool                        disable_drop_dmac_equal_smac;
    bool                        skip_host_route;
    bool                        disable_nhg_member_randomization;
    bool                        sdk_pfc_wd_node_enabled;
    bool                        init_copp_acl_table_with_global_ars;
    uint32_t                    nhg_reserved_for_local_ars;
    bool                        create_all_nhg_with_local_ars;
    ars_global_info_t           ars_global_info;
} switch_db_info_t;



typedef struct  isai_shim_qos_info_s {
    sai_object_id_t oid;            /* SAI_OBJECT  id */
    ifcs_node_id_t  node_id;        /// valid for objects with corresponding IFCS
    ifcs_handle_t   handle;         /// valid for objects with corresponding IFCS
    ifcs_handle_t   counter_handle; /// valid for objects with counter, today it is Policer

    /* User configured SAI attr count and list for this SAI object*/
    uint32_t        attr_count;
    sai_attribute_t attr_list[ISAI_QOS_ATTR_MAX];

    /* Bindpoint list has the list of queues to
     * which this scheduler/buffer* is attached to.
     * when any scheduler attr is updated,
     * walk through the bind-point-list and update each queue */
    uint32_t        bind_point_list_count;
    sai_object_id_t bind_point_list[ISAI_QOS_BIND_MAX];
} isai_shim_qos_info_t;

#define PORT_TO_SAI_OID(port_oid) ( * ( (sai_object_id_t *) (void *) (&(port_oid)) ) )
#define PORT_SERDES_TO_SAI_OID(port_serdes_oid) ( * ( (sai_object_id_t *) (void *) (&(port_serdes_oid)) ) )
#define SAI_TO_PORT_OID(sai_oid)  ( * ( (ifcs_sai_shim_oid_t *) &(sai_oid) ) )
#define SAI_TO_PORT_SERDES_OID(sai_oid)  ( * ( (ifcs_sai_shim_oid_t *) &(sai_oid) ) )
#define SAI_TO_PORT_OID_P(sai_oid)  ((ifcs_sai_shim_oid_t *) &(sai_oid))
/*
 * N.B: For port module devport ID is stored in isai_ds_hdl
 */
#define PORT_OID_P_TO_DEVPORT(port_oid_p) \
        ( (ifcs_devport_t) (((ifcs_sai_shim_oid_t *) (port_oid_p))->isai_ds_hdl) )

/*
 * N.B: For port serdes module devport ID is stored in isai_ds_hdl
 */
#define PORT_SERDES_OID_P_TO_DEVPORT(port_serdes_oid_p) \
        ( (ifcs_devport_t) (((ifcs_sai_shim_oid_t *) (port_serdes_oid_p))->isai_ds_hdl) )

 /**/

#define IFCS_SAI_DEFAULT_MTU            1514

#define MAX_NUM_SPEEDS                  10
#define MAX_NUM_FEC_MODES               4

#define ISAI_NUM_PG                     8
#define ISAI_MAX_TAM_OBJECTS_PER_PORT   256

#define ISAI_IS_TL7_DEVICE_TYPE(_device_type)  ( \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_1) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_2) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_3) || \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX7_4)    \
        )

#define ISAI_IS_TL10_DEVICE_TYPE(_device_type)  ( \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX10_1) \
        )

#define ISAI_IS_T100_DEVICE_TYPE(_device_type)  ( \
        ( _device_type == IFCS_DEVICE_TYPE_TERALYNX100_1) \
        )

typedef struct _sai_shim_port_info_s
{

    /* top level */
    ifcs_bool_t                 exists;
    ifcs_sai_shim_oid_t         sai_port_oid;
    ifcs_node_id_t              node_id;
    ifcs_handle_t               sysport_hdl;

    /* Devport related, IFCS params */
    ifcs_devport_type_t         type;
    ifcs_devport_t              devport;
    uint32_t                    isg_num; // iSAI isg number
                                         // 0-31 for tl7, 0-63 for tl10
    uint32_t                    start_lane, num_lanes;
    ifcs_devport_fec_mode_t     fec_mode;

    /* Hostif related */
    bool                        has_hostif_name;
    //char                        hostif_name[32];
    uint32_t                    hostif_name_max_length; //Max length for hostif_name. =SAI_HOSTIF_NAME_SIZE
    char                        *hostif_name;

    /* Auto-Neg */
    uint32_t                    num_advertized_speeds;
    //uint32_t                    advertized_speeds[MAX_NUM_SPEEDS];
    uint32_t                    advertized_speeds_list_max_index;    // Max size of advertized speed list. =MAX_NUM_SPEEDS
    uint32_t                    *advertized_speeds_list;
    uint32_t                    num_advertized_fec_modes;
    //sai_port_fec_mode_t         advertized_fec_modes[MAX_NUM_FEC_MODES];
    uint32_t                    advertized_fec_modes_list_max_index; // Max size of advertized speed list. =MAX_NUM_FEC_MODES
    sai_port_fec_mode_t         *advertized_fec_modes_list;
    uint32_t                    num_advertized_if_types;
    //sai_port_interface_type_t   advertized_if_types[SAI_PORT_INTERFACE_TYPE_MAX];
    uint32_t                    advertized_if_types_list_max_index; // Max size of advertized if types list. =SAI_PORT_INTERFACE_TYPE_MAX
    sai_port_interface_type_t   *advertized_if_types_list;

    /* PFC related */
    ifcs_devport_pfc_mode_t     pfc_mode;
    ifcs_bool_t                 is_ipg_created_by_default;
    ifcs_bool_t                 is_ipg_created_by_user;
    ifcs_bool_t                 is_queue_created_by_default;
    ifcs_bool_t                 is_queue_created_by_user;
    //sai_object_id_t             pg_oids[ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT];
    uint32_t                    pg_oids_list_max_index;            // Max size of pg oids list. =ISAI_MAX_SUPPORTED_IPG_QUEUE_COUNT
    sai_object_id_t             *pg_oids_list;
    uint32_t                    queue_oids_list_max_index;         // Max size of queue oids list. =MAX_NUM_CPU_QUEUES
    sai_object_id_t             *queue_oids_list;

    /* Scheduler related */
    sai_object_id_t             scheduler_oid;

    ifcs_bool_t                 is_datapath_inited;
    /* SDK PFC WD: queues with pending DLDR enable before datapath_init_done.
     * Bit N = queue index N. T100: 12 queues (0..11); TL10/Teralynx: 8 queues (0..7). */
    uint16_t                    sdk_pfc_wd_dldr_pending_bmap;
    /* Sflow related */
    sai_object_id_t             ing_samplepacket_oid;
    sai_object_id_t             egr_samplepacket_oid;

    sai_object_id_t             ingress_mirror_oid;
    sai_object_id_t             ingress_acl;

    /* Port Storm Control */
    sai_object_id_t             flood_storm_policer_oid;
    sai_object_id_t             broadcast_storm_policer_oid;
    sai_object_id_t             multicast_storm_policer_oid;
    /*
     * Unknown-unicast storm-control policer OID
     * (SAI_PORT_ATTR_CUSTOM_UNKNOWN_UNICAST_STORM_CONTROL_POLICER_ID).
     * Stored separately from flood_storm_policer_oid, but shares the same
     * underlying hardware resource as flood (native FLOOD meter offset in
     * SONiC behavior mode / flood UUC ACE in ACL mode). Last-writer-wins if
     * both flood and unknown-unicast attributes are set on the same port.
     */
    sai_object_id_t             unknown_unicast_storm_policer_oid;
    /*
     * Unknown-multicast storm-control policer OID
     * (SAI_PORT_ATTR_CUSTOM_UNKNOWN_MULTICAST_STORM_CONTROL_POLICER_ID).
     * Native SAI behavior mapping: programs a dedicated unknown-multicast (UMC)
     * meter offset (ISAI_STORM_CTRL_UMC_OFFSET). Native SONiC behavior mapping and
     * ACL mode: shares the same underlying resource as
     * multicast_storm_policer_oid (native MULTICAST meter offset / multicast ACE),
     * since there both carry unknown multicast. Tracked separately at the SAI
     * layer; last-writer-wins with multicast when they share a resource.
     */
    sai_object_id_t             unknown_multicast_storm_policer_oid;
    /*
     * Known-multicast storm-control policer OID
     * (SAI_PORT_ATTR_CUSTOM_KNOWN_MULTICAST_STORM_CONTROL_POLICER_ID).
     * Only supported in native SAI behavior mapping, where it shares the
     * MULTICAST meter offset (known multicast) with multicast_storm_policer_oid.
     * Rejected (SAI_STATUS_NOT_SUPPORTED) in native SONiC behavior mapping and in
     * ACL mode, which have no known-multicast-only resource.
     */
    sai_object_id_t             known_multicast_storm_policer_oid;
    ifcs_handle_t               storm_acl_hdl;
    ifcs_handle_t               storm_fld_ace_hdl;
    ifcs_handle_t               storm_bc_ace_hdl;
    ifcs_handle_t               storm_mc_ace_hdl;
    sai_object_id_t             port_policer_oid;
    ifcs_handle_t               port_policer_ace_hdl;

    /*ARS related*/
    ifcs_bool_t                 ars_enable;
    uint32_t                    ars_scaling_factor;
    uint32_t                    ars_mode;

    /* Port Serdes Related */

    uint32_t max_serdes_lanes_per_port;  // Max size of default devport tx eq lists. =MAX_NUM_SERDES_LANES_PER_PORT
    int32_t  *default_devport_tx_eq_pre1_list;
    int32_t  *default_devport_tx_eq_pre2_list;
    int32_t  *default_devport_tx_eq_pre3_list;
    int32_t  *default_devport_tx_eq_main_list;
    int32_t  *default_devport_tx_eq_attn_list;
    int32_t  *default_devport_tx_eq_post_list;
    int32_t  *default_devport_tx_eq_post2_list;
    sai_object_id_t port_serdes_oid; // Oid of port serdes object attached to the port
    uint32_t  watson_ref_count; // watson reference count
    ifcs_bool_t     is_sg_created_by_user;
    sai_object_id_t   isolation_group_oid; // Isolation group oid
    uint32_t  port_isg_ace_list_max_index; // Max  IB
    uint32_t  *port_isg_ace_list;
    ifcs_bool_t is_lt_enabled_by_user; /// Is Link Training explicitly enabled by User
    ifcs_bool_t is_port_serdes_no_op_hw; /// Port Serdes deferred to be applied in HW when LT is Off
    uint32_t         tam_oid_list_max_index;
    sai_object_id_t  *tam_oid_list;
    uint32_t         afm_profile_handle_list_max_index;
    uint32_t         *afm_profile_handle_list;
    /* SAI loopback / internal-loopback enum values as u32 in port DS */
    ifcs_uint32_t    port_ds_loopback_mode;
    ifcs_uint32_t    port_ds_internal_loopback_mode;
    uint32_t    ifcs_prbs_polynomial;
    uint32_t         ars_port_load_past_weight;
    uint32_t         ars_port_load_future_weight;
    uint8_t     *pfc_tc_dld_interval_list;
    uint32_t    pfc_tc_dld_interval_count;
    uint8_t     *pfc_tc_dlr_interval_list;
    uint32_t    pfc_tc_dlr_interval_count;
} sai_port_info_t;


/* Structure to hold sample packet object ID information */
typedef struct ifcs_sai_samplepacket_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS DS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_samplepacket_oid_t;

/* Structure to hold tam_int object ID information */
typedef struct ifcs_sai_tam_int_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS DS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_tam_int_oid_t;


typedef struct ifcs_sai_switch_oid_s {
    ifcs_handle_t switch_hdl; ///< Holds switch handle
    uint16_t      reserved;   ///< Reserved for future use
    uint8_t       node_id;    ///< Holds NODE-ID of the object
    uint8_t       type;       ///< Holds type of the object
} ifcs_sai_switch_oid_t;

/*SAI Queue object OID structure */
typedef struct ifcs_sai_queue_oid_s {
    uint32_t devport;
    uint8_t  node;
    uint8_t  queue_id;
    uint8_t  reserved3;
    uint8_t  type;
} ifcs_sai_queue_oid_t;

/* Generic SAI QOS related object OID structure */
typedef struct ifcs_sai_qos_oid_s {
    uint32_t id;
    uint8_t  node;
    uint8_t  reserved2;
    uint8_t  reserved3;
    uint8_t  type;
} ifcs_sai_qos_oid_t;

/* Structure to hold wred object ID information */
typedef struct ifcs_sai_wred_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS DS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_wred_oid_t;

/* Structure to hold scheduler object ID information */
typedef struct ifcs_sai_scheduler_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS DS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_scheduler_oid_t;

/* Structure to hold scheduler_group object ID information */
typedef struct ifcs_sai_scheduler_group_oid_s {
    uint32_t devport;
    uint8_t  node;
    uint8_t  scheduler_group_id;
    uint8_t  reserved3;
    uint8_t  type;
} ifcs_sai_scheduler_group_oid_t;

extern uint8_t g_pkt_trim_q_index_ref_counts[ISAI_MAX_NUM_FP_QUEUES_PER_PORT];

#define ISAI_QOS_BUFFER_POOL_TO_PARTITION_ID(obj_id)     (((ifcs_sai_qos_oid_t *)&obj_id)->id - ISAI_BASE_BUFFER_POOL_INDEX)

/*SAI Ingress priority group object OID structure */
typedef struct ifcs_sai_ingress_priority_group_oid_s {
    uint32_t devport;
    uint8_t  node;
    uint8_t  reserved;
    uint8_t  ipg_index;
    uint8_t  type;
} ifcs_sai_ingress_priority_group_oid_t;

#define ISAI_QOS_TYPE(obj_id)    (((ifcs_sai_qos_oid_t *)&obj_id)->type)

#define ISAI_QOS_PG_ID(obj_id)                            \
    (((ifcs_sai_ingress_priority_group_oid_t *)&obj_id)-> \
        ipg_index)

#define ISAI_QOS_PS_ID(obj_id)                            \
    (uint8_t)g_pgindex_to_ps_id_mapping[ISAI_QOS_PG_ID(obj_id)]

#define ISAI_QOS_PG_DEVPORT(obj_id)                       \
    (((ifcs_sai_ingress_priority_group_oid_t *)&obj_id)-> \
        devport)

#define ISAI_QOS_Q_ID(obj_id)            \
    (((ifcs_sai_queue_oid_t *)&obj_id)-> \
        queue_id)

#define ISAI_QOS_NODE_ID(obj_id)    (((ifcs_sai_qos_oid_t *)&obj_id)->node)
#define ISAI_QOS_OBJ_ID(obj_id)     (((ifcs_sai_qos_oid_t *)&obj_id)->id)

#define ISAI_QOS_Q_DEVPORT(obj_id)       \
    (((ifcs_sai_queue_oid_t *)&obj_id)-> \
        devport)

#define ISAI_WRED_NODE_ID(obj_id)    (((ifcs_sai_wred_oid_t *)&obj_id)->node_id)
#define ISAI_SCHED_NODE_ID(obj_id)    (((ifcs_sai_scheduler_oid_t *)&obj_id)->node_id)
#define ISAI_SCHED_GROUP_NODE_ID(obj_id)    (((ifcs_sai_scheduler_group_oid_t *)&obj_id)->node)
#define ISAI_SCHED_GROUP_DEVPORT(obj_id)    (((ifcs_sai_scheduler_group_oid_t *)&obj_id)->devport)
#define ISAI_SCHED_GROUP_TYPE(obj_id)    (((ifcs_sai_scheduler_group_oid_t *)&obj_id)->type)
#define ISAI_SCHED_GROUP_SG(obj_id)    (((ifcs_sai_scheduler_group_oid_t *)&obj_id)->scheduler_group_id)

/* Structure to hold HASH object ID information */
typedef struct ifcs_sai_hash_oid_s {
    ifcs_handle_t handle;    ///< Holds IFCS handle
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the object
    uint8_t       type;      ///< Holds type of the object
} ifcs_sai_hash_oid_t;

typedef enum _isai_shim_dp_qmap_type_e {
    ISAI_SHIM_DP_QMAP_TYPE_TC_TO_QUEUE,
    ISAI_SHIM_DP_QMAP_TYPE_TC_TO_PRIORITY_GROUP,
    ISAI_SHIM_DP_QMAP_TYPE_PFC_PRIORITY_TO_PRIORITY_GROUP,
    ISAI_SHIM_DP_QMAP_TYPE_PFC_PRIORITY_TO_QUEUE,
    ISAI_SHIM_DP_QMAP_TYPE_TC_TO_QUEUE_MULTICAST,
    ISAI_SHIM_DP_QMAP_TYPE_MAX
} isai_shim_dp_qmap_type_t;

typedef struct _isai_shim_datapath_qmap_cfg_s {
    sai_object_id_t map_oid;    // SAI qos map object id for this type
} isai_shim_datapath_qmap_cfg_t;

typedef struct _isai_shim_qm_interface_db_entry_s {
    //sysport handle is the key to this hash db.
    isai_shim_datapath_qmap_cfg_t dp_qmap_arr[ISAI_SHIM_DP_QMAP_TYPE_MAX];
    sai_object_id_t               dscp_to_tc_oid;
    sai_object_id_t               dscp_to_color_oid;
    sai_object_id_t               dot1p_to_tc_oid;
    sai_object_id_t               dot1p_to_color_oid;
    sai_object_id_t               tc_color_to_dscp_oid;
    sai_object_id_t               tc_color_to_dot1p_oid;
} isai_shim_qm_interface_db_entry_t;

typedef enum isai_shim_qmh_type_e {
    ISAI_SHIM_QMHDL_TYPE_START = 0,
    ISAI_SHIM_QMHDL_TYPE_DSCP  = ISAI_SHIM_QMHDL_TYPE_START,
    ISAI_SHIM_QMHDL_TYPE_DOT1P,
//    ISAI_SHIM_QMHDL_TYPE_EXP,
    ISAI_SHIM_QMHDL_TYPE_MAX   = ISAI_SHIM_QMHDL_TYPE_DOT1P + 1,

    /* Do not change ISAI_SHIM_QMHDL_TYPE_TUNNEL value. Warmboot upgrade wiil
     * have issues if value is changed/inbetween ISAI_SHIM_QMHDL_TYPE_START and
     * ISAI_SHIM_QMHDL_TYPE_MAX
     */
    ISAI_SHIM_QMHDL_TYPE_TUNNEL = 33,
    ISAI_SHIM_QMHDL_TYPE_PFC_QUEUE = 34,
    ISAI_SHIM_QMHDL_TYPE_PFC_PRIORITY_GROUP = 35,
} isai_shim_qmh_type_t;

typedef struct _sai_shim_qmhdl_db_entry_s {
    isai_shim_qmh_type_t type;
    uint32_t             ref_count;
    sai_object_id_t      ingress_tc_oid;
    sai_object_id_t      ingress_dp_oid;
    sai_object_id_t      egress_tc_dp_oid;
} isai_shim_qmhdl_db_entry_t;

#define ISAI_SHIM_PORT_QOSATTR_MAX    (10)

#define ISAI_MAX_STP_PORT 0xffff //IFCS_STP_PORT_MAX

typedef struct _sai_shim_stp_port_info_s {
    ifcs_handle_t   stp_hdl;
    ifcs_handle_t   sysport_hdl;
} sai_shim_stp_port_info_t;

/* STP Vlan list call_back */
typedef struct ifcs_sai_stp_vlan_list_s {
    sai_vlan_list_t    *vlan_list_p;
    uint32_t            total_count;
    sai_status_t        cb_rc;
} ifcs_sai_stp_vlan_list_t;

/* STP Port list call_back */
typedef struct ifcs_sai_stp_port_list_s {
    sai_object_list_t   *port_list_p;
    uint32_t            total_count;
    sai_status_t        cb_rc;
} ifcs_sai_stp_port_list_t;


#define IFCS_SAI_MAX_BRIDGE        4096
#define IFCS_SAI_MAX_BRIDGE_PORTS  (16 * 1024)

/*  Object id structures */
typedef struct _sai_shim_bridge_port_db_entry_s {
   sai_object_id_t bridge_port_id;   /* Bridge port OID           */
   sai_bridge_port_type_t type;      /* Type of bridge port       */
   sai_object_id_t port_oid;         /* Port/LAG object ID        */
   sai_object_id_t bridge_oid;       /* Bridge Instance Object ID */
   bool            admin_mode;       /* Adminstrative mode        */
   ii_hash_el_t    hash_el;
   sai_object_id_t tunnel_oid;
} sai_shim_bridge_port_db_entry_t;

typedef struct _sai_shim_isg_mem_info_s {
    ifcs_handle_t   sysport_hdl;
    sai_object_id_t bport_oid;        /* Bridgeport oid */
    sai_object_id_t isg_oid;          /* Isg oid */
    sai_object_id_t port_oid;         /* Port oid */
} sai_shim_isg_mem_info_t;

#define FLUSH_NOTIFICATION_SIZE    10
/**
 *  * @brief FDB event type - used in SHIM Layer
 *  */
typedef enum _sai_shim_fdb_event_t
{
    /** New FDB entry learned */
    SAI_SHIM_FDB_EVENT_LEARNED,

    /** FDB entry aged */
    SAI_SHIM_FDB_EVENT_AGED,

    /** FDB entry move */
    SAI_SHIM_FDB_EVENT_MOVE,

    /** FDB entry flushed */
    SAI_SHIM_FDB_EVENT_FLUSHED,

    /** FDB entry added statically by SAI API */
    SAI_SHIM_FDB_EVENT_ADD,

    /** FDB entry deleted by SAI API */
    SAI_SHIM_FDB_EVENT_REMOVE,

    /** FDB entry set */
    SAI_SHIM_FDB_EVENT_SET,

} sai_shim_fdb_event_t;
/**
 * @brief FDB Notification data format for SHIM layer modules
 */
typedef struct _sai_shim_fdb_event_notification_data_t
{
    /** Event type */
    sai_shim_fdb_event_t event_type;

    /** FDB entry */
    sai_fdb_entry_t fdb_entry;

} sai_shim_fdb_event_notification_data_t;
typedef struct _fdb_flush_notification_cb_data {
    uint32_t    count;
    uint32_t    remaining_count;
    sai_fdb_event_notification_fn notify_p;
    sai_fdb_event_notification_data_t *n_data;
    sai_shim_fdb_event_notification_data_t *shim_data; /*For shim layer*/
} fdb_flush_notification_cb_data_t;

/* Structure for link scan event queue message */
typedef struct fdb_msg_s {
    uint32_t                          count;
    sai_shim_fdb_event_notification_data_t data_p[FLUSH_NOTIFICATION_SIZE];
} fdb_msg_t;

typedef struct _sai_shim_debug_counter_info_s
{
    ifcs_sai_shim_oid_t debug_counter_oid;
    ifcs_uint8_t node_id;
    ifcs_uint32_t bind_method;
    ifcs_uint32_t  family_type;  // Type of family to which the
                                 // debug counter belongs to. Eg:
                                 // SAI_DEBUG_COUNTER_TYPE_PORT_IN_DROP_REASONS
    ifcs_uint32_t family_stat_index;  // The stat index assigned
                                      // when the debug object
                                      // is attached to the family object type
    ifcs_u32_list_t family_stats_list; // The list of family stats
                                       // the debug counter s associated with
    ifcs_handle_t ing_drop_counter_handle; //ingress pp_dc_handle if applicable
    ifcs_handle_t eg_drop_counter_handle; //egress pp_dc_handle if applicable


} sai_shim_debug_counter_info_t;

/* Type definition for link scan event callback */
typedef void
(*isai_fdb_event_cb_t) (uint32_t                          count,
                        sai_shim_fdb_event_notification_data_t *data_p);

PRAGMA_IGNORE_START(-Wpacked)

struct vlan_header {
    uint16_t tci;
    uint16_t ethertype;
}__attribute__((__packed__));

struct clock_id {
    uint8_t id[8];
};

struct port_id {
    struct clock_id        clock_id;
    uint16_t               port_number;
}  __attribute__((__packed__));

struct ptp_header {
    uint8_t              msg_type;
    uint8_t              ver;
    uint16_t             message_length;
    uint8_t              domain_number;
    uint8_t              reserved1;
    uint8_t              flag_field[2];
    int64_t              correction;
    uint32_t             reserved2;
    struct port_id       source_port_id;
    uint16_t             seq_id;
    uint8_t              control;
    int8_t               log_message_interval;
}__attribute__((packed));

struct origin_timestamp {
    uint16_t   sec_msb;
    uint32_t   sec_lsb;
    uint32_t   ns;
}__attribute__((__packed__));

PRAGMA_IGNORE_END

/* Values for the PTP messageType field. */
#define SYNC                  0x0
#define DELAY_REQ             0x1
#define PDELAY_REQ            0x2
#define PDELAY_RESP           0x3
#define FOLLOW_UP             0x8
#define DELAY_RESP            0x9
#define PDELAY_RESP_FOLLOW_UP 0xA
#define ANNOUNCE              0xB

/* Structure for ptp tx event queue data */
typedef struct _sai_shim_ptp_tx_event_notification_data_s
{
    /* IFCS node identifier */
    ifcs_node_id_t          node_id;
    /* PTP Tx Origin Timestamp */
    sai_timespec_t          ptp_origin_ts;
    /* Packet size in bytes */
    sai_size_t              pkt_buf_len;
    /* Packet buffer */
    const void              *pkt_buf;
    /* Egress port or LAG */
    sai_object_id_t         egress_port_or_lag;
} sai_shim_ptp_tx_event_notification_data_t;


/*
 * @brief Function to enqueue ptp tx event to
 *        ptp tx event queue
 *
 * @param [in] node_id - Node ID
 * @param [in] sai_shim_ptp_tx_notify_data_p     - data Pointer to ptp tx event notification data
 */
sai_status_t
isai_ptp_tx_event_enqueue(ifcs_node_id_t node_id,
                          sai_shim_ptp_tx_event_notification_data_t *shim_ptp_tx_notify_data_p);


#define ISAI_MAX_LAG_MEMBERS 512    //IFCS_LAG_MEMBER_MAX

/* Maximum callbacks that can be registered to get LAG events */
#define ISAI_LAG_MAX_REG_CB (16)

/* Maximum callbacks that can be registered to get LAG member events */
#define ISAI_LAG_MEM_MAX_REG_CB (16)

/* Enumerations for LAG events */
typedef enum isai_lag_event_s {
    ISAI_LAG_EVENT_CREATE = 0, ///< LAG group is created
    ISAI_LAG_EVENT_DELETE = 1, ///< LAG groupd is deleted
    ISAI_LAG_EVENT_MAX = 2     ///< Maximum lag events - invalid event
} isai_lag_event_t;

/* Enumerations for LAG member events */
typedef enum isai_lag_mem_event_s {
    ISAI_LAG_MEM_EVENT_CREATE = 0, ///< LAG member group is created
    ISAI_LAG_MEM_EVENT_DELETE = 1, ///< LAG member groupd is deleted
    ISAI_LAG_MEM_EVENT_MAX = 2     ///< Maximum lag member events - invalid event
} isai_lag_mem_event_t;


#define IFCS_COLLECTOR_MAX               96
#define IFCS_COLLECTOR_SET_MAX           24
#define IFCS_DCDP_MAX                    8
#define IFCS_COLLECTOR_SET_MEMBER_MAX    4
typedef struct _ms_collector_info {
    uint32_t            dir;
    uint16_t            rspan_dot1q_tpid;
    uint8_t             rspan_dot1q_pri;
    uint8_t             rspan_dot1q_cfi;
    ifcs_mac_t          dst_mac;
    ifcs_mac_t          src_mac;
    ifcs_ip_address_t   src_ip;
    ifcs_ip_address_t   dst_ip;
    uint8_t             dscp;
    uint8_t             ttl;
    uint16_t            session_id;
    uint32_t            truncate;
    uint16_t            gre_flags_ver_rsvd;
} sai_collector_info_t;
typedef struct _sai_shim_mirror_session_db_entry_s {
    sai_collector_info_t    collector_info;
    uint32_t                ing_ref_count;
    uint32_t                eg_ref_count;
    ifcs_handle_t           ifcs_dcdp_handle;
    ifcs_handle_t           ing_collector_handle;
    ifcs_handle_t           eg_collector_handle;
    ifcs_handle_t           ing_collector_set_handle;
    ifcs_handle_t           egr_collector_set_handle;
    ifcs_handle_t           ace_meter_ingress;
    ifcs_handle_t           ace_meter_egress;
    sai_object_id_t         port_oid;
    sai_object_id_t         policer_oid;
    uint32_t                sample_rate;
    uint8_t                 type;
    bool                    vlan_hdr_valid;
    uint16_t                udp_src_port;
    uint16_t                udp_dst_port;
    uint32_t                encap_type;
    uint16_t                gre_proto;
    uint16_t                vlan;
    uint32_t                truncate_size;
} sai_shim_mirror_session_db_entry_t;

/* db for port dcdp mapping */
typedef struct _sai_shim_sysport_dcdp_db_entry_s {
    sai_object_id_t port_oid;
    ifcs_handle_t   dcdp_hdl;
    uint32_t        ref_count;
} sysport_dcdp_db_entry_t;

typedef struct _sai_shim_sysport_cs_db_entry_s {
    sai_object_id_t port_oid;
    ifcs_handle_t   ing_collector_set_handle;
    uint32_t        ing_count;
    sai_object_id_t ing_obj_list[IFCS_COLLECTOR_SET_MEMBER_MAX];
    ifcs_handle_t   eg_collector_set_handle;
    uint32_t        eg_count;
    sai_object_id_t eg_obj_list[IFCS_COLLECTOR_SET_MEMBER_MAX];
} sysport_cs_db_entry_t;

/* db for acl collector set */

typedef struct _sai_shim_collector_set_db_entry_s {
    sai_object_id_t collector_set_handle;
    uint32_t        count;
    sai_object_id_t obj_list[IFCS_COLLECTOR_SET_MEMBER_MAX];
    uint8_t         direction;
    uint8_t         type;
    uint32_t        ref_count;
} collector_set_db_entry_t;


#define MAX_MIRROR_SESSION      8
#define MAX_ISAI_COLLECTOR      (MAX_MIRROR_SESSION * 2)
#define MAX_ISAI_COLLECTOR_SET  MAX_MIRROR_SESSION
typedef struct collector_inf_s{
    ifcs_handle_t       collector_hdl;
    uint32_t            count;
    uint32_t            type;
    uint32_t            dir;
    sai_object_id_t     ms_oid;
    ifcs_handle_t       cs_list[MAX_ISAI_COLLECTOR_SET];
    uint32_t            attr_count;
    ifcs_attr_t         attr_list[IFCS_COLLECTOR_ATTR_MAX_COUNT];
    sai_object_id_t     policer_oid;
    sai_object_id_t     mport_oid;
    ifcs_handle_t       meter_ace_hdl;
}collector_info_t;

typedef struct cs_list_s{
    uint32_t            max;
    uint32_t            count;
    ifcs_handle_t       *list;
    sai_status_t        cb_rc;
}cs_list_t;

/* Policer */
/*
 * Number of action handles typically created on an ACE to implement policing in
 * the datapath.
 * The action types are typically METER, COUNTER, DROP and MOD
 */
#define ISAI_POLICER_ACTION_HANDLE_COUNT  (4)
typedef enum isai_policer_color_e {
    POLICER_COLOR_GREEN,
    POLICER_COLOR_YELLOW,
    POLICER_COLOR_RED
} ifcs_sai_policer_color_t;

typedef struct isai_policer_meter_internal_s {
    ifcs_handle_t acl_table_handle;
    uint32_t      meter_attr_count;
    ifcs_attr_t   *meter_attr_list_p;
    uint32_t      counter_attr_count;
    ifcs_attr_t   *counter_attr_list_p;
} isai_policer_meter_internal_t;

/* END POLICER */


/*****************************************************************
 * L3 module related declarations
 ****************************************************************/
#define TUN_NHRES_SIZE  (sizeof(isai_tun_nhop_res_t))

/* Structure to break router OID */
typedef struct ifcs_sai_router_oid_s {
    ifcs_handle_t l3vni_hdl; ///< Holds handle to L3VNI object
    uint16_t      reserved;  ///< Reserved for future use
    uint8_t       node_id;   ///< Holds NODE-ID of the handle
    uint8_t       type;      ///< Holds type of the handle
} ifcs_sai_router_oid_t;

/* Nexthop info */
typedef struct isai_shim_nexthop_info_s {
    sai_ip_address_t nh_ip;         /* Nexthop ip address */
    ifcs_handle_t    intf_hdl;      /* Nexthop interface handle */
    ifcs_handle_t    local_dst_hdl; /* Local dest handle */
    sai_mac_t        nh_mac;        /* Nexthop mac address */
} isai_shim_nexthop_info_t;


/* Structure to break next-hop group OID */
typedef struct ifcs_sai_next_hop_group_oid_s {
    ifcs_handle_t ifcs_hdl;     ///< ECMP group IFCS handle
    uint16_t      reserved;     ///< Reserved for future use
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_next_hop_group_oid_t;

/* Structure to break next-hop group member OID */
typedef struct ifcs_sai_next_hop_group_member_oid_s {
    ifcs_handle_t ecmp_hdl;     ///< ECMP group IFCS handle
    ifcs_handle_t mem_hdl;      ///< Member IFCS handle
} ifcs_sai_next_hop_group_member_oid_t;

/* L3 multicast related declarations */
/* Structure to break RPF group OID */
typedef struct ifcs_sai_rpfg_oid_s {
    ifcs_handle_t ds_hdl;     ///< IFCS Interface List Handle
    uint16_t      reserved;     ///< Reserved for future use
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_rpfg_oid_t;

/* Structure to break RPF group member OID */
typedef struct ifcs_sai_rpfg_member_oid_s {
    ifcs_handle_t ds_hdl;       ///< DS handle for RPFG member
    uint16_t      reserved;     ///< Reserved for future use
    uint8_t       node_id;      ///< Node ID of the object
    uint8_t       type;         ///< Type of the object
} ifcs_sai_rpfg_mem_oid_t;

/**
 *  @brief isai_ds_rpf_group info
 *
 */
typedef struct isai_ds_rpf_group_ds_entry_s {
    sai_object_id_t  oid;           ///< OID of RPF group
    ifcs_handle_t    intf_count;   ///< Interface count
    ifcs_handle_t    ref_count;   ///< Ref count
} isai_shim_rpf_group_ds_entry_t;

/**
 *  @brief isai_ds_rpf_group_member info
 *
 */
typedef struct isai_ds_rpf_group_member_ds_entry_s {
    sai_object_id_t oid;            ///< OID of rpf Member
    sai_object_id_t group_oid;      ///< OID of rpf Group
    sai_object_id_t rpf_intf_oid;   ///< RPF interface OID
} isai_shim_rpf_group_member_ds_entry_t;


/*
 * Entry structure for VLAN to Mutlicast nexthop data store
 * This should be the mirror  definition of ipmc_rif_mcast_nexthop  in isai_ds.yaml
 */
typedef struct _isai_shim_ipmc_vlan_mcast_nexthop_s {
    uint64_t vlan_oid;    /* VLAN OID */
    uint32_t addr_family; /* SAI_IP_ADDR_FAMILY_IPV4 or IPV6 */
    uint32_t nh_handle;   /* Nh handle */
    uint32_t ref_count;   /* ref count */
} isai_shim_vlan_mcast_nexthop_db_entry;

/**
 *  @brief isai_ds_ipmc_group info
 *
 */
typedef struct isai_ds_ipmc_group_ds_entry_s {
    sai_object_id_t  oid;          ///< OID of IPMC group
    ifcs_uint32_t    mem_count;    ///< Member count
    ifcs_uint32_t    ref_count;    ///< Ref count
    ifcs_handle_t    mdg_hdl;      ///< MDG handle
    ifcs_uint32_t    egress_route_ref_v4; ///< IPv4 route refs on output group
    ifcs_uint32_t    egress_route_ref_v6; ///< IPv6 route refs on output group
} isai_shim_ipmc_group_ds_entry_t;

/**
 *  @brief isai_ds_ipmc_group_member info
 *
 */
typedef struct isai_ds_ipmc_group_member_ds_entry_s {
    sai_object_id_t oid;            ///< OID of ipmc Member
    sai_object_id_t group_oid;      ///< OID of ipmc Group
    sai_object_id_t output_id;      ///< Member OUTPUT ID/Bride port OID
    ifcs_handle_t   mc_dest_hdl;    ///< MC Destination handle
} isai_shim_ipmc_group_member_ds_entry_t;


/*
 * Entry structure for RIF to Mutlicast nexthop data store
 * This should be the mirror  definition of ipmc_rif_mcast_nexthop  in isai_ds.yaml
 */
typedef struct _isai_shim_ipmc_rif_mcast_nexthop_s {
    uint64_t rif_oid;     /* RIF OID */
    uint32_t addr_family; /* SAI_IP_ADDR_FAMILY_IPV4 or IPV6 */
    uint32_t nh_handle;   /* Nh handle */
    uint32_t ref_count;   /* ref count */
} isai_shim_rif_mcast_nexthop_db_entry;


/**
 * @brief Key for isai_ds_ipmc_entry Entry
 */
typedef struct _isai_ds_ipmc_entry_t_key_s {

  ifcs_uint64_t switch_id;           /* Switch OID */
  ifcs_uint64_t vr_id;               /* Virtual Router OID */
  ifcs_uint8_t type;                 /* IPMC Entry Type */
  ifcs_ip_address_t destination;     /* Group IP address */
  ifcs_ip_address_t source;          /* Source IP address */
} isai_ds_ipmc_entry_key_t;

/*
 * Entry structure for IPMC Entry data store
 * This should be the mirror  definition of ipmc_entry  in isai_ds.yaml
 */
typedef struct isai_shim_ipmc_ds_entry_s {
  isai_ds_ipmc_entry_key_t  key;
  ifcs_uint32_t packet_action;                  /* packet action */
  ifcs_uint64_t output_group_id;                /* IPMC Group Id */
  ifcs_uint64_t rpf_group_id;                   /* RPF Group Id */
  ifcs_uint64_t user_trap_oid;                    /* SAI_IPMC_ENTRY_ATTR_CUSTOM_USER_TRAP_ID */
} isai_shim_ipmc_ds_entry_t;

/* IPMC DS Table */
typedef struct isai_shim_ipmc_ds_entry_list_s {
    isai_shim_ipmc_ds_entry_t  *ipmc_ds_entry_p;  /* Array of IPMC DS entry */
    uint32_t            max_count;    /* Max count -- indicate memory allocated */
    uint32_t            actual_count; /* Number of entries populated [out] */
    sai_status_t        cb_rc; /* Callback return status */
} isai_shim_ipmc_ds_entry_list_t;

/* Tunnel related declarations */

typedef enum _sai_shim_nh_tunnel_dir_s {
    ISAI_NH_TUNNEL_DIRECTION_TX_ONLY,
    ISAI_NH_TUNNEL_DIRECTION_RX_ONLY,
    ISAI_NH_TUNNEL_DIRECTION_BOTH
} sai_shim_nh_tunnel_dir_t;

typedef enum _sai_shim_nh_tunnel_nh_type_s {
    ISAI_NH_TUNNEL_NH_TYPE_UNICAST,
    ISAI_NH_TUNNEL_NH_TYPE_MULTICAST,
} sai_shim_nh_tunnel_nh_type_t;

/* Tunnel Nhop Resolution data */
typedef struct _isai_tun_nhop_res_t {
    sai_ip_address_t  tun_nh_ip;
    ifcs_handle_t     underlay_nh_hdl;
    sai_ip_address_t  res_ip_addr;
    sai_ip_address_t  res_ip_mask;
    sai_object_id_t   tun_nh_oid;
    sai_object_id_t   tun_oid;
    uint32_t          direction;
    uint32_t         nh_type;
} isai_tun_nhop_res_t;

extern isai_id_alloc_t *l2vni_id_allocator;
extern isai_id_alloc_t *tun_nh_id_allocator;

/*
 * Entry structure for tnl nh ip to hdl ds
 * This should be the mirror  definition of tnl_nh_ip_to_hdl table in isai_ds.yam
 */
typedef struct _isai_shim_tunnel_nexthop_handle_db_s {
    uint8_t          nh_type;             /* IFCS nexthop Type */
    sai_ip_address_t tnl_nh_ip;           /* TUN NH ID */
    uint32_t         nh_hdl;              /* Nh handle */
    uint32_t         ref_count;           /* Ref count */
    sai_object_id_t  l2_tun_nh_oid;       /* L2 tunnel nexthop oid */
    uint32_t         l2_ref_count;        /* L2 nexthop ref count */
    uint32_t         mcast_selected_port; /* Mcast selected sys port */
    ifcs_uint64_t    tnl_oid;             /* Tunnel OID */
    sai_object_id_t  counter_oid;         /* Per VTEP single common counter */
    sai_object_id_t  internal_counter_oid;/* Per VTEP internal BUM egress counter (EVPN-MH P2P) */
} isai_shim_tunnel_nexthop_handle_db_entry;

/*
 * Entry structure for VxLAN underlay unicast to mcast map table
 */
typedef struct _isai_shim_vxlan_mcast_map_table_db_s {
    uint32_t unicast_nh_hdl;      /* Unicast Nh handle */
    uint32_t mcast_nh_hdl;        /* Nh handle */
    uint32_t ref_count;           /* Ref count */
    uint32_t selected_ng_mem_hdl; /* Selected ECMP member handle */
} isai_vxlan_ul_mcast_nh_db_entry;

/*
 * Entry structure for TNL NH to Overlay Nh map data store
 * This should be the mirror  definition of tnl_nh_to_overlay_nh in isai_ds.yaml
 */
typedef struct _isai_shim_tnl_nh_to_overlay_nh_db_s {
    ifcs_isai_ds_vxlan_tnl_nh_to_overlay_nh_t key;
    uint32_t overlay_nh_hdl;
}isai_shim_tnl_nh_to_overlay_nh_db_entry_t;

/*
 * Entry structure for Overlay next hop entry
 * This should be the mirror  definition of tnl_nh_to_overlay_nh in isai_ds.yaml
 */
typedef struct _isai_shim_vxlan_overlay_nexthop_db_s {
  uint32_t overlay_nh_hdl;            /* Key */
  sai_mac_t dst_mac;                  /* Nexthop Mac */
  uint32_t l3if_hdl;                  /* L3 interface handle */
  uint64_t tnl_nh_oid;                /* Tunnel nexthop OID */
  bool     default_vxlan_mac_used;    /* Using VxLAN default router mac or not */
  uint32_t ref_count;                 /* ref count */
} isai_shim_overlay_nexthop_db_entry_t;

/*
 * Entry structure for VR to VNI map data store
 * This should be the mirror  definition of vr_to_vni map in isai_ds.yaml
 */
typedef struct _isai_shim_vr_to_vni_db_s {
  uint64_t vr_id;       /* Virtual router OID */
  uint32_t vni_id;      /* VxLAN  VNI Id */
  uint16_t il2vni;      /* Internal L2VNI */
  uint32_t svi_hdl;     /* Internal SVI handle */
  uint32_t ref_cnt;     /* Route count */
} isai_shim_vr_to_vni_db_entry;

/*
 * Entry structure for override data store
 * This should be the mirror  definition of vxlan_override_vni table in isai_ds.yaml
 */
typedef struct _isai_shim_override_vni_db_s {
  uint32_t vni_id;       /* VxLAN  VNI Id */
  uint16_t il2vni;      /* Internal L2VNI */
  uint32_t svi_hdl;     /* Internal SVI handle */
  uint32_t ref_count;   /* Ref count */
} isai_shim_override_vni_db_entry;


/* HOSTIF START */
#define ISAI_HOSTIF_DEF_VLAN_TAG_ACT    SAI_HOSTIF_VLAN_TAG_STRIP
#define MOD_HOSTIFNAME      "NET_DM"
#define MOD_MC_GRP_NAME     "events"

/* First MSB of priority value is used for internal traps,
 * as they always should have lower priority than
 * hostif_trap's user configured priority*/
#define ISAI_HOSTIF_ACE_PRIORITY_MSB_SHIFT_BITS    1

/* This is used to reserve 1 LSB bit from ifcs priority to create
 * highter priority ace for a hostif_trap to support exclude_port list
 */
#define ISAI_HOSTIF_ACE_PRIORITY_LSB_SHIFT_BITS    1
/*
 * IP2ME trap priority constant
 */
#define IP2ME_PRIORITY          3


/*
 * Default hostif trap priority (SAI header it is 0, in DS it is 1)
 */
#define DEFAULT_HOSTIF_TRAP_PRIORITY    (1)

/*  UDT Info structure exposed other module like ACL */
typedef struct ifcs_sai_shim_hostif_user_defined_trap_info_s {
    ifcs_handle_t   trap_handle;
    sai_object_id_t policer_id;
    sai_object_id_t trap_group_oid;
    sai_object_id_t udt_oid;
    bool            admin_state;
    /** #sai_hostif_user_defined_trap_type_t from UDT data store */
    uint32_t        udt_type;
} ifcs_sai_shim_hostif_user_defined_trap_info_t;

typedef enum _sai_shim_fdb_pkt_type_t {
    FDB_UNICAST   = 1,
    FDB_MULTICAST = 2,
    FDB_BROADCAST = 3,
} sai_shim_fdb_pkt_type_t;


/*
 * Trap group type based on the traps contained in it.
 * NONE: Empty.
 * PROTOCOL: BGP, VRRP, ARP, etc
 * SFLOW   : SAMPLE_PACKET
 * UDT     : User Defined Trap.
 */

typedef enum isai_shim_hostif_trap_group_type_e {
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_NONE,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_PROTOCOL,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_SFLOW,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_UDT,
    ISAI_SHIM_HOSTIF_TRAP_GROUP_TYPE_MAX,
} isai_shim_hostif_trap_group_type_t;

/* HOSTIF END */

/* ACL START */
/* ACL Counter OID */

#define ISAI_ACL_COUNTER_ATTR_MAX  (256)

typedef struct  isai_shim_acl_counter_info_s {
    sai_object_id_t oid;            /* SAI_OBJECT  id */
    /* User configured SAI attr count and list for this SAI object*/
    uint32_t        attr_count;
    sai_attribute_t attr_list[ISAI_ACL_COUNTER_ATTR_MAX];
} isai_shim_acl_counter_info_t;

/*
 * ISAI_IFCS_ACL_TABLE_ATTR_COUNT_MAX is the greatest of the following:
 *  IFCS_ACL_TABLE_ATTR_MAX_COUNT
 *  IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT
 *  IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT
 */
#define ISAI_IFCS_ACL_TABLE_ATTR_COUNT_MAX                                      \
    (((uint32_t)IFCS_ACL_TABLE_ATTR_MAX_COUNT >                                 \
      (uint32_t)IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT) ?                        \
     (((uint32_t)IFCS_ACL_TABLE_ATTR_MAX_COUNT >                                \
       (uint32_t)IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT) ?                      \
      IFCS_ACL_TABLE_ATTR_MAX_COUNT : IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT) : \
     (((uint32_t)IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT >                        \
       (uint32_t)IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT) ?                      \
      IFCS_ACL_MATCH_PROFILE_ATTR_MAX_COUNT :                                   \
      IFCS_ACL_ACTION_PROFILE_ATTR_MAX_COUNT))

#define IFCS_SAI_PKTACTIONS_MAX    5

#define IFCS_SAI_PKT_ACTION_ACL_HDL_MAX    5 /*CTC, Drop, Policer, Counter, copy cancel */
/*
 * The priority space that we expose to the user is a subset of the actual
 * priority space that IFCS supports. This is because some ACLs may need to
 * be implemented via a combination of multiple ACEs pf different priorities
 * and so we need holes in the priority space to accomodate those implicit
 * ACEs. The use case today is ACL entries with 'ip type' match field.
 */
#define ISAI_ACE_PRIORITY_SHIFT_BITS    1
#define ISAI_ACE_MIN_USER_PRIORITY \
    (IAI_ACE_MIN_PRIORITY >>       \
     ISAI_ACE_PRIORITY_SHIFT_BITS)

/* Constants derived from SAI */
#define ISAI_ACE_MATCH_ATTR_MAX     \
    (SAI_ACL_ENTRY_ATTR_FIELD_END - \
     SAI_ACL_ENTRY_ATTR_FIELD_START)
#define ISAI_ACE_ACTION_ATTR_MAX     \
    (SAI_ACL_ENTRY_ATTR_ACTION_END - \
     SAI_ACL_ENTRY_ATTR_ACTION_START)
#define ISAI_ACE_ATTR_MAX                                       \
    ((ISAI_ACE_MATCH_ATTR_MAX) >                                \
     (ISAI_ACE_ACTION_ATTR_MAX) ? (ISAI_ACE_MATCH_ATTR_MAX) : ( \
         ISAI_ACE_ACTION_ATTR_MAX))


#define ISAI_ACE_OBJECT_MAX    \
    (IFCS_ACE_ATTR_MAX_COUNT + \
     IFCS_ACL_MATCH_ATTR_MAX_COUNT + IFCS_ACL_ACTION_ATTR_MAX_COUNT)

/*
 * IFCS Supports only Muliple of 128 ACL Table size
 * Convert User passed value to ceil(128)
 */
#define CEIL_128(acl_table_size)      ((acl_table_size + 127) & (uint32_t) ~(0x7F))
/*
 * Entry type in acl_pktaction_arr. Look at ifcs_acl_action_type_t and
 * ifcs_acl_action_value_t to understand what type/value pairs IFCS expects.
 */
typedef struct pkt_action_stoi_acl_action_s {
    uint8_t                 count; // Number of acl actions

    // Only a subset of action types have valid values.
    bool                    value_valid[IFCS_SAI_PKT_ACTION_ACL_HDL_MAX];
    ifcs_acl_action_type_t  type[IFCS_SAI_PKT_ACTION_ACL_HDL_MAX];

    //valid only when value_valid is TRUE
    ifcs_acl_action_value_t value[IFCS_SAI_PKT_ACTION_ACL_HDL_MAX];
} pkt_action_stoi_acl_action_t;

typedef struct pkt_action_stoi_acl_action_policer_s {
    ifcs_acl_action_type_t ifcs_action;
    /* list of all possible SAI actions, for given ifcs_action type */
    uint32_t               num_sai_actions;
    sai_packet_action_t    sai_actions[IFCS_SAI_PKTACTIONS_MAX];
} pkt_action_stoi_acl_action_policer_t;

/* ACL END */

/* SWITCH START */

#define SAI_SWITCH_CUSTOM_ATTR_OFFSET(id) (id - SAI_SWITCH_ATTR_CUSTOM_RANGE_START - 1)
#define SAI_PORT_CUSTOM_ATTR_OFFSET(id) (id - SAI_PORT_ATTR_CUSTOM_RANGE_START - 1)


#define ISAI_SHIM_SWITCH_DB_RESERVED_SIZE_MASK                 (0x1 << 0)
#define ISAI_SHIM_SWITCH_DB_UC_DTL_MASK                        (0x1 << 1)
#define ISAI_SHIM_SWITCH_DB_NONUC_DTL_MASK                     (0x1 << 2)
#define ISAI_SHIM_SWITCH_DB_UC_SHARED_BUFFER_MAX_LIMIT_MASK    (0x1 << 3)
#define ISAI_SHIM_SWITCH_DB_NONUC_SHARED_BUFFER_MAX_LIMIT_MASK (0x1 << 4)
#define ISAI_SHIM_SWITCH_DB_RESUME_OFFSET_MASK                 (0x1 << 5)

#define ISAI_MIRROR_SAMPLE_RATE                           1

#define SAI_KEY_PLATFORM_LIBRARY   "PLATFORM_LIBRARY"

/* SWITCH END */

/* TAM START */
typedef struct isai_shim_tam_hdc_policy_s {
    /* HDC Policy */
    ifcs_hdc_policy_t hdc_policy;
    /* Delay threshold handle */
    ifcs_handle_t dth_handle;
    /* Visibility sampler handle */
    ifcs_handle_t vs_handle;
    /* Collector set handle */
    ifcs_handle_t cset_handle;
} isai_shim_tam_hdc_policy_t;
/* TAM END */

/**
 * @brief counter Type
 */
typedef enum ifcs_isai_counter_type_e {

  IFCS_ISAI_SHIM_COUNTER_OBJECT_TYPE_NONE = 0,
  IFCS_ISAI_SHIM_COUNTER_OBJECT_TYPE_HOSTIF_TRAP = 1,
  IFCS_ISAI_SHIM_COUNTER_OBJECT_TYPE_ROUTE_ENTRY = 2,
  IFCS_ISAI_SHIM_COUNTER_OBJECT_TYPE_IPMC_ENTERY = 3,
  IFCS_ISAI_SHIM_COUNTER_OBJECT_TYPE_NEXTHOP = 4,
  IFCS_ISAI_SHIM_COUNTER_OBJECT_TYPE_MAX = 5,
} ifcs_isai_shim_counter_object_type_t;

#define ISAI_SHIM_SWITCH_DB_MAX_FLEXCOUNTER_INDEX 65535
#endif /* __IFCS_SAI_TYPES_H__ */
