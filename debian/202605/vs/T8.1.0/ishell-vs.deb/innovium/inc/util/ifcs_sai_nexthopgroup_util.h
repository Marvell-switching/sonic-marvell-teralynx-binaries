/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_nexthopgroup_util.h
 * @brief ISAI Util Include file for NEXTHOPGROUP module
 */


#ifndef __IFCS_SAI_NEXTHOPGROUP_UTIL_H__
#define __IFCS_SAI_NEXTHOPGROUP_UTIL_H__

#include "util/ifcs_sai_nexthopgroup_util_dep.h"


/*
 * @brief Initializes nexthopgroup module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_init(
    sai_switch_init_info_t *sai_switch_init_info_p);


/*
 * @brief Un-initializes nexthopgroup module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief  Converts SAI object ID to IFCS handle
 *
 * @param [in]  sai_object_id - SAI object ID
 * @param [out] ifcs_handle   - Handle to IFCS nexthop-group object
 * @return sai_status_t
 */
extern sai_status_t
isai_im_nexthopgroup_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);




sai_status_t
isai_im_nexthopgroup_get_group_hdl(sai_object_id_t   object_id,
                                   ifcs_handle_t     *group_hdl_p);

/*
 * @brief Get Nexthopgroup object type resource availability.
 *
 * @param[in] switch_id   SAI Switch object id
 * @param[in] attr_count  Number of attributes
 * @param[in] attr_list_p List of attributes that to distinguish resource
 * @param[out] count_p    Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accounting.
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_nexthopgroup_object_type_get_availability(sai_object_id_t       switch_id,
                                                  uint32_t              attr_count,
                                                  const sai_attribute_t *attr_list_p,
                                                  uint64_t              *count_p);


/*
 * @brief Get the next_hop_group Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_next_hop_group_get_object_count(sai_object_id_t switch_id,
                                                     uint32_t *object_count);

/*
 * @brief Get the next_hop_group Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_next_hop_group_get_object_key(sai_object_id_t switch_id,
                                      uint32_t *object_count,
                                      sai_object_key_t *object_list);

/*
 * @brief Get the next_hop_group_member Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_next_hop_group_member_get_object_count(sai_object_id_t switch_id,
                                               uint32_t *object_count);

/*
 * @brief Get the next_hop_group_member Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_next_hop_group_member_get_object_key(sai_object_id_t switch_id,
                                             uint32_t *object_count,
                                             sai_object_key_t *object_list);

/*
 * @brief Get the next_hop_group_map Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_next_hop_group_map_get_object_count(sai_object_id_t switch_id,
                                            uint32_t *object_count);

/*
 * @brief Get the next_hop_group_map Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_next_hop_group_map_get_object_key(sai_object_id_t switch_id,
                                          uint32_t *object_count,
                                          sai_object_key_t *object_list);

#endif /* __IFCS_SAI_NEXTHOPGROUP_UTIL_H__ */
