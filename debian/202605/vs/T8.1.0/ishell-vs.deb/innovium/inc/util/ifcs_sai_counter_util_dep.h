/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_counter_util_dep.h
 * @brief ISAI Util Dependency Include file for COUNTER module
 */

#ifndef __IFCS_SAI_COUNTER_UTIL_DEP_H__
#define __IFCS_SAI_COUNTER_UTIL_DEP_H__

#include "ifcs_sai_counter.h"
#include "util/ifcs_sai_hostif_util.h"
#include "util/ifcs_sai_route_util.h"
#include "util/ifcs_sai_switch_util.h"
#endif /* __IFCS_SAI_COUNTER_UTIL_DEP_H__ */
