/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_scheduler_group_util.h
 * @brief ISAI Util Include file for SCHEDULER_GROUP module
 */


#ifndef __IFCS_SAI_SCHEDULER_GROUP_UTIL_H__
#define __IFCS_SAI_SCHEDULER_GROUP_UTIL_H__

#include "util/ifcs_sai_scheduler_group_util_dep.h"

/*
 * @brief  Initializes scheduler group module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_scheduler_group_init(
    sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Fill scheduler_group SAI attribute list
 *
 * Caller provides port-id and index.
 *
 * @param [in] port_id Port  object id
 * @param [in] index uin32_t 0 to 7
 * @param [in] attr_count_p                - Number of attributes
 * @param [in] attr_list_p                 - Attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_group_attr_fill(
    sai_object_id_t port_id,
    uint32_t        index,
    uint32_t        *attr_count_p,
    sai_attribute_t *attr_list_p);

/**
 * @brief Delete a given scheduler_group
 *
 * Caller provides a scheduler_group  to be
 * deleted. If object_id exists, then it is deleted from the device.
 *
 * @param [in] scheduler_group_object_id - scheduler_group object_id
 * @param [in] is_default_sched_group - is this default scheduler group
 * @return sai_status_t
 */

sai_status_t
isai_im_scheduler_group_remove(sai_object_id_t scheduler_group_object_id,
                               bool is_default_sched_group);

sai_status_t
isai_im_scheduler_group_sai_id_get(ifcs_node_id_t        node_id,
                                   uint32_t              dev_port,
                                   uint32_t              scheduler_group_id,
                                   sai_object_id_t       *id_p,
                                   bool                  is_create,
                                   uint32_t              attr_count,
                                   const sai_attribute_t *attr_list_p);

sai_status_t
isai_im_scheduler_group_get_sg_list_from_port(ifcs_node_id_t  node_id,
                                              sai_object_id_t port_oid,
                                              sai_attribute_t *attr_p);


/*
 * @brief Get the scheduler_group Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_scheduler_group_get_object_count(sai_object_id_t switch_id,
                                                      uint32_t *object_count);

/*
 * @brief Get the scheduler_group Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_scheduler_group_get_object_key(sai_object_id_t switch_id,
                                       uint32_t *object_count,
                                       sai_object_key_t *object_list);

#endif /* __IFCS_SAI_SCHEDULER_GROUP_UTIL_H__ */
