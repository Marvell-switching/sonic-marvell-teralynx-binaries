/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_route_util.h
 * @brief ISAI Util Include file for ROUTE module
 */


#ifndef __IFCS_SAI_ROUTE_UTIL_H__
#define __IFCS_SAI_ROUTE_UTIL_H__

#include "util/ifcs_sai_route_util_dep.h"

/*
 * @brief  Initializes route module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief  Initializes post route module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_post_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief  Uninitializes route module
 * @param [in]  switch_deinit_info_p   - Pointer to deinit information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_pre_deinit(
    sai_switch_deinit_info_t  *switch_deinit_info_p);
/*
 * @brief  Uninitializes route module
 * @param [in]  switch_deinit_info_p   - Pointer to deinit information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_deinit(
    sai_switch_deinit_info_t  *switch_deinit_info_p);

/**
 * @brief: Register for RCP Processing in the VR
 *
 * Start Tracking this VR for Tunnel Nhop Update Resolution.
 *
 * @param [in] vr_oid   - Object ID Of a VR
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_rcp_event_register(const sai_object_id_t vr_oid);


/**
 * @brief: De-Register for RCP Processing in the VR
 *
 * Stop Tracking this VR for Tunnel Nhop Updates
 * after VR Tunnel Nhop count becomes 0.
 *
 * @param [in] vr_oid   - Object ID Of a VR
 * @return sai_status_t
 */
extern sai_status_t
isai_im_route_rcp_event_deregister(const sai_object_id_t vr_oid);


/**
 * @brief: Build VR database with Tunenl Nhops
 *
 * Create teh VR database with Number of Tunnel Nhops
 *
 * @param [in] vr_oid   - Object ID Of a VR
 * @return sai_status_t
 */
sai_status_t
isai_im_route_update_tunnh_count_in_vr(const sai_object_id_t vr_oid);


/**
 * @brief: Process Route update
 *
 * Check whether Route update, modifies Underlay Tunnel Resolution
 *
 * @param [in] data - Pointer for Route update
 */
sai_status_t
isai_im_route_rcp_process_route_update(void *data);


/**
 * @brief: ADD Tunnel NH element to VR list
 *
 * @param [in] node_id      - IFCS Node id
 * @param [in] tun_nh_res_p - Pointer for TUN NH data
 *
 */
sai_status_t
isai_im_route_add_tunnh_to_vr(ifcs_node_id_t       node_id,
                              isai_tun_nhop_res_t  *tun_nh_res_p);

/**
 * @brief Inter module function to retrieve type of the route
 *
 * @param [in]  node_id            - IFCS Node ID
 * @param [in]  ifcs_route_entry_p - Pointer to IFCS route entry
 * @param [out] rt_type_p          - Pointer to route type
 * @param [out] nh_hdl_p           - Pointer to nh handle
 * @return sai_status_t
 */

sai_status_t
isai_im_route_get_type(
    const ifcs_node_id_t          node_id,
    ifcs_route_entry_key_t        *ifcs_route_entry_p,
    ifcs_sai_nh_type_t            *rt_type_p,
    ifcs_handle_t                 *nh_hdl_p);



/*
 * @brief Get Route object type resource availability.
 *
 * @param[in] switch_id   SAI Switch object id
 * @param[in] attr_count  Number of attributes
 * @param[in] attr_list_p List of attributes that to distinguish resource
 * @param[out] count_p    Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accou
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_route_object_type_get_availability(sai_object_id_t       switch_id,
                                           uint32_t              attr_count,
                                           const sai_attribute_t *attr_list_p,
                                           uint64_t              *count_p);

/*
 * @brief Get route hardware resource utilization list
 *
 * Returns SAI_ROUTE_HW_RESOURCE_GROUP_COUNT utilization percentages (0-100%),
 * one per underlying route hardware resource group.
 *
 * @param[in]     switch_id  SAI switch OID
 * @param[in,out] attr_p     switch attribute (sai_u32_list_t)
 * @return sai_status_t
 */
sai_status_t
isai_im_route_hw_resource_utilization_list_get(
    sai_object_id_t  switch_id,
    sai_attribute_t *attr_p);

/*
 * @brief Creates route Entry
 *
 * @param [in]  route_entry_p     - Pointer to route entry
 * @param [in]  host_route_info_p - Pointer to Host route data
 * @return sai_status_t
 */
sai_status_t
isai_im_route_restore_route_entry(
    const sai_route_entry_t *route_entry_p,
    isai_host_route_t       *host_route_info_p);


/*
 * @brief Read route Entry
 *
 * @param [in]  route_entry_p     - Pointer to route entry
 * @param [in]  attr_count        - No of attributes
 * @param [out] attr_list_p       - Pointer to attributes
 * @return sai_status_t
 */
sai_status_t
isai_im_route_get_route_entry(
    const sai_route_entry_t *route_entry_p,
    uint32_t                attr_count,
    sai_attribute_t         *attr_list_p);

/*
 * @brief Creates route DB entry
 *
 * @param [in]  route_entry_p     - Pointer to route entry
 * @param [in]  host_route_info_p - Pointer to Host route data
 * @return sai_status_t
 */
sai_status_t
isai_im_route_create_neighbor_host_route_db_entry(
    const sai_route_entry_t *route_entry_p,
    isai_host_route_t       *host_route_info_p);

/*
 * @brief Deletes route DB entry
 *
 * @param [in]  route_entry_p   - Pointer to route entry
 * @return sai_status_t
 */
sai_status_t
isai_im_route_remove_neighbor_host_route_db_entry(
    const sai_route_entry_t *route_entry_p);


/**
 * @brief Get Dup Route DS Entry
 *
 * @param[in]  route_entry_p     - Pointer to route entry
 * @param[out] host_route_info_p - Pointer to Host route data
 * @param[out] entry_found_p     - returns true if entry in DS
 * @return sai_status_t
 */
sai_status_t
isai_im_route_get_neighbor_host_route_db_entry(
    const sai_route_entry_t *route_entry_p,
    isai_host_route_t       *host_route_info_p,
    bool                    *entry_found_p);

/**
 * @brief Set Dup Route DS Entry
 *
 * @param[in]  route_entry_p     - Pointer to route entry
 * @param[out] host_route_info_p - Pointer to Host route data
 * @return sai_status_t
 */
sai_status_t
isai_im_route_set_neighbor_host_route_db_entry(
    const sai_route_entry_t *route_entry_p,
    isai_host_route_t       *host_route_info_p);

sai_status_t
isai_im_route_mod_enable(ifcs_node_id_t node_id,
                                 ifcs_handle_t mod_trap);
sai_status_t
isai_im_route_mod_disable(ifcs_node_id_t node_id,
                                 ifcs_handle_t mod_trap);

/*
 * @brief Updates global ip2me_trap_hdl
 *
 * @param [in] node_id         - IFCS Node id
 * @param [in] ip2me_trap_hdl  - New ip2me trap handle value
 * @return sai_status_t
 */
sai_status_t
isai_im_route_update_ip2me_trap_hdl(ifcs_node_id_t  node_id,
                                    ifcs_handle_t   ip2me_trap_hdl);

/*
 * @brief Updates global ttl profile for a given virtual router
 *
 * @param [in] switch_oid     - Switch oid
 * @param [in] vr_oid         - Object ID Of a VR
 * @param [in] ttl_profile    - New ttl profile value
 * @return sai_status_t
 */
sai_status_t
isai_im_route_update_vrf_ttl_profile(sai_object_id_t switch_oid,
                                     sai_object_id_t vr_oid,
                                     sai_ttl_check_profile_t ttl_profile);
/*
 * @brief  Gets handle to next-hop/next-hop group
 *
 * @param [in]  switch_id - Switch OID
 * @param [in]  oid       - OID of next-hop/next-hop group
 * @param [in]  vr_id     - VR ID
 * @param [out] hdl_p     - Pointer to IFCS handle
 * @return sai_status_t
 */
sai_status_t
isai_im_route_get_next_hop_handle(sai_object_id_t switch_id,
                                  sai_object_id_t oid,
                                  sai_object_id_t vr_id,
                                  ifcs_handle_t   *hdl_p);

/*
 * @brief Clean up VxLAN overlay nexthop
 *
 * @param    [in] node_id - Ifcs node id
 * @param    [in] overlay_nh_hdl  - overlay nexthop handle
 * @return sai_status_t
 */
sai_status_t
isai_im_route_clean_up_vxlan_overlay_nexthop(ifcs_node_id_t  node_id,
                                     ifcs_handle_t   overlay_nh_hdl,
                                     sai_object_id_t vr_oid);


/*
 * @brief Get the route_entry Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_route_entry_get_object_count(sai_object_id_t switch_id,
                                                  uint32_t *object_count);

/*
 * @brief Get the route_entry Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_route_entry_get_object_key(sai_object_id_t switch_id,
                                                uint32_t *object_count,
                                                sai_object_key_t *object_list);

#endif /* __IFCS_SAI_ROUTE_UTIL_H__ */
