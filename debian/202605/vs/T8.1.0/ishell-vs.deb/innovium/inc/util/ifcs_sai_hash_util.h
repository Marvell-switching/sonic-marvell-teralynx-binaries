/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_hash_util.h
 * @brief ISAI Util Include file for HASH module
 */


#ifndef __IFCS_SAI_HASH_UTIL_H__
#define __IFCS_SAI_HASH_UTIL_H__

#include "util/ifcs_sai_hash_util_dep.h"


/*
 *  @brief Initializes hash module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_hash_init(
    sai_switch_init_info_t *sai_switch_init_info_p);


/*
 * @brief Un-initializes hash module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_hash_deinit(
    sai_switch_deinit_info_t *switch_deinit_info_p);


/*
 * @brief Get IFCS extended field list handles from HASH DS Entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [in] is_entropy2    - Read Entropy/Entropy2
 * @param [in] ifcs_hdl_p     - Pointer to EFL IFCS handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_get_efl_from_ds_entry(sai_object_id_t switch_id,
                                   hash_type_t     hash_type,
                                   sai_object_id_t hash_oid, 
                                   bool            is_entropy2,
                                   ifcs_handle_t   *ifcs_hdl_p);




/*
 * @brief Create extended field list in IFCS from HASH DS entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [in] is_entropy2    - Configuring Entropy/Entropy2
 * @param [out] ifcs_hdl_p    - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_create_efl_from_ds_entry(sai_object_id_t switch_id,
                                      hash_type_t     hash_type,
                                      sai_object_id_t hash_oid,
                                      bool            is_entropy2,
                                      ifcs_handle_t   *ifcs_hdl_p);

/**
 * @brief Delete extended field list from IFCS and update HASH DS Entry
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_type      - Hash type
 * @param [in] hash_oid       - Hash object id
 * @param [in] skip_ds_update - Skip DS update flag
 * @param [in] is_entropy2    - Configuring Entropy/Entropy2
 * @param [out] ifcs_hdl_p    - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_delete_efl_from_ifcs(sai_object_id_t switch_id,
                                  hash_type_t     hash_type,
                                  sai_object_id_t hash_oid, 
                                  bool            skip_ds_update,
                                  bool            is_entropy2,
                                  ifcs_handle_t   *ifcs_hdl_p);


/**
 * @brief Create extended field list for IPv4 in IPv4 hash
 *
 * @param [in] switch_id      - Switch object id
 * @param [in] hash_oid       - Hash object id
 * @param [out] ifcs_handles  - Pointer to ifcs_handles
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_create_ip_in_ipv4_efl(sai_object_id_t switch_id,
                                   sai_object_id_t hash_oid,
                                   ifcs_handle_t   *ifcs_handles);


/*
 * @brief Recreate extended field list in IFCS from HASH DS Entry
 *
 * @param [in] node_id          - node id
 * @param [in] hash_oid         - Hash object id
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_recreate_switch_hash_map
(
    ifcs_node_id_t              node_id,
    sai_object_id_t             hash_oid
);

/*
 * @brief Update PBH field in IFCS from HASH DS Entry
 *
 * @param [in] node_id          - node id
 * @param [in] hash_oid         - Hash object id
 * @param [in] inner_ether_type - Inner Ether Type
 * @param [in] is_entropy2      - Is Entropy2
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_update_pbh_field(ifcs_node_id_t  node_id,
                              sai_object_id_t hash_oid,
                              uint16_t        inner_ether_type,
                              bool            is_entropy2);

/*
 * @brief Reset PBH field in IFCS from HASH DS Entry
 *
 * @param [in] node_id          - node id
 * @param [in] hash_oid         - Hash object id
 * @param [in] inner_ether_type - Inner Ether Type
 * @param [in] is_entropy2      - Is Entropy2
 * @return sai_status_t
 */
sai_status_t
isai_im_hash_reset_pbh_field(ifcs_node_id_t  node_id,
                             sai_object_id_t hash_oid,
                             uint16_t        inner_ether_type,
                             bool            is_entropy2);



/*
 * @brief Get the hash Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_hash_get_object_count(sai_object_id_t switch_id,
                                           uint32_t *object_count);

/*
 * @brief Get the hash Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_hash_get_object_key(sai_object_id_t switch_id,
                                         uint32_t *object_count,
                                         sai_object_key_t *object_list);

/*
 * @brief Get the fine_grained_hash_field Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_fine_grained_hash_field_get_object_count(sai_object_id_t switch_id,
                                                 uint32_t *object_count);

/*
 * @brief Get the fine_grained_hash_field Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_fine_grained_hash_field_get_object_key(sai_object_id_t switch_id,
                                               uint32_t *object_count,
                                               sai_object_key_t *object_list);

#endif /* __IFCS_SAI_HASH_UTIL_H__ */
