/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_router_util.h
 * @brief ISAI Util Include file for ROUTER module
 */


#ifndef __IFCS_SAI_ROUTER_UTIL_H__
#define __IFCS_SAI_ROUTER_UTIL_H__

#include "util/ifcs_sai_router_util_dep.h"

/*
 * @brief Translates VR SAI object ID to L3VNI IFCS handle
 *
 * @param [out] ifcs_handle_p - Pointer to IFCS handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);


/*
 * @brief Translates L3VNI IFCS handle to SAI object ID
 *
 * @param [in]  ifcs_handle - IFCS handle
 * @param [out] object_id_p - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_itos_xlate_oid(
    sai_object_id_t switch_oid,
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *object_id_p);




/**
 * @brief: Update IFCS attributes of route to
 * configure TTL profile based on VR configuration
 *
 * @param [in] switch_id        - Switch Id
 * @param [in] vr_oid           - Virtual router object ID
 * @param [in] attr_count_p     - Pointer to IFCS attribute count
 * @param [in] attr_list_p      - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_virtual_router_rt_ttl_profile_update(
    sai_object_id_t       switch_id,
    sai_object_id_t       vr_oid,
    uint32_t              *attr_count_p,
    ifcs_attr_t           *attr_list_p);

/**
 * @brief Initializes router module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes router module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);


/**
 * @brief Update l3vni unicast_dst_miss_ctc
 *
 * @param [in] node_id   - IFCS node_id
 * @param [in] enable    - Enable/Disable attr
 * @return sai_status_t
 */
sai_status_t
isai_im_router_update_l3vni_attr(ifcs_node_id_t   node_id,
                                 ifcs_bool_t      enable);

/*
 * @brief get a given entry from virtual router DB
 *
 * @param [in] oid          - Virtual Router object ID
 * @param [in] attr_count   - SAI attribute count
 * @param [in] attr_list_p  - Pointer to SAI attribute
 * @return sai_status_t
 */
sai_status_t
isai_im_router_get_vr_db_entry(sai_object_id_t   oid,
                     const uint32_t    attr_count,
                     sai_attribute_t   *attr_list_p);

/*
 * @brief Get the virtual_router Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_virtual_router_get_object_count(sai_object_id_t switch_id,
                                                     uint32_t *object_count);

/*
 * @brief Get the virtual_router Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_virtual_router_get_object_key(sai_object_id_t switch_id,
                                      uint32_t *object_count,
                                      sai_object_key_t *object_list);

#endif /* __IFCS_SAI_ROUTER_UTIL_H__ */
