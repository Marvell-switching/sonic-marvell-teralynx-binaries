/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_debug_counter_util.h
 * @brief ISAI Util Include file for DEBUG_COUNTER module
 */


#ifndef __IFCS_SAI_DEBUG_COUNTER_UTIL_H__
#define __IFCS_SAI_DEBUG_COUNTER_UTIL_H__

#include "util/ifcs_sai_debug_counter_util_dep.h"
/*
 * @brief Get the ifcs handle of the debug counter datastore entry
 *
 * @param [in] family_type      - Family Type
 * @param [in] stat_index       - Debug Stat Index
 * @param [OUT] ifcs_hdl        - IFCS Handle
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_ifcs_handle_get(uint16_t family_type,
                                     uint32_t stat_index,
                                     ifcs_handle_t *ifcs_hdl);

/*
 * @brief Get the Debug Counter Datastore Entry
 *
 * @param [in]  node_id      - Node Id
 * @param [in]  ifcs_hdl     - IFCS Handle
 * @param [out] dc_info      - Debug Counter datastore values
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_ds_entry_get(ifcs_uint32_t node_id,
                                ifcs_handle_t ifcs_hdl,
                                sai_shim_debug_counter_info_t *dc_info);

/*
 * @brief Get the pp drop handle from switch datastore
 *
 * @param [in]  node_id               - Node Id
 * @param [in]  drop_ifcs_attr_id     - pp drop attr list
 * @param [out] pp_drop_ifcs_hdl      - pp drop IFCS Handle
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_get_pp_drop_handle(ifcs_node_id_t node_id,
                                         ifcs_attr_id_t  drop_ifcs_attr_id,
                                         ifcs_handle_t *pp_drop_ifcs_hdl);

/*
 * @brief PP drop counter and reason cleanup
 *
 * @param [in]  sai_switch_deinit_info_p  - Switch DS attributes
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_deinit(
                       sai_switch_deinit_info_t *sai_switch_deinit_info_p);
/*
 * @brief PP drop handles init called during switch startup
 *
 * @param [in]  sai_switch_init_info_p  - Switch DS attributes
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_pp_drop_reason_init(
                       sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_debug_counter_acl_install(
                       sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * @brief Get Debug-counter object type resource availability.
 *
 * @param[in] switch_id   SAI Switch object id
 * @param[in] attr_count  Number of attributes
 * @param[in] attr_list_p List of attributes that to distinguish resource
 * @param[out] count_p    Available objects left
 *
 * @return #SAI_STATUS_NOT_SUPPORTED if the given object type does not support resource accounting.
 * Otherwise, return #SAI_STATUS_SUCCESS.
 */
sai_status_t
isai_im_debug_counter_object_type_get_availability(sai_object_id_t       switch_id,
                                                   uint32_t              attr_count,
                                                   const sai_attribute_t *attr_list_p,
                                                   uint64_t              *count_p);

/*
 * @brief Get the debug_counter Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_debug_counter_get_object_count(sai_object_id_t switch_id,
                                                    uint32_t *object_count);

/*
 * @brief Get the debug_counter Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_debug_counter_get_object_key(sai_object_id_t switch_id,
                                     uint32_t *object_count,
                                     sai_object_key_t *object_list);

#endif /* __IFCS_SAI_DEBUG_COUNTER_UTIL_H__ */
