/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_ars_util.h
 * @brief ISAI Util Include file for ARS module
 */


#ifndef __IFCS_SAI_ARS_UTIL_H__
#define __IFCS_SAI_ARS_UTIL_H__

#include "util/ifcs_sai_ars_util_dep.h"

/**
 * @brief Initializes ARS module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes ARS module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/**
 * @brief Retrieves the ARS handle for a given node and ARS object ID.
 *
 * @param node_id The ID of the node.
 * @param ars_oid The object ID of the ARS.
 * @param ars_handle_p Pointer to the ARS handle to be retrieved.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_get_ars_handle(ifcs_node_id_t node_id,
                           sai_object_id_t ars_oid,
                           ifcs_handle_t   *ars_handle_p);

/**
 * @brief Increments the reference count of the ARS handle for a given node.
 *
 * @param node_id The ID of the node.
 * @param ars_handle The ARS handle to be incremented.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_increment_ars_ref_count(ifcs_node_id_t node_id,
                                    sai_object_id_t ars_handle);

/**
 * @brief Decrements the reference count of the ARS handle for a given node.
 *
 * @param node_id The ID of the node.
 * @param ars_handle The ARS handle to be incremented.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_decrement_ars_ref_count(ifcs_node_id_t node_id,
                                    sai_object_id_t ars_handle);

/**
 * @brief Create the ARS object(s) for the global AR path
 *
 * @param node_id The ID of the node.
 * @param ars_oid The ARS object id (mutually exclusive with qgp_oid_list_p).
 * @param qgp_oid_list_p The queue group profile oid list (mutually exclusive
 *                       with ars_oid).
 * @param ar_hdl_list_p The resulting IFCS AR/ALB handle list.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_object_create(ifcs_node_id_t node_id,
                          sai_object_id_t ars_oid,
                          sai_object_list_t *qgp_oid_list_p,
                          ifcs_handle_list_t *ar_hdl_list_p);

/**
 * @brief Remove AR group handles from the ARS object(s) iSAI DS ar_hdl_list
 *
 * @param node_id The ID of the node.
 * @param ars_oid The ARS object id (mutually exclusive with qgp_oid_list_p).
 * @param qgp_oid_list_p The queue group profile oid list (mutually exclusive
 *                       with ars_oid).
 * @param ar_hdl_list_p The IFCS AR/ALB handle list to remove.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_update_alb_handle(ifcs_node_id_t node_id,
                              sai_object_id_t ars_oid,
                              const sai_object_list_t *qgp_oid_list_p,
                              ifcs_handle_list_t *ar_hdl_list_p);

/**
 * @brief Updates the ALB port selection mode.
 *
 * @param node_id The ID of the node.
 * @param profile_port_load_past The port load past profile.
 * @param profile_port_load_current The port load current profile.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_update_alb_port_selection_mode(ifcs_node_id_t node_id,
                                          bool profile_port_load_past,
                                          bool profile_port_load_current);
 /*  */


/*
 * @brief Get the ars Object Count
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t isai_im_ars_get_object_count(sai_object_id_t switch_id,
                                          uint32_t *object_count);

/*
 * @brief Get the ars Object Key
 *
 * @param [in]     switch_id      - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t isai_im_ars_get_object_key(sai_object_id_t switch_id,
                                        uint32_t *object_count,
                                        sai_object_key_t *object_list);

#endif /* __IFCS_SAI_ARS_UTIL_H__ */
