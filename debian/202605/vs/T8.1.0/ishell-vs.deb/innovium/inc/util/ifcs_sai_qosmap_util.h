/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_qosmap_util.h
 * @brief ISAI Util Include file for QOSMAP module
 */


#ifndef __IFCS_SAI_QOSMAP_UTIL_H__
#define __IFCS_SAI_QOSMAP_UTIL_H__

#include "util/ifcs_sai_qosmap_util_dep.h"



typedef enum isai_qmg_bind_interface_type_e {
    ISAI_QM_QMGRP_INTERFACE_TYPE_START = 0,
    ISAI_QM_QMGRP_INTERFACE_TYPE_PORT  = ISAI_QM_QMGRP_INTERFACE_TYPE_START,
    ISAI_QM_QMGRP_INTERFACE_TYPE_RIF,
    ISAI_QM_QMGRP_INTERFACE_TYPE_TUNNEL,
    ISAI_QM_QMGRP_INTERFACE_TYPE_MAX
} isai_qm_qmg_bind_interface_type_t;

sai_status_t
isai_im_qosmap_pre_attach_process(ifcs_node_id_t node_id);

sai_status_t
isai_im_qosmap_qmg_init(ifcs_node_id_t         node_id,
                        sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_qosmap_qmg_deinit(ifcs_node_id_t           node_id,
                          sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_qosmap_qmg_create(isai_qm_qmg_bind_interface_type_t interface_type,
                          sai_object_id_t                   interface_oid,
                          const sai_attribute_t             *attr_list_p,
                          uint32_t                          qosmap_attr_arr[],
                          uint32_t                          qosmap_attr_count);

sai_status_t
isai_im_qosmap_qmg_set(isai_qm_qmg_bind_interface_type_t interface_type,
                       sai_object_id_t                   interface_oid,
                       const sai_attribute_t             *attr_p);

sai_status_t
isai_im_qosmap_qmg_get(isai_qm_qmg_bind_interface_type_t interface_type,
                       sai_object_id_t                   interface_oid,
                       sai_attribute_t                   *attr_p);


extern sai_status_t
isai_im_qosmap_qmhdl_hash_insert_item(ifcs_node_id_t             node_id,
                                      ifcs_handle_t              qm_handle,
                                      isai_shim_qmhdl_db_entry_t *qmhdl_entry_p);

extern sai_status_t
isai_im_qosmap_qmhdl_hash_delete_item(ifcs_node_id_t             node_id,
                                      ifcs_handle_t              qm_handle);

extern sai_status_t
isai_im_qosmap_qmhdl_ref_count_inc(ifcs_node_id_t node_id,
                                   ifcs_handle_t  qmhdl);

extern sai_status_t
isai_im_qosmap_qmhdl_ref_count_dec(ifcs_node_id_t node_id,
                                   ifcs_handle_t  qmhdl);
/**
 * @brief: Retrieve QoS Map Attribute
 *
 * @param [in] qos_map_object_id            - QosMap object
 * @param [in] attr_count                   - Number of attributes
 * @param [in] attr_list_p                  - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_qosmap_attribute_get(sai_object_id_t qos_map_object_id,
                            uint32_t         attr_count,
                            sai_attribute_t  *attr_list_p);
/**
 * @brief Initializes qosmap module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_qosmap_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes qosmap module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_qosmap_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Get the Hash Object Count
 *
 * @param [in]     switch_id     - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @return sai_status_t
 */
sai_status_t
isai_im_qosmap_get_object_count(sai_object_id_t switch_id,
                              uint32_t *object_count);

/*
 * @brief Get the hash Object Key
 *
 * @param [in]     switch_id     - SAI switch object ID
 * @param [in,out] object_count   - Pointer to the object count
 * @param [in,out] object_list    - Pointer to the sai_object_key_t
 * @return sai_status_t
 */
sai_status_t
isai_im_qosmap_get_object_key(sai_object_id_t switch_id,
                            uint32_t *object_count,
                            sai_object_key_t *object_list);

#endif /* __IFCS_SAI_QOSMAP_UTIL_H__ */
