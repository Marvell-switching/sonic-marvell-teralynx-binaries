/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_acl.h
 * @brief ISAI IM Include file for ACL module
 */

#ifndef __IFCS_SAI_ACL_H__
#define __IFCS_SAI_ACL_H__

#define ISAI_MODULE_LOCK_ACL 1ULL

#include "ifcs_sai_debug_counter.h"
#include "ifcs_sai_hostif.h"
#include "ifcs_sai_mirror.h"
#include "ifcs_sai_policer.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_tam.h"
#include "ifcs_sai_udf.h"
#include "isai_im_nmgr.h"
#endif /* __IFCS_SAI_ACL_H__ */
