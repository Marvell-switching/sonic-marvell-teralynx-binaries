/**
 *copyright (c) 2025 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    sainexthopgroupcustom.h
 *
 * @brief   This module defines custom attributes for the Switch Abstraction Interface (SAI)
 */

#ifndef __SAINEXTHOPGROUPCUSTOM_H_
#define __SAINEXTHOPGROUPCUSTOM_H_

#include <sainexthopgroup.h>
#include <saitypes.h>

/**
 * @brief Next hop group is configured with weights or not
 */
typedef enum _sai_next_hop_group_custom_members_weight_t
{
    /** This is for legacy platforms where this attribute is don't care */
    SAI_NEXT_HOP_GROUP_CUSTOM_MEMBERS_WEIGHT_DONT_CARE,

    /** Next hop group members are weighted */
    SAI_NEXT_HOP_GROUP_CUSTOM_MEMBERS_WEIGHT_WEIGHTED,

    /** Next hop group members are unweighted */
    SAI_NEXT_HOP_GROUP_CUSTOM_MEMBERS_WEIGHT_UNWEIGHTED,

} sai_next_hop_group_custom_members_weight_t;

/**
 * @brief Enum defining ARS mode for the next hop group
 */
typedef enum _sai_next_hop_group_custom_ars_mode_t
{
    /** Disable ARS for the next hop group */
    SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_NONE,

    /** Consider only local link congestion */
    SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_LOCAL,

    /** Consider local + remote congestion, consume/process remote congestion via RX */
    SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_GLOBAL_RX,

    /** Consider local congestion, send remote congestion data via TX */
    SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_GLOBAL_TX,

    /** Consider local + remote congestion, send (TX) and consume/process (RX) remote congestion */
    SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_GLOBAL_BIDIR,

} sai_next_hop_group_custom_ars_mode_t;

/**
 * @brief SAI nexthopgroup custom attribute
 */
typedef enum _sai_next_hop_group_attr_custom_t
{
    /**
     * @brief SAI ECMP default hash offset
     *
     * When set, the output of the ECMP hash calculation will be rotated right
     * by the specified number of bits.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_DEFAULT_HASH_OFFSET = SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief SAI nexthop group members weight
     *
     * @type sai_next_hop_group_custom_members_weight_t
     * @flags CREATE_ONLY
     * @default SAI_NEXT_HOP_GROUP_CUSTOM_MEMBERS_WEIGHT_DONT_CARE
     */
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_MEMBERS_WEIGHT,

    /**
     * @brief ARS mode for the next hop group
     *
     * @type sai_next_hop_group_custom_ars_mode_t
     * @flags CREATE_ONLY
     * @default SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_NONE
     */
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_ARS_MODE,

    /**
     * @brief List of ARS object IDs mapped to the queue group profile indices.
     *
     * Allowed and mandatory while binding ARS only when ARS queue group profile are configured.
     * The number of ARS OIDs in the list must exactly match the number of Queue Group Profiles.
     *
     * @type sai_object_list_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_ARS
     * @default empty
     */
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_QUEUE_GROUP_PROFILE_ARS_OID_LIST,

    /**
     * @brief ARS destination id of the destination ToR switch
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_ARS_MODE == SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_GLOBAL_RX or SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_ARS_MODE == SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_GLOBAL_TX or SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_ARS_MODE == SAI_NEXT_HOP_GROUP_CUSTOM_ARS_MODE_GLOBAL_BIDIR
     */
    SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_ARS_DESTINATION_ID,
} sai_next_hop_group_attr_custom_t;

/*
 * Backward-compatibility aliases for the old typedef name and the RANGE_MAX
 * sentinel. The doxygen cond/endcond commands exclude them from the
 * generated doxygen output that the metadata/RPC generator consumes, so it
 * does not emit duplicate definitions; it has no effect on normal compilation.
 */
/** @cond */
typedef sai_next_hop_group_attr_custom_t sai_nexthopgroup_attr_custom_t;
#define SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_RANGE_MAX \
        (SAI_NEXT_HOP_GROUP_ATTR_CUSTOM_ARS_DESTINATION_ID + 1)
/** @endcond */

#endif /* __SAINEXTHOPGROUPCUSTOM_H_ */
