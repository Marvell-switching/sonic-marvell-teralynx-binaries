/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiarsprofilecustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIARSPROFILECUSTOM_H_
#define __SAIARSPROFILECUSTOM_H_

#include <saiarsprofile.h>
#include <saitypes.h>

/**
 * @brief SAI ars profile custom attribute
 */
typedef enum _sai_ars_profile_attr_custom_t
{
    /**
     * @brief Enable Queue Delay as the quality parameter. This is the average queue delay measured on a queue.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_ARS_PROFILE_ATTR_ALGO == SAI_ARS_PROFILE_ALGO_EWMA
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY = SAI_ARS_PROFILE_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Weight attribute is used in EWMA calculations.
     * Large weight lowers the significance of instantaneous measure on the overall average.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 16
     * @validonly SAI_ARS_PROFILE_ATTR_ALGO == SAI_ARS_PROFILE_ALGO_EWMA
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_WEIGHT,

    /**
     * @brief Sampling interval in microseconds of data for quality measure computation
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 16
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_SAMPLING_INTERVAL,

    /**
     * @brief Minimum Queue delay threshold in nanoseconds for quantization process.
     * Used by hardware to allocate the quantization bands.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_MIN_VAL,

    /**
     * @brief Maximum Queue delay threshold in nanoseconds for quantization process.
     * Used by hardware to allocate the quantization bands.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_DELAY_MAX_VAL,

    /**
     * @brief DMAC for PSM packet
     * Required in configuring Global ARS (Remote + Local Link Congestion)
     * Must be unicast mac address
     *
     * @type sai_mac_t
     * @flags CREATE_AND_SET
     * @default 00:00:00:00:00:00
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_DMAC,

    /**
     * @brief Ethertype for PSM packet
     * Required in configuring Global ARS (Remote + Local Link Congestion)
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_ETHERTYPE,

    /**
     * @brief Destination id assigned to ToR switches
     * Required in configuring Global ARS (Remote + Local Link Congestion)
     * It should be unique in the network
     *
     * @type sai_u32_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_DESTINATION_ID,

    /**
     * @brief Enable past queue load as the quality parameter. This is the average egress bytes measured on queue
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_ARS_PROFILE_ATTR_ALGO == SAI_ARS_PROFILE_ALGO_EWMA
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_LOAD_PAST,

    /**
     * @brief Assign weight in percent to past port load quality measure in switch pipeline.
     * All quality measures if add up to less then 100 then remaining value is used for vendor specific internal weights.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 50
     * @validonly SAI_ARS_PROFILE_ATTR_PORT_LOAD_PAST == true
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_PATH_SELECT_PORT_LOAD_PAST_WEIGHT,

    /**
     * @brief Assign weight in percent to future port load quality measure in switch pipeline.
     * All quality measures if add up to less then 100 then remaining value is used for vendor specific internal weights.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 50
     * @validonly SAI_ARS_PROFILE_ATTR_PORT_LOAD_FUTURE == true
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_PATH_SELECT_PORT_LOAD_FUTURE_WEIGHT,

    /**
     * @brief Assign weight in percent to past queue load quality measure in switch pipeline.
     * All quality measures if add up to less then 100 then remaining value is used for vendor specific internal weights.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_ARS_PROFILE_ATTR_CUSTOM_QUEUE_LOAD_PAST == true
     */
    SAI_ARS_PROFILE_ATTR_CUSTOM_PATH_SELECT_QUEUE_LOAD_PAST_WEIGHT,

}sai_ars_profile_attr_custom_t;

typedef enum _sai_ars_queue_group_profile_attr_custom_t
{

    /**
     * @brief List of queue indices which will form the queue group
     *
     * @type sai_u8_list_t
     * @flags CREATE_AND_SET
     * @default empty
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_QUEUE_INDEX_LIST = SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Enable past port load as the quality parameter. This is the average egress bytes measured on a port
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PORT_LOAD_PAST,

    /**
     * @brief Enable future port load as the quality parameter. This is the average egress bytes measured on a port
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PORT_LOAD_FUTURE,

    /**
     * @brief Enable past queue load as the quality parameter. This is the average egress bytes measured on a queue
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_QUEUE_LOAD_PAST,

    /**
     * @brief Assign weight in percent to past port load quality measure in switch pipeline.
     * All quality measures if add up to less then 100 then remaining value is used for vendor specific internal weights.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 50
     * @validonly SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PORT_LOAD_PAST == true
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PATH_SELECT_PORT_LOAD_PAST_WEIGHT,

    /**
     * @brief Assign weight in percent to future port load quality measure in switch pipeline.
     * All quality measures if add up to less then 100 then remaining value is used for vendor specific internal weights.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 50
     * @validonly SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PORT_LOAD_FUTURE == true
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PATH_SELECT_PORT_LOAD_FUTURE_WEIGHT,

    /**
     * @brief Assign weight in percent to past queue load quality measure in switch pipeline.
     * All quality measures if add up to less then 100 then remaining value is used for vendor specific internal weights.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_QUEUE_LOAD_PAST == true
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_PATH_SELECT_QUEUE_LOAD_PAST_WEIGHT,

    /**
     * @brief End of custom range base
     */
    SAI_ARS_QUEUE_GROUP_PROFILE_ATTR_CUSTOM_RANGE_END,

} sai_ars_queue_group_profile_attr_custom_t;

#endif /* __SAIARSPROFILECUSTOM_H_ */