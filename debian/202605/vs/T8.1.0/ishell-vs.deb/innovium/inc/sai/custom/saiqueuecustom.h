/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiqueuecustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIQUEUECUSTOM_H_
#define __SAIQUEUECUSTOM_H_

#include <saiqueue.h>
#include <saitypes.h>


/**
 * @brief SAI queue custom attribute
 */
typedef enum _sai_queue_attr_custom_t
{
    /**
     * @brief Drop unknown unicast packets on a lossless queue.
     *
     * If the attribute is true, drop unknown unicast packets
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_QUEUE_ATTR_LOSSLESS_FLOOD_CONTROL_ENABLE = SAI_QUEUE_ATTR_CUSTOM_RANGE_START + 1,

    /**
     * @brief Attach/Detach policer to queue
     *
     * Set policer id = #SAI_NULL_OBJECT_ID to disable policer on queue.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_POLICER
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_QUEUE_ATTR_CUSTOM_POLICER_ID = SAI_QUEUE_ATTR_CUSTOM_RANGE_START + 2,

    /**
     * @brief PFC watchdog restoration mode for the queue
     *
     * Controls how PFC watchdog restoration is triggered on the queue's
     * devport when SDK PFC WD DLDR is enabled.
     *
     * @type sai_queue_custom_pfc_wd_restoration_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_QUEUE_CUSTOM_PFC_WD_RESTORATION_MODE_FORCE
     */
    SAI_QUEUE_ATTR_CUSTOM_PFC_WD_RESTORATION_MODE = SAI_QUEUE_ATTR_CUSTOM_RANGE_START + 3,

    /**
     * @brief PFC watchdog manual restoration trigger for the queue
     *
     * When restoration mode is MANUAL, programs
     * IFCS_DEVPORT_ATTR_PFC_WD_MANUAL_RESTORATION_TRIGGER on the queue's
     * devport.  May only be set true when restoration mode is MANUAL.
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_QUEUE_ATTR_CUSTOM_PFC_WD_MANUAL_RESTORATION_TRIGGER = SAI_QUEUE_ATTR_CUSTOM_RANGE_START + 4,
}sai_queue_attr_custom_t;


/**
 * @brief Attribute data for SAI_QUEUE_ATTR_CUSTOM_PFC_WD_RESTORATION_MODE
 */
typedef enum _sai_queue_custom_pfc_wd_restoration_mode_t
{
    /**
     * @brief Restore if no PFC frames received for restoration threshold time
     */
    SAI_QUEUE_CUSTOM_PFC_WD_RESTORATION_MODE_AUTO = 0,

    /**
     * @brief Restore forcefully after restoration threshold time even if PFC
     *        frames are received
     */
    SAI_QUEUE_CUSTOM_PFC_WD_RESTORATION_MODE_FORCE = 1,

    /**
     * @brief Restore only when user triggers manual restoration
     */
    SAI_QUEUE_CUSTOM_PFC_WD_RESTORATION_MODE_MANUAL = 2,

} sai_queue_custom_pfc_wd_restoration_mode_t;


/**
 * @brief SAI queue stat custom
 */
typedef enum _sai_queue_stat_custom_t
{
    /** Custom range start */
    SAI_QUEUE_STAT_CUSTOM_RANGE_START = SAI_QUEUE_STAT_CUSTOM_RANGE_BASE,

    /** Get/set unknown unicast packet drop count [uint64_t] */
    SAI_QUEUE_STAT_LOSSLESS_FLOOD_CONTROL_PACKETS = SAI_QUEUE_STAT_CUSTOM_RANGE_BASE + 1,

    /** Get/set unknown unicast bytes drop count [uint64_t] */
    SAI_QUEUE_STAT_LOSSLESS_FLOOD_CONTROL_BYTES,

    /** Custom statistics to get queue delay [uint64_t] */
    SAI_QUEUE_STAT_CUSTOM_QUEUE_DELAY,

    /** Get current queue occupancy in cells [uint64_t] */
    SAI_QUEUE_STAT_CUSTOM_CURR_OCCUPANCY_CELLS,

    /** Get watermark queue occupancy in cells [uint64_t] */
    SAI_QUEUE_STAT_CUSTOM_WATERMARK_CELLS,

    /** Custom range end */
    SAI_QUEUE_STAT_CUSTOM_RANGE_END

}sai_queue_stat_custom_t;

#endif /* __SAIQUEUECUSTOM_H_ */
