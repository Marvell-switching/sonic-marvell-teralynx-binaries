/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2025) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @brief This file provides aliasing to the SAI attribute/stats/types which contributed to SAI
 *        open source community from Marvell, but before maintained as custom.
 */


/**
 * comenting out bekow custom attribute since it contribued to community
 */

/**
    #define SAI_SWITCH_CUSTOM_ATTR_ECMP_HASH_IPV4_RDMA     SAI_SWITCH_ATTR_ECMP_HASH_IPV4_RDMA
    #define SAI_SWITCH_CUSTOM_ATTR_ECMP_HASH_IPV6_RDMA     SAI_SWITCH_ATTR_ECMP_HASH_IPV4_RDMA
    #define SAI_SWITCH_CUSTOM_ATTR_LAG_HASH_IPV4_RDMA      SAI_SWITCH_ATTR_LAG_HASH_IPV4_RDMA
    #define SAI_SWITCH_CUSTOM_ATTR_LAG_HASH_IPV6_RDMA      SAI_SWITCH_ATTR_LAG_HASH_IPV6_RDMA
    #define SAI_NATIVE_CUSTOM_HASH_FIELD_RDMA_BTH_OPCODE   SAI_NATIVE_HASH_FIELD_RDMA_BTH_OPCODE
    #define SAI_NATIVE_CUSTOM_HASH_FIELD_RDMA_BTH_DEST_QP  SAI_NATIVE_HASH_FIELD_RDMA_BTH_DEST_QP

    #define SAI_LAG_MEMBER_ATTR_CUSTOM_WEIGHT SAI_LAG_MEMBER_ATTR_WEIGHT

    #define SAI_MIRROR_SESSION_ATTR_CUSTOM_GRE_FLAGS_VER_RSVD                         SAI_MIRROR_SESSION_ATTR_GRE_HEADER_FIRST_16BIT
    #define SAI_MIRROR_SESSION_ATTR_CUSTOM_ERSPAN_SESSION_ID                          SAI_MIRROR_SESSION_ATTR_ERSPAN_SESSION_ID
    #define SAI_ERSPAN_ENCAPSULATION_TYPE_CUSTOM_MIRROR_L3_GRE_TUNNEL_ERSPAN_TYPE_II  SAI_ERSPAN_ENCAPSULATION_TYPE_II
    #define SAI_ERSPAN_ENCAPSULATION_TYPE_CUSTOM_MIRROR_L3_GRE_TUNNEL_ERSPAN_TYPE_III SAI_ERSPAN_ENCAPSULATION_TYPE_III

    #define SAI_TAM_COLLECTOR_ATTR_CUSTOM_SRC_MAC      SAI_TAM_COLLECTOR_ATTR_SRC_MAC
    #define SAI_TAM_COLLECTOR_ATTR_CUSTOM_DST_MAC      SAI_TAM_COLLECTOR_ATTR_DST_MAC
    #define SAI_TAM_COLLECTOR_ATTR_CUSTOM_DESTINATION  SAI_TAM_COLLECTOR_ATTR_DESTINATION
    #define SAI_TAM_TRANSPORT_TYPE_CUSTOM_GRE          SAI_TAM_TRANSPORT_TYPE_GRE
*/

/**
 * below KS specific custom attributes are not including CUSTOM keyword
 * defining same attribute with CUSTOM keyword so in production codebase
 * it will be identified as CUSTOM attributes
 */

/*
 * Name-compatibility aliases for attributes already defined in their own custom
 * header. The cond/endcond block hides them from the metadata/RPC generator so it
 * does not emit duplicate definitions; it has no effect on normal compilation.
 */
/** @cond */
#define SAI_PORT_ATTR_FIELD_SRC_IP        SAI_PORT_ATTR_CUSTOM_FIELD_SRC_IP
#define SAI_PORT_ATTR_FIELD_DST_IP        SAI_PORT_ATTR_CUSTOM_FIELD_DST_IP
#define SAI_PORT_ATTR_FIELD_SRC_IPV6      SAI_PORT_ATTR_CUSTOM_FIELD_SRC_IPV6
#define SAI_PORT_ATTR_FIELD_DST_IPV6      SAI_PORT_ATTR_CUSTOM_FIELD_DST_IPV6
#define SAI_PORT_ATTR_FIELD_L4_SRC_PORT   SAI_PORT_ATTR_CUSTOM_FIELD_L4_SRC_PORT
#define SAI_PORT_ATTR_FIELD_L4_DST_PORT   SAI_PORT_ATTR_CUSTOM_FIELD_L4_DST_PORT
#define SAI_PORT_ATTR_FIELD_IP_PROTOCOL   SAI_PORT_ATTR_CUSTOM_FIELD_IP_PROTOCOL
#define SAI_PORT_ATTR_FIELD_EGRESS_PORT   SAI_PORT_ATTR_CUSTOM_FIELD_EGRESS_PORT
#define SAI_ACL_TABLE_CUSTOM_SUPPORTED_MATCH_TYPE_TERNARY_AND_EXACT \
        SAI_ACL_TABLE_SUPPORTED_MATCH_TYPE_CUSTOM_TERNARY_AND_EXACT
/** @endcond */
