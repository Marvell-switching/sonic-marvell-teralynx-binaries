/**
 *copyright (c) 2025 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saitunnelcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITUNNELCUSTOM_H_
#define __SAITUNNELCUSTOM_H_

#include <saitunnel.h>
#include <saitypes.h>

/**
 * @brief SAI tunnel custom attribute
 */
typedef enum _sai_tunnel_attr_custom_t
{
    /**
     * @brief User-based egress tunnel metadata
     *
     * Metadata tagged on the tunnel object, matchable in an egress ACL via
     * the SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_TUNNEL_USER_META ACL entry attribute.
     *
     * Value must be in the range defined in
     * #SAI_SWITCH_ATTR_CUSTOM_TUNNEL_META_DATA_EGRESS_RANGE.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_TUNNEL_ATTR_CUSTOM_META_DATA_EGRESS = SAI_TUNNEL_ATTR_CUSTOM_RANGE_START,

} sai_tunnel_attr_custom_t;

/*
 * One past the last custom tunnel attribute (exclusive upper bound). Defined as
 * a macro rather than an enum member so the SAI metadata/RPC generator does not
 * treat it as an attribute requiring type/flags annotations. The doxygen
 * cond/endcond commands exclude it from the generated doxygen output the
 * generator consumes; it has no effect on normal compilation.
 */
/** @cond */
#define SAI_TUNNEL_ATTR_CUSTOM_RANGE_MAX \
        (SAI_TUNNEL_ATTR_CUSTOM_META_DATA_EGRESS + 1)
/** @endcond */

#endif /* __SAITUNNELCUSTOM_H_ */
