/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_vlan.h
 * @brief ISAI IM Include file for VLAN module
 */

#ifndef __IFCS_SAI_VLAN_H__
#define __IFCS_SAI_VLAN_H__

#define ISAI_MODULE_LOCK_VLAN 1ULL

#include "ifcs_sai_acl.h"
#include "ifcs_sai_bridge.h"
#include "ifcs_sai_ipmc.h"
#include "ifcs_sai_l2mc_group.h"
#include "ifcs_sai_lag.h"
#include "ifcs_sai_switch.h"
#include "isai_im_nmgr.h"
#endif /* __IFCS_SAI_VLAN_H__ */
