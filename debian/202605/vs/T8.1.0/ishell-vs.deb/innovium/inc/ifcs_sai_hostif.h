/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_hostif.h
 * @brief ISAI IM Include file for HOSTIF module
 */

#ifndef __IFCS_SAI_HOSTIF_H__
#define __IFCS_SAI_HOSTIF_H__

#define ISAI_MODULE_LOCK_HOSTIF 1ULL

#include "ifcs_sai_acl.h"
#include "ifcs_sai_counter.h"
#include "ifcs_sai_fdb.h"
#include "ifcs_sai_ipmc.h"
#include "ifcs_sai_l2mc.h"
#include "ifcs_sai_neighbor.h"
#include "ifcs_sai_policer.h"
#include "ifcs_sai_route.h"
#include "ifcs_sai_srv6.h"
#include "isai_im_nmgr.h"
#endif /* __IFCS_SAI_HOSTIF_H__ */
