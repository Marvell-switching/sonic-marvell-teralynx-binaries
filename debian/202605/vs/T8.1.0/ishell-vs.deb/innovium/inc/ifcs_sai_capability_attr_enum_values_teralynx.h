
/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2026) Marvell. All rights reserved.
 * This file is auto generated. DO NOT EDIT!
 *-------------------------------------------------------------------------------------
 */
#ifndef __IFCS_SAI_CAPABILITY_ATTR_ENUM_VALUES_TERALYNX_H__
#define __IFCS_SAI_CAPABILITY_ATTR_ENUM_VALUES_TERALYNX_H__
#include "ifcs_sai_shim_util.h"

sai_status_t sai_query_attribute_enum_values_capability_teralynx(sai_object_id_t switch_id, sai_object_type_t object_type, sai_attr_id_t attr_id, sai_s32_list_t *enum_values_capability);

#endif /* __IFCS_SAI_CAPABILITY_ATTR_ENUM_VALUES_TERALYNX_H__ */
