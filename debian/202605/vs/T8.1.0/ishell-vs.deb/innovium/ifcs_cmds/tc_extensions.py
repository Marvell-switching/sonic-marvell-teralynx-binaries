#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import sys
from ifcs_cmds.tc import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
ifcs_ctypes = sys.modules['ifcs_ctypes']


def _tc_attr_is_valid(tc_instance, attr_name):
    '''Return whether a tc attribute is supported on the current node.

    Resolves the attribute enum and the im_tc_attr_is_valid() helper via
    getattr so that an older/stale ifcs_ctypes binding (missing newer symbols)
    is treated as "attribute not supported" instead of raising AttributeError
    and forcing the CLI to fall back to the help text.
    '''
    attr = getattr(ifcs_ctypes, attr_name, None)
    is_valid_fn = getattr(ifcs_ctypes, 'im_tc_attr_is_valid', None)
    if attr is None or is_valid_fn is None:
        return False
    try:
        return bool(is_valid_fn(tc_instance.cli.node_id, attr))
    except Exception:
        return False


def show_tc_extension_brief(args, tc_instance):
    log_dbg(1, "Inside tc extension brief show")
    '''Displays summary of all instances of type Tc.'''

    # tc_instance is the Tc() object; avoid using undefined 'self'.
    try:
        rc, all_tc = tc_instance.bulk_get_all_tc_keys()
    except Exception:
        log_err("Failed to get all tc")
        return

    table = PrintTable()

    field_names = ['Tc', 'lossless', 'queue_id', 'ps_id', 'pfc_rx_cp', 'pfc_tx_cp']

    non_uc_queue_id_is_valid = _tc_attr_is_valid(
        tc_instance, 'IFCS_TC_ATTR_NON_UC_QUEUE_ID')
    field_names.append('pause_ps_id')

    if non_uc_queue_id_is_valid:
        field_names.append('non_uc_queue_id')

    table.add_row(field_names)

    try:
        sort_key = tc_instance.filter_option.get('sort')
        if sort_key in tc_instance.get_methods:
            all_tc = sorted(all_tc, key=lambda x: tc_instance.get_methods[sort_key](x))
        else:
            all_tc = sorted(all_tc)
    except Exception:
        all_tc = sorted(all_tc)

    log("Total tc count: {0} ".format(len(all_tc)))
    count = 0
    for tc_key in all_tc:
        attr_row = [str(tc_key)]
        try:
            lossless = tc_instance.getLossless(tc_key, True)
            queue_id = tc_instance.getQueueId(tc_key, True)
            ps_id = tc_instance.getPsId(tc_key, True)
            pfc_rx_cp = tc_instance.getPfcRxCp(tc_key, True)
            pfc_tx_cp = tc_instance.getPfcTxCp(tc_key, True)
            if non_uc_queue_id_is_valid:
                non_uc_queue_id = tc_instance.getNonUcQueueId(tc_key, True)
            pause_ps_id = tc_instance.getPausePsId(tc_key, True)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(1, "KeyError in show tc brief. tc: {}, error: {}".format(tc_key, einfo))
            if tc_instance.not_found_exc_msg.format(ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                continue
            raise

        attr_row.append('N/A' if lossless is None else tc_instance.enum_to_str('bool', lossless))
        attr_row.append('N/A' if queue_id is None else str(queue_id))
        attr_row.append('N/A' if ps_id is None else str(ps_id))
        attr_row.append('N/A' if pfc_rx_cp is None else tc_instance.enum_to_str('pfc_rx_cp', pfc_rx_cp))
        attr_row.append('N/A' if pfc_tx_cp is None else tc_instance.enum_to_str('pfc_tx_cp', pfc_tx_cp))
        attr_row.append('N/A' if pause_ps_id is None else str(pause_ps_id))
        if non_uc_queue_id_is_valid:
            attr_row.append('N/A' if non_uc_queue_id is None else str(non_uc_queue_id))
        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total tc count: {0}".format(count))
    return
