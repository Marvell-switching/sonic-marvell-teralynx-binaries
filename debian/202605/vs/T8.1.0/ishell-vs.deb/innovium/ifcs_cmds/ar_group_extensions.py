#-------------------------------------------------------------------------------
# Copyright (c) (2026) Marvell. All rights reserved
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

ar_group_usage_obj_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_GLOBAL: "Global",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG1: "Stage-1",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG1_AQGC_ENABLED: "Stage-1 (AQGC enabled)",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG1_AQGC_DISABLED: "Stage-1 (AQGC disabled)",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG2: "Stage-2",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG2_AQGC_ENABLED: "Stage-2 (AQGC enabled)",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG2_AQGC_DISABLED: "Stage-2 (AQGC disabled)",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_SW_GLOBAL: "Global",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_SW_AQGC_ENABLED: "AQGC Enabled",
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_SW_AQGC_DISABLED: "AQGC Disabled",
}

# HW usage: real HW-row consumption, keyed by ECMP attach state (D.9).
ar_group_usage_obj_order_hw = [
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_GLOBAL,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG1,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG1_AQGC_ENABLED,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG1_AQGC_DISABLED,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG2,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG2_AQGC_ENABLED,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_ECMP_STG2_AQGC_DISABLED,
]

# SW usage: ar_group objects tallied by AQGC as of create/delete, independent
# of whether they're ever attached to an ECMP.
ar_group_usage_obj_order_sw = [
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_SW_GLOBAL,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_SW_AQGC_ENABLED,
    ifcs_ctypes.IFCS_USAGE_OBJ_AR_GROUP_SW_AQGC_DISABLED,
]


def _fetch_ar_group_usage(node_id, order_list):
    num_obj = len(order_list)
    usage_p = (ifcs_ctypes.ifcs_usage_t * num_obj)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * num_obj)()

    for index in range(num_obj):
        obj[index].ar_group = order_list[index]

    for index in range(num_obj):
        ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_AR_GROUP)
        ifcs_ctypes.ifcs_usage_t_obj_type_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            compat_pointerAtIndex(obj, ifcs_ctypes.ifcs_usage_obj_t, index))
        rc = ifcs_ctypes.ifcs_ar_group_usage_detail_get(
            node_id, 0, None,
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index))
        rc_reason = ifcs_ctypes.IFCS_STATUS_REASON(rc)
        if rc_reason != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get AR group usage rc: {} ({})".format(
                rc, rc_reason))
            return None
    return usage_p


def _print_ar_group_usage_section(title, order_list, usage_p):
    log(title)
    table = PrintTable()
    table.add_row(["usage type", "max", "used", "available"])
    for index in range(len(order_list)):
        table.add_row([
            ar_group_usage_obj_dict[order_list[index]],
            usage_p[index].max, usage_p[index].current,
            usage_p[index].available
        ])
    table.print_table(brief=True)
    table.reset_table()


def show_ar_group_extension_usage_detail(arg1, arg2, self):
    log_dbg(1, " Inside extension ar_group usage detail show")

    sw_usage_p = _fetch_ar_group_usage(self.cli.node_id, ar_group_usage_obj_order_sw)
    if sw_usage_p is None:
        return
    _print_ar_group_usage_section("SW usage:", ar_group_usage_obj_order_sw, sw_usage_p)

    hw_usage_p = _fetch_ar_group_usage(self.cli.node_id, ar_group_usage_obj_order_hw)
    if hw_usage_p is None:
        return
    _print_ar_group_usage_section("HW usage:", ar_group_usage_obj_order_hw, hw_usage_p)
    return
