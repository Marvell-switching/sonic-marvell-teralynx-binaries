#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

import copy
import socket
import struct
from ctypes import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

# Key type dictionary for my_sid_entry
key_type_dict = {
    ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID : "sid",
}

def get_sid_from_my_sid_entry(my_sid_entry):
    """Extract SID from my_sid_entry key"""
    if my_sid_entry.contents.key_type == ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID:
        return socket.inet_ntop(
                    socket.AF_INET6,
                    my_sid_entry.contents.key.sid.sid)
    return "0x0"

def get_locator_block_len_from_my_sid_entry(my_sid_entry):
    """Extract locator block length from my_sid_entry key"""
    if my_sid_entry.contents.key_type == ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID:
        return my_sid_entry.contents.key.sid.locator_block_len
    return 0

def get_locator_node_len_from_my_sid_entry(my_sid_entry):
    """Extract locator node length from my_sid_entry key"""
    if my_sid_entry.contents.key_type == ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID:
        return my_sid_entry.contents.key.sid.locator_node_len
    return 0

def get_function_len_from_my_sid_entry(my_sid_entry):
    """Extract function length from my_sid_entry key"""
    if my_sid_entry.contents.key_type == ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID:
        return my_sid_entry.contents.key.sid.function_len
    return 0

def get_args_len_from_my_sid_entry(my_sid_entry):
    """Extract args length from my_sid_entry key"""
    if my_sid_entry.contents.key_type == ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID:
        return my_sid_entry.contents.key.sid.args_len
    return 0

def get_key_from_my_sid_entry(entry, my_sid_entry_obj):
    """Extract all key components from my_sid_entry"""
    sid = get_sid_from_my_sid_entry(entry)
    locator_block_len = get_locator_block_len_from_my_sid_entry(entry)
    locator_node_len = get_locator_node_len_from_my_sid_entry(entry)
    function_len = get_function_len_from_my_sid_entry(entry)
    args_len = get_args_len_from_my_sid_entry(entry)
    
    return sid, locator_block_len, locator_node_len, function_len, args_len


def show_my_sid_entry_extension_brief(args, my_sid_entry):
    log_dbg(1, " Inside my_sid_entry extension brief show")

    try:
        if args:
            rc, all_keys = my_sid_entry.bulk_get_all_my_sid_entry_keys(args)
        else:
            rc, all_keys = my_sid_entry.bulk_get_all_my_sid_entry_keys()
    except BaseException:
        log_err(" Failed to get all my_sid_entry objects")
        return

    # Check device type. Some attributes are not supported on all devices and
    # must not be requested, otherwise the get returns IFCS_UNSUPPORTED and the
    # actual attribute count won't match the requested count.
    node_id = my_sid_entry.cli.node_id if my_sid_entry.cli.node_id is not None else 0
    device_type = ifcs_ctypes.im_nmgr_node_device_type_get(node_id)
    is_t100 = (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_T100)
    # TL7 maps to the TERALYNX device type and does not support l3vni_handle.
    is_tl7 = (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX)

    table = PrintTable()

    field_names = [
        'key_type',
        'sid',
        'locator_block_len',
        'locator_node_len',
        'function_len',
        'args_len',
        'endpoint_behavior',
        'endpoint_behavior_flavor',
        'l3vni_handle',
        'fwd_policy',
        'ctc_policy'
    ]

    attr_ids = [
        ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_ENDPOINT_BEHAVIOR,
        ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_ENDPOINT_BEHAVIOR_FLAVOR,
        ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_L3VNI_HANDLE,
        ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_FWD_POLICY,
        ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_CTC_POLICY,
        ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_FLEX_COUNTER
    ]

    # l3vni_handle is not supported on TL7 (TERALYNX); requesting it there
    # returns IFCS_UNSUPPORTED and breaks the attribute count check below.
    # It remains supported on TL10 and t100.
    if is_tl7:
        field_names.remove('l3vni_handle')
        attr_ids.remove(ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_L3VNI_HANDLE)

    # Add decap_dscp_mode only for t100 devices
    if is_t100:
        field_names.append('decap_dscp_mode')
        # Insert decap_dscp_mode before flex_counter in attr_ids
        attr_ids.insert(-1, ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_DECAP_DSCP_MODE)

    table.add_row(field_names)
    attr_count = len(attr_ids)

    log("Total my_sid_entry count : {0} ".format(len(all_keys)))
    
    
    count = 0

    for key_idx in range(len(all_keys)):
        row = []
        key_ptr = all_keys[key_idx]
        key_type = key_type_dict[key_ptr.contents.key_type]
        sid, locator_block_len, locator_node_len, function_len, args_len = get_key_from_my_sid_entry(key_ptr, my_sid_entry)
        locator_block_len = get_locator_block_len_from_my_sid_entry(key_ptr)
        locator_node_len = get_locator_node_len_from_my_sid_entry(key_ptr)
        function_len = get_function_len_from_my_sid_entry(key_ptr)
        args_len = get_args_len_from_my_sid_entry(key_ptr)
        sid = get_sid_from_my_sid_entry(key_ptr)


        # Get all attributes
        attr_list = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        for attr_idx in range(attr_count):
            attr_list[attr_idx].id = attr_ids[attr_idx]
        attr_p = compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t)

        try:
            actual_count = my_sid_entry.getAttr(key_ptr, attr_list, attr_p, attr_count, True)
            actual_count = actual_count.value
            if actual_count != attr_count:
                msg = "Attribute count different in show my_sid_entry. expected: {}, actual: {}".format(attr_count, actual_count)
                raise KeyError(msg)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(1, "KeyError in show my_sid_entry. my_sid_entry: {}, error: {}".
                    format(key_ptr, einfo))
            if my_sid_entry.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Don't display error message for expected exception.
                # Skip the instance as the object is not found.
                continue
            log_err("Failed to get attributes for my_sid_entry YYY")
            raise
        except BaseException:
            log_dbg(
                1, "OtherError in show my_sid_entry. my_sid_entry: {}, error: {}". format(key_ptr, sys.exc_info()))
            log_err("Failed to get attributes for my_sid_entry ")
            raise KeyError

        # Process attribute values and display
        count += 1
        endpoint_behavior = " * "
        endpoint_behavior_flavor = " * "
        l3vni_handle = " * "
        fwd_policy = " * "
        ctc_policy = " * "
        decap_dscp_mode = " * "
        
        for attr_idx in range(attr_count):
            if attr_list[attr_idx].id == ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_ENDPOINT_BEHAVIOR:
                if attr_list[attr_idx].bitmap.u32:
                    endpoint_behavior = my_sid_entry.enum_to_str('endpoint_behavior', attr_list[attr_idx].value.u32)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_ENDPOINT_BEHAVIOR_FLAVOR:
                if attr_list[attr_idx].bitmap.u32:
                    endpoint_behavior_flavor = my_sid_entry.enum_to_str('endpoint_behavior_flavor', attr_list[attr_idx].value.u32)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_L3VNI_HANDLE:
                if attr_list[attr_idx].bitmap.handle:
                    l3vni_handle = my_sid_entry.handle_to_str(attr_list[attr_idx].value.handle)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_FWD_POLICY:
                if attr_list[attr_idx].bitmap.fwd_policy:
                    fwd_policy_val = attr_list[attr_idx].value.fwd_policy
                    fwd_policy = my_sid_entry.handle_to_str(fwd_policy_val.pp_drop_reason), my_sid_entry.enum_to_str('fwd_action', fwd_policy_val.fwd_action)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_CTC_POLICY:
                if attr_list[attr_idx].bitmap.ctc_policy:
                    ctc_policy_val = attr_list[attr_idx].value.ctc_policy
                    ctc_policy = my_sid_entry.handle_to_str(ctc_policy_val.trap_handle), my_sid_entry.enum_to_str('copy_to_cpu', ctc_policy_val.ctc_action)
                continue
            elif attr_list[attr_idx].id == ifcs_ctypes.IFCS_MY_SID_ENTRY_ATTR_DECAP_DSCP_MODE:
                if attr_list[attr_idx].bitmap.u32:
                    decap_dscp_mode = my_sid_entry.enum_to_str('decap_dscp_mode', attr_list[attr_idx].value.u32)
                continue

        row.append(key_type)
        row.append(sid)
        row.append(locator_block_len)
        row.append(locator_node_len)
        row.append(function_len)
        row.append(args_len)
        row.append(endpoint_behavior)
        row.append(endpoint_behavior_flavor)
        # l3vni_handle is not supported on TL7 (TERALYNX).
        if not is_tl7:
            row.append(l3vni_handle)
        row.append(fwd_policy)
        row.append(ctc_policy)
        # Add decap_dscp_mode only for t100 devices
        if is_t100:
            row.append(decap_dscp_mode)
        table.add_row(row)
        
    table.print_table(brief=True)
    table.reset_table()
    log("Total my_sid_entry count: {0} \n".format(count))

    return


def show_my_sid_entry_extension_key_helper(entry, my_sid_entry_obj):
    """Helper function to extract key information for display"""
    log_dbg(1, " Inside my_sid_entry extension key helper")
    key_type = key_type_dict[entry.contents.key_type]
    sid, locator_block_len, locator_node_len, function_len, args_len = get_key_from_my_sid_entry(
        entry, my_sid_entry_obj)
    
    if entry.contents.key_type == ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID:
        return [('key_type', key_type),
                ('sid', sid),
                ('locator_block_len', locator_block_len),
                ('locator_node_len', locator_node_len),
                ('function_len', function_len),
                ('args_len', args_len)]
    else:
        return []


def show_my_sid_entry_extension_usage_helper(my_sid_entry, filter_option):
    """Helper function to display usage statistics"""
    usage_p = ifcs_ctypes.ifcs_usage_t()

    if filter_option not in ['sid', 'all']:
        log_err("Invalid filter option {0}".format(filter_option))
        return

    my_sid_entry_key = ifcs_ctypes.ifcs_my_sid_entry_key_t()
    ifcs_ctypes.ifcs_my_sid_entry_key_t_init(pointer(my_sid_entry_key))
    
    if filter_option == 'sid':
        ifcs_ctypes.ifcs_my_sid_entry_key_t_key_type_set(pointer(my_sid_entry_key), ifcs_ctypes.IFCS_MY_SID_ENTRY_KEY_TYPE_SID)

    rc = ifcs_ctypes.ifcs_my_sid_entry_usage_get(0, pointer(my_sid_entry_key), 0, None, pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get all {0} my_sid_entry rc: {1}".format(filter_option, convert_error_code_to_string(rc)))
        return

    log("Usage for {0} my_sid entries".format(filter_option))

    table = PrintTable()
    table.add_row(["Current", "Max"])
    table.add_row([usage_p.current, usage_p.max])
    table.print_table()
    table.reset_table()

    return


def show_my_sid_entry_extension_usage(arg1, arg2, my_sid_entry):
    """Display usage statistics for my_sid_entry"""
    log_dbg(1, " Inside extension usage show")

    if my_sid_entry.filter_option == {}:
        for filter_option in ['sid']:
            show_my_sid_entry_extension_usage_helper(my_sid_entry, filter_option)
            log("\n")
    else:
        filter_option = (my_sid_entry.filter_option['filter']).strip()
        show_my_sid_entry_extension_usage_helper(my_sid_entry, filter_option)

    return


def show_my_sid_entry_extension_usage_detail(arg1, arg2, my_sid_entry):
    """Display detailed usage statistics for my_sid_entry"""
    log_dbg(1, " Inside extension usage detail show")

    usage_title = {
        'my_sid_entry': "My SID Entry"
    }

    usage_p = ifcs_ctypes.ifcs_usage_t()
    obj_type = ifcs_ctypes.ifcs_usage_obj_t()

    log("My SID Entry Usage Details")
    table = PrintTable()
    table.set_justification("left")
    table.add_row(["Type", "Current", "Free", "Max"])

    ifcs_ctypes.ifcs_usage_t_init(pointer(usage_p))
    rc = ifcs_ctypes.ifcs_my_sid_entry_usage_detail_get(0, None, 0, None, pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get my_sid_entry usage detail rc: {0}".format(convert_error_code_to_string(rc)))
        return

    table.add_row(["My SID Entry", usage_p.current, usage_p.available, usage_p.max])
    table.print_table()
    table.reset_table()
    log("\n")
    
    return

