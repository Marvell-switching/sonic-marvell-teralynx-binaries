/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License
 *Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */
/**
 * @file  ifcs_sai_port.h
 * @brief ISAI IM Include file for PORT module
 */

#ifndef __IFCS_SAI_PORT_H__
#define __IFCS_SAI_PORT_H__

#define ISAI_MODULE_LOCK_PORT 1ULL

#include "ifcs_sai_arsprofile.h"
#include "ifcs_sai_buffer.h"
#include "ifcs_sai_debug_counter.h"
#include "ifcs_sai_hostif.h"
#include "ifcs_sai_isolation_group.h"
#include "ifcs_sai_mirror.h"
#include "ifcs_sai_policer.h"
#include "ifcs_sai_qos_common.h"
#include "ifcs_sai_qosmap.h"
#include "ifcs_sai_queue.h"
#include "ifcs_sai_samplepacket.h"
#include "ifcs_sai_scheduler_group.h"
#include "ifcs_sai_switch.h"
#include "ifcs_sai_wred.h"
#include "isai_im_nmgr.h"
#endif /* __IFCS_SAI_PORT_H__ */
