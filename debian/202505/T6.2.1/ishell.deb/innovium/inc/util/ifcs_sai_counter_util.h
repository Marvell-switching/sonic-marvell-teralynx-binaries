/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_counter_util.h
 * @brief ISAI Util Include file for Counter module
 */


#ifndef __IFCS_SAI_COUNTER_UTIL_H__
#define __IFCS_SAI_COUNTER_UTIL_H__

#include "util/ifcs_sai_counter_util_dep.h"
#include "ifcs_sysport.h"

sai_status_t
isai_im_counter_init(sai_switch_init_info_t * sai_switch_init_info_p);

sai_status_t
isai_im_counter_alloc_flex_pool_counter_with_id(ifcs_node_id_t    node_id,
                                                ifcs_handle_t     flex_counter_hdl);

sai_status_t
isai_im_counter_free_flex_pool_counter_with_id(ifcs_node_id_t    node_id,
                                               ifcs_handle_t     flex_counter_hdl);
/*
 * Routine Description:
 *   Attach/Detach Bindpoint Oid to Counter Oid
 *
 * Arguments:
 *    [in] node_id            - IFCS node_id
 *    [in] counter_oid        - Object Id of Counter
 *    [in] bindpoint_obj_id   - Object Id of bindpoint
 *    [in] counter_ids        - specifies the array of counter ids
 *    [in] is_attach          - 1-Attach , 0-Detach
 *
 * Return Values:
 *    SAI_STATUS_SUCCESS on success
 *    Failure status code on error
 */
sai_status_t
isai_im_counter_attach_sai_object(ifcs_node_id_t    node_id,
                                  sai_object_id_t   counter_oid,
                                  sai_object_id_t   bindpoint_obj_id,
                                  bool              is_attach);


#endif /* __IFCS_SAI_COUNTER_UTIL_H__ */

