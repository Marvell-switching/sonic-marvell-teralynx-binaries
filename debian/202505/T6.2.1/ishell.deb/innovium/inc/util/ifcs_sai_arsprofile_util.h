/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_ars_profile_util.h
 * @brief ISAI Util Include file for ARSPROFILE module
 */


#ifndef __IFCS_SAI_ARSPROFILE_UTIL_H__
#define __IFCS_SAI_ARSPROFILE_UTIL_H__

#include "util/ifcs_sai_arsprofile_util_dep.h"



/**
 * @brief Initializes ARS Profile module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_profile_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes ARS Profile module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_ars_profile_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/**
 * @brief Retrieves the threshold attributes for a given ARS profile.
 *
 * @param node_id The ID of the node.
 * @param ars_profile_oid The object ID of the ARS profile.
 * @param threshold_p A pointer to the threshold attributes structure.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_profile_get_threshold_attributes(ifcs_node_id_t node_id,
                                            sai_object_id_t ars_profile_oid,
                                            ars_config_thresholds_t *threshold_p);

/**
 * @brief Retrieves the attributes for a given ARS profile.
 *
 * @param switch_id The object ID of the switch.
 * @param ars_profile_id The object ID of the ARS profile.
 * @param attr_count The number of attributes to retrieve.
 * @param attr_list_p Pointer to an array of attribute structures.
 * @return sai_status_t
 */
sai_status_t
isai_im_ars_profile_get_attribute(sai_object_id_t switch_id,
                                  sai_object_id_t ars_profile_id,
                                  uint32_t attr_count,
                                  sai_attribute_t *attr_list_p);
#endif /* __IFCS_SAI_ARSPROFILE_UTIL_H__ */