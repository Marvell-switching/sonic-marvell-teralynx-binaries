/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_isolation_group_util.h
 * @brief ISAI Util Include file for ISOLATION_GROUP module
 */


#ifndef __IFCS_SAI_ISOLATION_GROUP_UTIL_H__
#define __IFCS_SAI_ISOLATION_GROUP_UTIL_H__

#include "util/ifcs_sai_isolation_group_util_dep.h"

sai_status_t
isai_im_isolation_group_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);

sai_status_t
isai_im_isolation_group_init(sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_isolation_group_get_isg_port_oid(sai_object_id_t *isg_oid_p);

sai_status_t
isai_im_isolation_group_port_set(ifcs_node_id_t   node_id,
                                        sai_object_id_t port_id,
                                        sai_attribute_t *attr_p);

sai_status_t
isai_im_isolation_group_get_isg_port_list(ifcs_node_id_t  node_id,
                                          sai_object_id_t isg_oid,
                                          sai_attribute_t *attr_p);

sai_status_t
isai_im_isolation_group_get_bp_isg_oid(sai_object_id_t   bp_oid,
                            sai_object_id_t   *isg_oid);
#endif /* __IFCS_SAI_ISOLATION_GROUP_UTIL_H__ */
