/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    sairouterinterfacecustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIROUTERINTERFACECUSTOM_H_
#define __SAIROUTERINTERFACECUSTOM_H_

#include <sairouterinterface.h>
#include <saitypes.h>


/**
 * @brief sai router interface custom attribute
 */
typedef enum _sai_router_interface_attr_custom_t
{
    /**
     *@brief User based Meta Data Ingress
     *
     * Value Range #SAI_SWITCH_ATTR_CUSTOM_ROUTER_INTERFACE_META_DATA_INGRESS_RANGE
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_META_DATA_INGRESS = SAI_ROUTER_INTERFACE_ATTR_CUSTOM_RANGE_START,

    /**
     *@brief User based Meta Data Egress
     *
     * Value Range #SAI_SWITCH_ATTR_CUSTOM_ROUTER_INTERFACE_META_DATA_EGRESS_RANGE
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_META_DATA_EGRESS,

    /**
     * @brief Enable DSCP -> TC MAP on Router Interface.
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on Router Interface.
     * To enable/disable trust DSCP, map ID should be added/removed on Router Interface.
     * Default no map.

     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_QOS_DSCP_TO_TC_MAP,

    /**
     * @brief Enable DSCP -> COLOR MAP on Router Interface.
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on Router Interface.
     * To enable/disable trust DSCP, map ID should be added/removed on Router Interface.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_QOS_DSCP_TO_COLOR_MAP,

    /**
     * @brief Enable DOT1P -> TC MAP on Router Interface.
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on Router Interface.
     * To enable/disable trust Dot1p, map ID should be added/removed on Router Interface.
     * Default no map.

     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_QOS_DOT1P_TO_TC_MAP,

    /**
     * @brief Enable DOT1P -> COLOR MAP on Router Interface.
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on Router Interface.
     * To enable/disable trust Dot1p, map ID should be added/removed on Router Interface.
     * Default no map.

     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_QOS_DOT1P_TO_COLOR_MAP,

    /**
     * @brief Enable TC AND COLOR -> DSCP MAP on Router Interface.
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on Router Interface.
     * Default no map.

     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_QOS_TC_AND_COLOR_TO_DSCP_MAP,

    /**
     * @brief Enable TC AND COLOR -> DOT1P MAP on Router Interface.
     *
     * Map id = #SAI_NULL_OBJECT_ID to disable map on Router Interface.
     * Default no map.

     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_ROUTER_INTERFACE_ATTR_CUSTOM_QOS_TC_AND_COLOR_TO_DOT1P_MAP,

}sai_router_interface_attr_custom_t;

#endif /* __SAIROUTERINTERFACECUSTOM_H_ */
