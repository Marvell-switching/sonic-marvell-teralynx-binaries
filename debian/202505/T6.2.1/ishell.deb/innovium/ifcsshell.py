#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ifcs_cli import IFCS_CLI
import sys
import os
import argparse
import time
from verbosity import log, log_dbg

def main():
    intro = "\n\t\tInnovium Standalone Command Shell. \n\tType '?' or 'help' for help menu. Type 'quit' or 'exit' to exit shell."

    cli = IFCS_CLI(intro)
    parser = argparse.ArgumentParser(description="IFCS Shell",
                formatter_class=argparse.ArgumentDefaultsHelpFormatter)

    parser.add_argument('-c', '--config', dest='config', help="Config file to load")
    parser.add_argument('-i', '--input', dest='infile', nargs='*', help='space separated list of files to load')
    parser.add_argument('-C', '--cmd', dest='cmd', nargs='*', help='space separated list of commands to execute')
    parser.add_argument('-e', '--env', type=str, nargs='*',default=['switch'],help=' runtime environment for cli, set board, emulator or switch')
    parser.add_argument('-R',
                        '--skip_interactive',
                        dest='skip_interactive',
                        action='store_true',
                        default=False,
                        help="don't start interactive command prompt")

    args = parser.parse_args()
    cli.set_standalone(True)

    if args.config:
        cli.config(args.config)
    else:
        cli.config(None)

    try:
        if args.env:
            cli.set_rt_env(args.env[0])
    except:
        log("Unsupported environment. Exiting..")
        return

    cli.init_cmds()

    if args.cmd:
        for aCmd in args.cmd:
            log("Executing Command: %s" % aCmd)
            cli.onecmd(aCmd)
            if aCmd == "exit":
                log_dbg(1, "Exiting due to exit command")
                return

    if args.infile:
        for aFile in args.infile:
            cli.cmdqueue.append("source " + aFile)

    if args.skip_interactive:
        log("Interactive command prompt not started per -R option specified")
        while True:
            time.sleep(120)
        return

    doQuit = False
    while doQuit != True:
        try:
            cli.cmdloop()
            doQuit = True
        except (KeyboardInterrupt, Exception) as e:
            log("%s\n" % str(e))


if __name__ == "__main__":
    main()
