
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

from ctypes import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from ifcs_cmds.egress_vlan_tag_map_entry import *
from print_table import PrintTable
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

def prepare_tag_action_dict(tag_action_struct):

    tag_action_dict = {}
    tag_action_dict['action_if_tag_not_detected'] = ''
    tag_action_dict['action_if_tag_detected'] = ''
    tag_action_dict['action_param'] = ''
    if tag_action_struct._dirty_action_if_tag_not_detected == 1:
        if tag_action_struct.action_if_tag_not_detected._dirty_cmd == 1:
            if tag_action_struct.action_if_tag_not_detected.cmd == ifcs_ctypes.IFCS_TAG_ACTION_IF_TAG_NOT_DETECTED_CMD_NOOP:
                tag_action_dict['action_if_tag_not_detected'] = 'cmd:noop'
            elif tag_action_struct.action_if_tag_not_detected.cmd == ifcs_ctypes.IFCS_TAG_ACTION_IF_TAG_NOT_DETECTED_CMD_ADD:
                tag_action_dict['action_if_tag_not_detected'] = 'cmd:add'

    if tag_action_struct._dirty_action_if_tag_detected == 1:
        if tag_action_struct.action_if_tag_detected._dirty_cmd == 1:
            if tag_action_struct.action_if_tag_detected.cmd == ifcs_ctypes.IFCS_TAG_ACTION_IF_TAG_DETECTED_CMD_NOOP:
                tag_action_dict['action_if_tag_detected'] += ' cmd:noop'
            elif tag_action_struct.action_if_tag_detected.cmd == ifcs_ctypes.IFCS_TAG_ACTION_IF_TAG_DETECTED_CMD_DELETE:
                tag_action_dict['action_if_tag_detected'] += ' cmd:delete'
            elif tag_action_struct.action_if_tag_detected.cmd == ifcs_ctypes.IFCS_TAG_ACTION_IF_TAG_DETECTED_CMD_REPLACE:
                tag_action_dict['action_if_tag_detected'] += ' cmd:replace'

        if tag_action_struct.action_if_tag_detected._dirty_replace_vid_cmd == 1:
            if tag_action_struct.action_if_tag_detected.replace_vid_cmd == ifcs_ctypes.IFCS_TAG_ACTION_REPLACE_VID_CMD_NOOP:
                tag_action_dict['action_if_tag_detected'] += ' replace_vid_cmd:noop'
            elif tag_action_struct.action_if_tag_detected.replace_vid_cmd == ifcs_ctypes.IFCS_TAG_ACTION_REPLACE_VID_CMD_REPLACE:
                tag_action_dict['action_if_tag_detected'] += ' replace_vid_cmd:replace'
            elif tag_action_struct.action_if_tag_detected.replace_vid_cmd == ifcs_ctypes.IFCS_TAG_ACTION_REPLACE_VID_CMD_REPLACE_ONLY_IF_PRI_TAGGED:
                tag_action_dict['action_if_tag_detected'] += ' replace_vid_cmd:replace_only_if_pri_tagged'

        if tag_action_struct.action_if_tag_detected._dirty_replace_dot1p_cfi_cmd == 1:
            if tag_action_struct.action_if_tag_detected.replace_dot1p_cfi_cmd == ifcs_ctypes.IFCS_TAG_ACTION_REPLACE_DOT1P_CFI_CMD_NOOP:
                tag_action_dict['action_if_tag_detected'] += ' replace_dot1p_cfi_cmd:noop'
            elif tag_action_struct.action_if_tag_detected.replace_dot1p_cfi_cmd == ifcs_ctypes.IFCS_TAG_ACTION_REPLACE_DOT1P_CFI_CMD_REPLACE:
                tag_action_dict['action_if_tag_detected'] += ' replace_dot1p_cfi_cmd:replace'

    if tag_action_struct._dirty_action_param == 1:
        if tag_action_struct.action_param._dirty_vid_value == 1:
            tag_action_dict['action_param'] += ' vid_value:' + str(tag_action_struct.action_param.vid_value)

        if tag_action_struct.action_param._dirty_dot1p_cfi == 1:
            if tag_action_struct.action_param.dot1p_cfi._dirty_dot1p_cfi_source == 1:
                if tag_action_struct.action_param.dot1p_cfi.dot1p_cfi_source == ifcs_ctypes.IFCS_DOT1P_CFI_SOURCE_TYPE_USE_VALUE:
                    tag_action_dict['action_param'] += ' dot1p_cfi_source:use_value'
                elif tag_action_struct.action_param.dot1p_cfi.dot1p_cfi_source == ifcs_ctypes.IFCS_DOT1P_CFI_SOURCE_TYPE_USE_MAP:
                    tag_action_dict['action_param'] += ' dot1p_cfi_source:use_map'

            if tag_action_struct.action_param.dot1p_cfi._dirty_qosmap == 1:
                qosmap = tag_action_struct.action_param.dot1p_cfi.qosmap
                tag_action_dict['action_param'] += ' qosmap:' + hex(qosmap)

            if tag_action_struct.action_param.dot1p_cfi._dirty_dot1p_value == 1:
                dot1p_value = tag_action_struct.action_param.dot1p_cfi.dot1p_value
                tag_action_dict['action_param'] += ' dot1p_value:' + hex(dot1p_value)

            if tag_action_struct.action_param.dot1p_cfi._dirty_cfi_value == 1:
                cfi_value = tag_action_struct.action_param.dot1p_cfi.cfi_value
                tag_action_dict['action_param'] += ' cfi_value:' + hex(cfi_value)

    return tag_action_dict



def show_egress_vlan_tag_map_entry_extension_brief(
        args, egress_vlan_tag_map_entry):
    log_dbg(1, " Inside egress_vlan_tag_map_entry extension brief show")

    try:
        if args:
            rc, all_egress_vlan_tag_map_entry = egress_vlan_tag_map_entry.bulk_get_all_egress_vlan_tag_map_entry_keys(args)
        else:
            rc, all_egress_vlan_tag_map_entry = egress_vlan_tag_map_entry.bulk_get_all_egress_vlan_tag_map_entry_keys()
    except BaseException:
        log_err(" Failed to get all egress_vlan_tag_map_entry")
        return

    table = PrintTable()
    field_names = []

    field_names.append('type')
    field_names.append('key')

    field_names.append('ctag_action')
    field_names.append('stag_action')
    table.add_row(field_names)

    log("Total egress_vlan_tag_map_entry count: {0} ".format(len(all_egress_vlan_tag_map_entry)))
    count = 0
    for map_entry in all_egress_vlan_tag_map_entry:
        attr_row = []

        type = egress_vlan_tag_map_entry.enum_to_str('egress_vlan_tag_map_key_type', map_entry.contents.type)
        attr_row.append(type)
        union_key = map_entry.contents.key
        if type == 'l2vni':
            key = hex(union_key.l2vni.l2vni)
        elif type == 'l2vni_sysport':
            key = hex(union_key.l2vni_sysport.l2vni) + ':' + hex(union_key.l2vni_sysport.sysport)
        elif type == 'l2vni_sysport_svid':
            key = hex(union_key.l2vni_sysport_svid.l2vni) + ':' + hex(union_key.l2vni_sysport_svid.sysport) + ':' + str(union_key.l2vni_sysport_svid.svid)
        elif type == 'l2vni_sysport_cvid':
            key = hex(union_key.l2vni_sysport_cvid.l2vni) + ':' + hex(union_key.l2vni_sysport_cvid.sysport) + ':' + str(union_key.l2vni_sysport_cvid.cvid)
        elif type == 'l2vni_sysport_svid_cvid':
            key = hex(union_key.l2vni_sysport_svid_cvid.l2vni) + ':' + hex(union_key.l2vni_sysport_svid_cvid.sysport) + ':' + str(union_key.l2vni_sysport_svid_cvid.svid) + ':' + str(union_key.l2vni_sysport_svid_cvid.cvid)

        attr_row.append(key)

        try:
            ctag_action_struct = egress_vlan_tag_map_entry.getCtagAction(
                map_entry, True)
            stag_action_struct = egress_vlan_tag_map_entry.getStagAction(
                map_entry, True)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show egress_vlan_tag_map_entry extension brief. egress_vlan_tag_map_entry: {} (type: {}, key: {}), error: {}"
                .format(map_entry, type, key, einfo))
            if egress_vlan_tag_map_entry.not_found_exc_msg.format(
                    ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise

        ctag_action_dict = prepare_tag_action_dict(ctag_action_struct)
        stag_action_dict = prepare_tag_action_dict(stag_action_struct)

        for i in range(len(ctag_action_dict)):
            attr_row.append(compat_listkeys(ctag_action_dict)[i] + '=' + compat_listvalues(ctag_action_dict)[i])
            attr_row.append(compat_listkeys(stag_action_dict)[i] + '=' + compat_listvalues(stag_action_dict)[i])
            table.add_row(attr_row)
            attr_row = ['','']
        count += 1

    table.print_table(brief=True)
    log("Total egress_vlan_tag_map_entry count: {0} \n".format(count))

    return


def show_egress_vlan_tag_map_entry_extension_attrs(args,
                                                   egress_vlan_tag_map_entry,
                                                   ignore_notfound_err=False,
                                                   display_count=False,
                                                   count_val=0):
    log_dbg(1, " Inside egress_vlan_tag_map_entry extension attrs show")
    #self.handle = int(args)

    log(" Command Not Supported, since the output of 'brief' displays all the info. ")

    return
