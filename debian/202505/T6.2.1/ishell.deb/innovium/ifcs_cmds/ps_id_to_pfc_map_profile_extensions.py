#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import sys
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

def show_ps_id_to_pfc_map_profile_extension_brief(args, ps_id_to_pfc_map_profile):
    log_dbg(1, " Inside ps_id_to_pfc_map_profile extension brief show")
    ''' Displays summary of all instance of type ps_id_to_pfc_map_profile'''
    log_dbg(1, "In show_ps_id_to_pfc_map_profile_brief method")
    # Use the passed-in instance directly
    obj = ps_id_to_pfc_map_profile
    if not hasattr(obj, 'filter_option'):
        obj.filter_option = {'sort': 'info'}  # Default sort key
    try:
        all_ps_id_to_pfc_map_profile = obj.getAllps_id_to_pfc_map_profile()
    except Exception as e:
        log_err(" Failed to get all ps_id_to_pfc_map_profile")
        return
    table = PrintTable()
    field_names = []
    field_names.append('ps_id_to_pfc_map_profile')
    field_names.append('info (ps_id,pfc)')
    field_names.append('ref_count')
    table.add_row(field_names)
    try:
        if obj.filter_option['sort'] in obj.get_methods.keys():
            all_ps_id_to_pfc_map_profile = sorted(
                all_ps_id_to_pfc_map_profile,
                key=lambda x: obj.get_methods[obj.filter_option['sort']](x))
        else:
            log("Cannot sort on {0}".format(obj.filter_option['sort']))
            all_ps_id_to_pfc_map_profile = sorted(all_ps_id_to_pfc_map_profile)
    except:
        all_ps_id_to_pfc_map_profile = sorted(all_ps_id_to_pfc_map_profile)

    log("Total ps_id_to_pfc_map_profile count: {0} ".format(
        len(all_ps_id_to_pfc_map_profile)))
    count = 0
    for ps_id_to_pfc_map_profile in all_ps_id_to_pfc_map_profile:
        attr_row = []
        attr_row.append(obj.handle_to_str(ps_id_to_pfc_map_profile))

        try:
            info = obj.getInfo(ps_id_to_pfc_map_profile, True)
            ref_count = obj.getRefCount(ps_id_to_pfc_map_profile, True)

        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show ps_id_to_pfc_map_profile brief. ps_id_to_pfc_map_profile: {}, error: {}"
                .format(obj.handle_to_str(ps_id_to_pfc_map_profile),
                        einfo))
            if PsIdToPfcMapProfile.not_found_exc_msg.format(
                    obj.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise
        if info is None:
            attr_row.append('N/A')
        else:
            tuple_list = []
            for entry in info:
                ps_id = getattr(entry, 'ps_id', None)
                pfc = getattr(entry, 'pfc', None)
                tuple_list.append("({}, {})".format(ps_id, pfc))
            attr_row.append("[{}]".format(", ".join(tuple_list)))
        attr_row.append('N/A' if ref_count is None else str(ref_count))

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total ps_id_to_pfc_map_profile count: {0}".format(count))
    return
