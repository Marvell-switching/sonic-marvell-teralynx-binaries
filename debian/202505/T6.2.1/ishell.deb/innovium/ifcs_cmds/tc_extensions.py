#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import sys
from ifcs_cmds.tc import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
ifcs_ctypes = sys.modules['ifcs_ctypes']


def show_tc_extension_brief(args, tc_instance):
    log_dbg(1, "Inside tc extension brief show")
    '''Displays summary of all instances of type Tc.'''

    # tc_instance is the Tc() object; avoid using undefined 'self'.
    try:
        rc, all_tc = tc_instance.bulk_get_all_tc_keys()
    except Exception:
        log_err("Failed to get all tc")
        return

    hide_pfc_rx_cp = False
    hide_pfc_tx_cp = False

    # Determine attribute validity before building headers
    queue_id_to_pfc_map_mode_is_valid = ifcs_ctypes.im_tc_attr_is_valid(
        tc_instance.cli.node_id, ifcs_ctypes.IFCS_TC_ATTR_QUEUE_ID_TO_PFC_MAP_MODE)
    ps_id_to_pfc_map_mode_is_valid = ifcs_ctypes.im_tc_attr_is_valid(
        tc_instance.cli.node_id, ifcs_ctypes.IFCS_TC_ATTR_PS_ID_TO_PFC_MAP_MODE)
    try:
        if all_tc:
            first_tc = all_tc[0]
            if queue_id_to_pfc_map_mode_is_valid:
                rx_mode = tc_instance.getQueueIdToPfcMapMode(first_tc, True)
                if rx_mode == ifcs_ctypes.IFCS_QUEUE_ID_TO_PFC_MAP_MODE_PROFILE:
                    hide_pfc_rx_cp = True
            if queue_id_to_pfc_map_mode_is_valid:
                tx_mode = tc_instance.getPsIdToPfcMapMode(first_tc, True)
                if tx_mode == ifcs_ctypes.IFCS_QUEUE_ID_TO_PFC_MAP_MODE_PROFILE:
                    hide_pfc_tx_cp = True
    except Exception:
        log_dbg(1, "Error checking map mode, showing all columns")

    table = PrintTable()

    field_names = ['Tc', 'lossless', 'queue_id', 'ps_id']

    if not hide_pfc_rx_cp:
        field_names.append('pfc_rx_cp')
    if not hide_pfc_tx_cp:
        field_names.append('pfc_tx_cp')

    non_uc_queue_id_is_valid = ifcs_ctypes.im_tc_attr_is_valid(
        tc_instance.cli.node_id, ifcs_ctypes.IFCS_TC_ATTR_NON_UC_QUEUE_ID)
    field_names.append('pause_ps_id')

    if non_uc_queue_id_is_valid:
        field_names.append('non_uc_queue_id')

    if queue_id_to_pfc_map_mode_is_valid:
        field_names.append('queue_id_to_pfc_map_mode')
    if ps_id_to_pfc_map_mode_is_valid:
        field_names.append('ps_id_to_pfc_map_mode')

    table.add_row(field_names)

    try:
        sort_key = tc_instance.filter_option.get('sort')
        if sort_key in tc_instance.get_methods:
            all_tc = sorted(all_tc, key=lambda x: tc_instance.get_methods[sort_key](x))
        else:
            all_tc = sorted(all_tc)
    except Exception:
        all_tc = sorted(all_tc)

    log("Total tc count: {0} ".format(len(all_tc)))
    count = 0
    for tc_key in all_tc:
        attr_row = [str(tc_key)]
        try:
            lossless = tc_instance.getLossless(tc_key, True)
            queue_id = tc_instance.getQueueId(tc_key, True)
            ps_id = tc_instance.getPsId(tc_key, True)
            if queue_id_to_pfc_map_mode_is_valid:
                queue_id_to_pfc_map_mode = tc_instance.getQueueIdToPfcMapMode(tc_key, True)
            else:
                queue_id_to_pfc_map_mode = None
            if ps_id_to_pfc_map_mode_is_valid:
                ps_id_to_pfc_map_mode = tc_instance.getPsIdToPfcMapMode(tc_key, True)
            else:
                ps_id_to_pfc_map_mode = None
            pfc_rx_cp = tc_instance.getPfcRxCp(tc_key, True)
            pfc_tx_cp = tc_instance.getPfcTxCp(tc_key, True)
            if non_uc_queue_id_is_valid:
                non_uc_queue_id = tc_instance.getNonUcQueueId(tc_key, True)
            pause_ps_id = tc_instance.getPausePsId(tc_key, True)
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(1, "KeyError in show tc brief. tc: {}, error: {}".format(tc_key, einfo))
            if tc_instance.not_found_exc_msg.format(ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                continue
            raise

        attr_row.append('N/A' if lossless is None else tc_instance.enum_to_str('bool', lossless))
        attr_row.append('N/A' if queue_id is None else str(queue_id))
        attr_row.append('N/A' if ps_id is None else str(ps_id))
        if not hide_pfc_rx_cp:
            attr_row.append('N/A' if pfc_rx_cp is None else tc_instance.enum_to_str('pfc_rx_cp', pfc_rx_cp))
        if not hide_pfc_tx_cp:
            attr_row.append('N/A' if pfc_tx_cp is None else tc_instance.enum_to_str('pfc_tx_cp', pfc_tx_cp))
        attr_row.append('N/A' if pause_ps_id is None else str(pause_ps_id))
        if non_uc_queue_id_is_valid:
            attr_row.append('N/A' if non_uc_queue_id is None else str(non_uc_queue_id))
        if queue_id_to_pfc_map_mode_is_valid:
            attr_row.append('N/A' if queue_id_to_pfc_map_mode is None else tc_instance.enum_to_str('queue_id_to_pfc_map_mode', queue_id_to_pfc_map_mode))
        if ps_id_to_pfc_map_mode_is_valid:
            attr_row.append('N/A' if ps_id_to_pfc_map_mode is None else tc_instance.enum_to_str('ps_id_to_pfc_map_mode', ps_id_to_pfc_map_mode))
        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total tc count: {0}".format(count))
    return
