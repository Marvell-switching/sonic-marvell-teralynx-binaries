
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

from ctypes import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from ifcs_cmds.mcast_route import *
from print_table import PrintTable
import sys
import socket
import struct
ifcs_ctypes=sys.modules['ifcs_ctypes']

def get_group_ip_addr_from_route_entry(route_entry):
    if route_entry.contents.key_type == ifcs_ctypes.IFCS_MCAST_ROUTE_KEY_TYPE_IP_SG_L3VNI:
        if route_entry.contents.key.ip_starg_l3vni.group.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        route_entry.contents.key.ip_sg_l3vni.group.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    route_entry.contents.key.ip_sg_l3vni.group.addr.ipv6))
    else:
        if route_entry.contents.key.ip_starg_l3vni.group.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        route_entry.contents.key.ip_starg_l3vni.group.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    route_entry.contents.key.ip_starg_l3vni.group.addr.ipv6))

def get_source_ip_addr_from_route_entry(route_entry):
    if route_entry.contents.key_type == ifcs_ctypes.IFCS_MCAST_ROUTE_KEY_TYPE_IP_SG_L3VNI:
        if route_entry.contents.key.ip_sg_l3vni.source.addr_family == ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4:
            return (
                socket.inet_ntoa(
                    struct.pack(
                        '!L',
                        route_entry.contents.key.ip_sg_l3vni.source.addr.ipv4)))
        else:
            return (
                socket.inet_ntop(
                    socket.AF_INET6,
                    route_entry.contents.key.ip_sg_l3vni.source.addr.ipv6))
    else:
        return "*"

def get_l3vni_from_route_entry(route_entry):
    if route_entry.contents.key_type == ifcs_ctypes.IFCS_MCAST_ROUTE_KEY_TYPE_IP_SG_L3VNI:
        return (route_entry.contents.key.ip_sg_l3vni.l3vni)
    else:
        return (route_entry.contents.key.ip_starg_l3vni.l3vni)


def show_mcast_route_extension_brief(args, mcast_route):
    log_dbg(1, " Inside mcast_route extension brief show")
    try:
        if args:
            rc, all_route_entry = mcast_route.bulk_get_all_mcast_route_keys(args)
        else:
            rc, all_route_entry = mcast_route.bulk_get_all_mcast_route_keys()
    except BaseException:
        log_err(" Failed to get all route_entry")
        return

    table = PrintTable()

    field_names = [
        'type',
        'source',
        'group',
        'l3vni',
        'intf_check_fail_policy',
        'intf_check_type',
        'intf_chk_object',
        'fwd_action',
        'intf_check_pass_ctc_action',
        'intf_check_pass_trap',
        'ctc_action',
        'trap',
        'mdg',
        'flex_counter']
    table.add_row(field_names)

    log("Total mcast_route count: {0} ".format(len(all_route_entry)))
    count = 0
    for route_entry in all_route_entry:
        row = []
        type =  mcast_route.enum_to_str('mcast_route_key_type',route_entry.contents.key_type)
        if route_entry.contents.key_type == ifcs_ctypes.IFCS_MCAST_ROUTE_KEY_TYPE_IP_SG_L3VNI:
            source = get_source_ip_addr_from_route_entry(route_entry)
        else:
            source = " * "
        group = get_group_ip_addr_from_route_entry(route_entry)
        l3vni = mcast_route.handle_to_str(get_l3vni_from_route_entry(route_entry))

        try:
            fwd_action = mcast_route.getFwdPolicy(route_entry, True)
            intf_check_pass_trap, intf_check_pass_ctc_action = mcast_route.getIntfCheckPassPolicy(
                route_entry, True)
            trap, ctc_action = mcast_route.getCtcPolicy(route_entry, True)
            mdg = mcast_route.handle_to_str(
                mcast_route.getMdg(route_entry, True))
            flex_counter = mcast_route.handle_to_str(
                mcast_route.getFlexCounter(route_entry, True))
            intf_check_type = mcast_route.enum_to_str(
                'intf_check_type',
                mcast_route.getIntfCheckType(route_entry, True))
            intf_check_fail_policy = mcast_route.enum_to_str(
                'intf_check_fail_policy',
                mcast_route.getIntfCheckFailPolicy(route_entry, True))
            intf_chk_object = mcast_route.handle_to_str(
                mcast_route.getIntfCheckObject(route_entry, True))
        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show mcast_route extension brief. mcast_route: {} (type: {}, source: {}, group: {}, l3vni: {}), error: {}"
                .format(route_entry, type, source, group, l3vni, einfo))
            if mcast_route.not_found_exc_msg.format(
                    ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise

        row.append(type)
        row.append(source)
        row.append(group)
        row.append(l3vni)
        row.append(intf_check_fail_policy)
        row.append(intf_check_type)
        row.append(intf_chk_object)
        row.append(fwd_action)
        row.append(intf_check_pass_ctc_action)
        row.append(intf_check_pass_trap)
        row.append(ctc_action)
        row.append(trap)
        row.append(mdg)
        row.append(flex_counter)
        table.add_row(row)
        count += 1
    table.print_table(brief=True)
    table.reset_table()
    log("Total mcast_route count: {0} \n".format(count))
    return

def show_mcast_route_extension_attrs(mcast_route,
                                     mcast_route_entry,
                                     ignore_notfound_err=False,
                                     display_count=False,
                                     count_val=0):
    log_dbg(1, " Inside mcast_route extension attrs show")

    attrCount = ifcs_ctypes.IFCS_MCAST_ROUTE_ATTR_COUNT_GET_ALL
    attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()
    attr_p = compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)

    try:
        actual_count = mcast_route_entry.getAttr(mcast_route, attr, attr_p,
                                                 attrCount, ignore_notfound_err)
    except KeyError:
        einfo = "{}".format(sys.exc_info())
        log_dbg(
            1,
            "KeyError in show mcast_route extension attrs. mcast_route: {}, error: {}"
            .format(mcast_route, einfo))
        if ignore_notfound_err and mcast_route_entry.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
            # Don't display error message for expected exception.
            # Re-raise for handling.
            raise
        log_err("Failed to get attributes for mcast_route ")
        raise
    except:
        log_dbg(
            1,
            "OtherError in show mcast_route extension attrs. mcast_route: {}, error: {}"
            .format(mcast_route, sys.exc_info()))
        log_err("Failed to get attributes for mcast_route ")
        raise KeyError

    type = mcast_route_entry.enum_to_str('mcast_route_key_type',
                                         mcast_route.contents.key_type)
    source = get_source_ip_addr_from_route_entry(mcast_route)
    group = get_group_ip_addr_from_route_entry(mcast_route)
    l3vni = mcast_route_entry.handle_to_str(
        get_l3vni_from_route_entry(mcast_route))

    try:
        fwd_policy = mcast_route_entry.getFwdPolicy(mcast_route,
                                                    ignore_notfound_err)
        intf_check_pass_policy = mcast_route_entry.getIntfCheckPassPolicy(
            mcast_route, ignore_notfound_err)
        ctc_policy = mcast_route_entry.getCtcPolicy(mcast_route,
                                                    ignore_notfound_err)
        mdg = mcast_route_entry.handle_to_str(
            mcast_route_entry.getMdg(mcast_route, ignore_notfound_err))
        flex_counter = mcast_route_entry.handle_to_str(
            mcast_route_entry.getFlexCounter(mcast_route, ignore_notfound_err))
        intf_check_type = mcast_route_entry.enum_to_str(
            'intf_check_type',
            mcast_route_entry.getIntfCheckType(mcast_route,
                                               ignore_notfound_err))
        intf_check_fail_policy = mcast_route_entry.enum_to_str(
            'intf_check_fail_policy',
            mcast_route_entry.getIntfCheckFailPolicy(mcast_route,
                                                     ignore_notfound_err))
        intf_check_object = mcast_route_entry.handle_to_str(
            mcast_route_entry.getIntfCheckObject(mcast_route,
                                                 ignore_notfound_err))
    except KeyError:
        einfo = "{}".format(sys.exc_info())
        log_dbg(
            1,
            "KeyError in show mcast_route extension attrs when getting values. mcast_route: (type: {}, source: {}, group: {}, l3vni: {}), error: {}"
            .format(type, source, group, l3vni, einfo))
        if ignore_notfound_err and mcast_route_entry.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
            # Don't display error message for expected exception.
            # Re-raise for handling.
            raise
        log_err("Failed to get attributes for mcast_route ")
        raise

    if display_count:
        log("McastRoute count: {0} ".format(count_val))
    table = PrintTable()
    table.add_row(['type', type])
    table.add_row(['source', source])
    table.add_row(['group', group])
    table.add_row(['l3vni', l3vni])
    table.set_header_size(4)
    table.add_row(['fwd_policy', fwd_policy])
    table.add_row(['intf_check_pass_policy', intf_check_pass_policy])
    table.add_row(['ctc_policy', ctc_policy])
    table.add_row(['mdg', mdg])
    table.add_row(['flex_counter', flex_counter])
    table.add_row(['intf_check_type', intf_check_type])
    table.add_row(['intf_check_fail_policy', intf_check_fail_policy])
    table.add_row(['intf_check_object', intf_check_object])
    table.print_table()
    table.reset_table()

    return


def show_mcast_route_extension_usage_helper(route_entry, filter_option):
    usage_p = ifcs_ctypes.ifcs_usage_t()

    if filter_option not in ['v4_sg', 'v6_sg', 'v4_starg', 'v6_starg']:
        log_err("Invalid filter option {0}".format(filter_option))
        return

    group = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(group))

    if 'v4' in filter_option:
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(group), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
    else: # v6 filter
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(group), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    mcast_route_entry_key = ifcs_ctypes.ifcs_mcast_route_entry_key_t()
    ifcs_ctypes.ifcs_mcast_route_entry_key_t_init(pointer(mcast_route_entry_key))
    if 'sg' in filter_option:
        ifcs_ctypes.ifcs_mcast_route_entry_key_t_key_type_set(pointer(mcast_route_entry_key), ifcs_ctypes.IFCS_MCAST_ROUTE_KEY_TYPE_IP_SG_L3VNI)
        ifcs_ctypes.ifcs_mcast_route_key_ip_sg_l3vni_t_group_set(pointer(mcast_route_entry_key.key.ip_sg_l3vni), pointer(group))
    else: # IP_STARG_L3VNI
        ifcs_ctypes.ifcs_mcast_route_entry_key_t_key_type_set(pointer(mcast_route_entry_key), ifcs_ctypes.IFCS_MCAST_ROUTE_KEY_TYPE_IP_STARG_L3VNI)
        ifcs_ctypes.ifcs_mcast_route_key_ip_starg_l3vni_t_group_set(pointer(mcast_route_entry_key.key.ip_starg_l3vni),pointer(group))

    rc = ifcs_ctypes.ifcs_mcast_route_usage_get(0, pointer(mcast_route_entry_key), 0, None, pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get all {0} mcast_route rc: {1}".format(filter_option, convert_error_code_to_string(rc)))
        return

    log("Usage for {0} mcast route entries".format(filter_option))

    table = PrintTable()
    table.add_row(["Current", "Max"])
    table.add_row([usage_p.current, usage_p.max])
    table.print_table()
    table.reset_table()

    return


def show_mcast_route_extension_usage(arg1, arg2, mcast_route):
    log_dbg(1, " Inside extension usage show")

    if mcast_route.filter_option == {}:
        for filter_option in ['v4_sg', 'v6_sg', 'v4_starg', 'v6_starg']:
            show_mcast_route_extension_usage_helper(mcast_route, filter_option)
            log("\n")
    else:
        filter_option = (mcast_route.filter_option['filter']).strip()
        show_mcast_route_extension_usage_helper(mcast_route, filter_option)

    return


def print_footer():
    log("NOTE:")
    log("\tEach resource group includes all types of mcast_routes that share common hardware resources.\n"
        "\tFree count for each type of mcast_route in a resource group is affected by all mcast_route entries present in that group.\n"
        "\n"
        "\tHardware resources for mcast_route entry are also shared with route.\n"
        "\tFree entries may be less than displayed values if routes are configured.\n"
        "\n"
        "\tAttr set indicates entries with attribute flex_counter.\n")


def print_rg_table(rg_list, filter_key):
    filter_usage = None

    if filter_key != None:
        filter_usage = {
            'v4_sg': [
                ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V4_SG
            ],

            'v6_sg': [
                ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_SG
            ],

            'v6_sg_with_flex_counter': [
                ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_SG_ATTR
            ],

            'v4_starg': [
                ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V4_STARG
            ],

            'v6_starg': [
                ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_STARG
            ],
        }

    rg_to_usage = {
        2: [ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V4_STARG,
            ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_STARG],

        5: [ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V4_SG,
            ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_SG,
            ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_SG_ATTR]
    }

    usage_title = {
        ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V4_SG:"IPv4 MCAST(S,G) (2X)",
        ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_SG:"IPv6 MCAST(S,G) (4X)",
        ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_SG_ATTR:"IPv6 MCAST(S,G) (Attr set) (5X)",
        ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V4_STARG:"IPv4 MCAST(*,G) (2X)",
        ifcs_ctypes.IFCS_USAGE_OBJ_MCAST_ROUTE_V6_STARG:"IPv6 MCAST(*,G) (3X)"
    }

    usage_p = ifcs_ctypes.ifcs_usage_t()
    obj_type = ifcs_ctypes.ifcs_usage_obj_t()

    for rg in rg_list:
        log("Resource Group {0}".format(rg))
        table = PrintTable()
        table.set_justification("left")
        table.add_row(["Type", "Current", "Free", "Max"])

        for usage in rg_to_usage[rg]:
            if filter_key != None:
                if usage not in filter_usage[filter_key]:
                    continue
            obj_type.mcast_route = usage
            ifcs_ctypes.ifcs_usage_t_init(pointer(usage_p))
            ifcs_ctypes.ifcs_usage_t_obj_type_set(pointer(usage_p), pointer(obj_type))
            ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(pointer(usage_p),
                ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_MCAST_ROUTE)
            rc = ifcs_ctypes.ifcs_mcast_route_usage_detail_get(0, None, 0, None, pointer(usage_p))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Failed to get {0} counters rc: {1}".format(usage_type, convert_error_code_to_string(rc)))
                return

            table.add_row([usage_title[usage], usage_p.current, usage_p.available, usage_p.max])
        table.print_table()
        table.reset_table()
        log("\n")

    print_footer()

    return

def show_mcast_route_extension_usage_detail(arg1, arg2, mcast_route):
    log_dbg(1, " Inside extension usage detail show new")

    filter_to_rg = {
        'all': [2,5],
        'v4_sg': [5],
        'v6_sg': [5],
        'v6_sg_with_flex_counter': [5],
        'v4_starg': [2],
        'v6_starg': [2]
    }

    rg_list = []

    filter_key = None
    if mcast_route.filter_option == {}:
        rg_list = filter_to_rg['all']
    else:
        filter_key = mcast_route.filter_option['filter'].strip()
        if filter_key not in ['v4_sg', 'v6_sg', 'v6_sg_with_flex_counter', 'v4_starg', 'v6_starg']:
            log("Invalid filter: {0}\n".format(filter_key))
            return
        else:
            rg_list = filter_to_rg[filter_key]

    print_rg_table(rg_list, filter_key)
