#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import sys
from ifcs_cmds.queue_id_to_pfc_map_profile import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
ifcs_ctypes = sys.modules['ifcs_ctypes']


def show_queue_id_to_pfc_map_profile_extension_brief(
        args, queue_id_to_pfc_map_profile):
    log_dbg(1, " Inside queue_id_to_pfc_map_profile extension brief show")
    ''' Displays summary of all instance of type queue_id_to_pfc_map_profile'''
    log_dbg(1, "In show_queue_id_to_pfc_map_profile_brief method")

    # Use the passed-in instance directly
    obj = queue_id_to_pfc_map_profile
    if not hasattr(obj, 'filter_option'):
        obj.filter_option = {'sort': 'info'}
    try:
        all_queue_id_to_pfc_map_profile = obj.getAllqueue_id_to_pfc_map_profile()
    except Exception as e:
        log_err(" Failed to get all queue_id_to_pfc_map_profile")
        return

    table = PrintTable()
    field_names = ['queue_id_to_pfc_map_profile', 'info (queue_id,pfc_cp)', 'ref_count']
    table.add_row(field_names)
    try:
        if obj.filter_option['sort'] in obj.get_methods.keys():
            all_queue_id_to_pfc_map_profile = sorted(
                all_queue_id_to_pfc_map_profile,
                key=lambda x: obj.get_methods[obj.filter_option['sort']](x))
        else:
            log("Cannot sort on {0}".format(obj.filter_option['sort']))
            all_queue_id_to_pfc_map_profile = sorted(all_queue_id_to_pfc_map_profile)
    except:
        all_queue_id_to_pfc_map_profile = sorted(all_queue_id_to_pfc_map_profile)

    log("Total queue_id_to_pfc_map_profile count: {0} ".format(len(all_queue_id_to_pfc_map_profile)))
    count = 0
    for queue_id_to_pfc_map_profile in all_queue_id_to_pfc_map_profile:
        attr_row = []
        attr_row.append(obj.handle_to_str(queue_id_to_pfc_map_profile))

        try:
            info = obj.getInfo(queue_id_to_pfc_map_profile, True)
            ref_count = obj.getRefCount(queue_id_to_pfc_map_profile, True)

        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show queue_id_to_pfc_map_profile brief. queue_id_to_pfc_map_profile: {}, error: {}"
                .format(obj.handle_to_str(queue_id_to_pfc_map_profile), einfo))
            if obj.not_found_exc_msg.format(
                    obj.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                continue
            raise
        if info is None:
            attr_row.append('N/A')
        else:
            tuple_list = []
            for entry in info:
                queue_id = getattr(entry, 'queue_id', None)
                pfc = getattr(entry, 'pfc', None)
                tuple_list.append("({}, {})".format(queue_id, pfc))
            attr_row.append("[{}]".format(", ".join(tuple_list)))
        attr_row.append('N/A' if ref_count is None else str(ref_count))

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total queue_id_to_pfc_map_profile count: {0}".format(count))
    return
