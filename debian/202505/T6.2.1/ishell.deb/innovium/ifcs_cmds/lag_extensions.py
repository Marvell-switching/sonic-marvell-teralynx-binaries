#-------------------------------------------------------------------------------
# Copyright (c) (2025) Marvell. All rights reserved
# *
# * This material is proprietary to Marvell. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

def show_lag_extension_brief(arg2, self):
    ''' Displays summary of all instance of type lag'''
    log_dbg(1, "In show_lag_brief method")

    try:
        rc, all_lag = self.bulk_get_all_lag_keys()
    except:
        log_err(" Failed to get all lag")
        return

    table = PrintTable()
    field_names = []
    field_names.append('lag')

    field_names.append('l3intf_handle')
    field_names.append('type')
    field_names.append('member_count')
    static_member_selection_mode_is_valid = self.cli.ifcs_ctypes.im_lag_attr_is_valid(
        self.cli.node_id,
        self.cli.ifcs_ctypes.IFCS_LAG_ATTR_STATIC_MEMBER_SELECTION_MODE)
    if static_member_selection_mode_is_valid:
        field_names.append('static_member_selection_mode')
    field_names.append('direction')
    alb_is_valid = self.cli.ifcs_ctypes.im_lag_attr_is_valid(
        self.cli.node_id, self.cli.ifcs_ctypes.IFCS_LAG_ATTR_ALB)
    if alb_is_valid:
        field_names.append('alb')
    field_names.append('ref_count')
    ecmp_alb_forwarding_nexthop_is_valid = self.cli.ifcs_ctypes.im_lag_attr_is_valid(
        self.cli.node_id,
        self.cli.ifcs_ctypes.IFCS_LAG_ATTR_ECMP_ALB_FORWARDING_NEXTHOP)
    if ecmp_alb_forwarding_nexthop_is_valid:
        field_names.append('ecmp_alb_forwarding_nexthop')
    table.add_row(field_names)
    try:
        if self.filter_option['sort'] in self.get_methods.keys():
            all_lag = sorted(
                all_lag,
                key=lambda x: self.get_methods[self.filter_option['sort']]
                (x))
        else:
            log("Cannot sort on {0}".format(self.filter_option['sort']))
            all_lag = sorted(all_lag)
    except:
        all_lag = sorted(all_lag)

    log("Total lag count: {0} ".format(len(all_lag)))
    count = 0
    for lag in all_lag:
        attr_row = []
        attr_row.append(self.handle_to_str(lag))

        try:
            l3intf_handle = self.getL3intfHandle(lag, True)
            type = self.getType(lag, True)
            member_count = self.getMemberCount(lag, True)
            if static_member_selection_mode_is_valid:
                static_member_selection_mode = self.getStaticMemberSelectionMode(
                    lag, True)
            direction = self.getDirection(lag, True)
            if alb_is_valid: alb = self.getAlb(lag, True)
            ref_count = self.getRefCount(lag, True)
            if ecmp_alb_forwarding_nexthop_is_valid:
                ecmp_alb_forwarding_nexthop = self.getEcmpAlbForwardingNexthop(
                    lag, True)

        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1, "KeyError in show lag brief. lag: {}, error: {}".format(
                    self.handle_to_str(lag), einfo))
            if self.not_found_exc_msg.format(
                    self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise
        attr_row.append('N/A' if l3intf_handle is None else self.
                        handle_to_str(l3intf_handle))
        attr_row.append(
            'N/A' if type is None else self.enum_to_str('type', type))
        attr_row.append(
            'N/A' if member_count is None else str(member_count))
        if static_member_selection_mode_is_valid:
            attr_row.append(
                'N/A' if static_member_selection_mode is None else self.
                enum_to_str('static_member_selection_mode',
                            static_member_selection_mode))
        attr_row.append('N/A' if direction is None else self.
                        enum_to_str('direction', direction))
        if alb_is_valid:
            attr_row.append(
                'N/A' if alb == 0 else self.handle_to_str(alb))
        attr_row.append('N/A' if ref_count is None else str(ref_count))
        if ecmp_alb_forwarding_nexthop_is_valid:
            attr_row.append('N/A' if ecmp_alb_forwarding_nexthop is None
                            else ecmp_alb_forwarding_nexthop)

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total lag count: {0}".format(count))
