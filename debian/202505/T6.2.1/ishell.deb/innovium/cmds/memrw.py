
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import fnmatch
import sys
from utils.compat_util import *
from verbosity import log, log_err
from ctypes import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.node import Node as node
from print_table import PrintTable
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
import datetime
from testutil.penrw import *
from functools import cmp_to_key
from testutil import pci

global pattern_list
global ib_list
global validate
global ecc_check
global verbose
global log_redirect
global exclude
global MAX_IBS

log_redirect = True

# macros for PEN Field Attribute values
FA_HW = (1 << 2)
FA_SR = (1 << 6)

# List of fields to skip verifcation
# ECC is generic field that can be skipped
# RSVD0_F and RSVD1_F are the fields in
# HEDTA_OPAQUE_STATS_WATERMARK* PENs that are
# not supposed to be written. Hence skipping
# TODO SNAKE UTIL: REL_12 has this:  skip_flds = []
skip_flds = ["*ECC*", "RSVD*_F"]


# Watson PENs which are applicable for only IB0
skip_watson_pen_pat = ["WATSON_STAT_TX_BUF*", "WATSON_EVENT_TX_BUF*"]

# List of pens to skip verifcation
# TODO SNAKE UTIL: REL_12 has this:  skip_pen_pat = ["*ABB*_AB", "*ABB*_CD", "*ABB*_BCD", "*ABB*_*2X*"]
skip_pen_pat = ["*ABB*_AB", "*ABB*_CD", "*ABB*_BCD",
                "*ABB*_*2X*", "IMT40_EM_POLICY*",
                "DTM_DFS_SIB*", "WATSON_STAT_TX_BUF*",
                "WATSON_EVENT_TX_BUF*"]

skip_pens = [
             "EPRS_SIP_CC", "EPRS_DIP_CC",
             "DTM_EA_PORT_CNT", "DTM_EA_PORT_MAX_CNT",
             "DTM_TC_CNT", "DTM_EA_ABM_CFG",
             "DTM_EA_STATE", "BAM_IA_STATE",
             "_TL10_P5485","ANP_APB"
            ]

hedta_opaque_stats_pen_pat = ["HEDTA_OPAQUE_STATS*"]

grouping_pens = [ 825, #IMT40_ABB0_CFG
                  864, #IMT40_ABB1_CFG
                  984, #IMT40_ABB2_CFG
                  1738 #EMT20_ABB0_CFG
                ]

tcam_ctrl_flds = ['_F166',  '_F165',
                  'ENTRY_VLD_F', 'ENTRY_VLD_0_F',
                  'ENTRY_VLD_1_F', 'ENTRY_VLD_A0_F',
                  'ENTRY_VLD_A1_F', 'ENTRY_VLD_B0_F',
                  'ENTRY_VLD_B1_F', 'ENTRY_VLD_C0_F',
                  'ENTRY_VLD_C1_F', 'ENTRY_VLD_D0_F',
                  'ENTRY_VLD_D1_F'
                ]


tcam_data_flds = ['_F82', '_F175', '_F489',
                  '_F504', '_F1824', '_F1825',
                  '_F1836', '_F1837', '_F1849',
                  '_F1850', '_F1862', '_F1863',
                  '_F2684', '_F2692', '_F6940',
                  '_F6942', '_F6944', '_F6946',
                  '_F6948', '_F6950', '_F6952',
                  '_F6954', '_F6956', '_F6958',
                  '_F6960', '_F6962', '_F6964',
                  '_F6966', '_F88', '_F173',
                  '_F359', '_F360', '_F488',
                  '_F500', '_F501', '_F502',
                  '_F1798', '_F1800', '_F1827',
                  '_F1830', '_F1832', '_F1839',
                  '_F1842', '_F1845', '_F1852',
                  '_F1855', '_F1858', '_F1865',
                  '_F126', '_F1106', '_F1112',
                  '_F1113', '_F1528', '_F1529',
                  '_F1844', '_F1857']

dtm_bank_pens = [
                "DTM_APL",
                "DTM_APD",
                "DTM_APLFREE",
                "DTM_HSS",
                "DTM_HSSFREE",
                "DTM_DFS_SIB0"
                ]

class Memrw(Command):
    def __init__(self, cli):

        self.cli = cli
        self.arg_list = []
        super(Memrw, self).__init__()


    def __del__(self):
        return

    def run_cmd(self, args):

        self.arg_list = shlex.split(args)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        mem_parser = argparse.ArgumentParser(
            prog="diagtest memrw",
            description="ECC Mem Test",
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)

        mem_parser.add_argument("-i",
                                "--ib",
                                dest="ib_list",
                                default="0x1f",
                                help="List of IBs to run the mem test, 0x1f for all IBs (broadcast) OR comma seperated list e.g. [0,2,4]")

        mem_parser.add_argument("-p",
                                "--pattern",
                                dest="pattern_list",
                                default="0xFFFFFFFF",
                                help="List of test pattens to use")

        mem_parser.add_argument("-r",
                                "--validate",
                                dest="validate",
                                help="Validate read data with test pattern and dump ecc stats",
                                action="store_true")

        mem_parser.add_argument("-e",
                                "--ecc",
                                dest="ecc",
                                help="Check ecc stats after every PEN access, use with -v",
                                action="store_true")


        mem_parser.add_argument("-v",
                                "--verbose",
                                dest="verbose",
                                help="Enable verbose output",
                                action="store_true")


        mem_parser.add_argument("-x",
                                "--exclude",
                                dest="exclude",
                                help="Exclude TCAM and registers from memtest",
                                action="store_true")

        args = mem_parser.parse_args(self.arg_list)
        try:
            rc = run_mem_test(self, args)
        except Exception as ex:
            log_err("memrw FAILED")
            log_err(str(ex))

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

def get_pen_info(pen_id):
    peninfo = ifcs_ctypes.pen_t()
    ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
    return peninfo

# Given a pen, return it basepen
def get_base_pen(pen_id):
    base_pen = pen_id       # Default
    peninfo = get_pen_info(pen_id)
    if peninfo.pen_prop:
       ppinfo = cast(peninfo.pen_prop, POINTER(ifcs_ctypes.pen_prop_t))
       base_pen = ppinfo.contents.resource
    return base_pen

# Given a pen, return it full
def get_full_pen(pen_id):
    full_pen = pen_id       # Default
    peninfo = get_pen_info(pen_id)
    if peninfo.pen_prop:
       ppinfo = cast(peninfo.pen_prop, POINTER(ifcs_ctypes.pen_prop_t))
       full_pen = ppinfo.contents.full_pen
    return full_pen

def get_pen_id(pen_str):
    try:
        pen_id = int(pen_str)
    except ValueError:
        try:
            pen_id = penstr_num_dict[pen_str.upper()]
        except KeyError:
            pen_id = -1
    return pen_id

def get_field_id(field_str):
    try:
        field_id = int(field_str)
    except ValueError:
        try:
            field_id = penfldstr_num_dict[field_str.upper()]
        except KeyError:
            field_id = -1
    return field_id

def get_pen_name(pen_id):
    ''' Return Pen name from Pen num '''

    if pen_id == -1:
        return "PEN_INVALID"

    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Pen:" + str(pen_id)
    return compat_bytesToStr(pen_str.value)

def get_field_name(field_id):
    ''' Return Field name from Field num '''

    if field_id == -1:
        return "PEN_FNAME_INVALID"

    fld_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_field_name(0, field_id, fld_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field:" + str(field_id)
    return compat_bytesToStr(fld_str.value)

def get_pen_type(peninfo):
    if peninfo.flags & ifcs_ctypes.PEN_TYPE_TCAM:
        return "PEN_TYPE_TCAM"
    elif  peninfo.flags & ifcs_ctypes.PEN_TYPE_LPM_TCAM:
        return "PEN_TYPE_LPM_TCAM"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_ABB_TCAM:
        return "PEN_TYPE_ABB_TCAM"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_HASH:
        return "PEN_TYPE_HASH"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_ILPM:
        return "PEN_TYPE_ILPM"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_INDEX:
        return "PEN_TYPE_INDEX"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_NONE:
        return "PEN_TYPE_NONE"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_FIRMWARE:
        return "PEN_TYPE_FIRMWARE"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_NOT_IMPL:
        return "PEN_TYPE_NOT_IMPL"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_RSVD10:
        return "PEN_TYPE_RSVD10"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_RSVD11:
        return "PEN_TYPE_RSVD11"
    elif peninfo.flags & ifcs_ctypes.PEN_TYPE_RSVD31:
        return "PEN_TYPE_RSVD31"
    else:
        return "PEN_TYPE_UNKNOWN"

def display_ecc_errors():
    global verbose
    global ib_list
    global MAX_IBS

    ecc_node_stat = ifcs_ctypes.ifcs_ecc_node_stats_t()
    ifcs_ctypes.ifcs_node_ecc_stats(0, pointer(ecc_node_stat ))
    sbuf = "\nECC Node Stats:\n"
    sbuf += "%12s:%8s, %12s:%8s, %12s:%8s, %12s:%8s, %12s:%8s\n" % (
        "TOTAL", str(ecc_node_stat.total_count),
        "TYPE_CE", str(ecc_node_stat.type_ce_count),
        "TYPE_UE", str(ecc_node_stat.type_ue_count),
        "TYPE_TREE", str(ecc_node_stat.type_tree_count),
        "TYPE_INV", str(ecc_node_stat.type_invalid_count))

    sbuf += "%12s:%8s, %12s:%8s, %12s:%8s,\n" % (
            "RATELIMIT", str(ecc_node_stat.rate_limit_hit_count),
            "SW Fixed CE", str(ecc_node_stat.sw_fixed_ce_count),
            "SW Fixed UE", str(ecc_node_stat.sw_fixed_ue_count))

    sbuf += "%12s %8s  %12s:%8s, %12s:%8s, %12s:%8s, %12s:%8s\n" % (
        "", "",
        "CLS_INFO", str(ecc_node_stat.class_info_count),
        "CLS_ALARM", str(ecc_node_stat.class_alarm_count),
        "CLS_FATAL", str(ecc_node_stat.class_fatal_count),
        "CLS_INV", str(ecc_node_stat.class_invalid_count))

    # If we have a pen name, extract the ID and only show detailed data for that PEN
    pen_stats = (ifcs_ctypes.ifcs_ecc_pen_stats_t * ecc_node_stat.pf_count)()
    ifcs_ctypes.ifcs_node_ecc_pen_stats(0, ecc_node_stat.pf_count, compat_pointer(pen_stats, ifcs_ctypes.ifcs_ecc_pen_stats_t))

    allpenlist = []
    for index in range(ecc_node_stat.pf_count):
        allpenlist.append(pen_stats[index])

    def comparator(p1, p2):
        p1d1 = p1.timestamp.tv_sec * 1000000 + p1.timestamp.tv_usec
        p2d1 = p2.timestamp.tv_sec * 1000000 + p2.timestamp.tv_usec
        result = (p1d1 - p2d1)
        return int(result)

    if COMPAT_PY3:
        allpenlist = sorted(allpenlist, key=cmp_to_key(comparator), reverse=True)
    else:
        allpenlist = sorted(allpenlist, cmp=comparator, reverse=True)

    for aPen in allpenlist:
        dt = datetime.datetime.fromtimestamp(aPen.timestamp.tv_sec)

        sbuf += '\n'
        try:
            sbuf += "### PEN Stats: IB: %s, Source: %s, Cause: %s, Field: %s\n" % (
                (str(aPen.ecc_ib)),
                get_pen_name(aPen.ecc_source_pen),
                get_pen_name(aPen.ecc_cause_pen),
                get_field_name(aPen.ecc_cause_field))
        except:
            sbuf += "### PEN Stats: IB: %s, Source: %s, Cause: %s, Field: %s\n" % (
                (str(aPen.ecc_ib)),
                (str(aPen.ecc_source_pen)),
                (str(aPen.ecc_cause_pen)),
                (str(aPen.ecc_cause_field)))

        sbuf += "    Total: %8d, CE: %6d,           UE: %6d, INFO: %6d, ALARM: %6d, RATELIMIT: %4d, Last: %s.%06d\n" % (
            aPen.total_count, aPen.type_ce_count, aPen.type_ue_count,
            aPen.class_info_count, aPen.class_alarm_count,
            aPen.rate_limit_hit_count,
            dt, aPen.timestamp.tv_usec)

        sbuf += "  %8s  SW Fixed CE: %6d,  SW Fixed UE: %6d,\n" % ("", aPen.sw_fixed_ce_count, aPen.sw_fixed_ue_count)

        for rowidx in range(16):
            aRow = aPen.err_idx_rows[rowidx]
            dt = datetime.datetime.fromtimestamp(aRow.timestamp.tv_sec)
            if aRow.count > 0:
                if aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_INVALID:
                    tstr = "INV"
                elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_CE:
                    tstr = "CE"
                elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_UE:
                    tstr = "UE"
                elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_TREE:
                    tstr = "TREE"
                elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_DEBUG:
                    tstr = "DBG"
                elif aRow.intr_type == ifcs_ctypes.IFCS_ECC_INTR_TYPE_USER:
                    tstr = "USR"
                else:
                    tstr = "UNKN"

                if aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_INVALID:
                    cstr = "INV"
                elif aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_INFO:
                    cstr = "INFO"
                elif aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_ALARM:
                    cstr = "ALRM"
                elif aRow.intr_class == ifcs_ctypes.IFCS_ECC_INTR_CLASS_FATAL:
                    cstr = "FATL"
                else:
                    cstr = "UNKN"

                sbuf += "   --> Err Index: %6d, Count: %4d, SW Fixed: %4d, Type: %4s, Class: %4s, %16s   Last: %s.%06d\n" % (
                        aRow.index, aRow.count, aRow.sw_fixed, tstr, cstr, "", dt, aRow.timestamp.tv_usec)

    log(sbuf)

    if ecc_node_stat.type_ce_count > 1 or\
            ecc_node_stat.type_ue_count > 0:
        log("memrw: ECC check failed\n")
    else:
        log("memrw: PASSED\n")


def dump_node_stats(src_pen, ctrl_pen, cause_pen, cause_field, nodestat):

    log("NODE Stats: Total: %d, CE: %d, UE: %d, PF: %d" % (
        nodestat.total_count, nodestat.type_ce_count,
        nodestat.type_ue_count, nodestat.pf_count))

def get_byte_array_from_val(val):
    ''' Convert any type num (int, long) to Byte array '''

    bytearr = list()

    while(val > 0):
        bval = val & 0xFF
        val = val >> 8
        bytearr.insert(0, int("%02x" % (bval), 16))

    return bytearr

def get_fld_values(pen_id, test_patterns, rcount):

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)

    flds = []
    fld_cli_str = " "
    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        fwidth = fldinfo[findx].width

        if fstr in ['_F163']:
            flds.append((fname, 0x0))
            fld_cli_str = fld_cli_str + "%s %s " %(fstr, 0x0)
        elif fwidth <= 32:
            value = (test_patterns[rcount] & ((0x1 << fwidth) - 1))
            flds.append((fname, value))
            fld_cli_str = fld_cli_str + " %s %s " %(fstr, str(value))
        else:
            num_bytes = compat_division(fwidth + 7, 8)
            data_arr = (c_ubyte * num_bytes)()
            if fwidth % 8:
                byte0_mask = (1 << (fwidth % 8)) - 1
            data_arr_str = ""
            for n in range(num_bytes):
                data_arr[n] = (test_patterns[rcount])
                if n == 0:
                    data_arr_str = data_arr_str + str(hex(data_arr[n])[2:])
                else:
                    data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                if (fwidth % 8) and n == 0:
                    data_arr[n] = data_arr[n] & byte0_mask
                    data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

            flds.append((fname, data_arr))
            fld_cli_str = fld_cli_str + " %s %s" %(fstr, str(data_arr_str))

    return flds

def get_fld_values_pen_type_indx_indir(pen_id, test_patterns, rcount):
    global verbose

    peninfo = get_pen_info(pen_id)
    pen_name = get_pen_name(pen_id)
    pen_width = peninfo.width
    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)
    flds = []
    fld_cli_str = " "

    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        fwidth = fldinfo[findx].width


        if fstr == "_F82":
            if fwidth <= 32:
                value = (test_patterns[rcount] & ((0x1 << fwidth) - 1))
                flds.append((fname, value))
                fld_cli_str = fld_cli_str + " %s %s " %(fstr, str(value))
            else:
                num_bytes = compat_division(fwidth + 7, 8)
                data_arr = (c_ubyte * num_bytes)()
                if fwidth % 8:
                    byte0_mask = (1 << (fwidth % 8)) - 1
                data_arr_str = ""
                for n in range(num_bytes):
                    data_arr[n] = (test_patterns[rcount])
                    if n == 0:
                        data_arr_str = data_arr_str + str(hex(data_arr[n])[2:])
                    else:
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                    if (fwidth % 8) and n == 0:
                        data_arr[n] = data_arr[n] & byte0_mask
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                flds.append((fname, data_arr))
                fld_cli_str = fld_cli_str + " %s %s" %(fstr, str(data_arr_str))

    return flds


def get_fld_values_pen_type_ilpm(pen_id, test_patterns, rcount) :

    global verbose

    peninfo = get_pen_info(pen_id)
    pen_name = get_pen_name(pen_id)
    pen_width = peninfo.width
    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)
    flds = []
    fld_cli_str = " "

    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        fwidth = fldinfo[findx].width

        if fstr == "ENTRY_F":
            if fwidth <= 32:
                value = (test_patterns[rcount] & ((0x1 << fwidth) - 1))
                flds.append((fname, value))
                fld_cli_str = fld_cli_str + " %s %s " %(fstr, str(value))
            else:
                num_bytes = compat_division(fwidth + 7, 8)
                data_arr = (c_ubyte * num_bytes)()
                if fwidth % 8:
                    byte0_mask = (1 << (fwidth % 8)) - 1
                data_arr_str = ""
                for n in range(num_bytes):
                    data_arr[n] = (test_patterns[rcount])
                    if n == 0:
                        data_arr_str = data_arr_str + str(hex(data_arr[n])[2:])
                    else:
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                    if (fwidth % 8) and n == 0:
                        data_arr[n] = data_arr[n] & byte0_mask
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                flds.append((fname, data_arr))
                fld_cli_str = fld_cli_str + " %s %s" %(fstr, str(data_arr_str))

    return flds


def get_fld_values_pen_type_hash(pen_id, fid, test_patterns, rcount) :

    global verbose

    peninfo = get_pen_info(pen_id)
    pen_name = get_pen_name(pen_id)
    pen_width = peninfo.width
    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)
    flds = []
    fld_cli_str = " "

    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        fwidth = fldinfo[findx].width


        if fstr == "FID_F":
            flds.append((fname, fid))
        elif fstr == "_F526":
            if fwidth <= 32:
                value = (test_patterns[rcount] & ((0x1 << fwidth) - 1))
                flds.append((fname, value))
                fld_cli_str = fld_cli_str + " %s %s " %(fstr, str(value))
            else:
                num_bytes = compat_division(fwidth + 7, 8)
                data_arr = (c_ubyte * num_bytes)()
                if fwidth % 8:
                    byte0_mask = (1 << (fwidth % 8)) - 1
                data_arr_str = ""
                for n in range(num_bytes):
                    data_arr[n] = (test_patterns[rcount])
                    if n == 0:
                        data_arr_str = data_arr_str + str(hex(data_arr[n])[2:])
                    else:
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                    if (fwidth % 8) and n == 0:
                        data_arr[n] = data_arr[n] & byte0_mask
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                flds.append((fname, data_arr))
                fld_cli_str = fld_cli_str + " %s %s" %(fstr, str(data_arr_str))

    return flds



def get_fld_values_pen_type_tcam(pen_id, test_patterns, rcount):
    global verbose

    peninfo = get_pen_info(pen_id)
    pen_name = get_pen_name(pen_id)
    pen_width = peninfo.width
    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)
    pen_name_str= compat_bytesToStr(pen_str.value)

    flds = []
    fld_cli_str = " "

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)

    pen_data_flds = tcam_data_flds[:]
    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        patterns = ["DATA_*", "MASK_*", "KEY_*"]
        for pat in patterns:
            if fnmatch.fnmatch(fstr, pat):
                pen_data_flds.append(fstr)

    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        fwidth = fldinfo[findx].width

        if fstr in tcam_ctrl_flds:
            flds.append((fname, 0x1))
            fld_cli_str = fld_cli_str + "%s %s " %(fstr, 0x0)

        elif fstr in pen_data_flds:
            if fwidth <= 32:
                value = (test_patterns[rcount] & ((0x1 << fwidth) - 1))
                flds.append((fname, value))
                fld_cli_str = fld_cli_str + " %s %s " %(fstr, str(value))
            else:
                num_bytes = compat_division(fwidth + 7, 8)
                data_arr = (c_ubyte * num_bytes)()
                if fwidth % 8:
                    byte0_mask = (1 << (fwidth % 8)) - 1
                data_arr_str = ""
                for n in range(num_bytes):
                    data_arr[n] = (test_patterns[rcount])
                    if n == 0:
                        data_arr_str = data_arr_str + str(hex(data_arr[n])[2:])
                    else:
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                    if (fwidth % 8) and n == 0:
                        data_arr[n] = data_arr[n] & byte0_mask
                        data_arr_str = data_arr_str + ":" + str(hex(data_arr[n])[2:])

                flds.append((fname, data_arr))
                fld_cli_str = fld_cli_str + " %s %s" %(fstr, str(data_arr_str))

    return flds



def perform_pen_access(pen_id, flds, index):
    """
    Write, read back from PEN and compare
    Args:
        pen_id - PEN ID
        flds - List of fields in this PEN
        index - index to the array of PENs of this type
    Returns:
        None
    Raises:
        Exception
    """

    global ib_list
    global validate
    global ecc_check
    global verbose
    global log_redirect
    global exclude
    global MAX_IBS

    peninfo = get_pen_info(pen_id)
    pen_name = get_pen_name(pen_id)
    pen_width = peninfo.width
    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)
    pen_name_str = compat_bytesToStr(pen_str.value)
    mismatch_count = 0

    if log_redirect:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        response = None
        # TODO SNAKE UTIL: REL_12 has this:  sys.stdout = new_stdout = compat_StringIO()
        # TODO SNAKE UTIL: REL_12 has this:  sys.stderr = new_stderr = compat_StringIO()
        new_stdout = compat_StringIO()
        new_stderr = compat_StringIO()

    if peninfo.cmpid != 16:
        # Write to the IBs
        for ib in ib_list:
            if ib == 0x1f:
                ib_str = "all IBs (broadcast)"
            else:
                ib_str = "IB%d" % ib

            try:
                pat_match = False
                for pat in skip_watson_pen_pat:
                    pen_name_str= compat_bytesToStr(pen_str.value)
                    if fnmatch.fnmatch(pen_name_str, pat):
                        if (not(ib == 0x0)):
                            msg = ("Skipping Write WATSON PEN: %s in cmpid ! 16 for IB %d" % (pen_name_str, ib))
                            if verbose:
                                log(msg)
                            pat_match = True
                if pat_match:
                    continue
                write_platform_pen(pen_id, index, flds, ib=ib)
            except Exception as ex:
                msg = ("Error writing to pen %s on %s"% (compat_bytesToStr(pen_str.value), ib_str))
                if log_redirect:
                    response = new_stdout.getvalue()
                    sys.stdout = old_stdout
                    sys.stderr = old_stderr
                    log_err(response)
                log_err(msg)
                raise ex

    else:
        # Write PIC pens without bcast
        if ib_list[0] == 0x1F:
            ibs = compat_listrange(MAX_IBS)
        else:
            ibs = ib_list

        for ib in ibs:
            # Iterate through all IBs
            msg = ("perform_pen_access: Writing to pen %s on IB%d"% (compat_bytesToStr(pen_str.value), ib))
            if verbose:
                log(msg)
            try:
                pat_match = False
                for pat in skip_watson_pen_pat:
                    pen_name_str= compat_bytesToStr(pen_str.value)
                    if fnmatch.fnmatch(pen_name_str, pat):
                        if (not(ib == 0x0)):
                            msg = ("Skipping Write WATSON PEN: %s in cmpid == 16 for IB %d" % (pen_name_str, ib))
                            if verbose:
                                log(msg)
                            pat_match = True
                if pat_match:
                    continue
                write_platform_pen(pen_id, index, flds, ib=ib)
            except Exception as ex:
                msg = ("Error writing to pen %s on IB%d"% (compat_bytesToStr(pen_str.value), ib))
                if log_redirect:
                    response = new_stdout.getvalue()
                    sys.stdout = old_stdout
                    sys.stderr = old_stderr
                    log_err(response)
                log_err(msg)
                raise ex

    # Read back and verify test pattern if requested
    if ib_list[0] == 0x1f:
        read_ib_list = compat_listrange(MAX_IBS)
    else:
        read_ib_list = ib_list

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)
    for ib in read_ib_list:
        pat_match = False
        for pat in skip_watson_pen_pat:
            pen_name_str= compat_bytesToStr(pen_str.value)
            if fnmatch.fnmatch(pen_name_str, pat):
                if (not(ib == 0x0)):
                    msg = ("Skipping Read WATSON PEN: %s in cmpid ! 16 for IB %d" % (pen_name_str, ib))
                    if verbose:
                        log(msg)
                    pat_match = True
        if pat_match:
            continue
        msg = ("Reading pen %s on IB%d"% (compat_bytesToStr(pen_str.value), ib))
        if verbose:
            log(msg)
        try:
            read_data = read_platform_pen(pen_id, index, ib=ib)
        except Exception as ex:
            msg = ("Error reading pen %s on IB%d"% (compat_bytesToStr(pen_str.value), ib))
            if log_redirect:
                response = new_stdout.getvalue()
                sys.stdout = old_stdout
                sys.stderr = old_stderr
                log_err(response)
            log_err(msg)
            raise ex

        if validate:
            msg = ("Validating test pattern for pen %s on IB%d" % (compat_bytesToStr(pen_str.value), ib))
            if verbose:
                log(msg)

            try:
                for fld in flds:
                    fld_idx = fld[0]

                    for findx in range(num_flds.value):
                        fname = fldinfo[findx].fname
                        fstr = get_field_name(fname)
                        fwidth = fldinfo[findx].width
                        fld_attr = fldinfo[findx].attributes

                        pat_match = False
                        for pat in skip_flds:
                            if fnmatch.fnmatch(fstr, pat):
                                pat_match = True
                                msg = ("Skipping FLD: %s of PEN %s with pat %s" % (fstr, compat_bytesToStr(pen_str.value), pat))
                                msg = str(datetime.datetime.now()) + ": " + msg
                                if verbose:
                                    log(msg)
                        if pat_match:
                            continue

                        if ((fld_attr & FA_HW) or (not(fld_attr & FA_SR))):
                            if (fld_attr & FA_HW):
                                pen_sw_data = ifcs_ctypes.pen_sw_metadata_t()
                                if (peninfo.sw_data):
                                    pen_sw_data = peninfo.sw_data
                                msg = ("Skipping FLD %s in PEN %s FA_HW xpen %d  %d byte %d entries" %(fstr, compat_bytesToStr(pen_str.value), pen_sw_data.contents.sw_is_pen_xpen, peninfo.width, peninfo.num_entries))
                                if verbose:
                                    log(msg)
                            else:
                                msg = ("Skipping FLD %s in PEN %s since it has FA_SR attr set" %(fstr, compat_bytesToStr(pen_str.value)))
                                if verbose:
                                    log(msg)
                            continue
                        rd_fld_idx = read_data[findx][0]
                        if rd_fld_idx != fld_idx:
                            continue

                        if fwidth <= 32:
                            if int(fld[1]) != int(read_data[findx][1]):
                                msg = ("***** [%s] [Attr %x]  Data write and read back on pen %d fld %d mismatch read data 0x%x, expected 0x%x"\
                                        % (fstr, fld_attr, pen_id, fld_idx, read_data[findx][1], fld[1]))
                                mismatch_count = mismatch_count  + 1
                                if verbose:
                                    log(msg)
                        else:
                            num_bytes = compat_division(fwidth + 7, 8)
                            for n in range(num_bytes):
                                if fld[1][n] != read_data[findx][1][n]:
                                    msg = ("***** [%s] [Attr %x] Data write and read back mismatch on pen %d fld %d at idx %d, read data 0x%x, expected 0x%x"\
                                    %(fstr, fld_attr, pen_id, fld_idx, n, read_data[findx][1][n], fld[1][n]))
                                    mismatch_count = mismatch_count  + 1
                                    if verbose:
                                        log(msg)
            except Exception as ex:
                msg = ("Error validating pen %s on IB%d"% (compat_bytesToStr(pen_str.value), ib))
                if log_redirect:
                    response = new_stdout.getvalue()
                    sys.stdout = old_stdout
                    sys.stderr = old_stderr
                    log_err(response)

                log_err(msg)
                raise ex
    if (mismatch_count != 0):
        msg = ("IB: %d PENID: %d PEN_NAME: %s PENTYPE: %s with num_flds %d readback failed with mismatch on %d fields " %
                (ib, pen_id, compat_bytesToStr(pen_str.value), get_pen_type(peninfo), num_flds.value, mismatch_count))
        if verbose:
            log(msg)
    else:
        msg = ("IB: %d PENID: %d PEN_NAME: %s PENTYPE: %s with num_flds %d readback is success" %
                (ib, pen_id, compat_bytesToStr(pen_str.value), get_pen_type(peninfo), num_flds.value))
        if verbose:
            log(msg)

    if log_redirect:
        response = new_stdout.getvalue()
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        if verbose:
            log(response)

def reset_grouping_pen_access():
    """
    Reset the grouping pen access
    """
    global verbose
    global log_redirect

    index = 0

    if log_redirect:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = new_stdout = compat_StringIO()
        sys.stderr = new_stderr = compat_StringIO()

    for pen_id in grouping_pens:

        flds = []
        pen_str = c_char_p(b" " * 64)
        rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)

        num_flds, fldinfo = get_flds_from_pen_id(pen_id)
        fname = fldinfo[0].fname
        flds.append((fname, 0x0))
        fname = fldinfo[1].fname
        flds.append((fname, 0x0))

        for ib in ib_list:
            if ib == 0x1f:
                ib_str = "all IBs (broadcast)"
            else:
                ib_str = "IB%d" % ib

            msg = ("reset_group: Writing to pen %s on %s"% (compat_bytesToStr(pen_str.value), ib_str))
            if verbose:
                log(msg)

            try:
                write_platform_pen(pen_id, index, flds, ib=ib)
            except Exception as ex:
                msg = ("Error writing to pen %s on %s"% (compat_bytesToStr(pen_str.value), ib_str))
                if log_redirect:
                    response = new_stdout.getvalue()
                    sys.stdout = old_stdout
                    sys.stderr = old_stderr
                    log_err(response)
                log_err(msg)
                raise ex

    if log_redirect:
        response = new_stdout.getvalue()
        sys.stdout = old_stdout
        sys.stderr = old_stderr
        if verbose:
            log(response)

def run_mem_test(self, parse_args):
    """
    Run tests and exit.
    Args:
        parse_args: parsed arguments
    Returns:
        none
    Raises:
        none
    """
    global pattern_list
    global ib_list
    global validate
    global ecc_check
    global verbose
    global log_redirect
    global exclude
    global MAX_IBS

    pattern_list = parse_args.pattern_list
    ib_list  = parse_args.ib_list
    validate = parse_args.validate
    ecc_check = parse_args.ecc
    exclude = parse_args.exclude
    verbose = True if parse_args.verbose else False
    rc_pass = True

    ib_list       = [int(x, 16) for x in ib_list.split(",")]
    test_patterns = [int(x, 16) for x in pattern_list.split(",")]

    count = len(test_patterns)

    device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
    if (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10):
        device_str = "TL10"
        msg = ("Running memrw in %s device" % device_str)
        log(msg)
        PEN_ID_DTM_DEBUG_SW = 4691
        BNUM_F = 5903
        PEN_ID_OSC_CONFIG = 2096
        MODE_F = 201
        WATSON_MEM_ENABLE_F = 3756
        MAX_IBS = 8
    elif (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX):
        device_str = "TL7"
        msg = ("Running memrw in %s device" % device_str)
        log(msg)
        PEN_ID_DTM_DEBUG_SW = 3221
        BNUM_F = 3781
        MAX_IBS = 6
    else:
        msg = "Unsupported device"
        log(msg)
        sys.exit()
    if ib_list[0] == 0x1f:
        ib_str = "all IBs (broadcast)"
    else:
        ib_str = "IB " + ",".join(str(x) for x in ib_list)

    if (not(ib_list[0] == 0x1f)):
        for x in ib_list:
            if ((x >= MAX_IBS) or (x < 0)):
                msg = ("IB%d is invalid for %s" % (x, device_str))
                log(msg)
                sys.exit()

    if (ifcs_ctypes.im_nmgr_is_node_enabled(self.cli.node_id) == ifcs_ctypes.IFCS_BOOL_FALSE):
        msg = ("Node %d NOT enabled. Node needs to be created and enabled before running memrw" % self.cli.node_id)
        log(msg)
        sys.exit()

    try:
        reset_grouping_pen_access()
        for rcount in range(count):
            index = 0
            pic_pens = []

            msg = "Writing pattern 0x%x to all memories" % test_patterns[rcount]
            log(msg)

            for pen_id in itertools.count():

                flds = []
                peninfo = ifcs_ctypes.pen_t()
                rc = ifcs_ctypes.node_get_pen_info(self.cli.node_id, pen_id, pointer(peninfo))
                if rc == ifcs_ctypes.IFCS_PARAM:
                    # Finished iterating through pen IDs.
                    break
                pen_name = get_pen_name(pen_id)
                pen_width = peninfo.width
                pen_str = c_char_p(b" " * 64)
                rc = ifcs_ctypes.node_get_pen_name(self.cli.node_id, pen_id, pen_str, 64)
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for pen id " + str(pen_id)
                pen_name_str= compat_bytesToStr(pen_str.value)

                if peninfo.num_entries >= 16 or\
                   (peninfo.flags & ifcs_ctypes.PEN_ACCESS_INDIR):

                    if pen_name in skip_pens:
                        pen_name_str= compat_bytesToStr(pen_str.value)
                        msg = ("Skipping PEN: %s" % (pen_name_str))
                        msg = str(datetime.datetime.now()) + ": " + msg
                        if verbose:
                            log(msg)
                        continue

                    pat_match = False
                    for pat in skip_pen_pat:
                        pen_name_str= compat_bytesToStr(pen_str.value)
                        if fnmatch.fnmatch(pen_name_str, pat):
                            msg = ("Skipping (pat) PEN: %s" % pen_name_str)
                            msg = str(datetime.datetime.now()) + ": " + msg
                            if verbose:
                                log(msg)
                            pat_match = True

                    if pat_match:
                        continue

                    # We need to do additional config for HEDTA_OPAQUE_STATS PENs
                    # This is Applicable only for TL10 and for TL7 this pattern match will be False
                    for pat in hedta_opaque_stats_pen_pat:
                        pen_name_str= compat_bytesToStr(pen_str.value)
                        if fnmatch.fnmatch(pen_name_str, pat):
                            msg = ("Enabling HEDTA stats config on PEN %s" % (pen_name_str))
                            if verbose:
                                log(msg)
                            fld_lst = []
                            fld_lst.append((MODE_F, 0xf))
                            fld_lst.append((WATSON_MEM_ENABLE_F, 0xff))
                            for ib in ib_list:
                                write_platform_pen(PEN_ID_OSC_CONFIG, 0, fld_lst, ib=ib)

                    if compat_bytesToStr(pen_str.value) in dtm_bank_pens:
                        index = 0
                        fld_vals = get_fld_values(pen_id, test_patterns, rcount)
                        for bank in range(8):
                            # Set the bank
                            fld_lst = []
                            fld_lst.append((BNUM_F, bank))
                            for ib in ib_list:
                                if log_redirect:
                                    old_stdout = sys.stdout
                                    old_stderr = sys.stderr
                                    sys.stdout = new_stdout = compat_StringIO()
                                    sys.stderr = new_stderr = compat_StringIO()

                                write_platform_pen(PEN_ID_DTM_DEBUG_SW, 0, fld_lst, ib=ib)

                                if log_redirect:
                                    response = new_stdout.getvalue()
                                    sys.stdout = old_stdout
                                    sys.stderr = old_stderr
                                    if verbose:
                                        log(response)

                                perform_pen_access(pen_id, fld_vals, index)

                    elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_TCAM or
                          peninfo.flags & ifcs_ctypes.PEN_TYPE_LPM_TCAM or
                          peninfo.flags & ifcs_ctypes.PEN_TYPE_ABB_TCAM):
                        if exclude:
                            msg = ("Excluding TCAM PEN: %s (%d)" % (pen_name_str, pen_id))
                            msg = str(datetime.datetime.now()) + ": " + msg
                            if verbose:
                                log(msg)
                            continue
                        index = 0
                        fld_vals = get_fld_values_pen_type_tcam(pen_id, test_patterns, rcount)
                        perform_pen_access(pen_id, fld_vals, index)

                    elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_HASH):
                        pat_match = False
                        bucket = slot = 0
                        index = 0
                        pat = "*_FULL"
                        if fnmatch.fnmatch(pen_name_str, pat):
                            pat_match = True

                        if pat_match:
                            for fid in range(2):
                                index = ifcs_ctypes.HASH_TO_INDEX(fid, bucket, slot)
                                fld_vals = get_fld_values_pen_type_hash(pen_id, fid, test_patterns, rcount)
                                perform_pen_access(pen_id, fld_vals, index)
                        else:
                            msg = ("Skipping HASH PEN: %s (%d)" % (pen_name_str, pen_id))
                            msg = str(datetime.datetime.now()) + ": " + msg
                            if verbose:
                                log(msg)

                    elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_ILPM):
                        pat_match = False
                        pat = "*_FULL"
                        index = 0
                        if fnmatch.fnmatch(pen_name_str, pat):
                            pat_match = True

                        if pat_match:
                            fld_vals = get_fld_values_pen_type_ilpm(pen_id, test_patterns, rcount)
                            perform_pen_access(pen_id, fld_vals, index)
                        else:
                            msg = ("Skipping ILPM PEN: %s" % pen_name_str)
                            msg = str(datetime.datetime.now()) + ": " + msg
                            if verbose:
                                log(msg)

                    elif (peninfo.flags & ifcs_ctypes.PEN_TYPE_INDEX and
                          peninfo.flags & ifcs_ctypes.PEN_ACCESS_INDIR):

                        index = 0
                        pat_match = False
                        pat = "*_1X*"
                        pen_name_str= compat_bytesToStr(pen_str.value)
                        if fnmatch.fnmatch(pen_name_str, pat):
                            pat_match = True

                        if pat_match:
                            fld_vals = get_fld_values_pen_type_indx_indir(pen_id, test_patterns, rcount)
                            perform_pen_access(pen_id, fld_vals, index)
                        else:
                            msg = ("Skipping INDEX_INDIR PEN: %s" % pen_name_str)
                            msg = str(datetime.datetime.now()) + ": " + msg
                            if verbose:
                                log(msg)

                    else:
                        index = 0
                        fld_vals = get_fld_values(pen_id, test_patterns, rcount)
                        perform_pen_access(pen_id, fld_vals, index)

                    if ecc_check:
                        display_ecc_errors()
    except Exception as ex:
        raise ex

    display_ecc_errors()

    return rc_pass
