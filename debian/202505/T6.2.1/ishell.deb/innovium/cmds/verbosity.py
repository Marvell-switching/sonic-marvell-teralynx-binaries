
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from __future__ import print_function

import shlex
import sys
from cmdmgr import Command
from utils.compat_util import *

# global verbosity level (default 0) can be set from CLI command
ifcs_verbosity = 0
ifcs_error = 0
quiet_mode = 0

def log_dbg(level, logstr):
    if(ifcs_verbosity >= level):
        print('CLI_LOG_DBG: ' + logstr)

def log_err(logstr):
    ifcs_error = 1
    print('CLI_LOG_ERR: ' + logstr)

def log(*argv):
    print(*argv)

def log_no_newline(*argv):
    print(*argv, end = " ")

def quiet():
    global quiet_mode
    return quiet_mode

class Verbosity(Command):
    def __init__(self, cli):
        self.sub_cmds = {'show'        : self.show,
                         'set'         : self.set,
                         'setq'        : self.setq,
                         'trace'       : self.trace,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.arg_list = []
        self.cli = cli
        super(Verbosity, self).__init__()
        return

    def run_cmd(self, args):
        log_dbg(1, 'in Verbosity run')
        self.arg_list = shlex.split(args)
        log_dbg(1, 'context: ' + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            log_dbg(
                1, "KeyError in verbosity [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
        except (ValueError):
            log_dbg(
                1, "ValueError in verbosity [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
        except:
            log_dbg(
                1, "OtherError in verbosity [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            log_err("Verb OtherError")
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def show(self, args):
        global ifcs_verbosity
        global quiet_mode
        print('Verbosity  = ', ifcs_verbosity)
        print('Quiet Mode = ', quiet_mode)
        return

    def set(self, args):
        global ifcs_verbosity
        arg_list = shlex.split(args)
        ifcs_verbosity = int(arg_list[2])
        print('Verbosity set to ' + arg_list[2])
        return

    def setq(self, args):
        global quiet_mode
        arg_list = shlex.split(args)
        quiet_mode = int(arg_list[2])
        print('Quiet Mode set to ' + arg_list[2])
        return

    def getq(self, args):
        return quiet_mode

    def trace(self, args):
        arg_list = shlex.split(args)
        trace_area = arg_list[2]
        trace_level = int(arg_list[3])
        print('Trace area ', trace_area, 'level set to ', trace_level)
        rc = ifcs_ctypes.im_trace_set("cli_sh", trace_area, trace_level)
        return

    def help(self, args):
        print("Usage: \n", \
              "verbosity set <level>   - set verbosity to <level>\n", \
              "verbosity setq <mode>   - set quiet mode to <mode>\n", \
              "verbosity show          - show verbosity level\n", \
              "verbosity trace <area> <level> - set ii trace level\n", \
              "verbosity help or ?     - show this text\n")
