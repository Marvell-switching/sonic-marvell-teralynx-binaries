 #-------------------------------------------------------------------------------
 # Copyright (c) (2021) Marvell. All rights reserved
 #
 # The following file is subject to the limited use license agreement
 # by and between Marvell and you,  your employer or other entity on
 # behalf of whom you act. In the absence of such license agreement the
 # following file is subject to Marvell's standard Limited Use License Agreement.
 #-------------------------------------------------------------------------------

import shlex
import time
import random
import copy
import argparse
import test_multi_traffic_send

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *

import sys
try:
    ifcs_ctypes = sys.modules['ifcs_ctypes']
except KeyError:
    import ifcs_ctypes

from ctypes import *
from testutil import pci
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.cpu_queue import CpuQueue as CpuQueue
from print_table import PrintTable
from node import *
from ifcs_cmds.node import Node as ifcs_node
from snake import Snake
from ifcs_config import IfcsConfig

# Constants
BITS_PER_BYTE = 8
LIST_TX_SIZE = 128
LIST_RX_SIZE = 48

# Global variables
g_tx_time_prev = None
g_tx_time_curr = None
g_tx_time_delta = None
g_total_tx_frames_rate = 0
g_total_tx_bytes_rate = 0

# Tx, RX Ports
g_rx_port_1 = 27
g_rx_port_2 = 31
g_tx_port_1 = 29

# CPU queue stats
g_cpu_queue_tx_frames_curr = [0] * LIST_TX_SIZE
g_cpu_queue_tx_frames_prev = [0] * LIST_TX_SIZE
g_cpu_queue_tx_frames_delta = [0] * LIST_TX_SIZE
g_cpu_queue_tx_frames_rate = [0] * LIST_TX_SIZE

g_cpu_queue_tx_bytes_curr = [0] * LIST_TX_SIZE
g_cpu_queue_tx_bytes_prev = [0] * LIST_TX_SIZE
g_cpu_queue_tx_bytes_delta = [0] * LIST_TX_SIZE
g_cpu_queue_tx_bytes_rate = [0] * LIST_TX_SIZE

g_rx_time_prev = None
g_rx_time_curr = None
g_rx_time_delta = None
g_total_rx_frames_rate = 0
g_total_rx_bytes_rate = 0

# CPU queue stats
g_cpu_queue_rx_frames_curr = [0] * LIST_RX_SIZE
g_cpu_queue_rx_frames_prev = [0] * LIST_RX_SIZE
g_cpu_queue_rx_frames_delta = [0] * LIST_RX_SIZE
g_cpu_queue_rx_frames_rate = [0] * LIST_RX_SIZE

g_cpu_queue_rx_bytes_curr = [0] * LIST_RX_SIZE
g_cpu_queue_rx_bytes_prev = [0] * LIST_RX_SIZE
g_cpu_queue_rx_bytes_delta = [0] * LIST_RX_SIZE
g_cpu_queue_rx_bytes_rate = [0] * LIST_RX_SIZE

def create_hostif_traps(create=1):
    # Create hostif_trap objects with identifiers and queue numbers
    # Define trap configurations
    trap_configs = [
        {"identifier": 74, "queue_num": 4},
        {"identifier": 75, "queue_num": 5},
        {"identifier": 76, "queue_num": 6},
        {"identifier": 77, "queue_num": 7}
    ]

    if create == 1:
        for config in trap_configs:
            # Create hostif_trap structure
            trap_handle = ifcs_ctypes.ifcs_handle_t()
            trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(config["identifier"])

            # Set queue number attribute
            attr_count = 1
            attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
            ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0))
            attr.queue_num = config["queue_num"]

            # Create the hostif_trap
            rc = ifcs_ctypes.ifcs_hostif_trap_create(
                    0,  # node_id
                    pointer(trap_handle),
                    attr_count,
                    compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))

            assert rc == ifcs_ctypes.IFCS_SUCCESS, "Hostif trap create failed"
            log(f"Created {config['identifier']} and queue_num {config['queue_num']}")

    elif create == 0:
        for config in trap_configs:
            trap_handle = ifcs_ctypes.ifcs_handle_t()
            trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(config["identifier"])
            rc = ifcs_ctypes.ifcs_hostif_trap_delete(0, trap_handle);
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "Hostif trap delete failed"
            log(f"Deleted identifier {config['identifier']} and queue_num {config['queue_num']}")


def configure_l2_entries():
    global g_rx_port_1, g_rx_port_2

    # Define L2 entry configurations
    l2_configs = [
        {
            "name": "l2_entry1",
            "mac_addr": "00:00:00:00:00:aa",
            "l2vni": g_rx_port_1,
            "sysport": g_rx_port_1,
            "trap_id": 74
        },
        {
            "name": "l2_entry2",
            "mac_addr": "00:00:00:00:00:bb",
            "l2vni": g_rx_port_1,
            "sysport": g_rx_port_2,
            "trap_id": 75
        },
        {
            "name": "l2_entry3",
            "mac_addr": "00:00:00:00:00:aa",
            "l2vni": g_rx_port_2,
            "sysport": g_rx_port_2,
            "trap_id": 76
        },
        {
            "name": "l2_entry4",
            "mac_addr": "00:00:00:00:00:bb",
            "l2vni": g_rx_port_2,
            "sysport": g_rx_port_1,
            "trap_id": 77
        }
    ]


    for config in l2_configs:
        mac_addr_t = c_uint8 * 6
        attr = ifcs_ctypes.ifcs_attr_t()
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(config["l2vni"])
        # Not checking the ret value
        ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), 0, pointer(attr))

        mac_bytes = [int(x, 16) for x in config["mac_addr"].split(':')]
        # Create mac_addr_t structure with the parsed bytes
        mac_addr = mac_addr_t(
            mac_bytes[0],
            mac_bytes[1],
            mac_bytes[2],
            mac_bytes[3],
            mac_bytes[4],
            mac_bytes[5]
        )

        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(config["sysport"])

        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(config["trap_id"])

        l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
        ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
        ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                l2_entry.key.mac_l2vni)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                mac_addr)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                l2vni_hdl)

        attr_count = 3
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0))
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 1))
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 2))

        attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
        attr[2].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY
        attr[2].value.ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
        attr[2].value.ctc_policy.trap_handle = trap_handle
        attr[2].value.ctc_policy._dirty_ctc_action = 1
        attr[2].value.ctc_policy._dirty_trap_handle = 1

        rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "L2 attr set failed"

def cfg():
    create_hostif_traps(1) #1 = create, 0 = delete
    configure_l2_entries()

def un_cfg():
    create_hostif_traps(0) #1 = create, 0 = delete

def set_tx_rx_ports(node_id=0):
    global g_rx_port_1, g_rx_port_2, g_tx_port_1

    def myCallback(node_id, arg, attr_count, attr_list, user_data):
        devport = arg
        devport_list.append(devport)

    devport_list = []

    callback_type = CFUNCTYPE(
        ifcs_ctypes.UNCHECKED(None),
        ifcs_ctypes.ifcs_node_id_t,
        ifcs_ctypes.ifcs_devport_t,
        c_uint32,
        POINTER(ifcs_ctypes.ifcs_attr_t),
        POINTER(None))
    callback = callback_type(myCallback)

    attr = ifcs_ctypes.ifcs_attr_t()
    ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
    ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

    try:
        rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
        if ( rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err("Failed to get all devport rc: {0}".format(rc))
    except:
        log_err("In except of devport get_all")
        pass

    valid_ports = [port for port in devport_list if port != 0 and port is not None]
    g_rx_port_1 = valid_ports[0]
    g_rx_port_2 = valid_ports[1]
    g_tx_port_1 = valid_ports[2]


# Measures RX traffic rate with the help of diagnostic snake test.
# 1. Enables devports and configures loopback for traffic generation.
# 2. Captures RX stats before and after traffic using IFCS APIs.
# 3. Computes delta and rate (pps and Gbps) including protocol overhead.i
# 4. Displays results in a formatted table.
# 5. Cleans up by stopping traffic and restoring devport config.

def process_rx_cpu_queue_rate (self, args):
    global g_rx_time_prev, g_rx_time_curr, g_rx_time_delta, g_rx_first_time

    set_tx_rx_ports(0)

    def get_rx_queue_stats():
        cpu_queue = CpuQueue(self.cli)
        if cpu_queue is None:
            log_err('Unknown IFCS Object: cpu_queue')
            return
        try:
            rc, all_queues = cpu_queue.bulk_get_all_cpu_queue_keys()
        except BaseException:
            log_err("Error retrieving cpu_queues")
            return

        for queueitr in all_queues:
            stats_list = cpu_queue.stats_get(queueitr)
            rx_pkt_count = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_PACKET_TX_COUNT]
            rx_bytes_count= stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_BYTE_TX_COUNT]

            g_cpu_queue_rx_frames_curr[queueitr] = rx_pkt_count
            g_cpu_queue_rx_bytes_curr[queueitr] = rx_bytes_count

    def calculate_rx_delta():
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        for i in range(LIST_RX_SIZE):
            curr = g_cpu_queue_rx_frames_curr[i]
            prev = g_cpu_queue_rx_frames_prev[i]
            g_cpu_queue_rx_frames_delta[i] = curr - prev if curr > prev else 0

        for i in range(LIST_RX_SIZE):
            curr = g_cpu_queue_rx_bytes_curr[i]
            prev = g_cpu_queue_rx_bytes_prev[i]
            pkt_delta = g_cpu_queue_rx_frames_delta[i]
            if curr >= prev:
                g_cpu_queue_rx_bytes_delta[i] = curr - prev + (pkt_delta * misc_delta_bytes)
            else:
                g_cpu_queue_rx_bytes_delta[i] = 0

    def calculate_rx_rate():
        global g_total_rx_frames_rate, g_total_rx_bytes_rate
        g_total_rx_frames_rate = 0
        g_total_rx_bytes_rate = 0
        for i in range(LIST_RX_SIZE):
            g_cpu_queue_rx_frames_rate[i] = g_cpu_queue_rx_frames_delta[i] / g_rx_time_delta
            g_cpu_queue_rx_bytes_rate[i] = (g_cpu_queue_rx_bytes_delta[i] * BITS_PER_BYTE / 1_000_000_000) / g_rx_time_delta
            g_total_rx_frames_rate += g_cpu_queue_rx_frames_rate[i]
            g_total_rx_bytes_rate  += g_cpu_queue_rx_bytes_rate[i]

    # Save current stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    # Redirect stdout and stderr
    sys.stdout = new_stdout = compat_StringIO()
    sys.stderr = new_stderr = compat_StringIO()

    try:
        snake_obj = Snake(self.cli)
        snake_obj.run_cmd(f"diagtest snake config -p {str(g_rx_port_1)},{str(g_rx_port_2)} -lb PCS")
        cfg()
        snake_obj.run_cmd("diagtest snake start_traffic -n 50 -s 9132")

    except Exception as ex:
        log_err("error occurred during rx pci_perf devport/snake/trap/l2 config")
        log_dbg(1, "diagtest rx pci_perf devport/snake/trap/l2 config error {}".format(ex))
        raise ex
    finally:
        # Restore stdout and stderr
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    mod_list = (ifcs_ctypes.ifcs_mod_t * 1)(ifcs_ctypes.IFCS_MOD_QUEUE)
    ret = ifcs_ctypes.ifcs_node_stats_sync_module(0, 1, compat_pointer(mod_list, ifcs_ctypes.ifcs_mod_t))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "Stats sync failed"
    # First snapshot
    get_rx_queue_stats()

    for i in range(LIST_RX_SIZE):
        g_cpu_queue_rx_frames_prev[i] = g_cpu_queue_rx_frames_curr[i]
        g_cpu_queue_rx_bytes_prev[i] = g_cpu_queue_rx_bytes_curr[i]
    g_rx_time_prev = round(time.time(), 6)

    # Sleep
    time.sleep(15)
    # Second snapshot
    get_rx_queue_stats()
    g_rx_time_curr = round(time.time(), 6)
    g_rx_time_delta = g_rx_time_curr - g_rx_time_prev

    # Calculate delta and rate
    calculate_rx_delta()
    calculate_rx_rate()

    # Display
    table = PrintTable()
    table.add_row([
                    'Rx Pps',
                    'Rx Gbps',
                    'Rx Port 1',
                    'Rx Port 2',
                   ])

    table.add_row(["%.2f" % g_total_rx_frames_rate, "%.2f" % g_total_rx_bytes_rate, "%d" % g_rx_port_1 , "%d" % g_rx_port_2])
    table.print_table(brief=True)
    table.reset_table()

    # Redirect stdout and stderr
    sys.stdout = new_stdout = compat_StringIO()
    sys.stderr = new_stderr = compat_StringIO()
    try:
        snake_obj.run_cmd("diagtest snake stop_traffic")
        snake_obj.run_cmd("diagtest snake unconfig")
        un_cfg()
    except Exception as ex:
        log_err("error occurred during rx pci_perf snake stop-traffic/unconfig or trap delete ")
        log_dbg(1, "diagtest rx pci_perf snake stop-traffic/unconfig or trap delete error {}".format(ex))
        raise ex
    finally:
        # Restore stdout and stderr
        sys.stdout = old_stdout
        sys.stderr = old_stderr

# Measures TX traffic rate with the help of diagnostic snake test.
# 1. Enables devport and configures loopback for traffic generation.
# 2. Writes max credits to TXE channels to allow full traffic flow.
# 3. Captures TX stats before and after traffic using IFCS APIs.
# 4. Computes delta and rate (pps and Gbps) including protocol overhead.
# 5. Displays results in a formatted table.
# 6. Cleans up by restoring TXE credits and unconfiguring devport.

def process_tx_cpu_queue_rate (self, args):
    global g_tx_time_prev, g_tx_time_curr, g_tx_time_delta, g_tx_first_time

    # Taking a backup, to be restored later down.
    txe_chnl_0_fields = pci.read_fields('TXE_CHNL_0')
    txe_chnl_1_fields = pci.read_fields('TXE_CHNL_1')
    txe_chnl_2_fields = pci.read_fields('TXE_CHNL_2')

    pci.write_fields('TXE_CHNL_0', credits_f=0x0)
    pci.write_fields('TXE_CHNL_1', credits_f=0x0)
    pci.write_fields('TXE_CHNL_2', credits_f=0x0)

    set_tx_rx_ports(0)

    test_multi_traffic_send.run_traffic_test(g_tx_port_1, 4)

    def get_tx_queue_stats():
        devport = Devport(self.cli)
        if devport is None:
           log_err('Unknown IFCS Object')
           return
        try:
            rc, all_devports = devport.bulk_get_all_devport_keys()
        except BaseException:
            log_err("Error retrieving devports")
            return

        input_pkt_count = input_bytes_count = 0
        stats_list = devport.stats_get(g_tx_port_1)
        if devport.getType(g_tx_port_1) != ifcs_ctypes.IFCS_DEVPORT_TYPE_CPU:
            cpu_tx_pkt_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            cpu_tx_bytes_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]

            g_cpu_queue_tx_frames_curr[g_tx_port_1] = cpu_tx_pkt_count
            g_cpu_queue_tx_bytes_curr[g_tx_port_1] = cpu_tx_bytes_count

    def calculate_tx_delta():
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        for i in range(LIST_TX_SIZE):
            curr = g_cpu_queue_tx_frames_curr[i]
            prev = g_cpu_queue_tx_frames_prev[i]
            g_cpu_queue_tx_frames_delta[i] = curr - prev if curr > prev else 0

        for i in range(LIST_TX_SIZE):
            curr = g_cpu_queue_tx_bytes_curr[i]
            prev = g_cpu_queue_tx_bytes_prev[i]
            pkt_delta = g_cpu_queue_tx_frames_delta[i]
            if curr >= prev:
                g_cpu_queue_tx_bytes_delta[i] = curr - prev + (pkt_delta * misc_delta_bytes)
            else:
                g_cpu_queue_tx_bytes_delta[i] = 0

    def calculate_tx_rate():
        global g_total_tx_frames_rate, g_total_tx_bytes_rate
        g_total_tx_frames_rate = 0
        g_total_tx_bytes_rate = 0
        for i in range(LIST_TX_SIZE):
            g_cpu_queue_tx_frames_rate[i] = g_cpu_queue_tx_frames_delta[i] / g_tx_time_delta
            g_cpu_queue_tx_bytes_rate[i] = (g_cpu_queue_tx_bytes_delta[i] * BITS_PER_BYTE / 1_000_000_000) / g_tx_time_delta
            g_total_tx_frames_rate += g_cpu_queue_tx_frames_rate[i]
            g_total_tx_bytes_rate  += g_cpu_queue_tx_bytes_rate[i]

    # Save current stdout and stderr
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    # Redirect stdout and stderr
    sys.stdout = new_stdout = compat_StringIO()
    sys.stderr = new_stderr = compat_StringIO()
    try:
        snake_obj = Snake(self.cli)
        snake_obj.run_cmd(f"diagtest snake config -p {str(g_tx_port_1)} -lb PCS")
    except Exception as ex:
        log_err("error occurred during diagtest snake config")
        log_dbg(1, "diagtest snake config error {}".format(ex))
        raise ex
    finally:
        # Restore stdout and stderr
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    mod_list = (ifcs_ctypes.ifcs_mod_t * 1)(ifcs_ctypes.IFCS_MOD_QUEUE)
    ret = ifcs_ctypes.ifcs_node_stats_sync_module(0, 1, compat_pointer(mod_list, ifcs_ctypes.ifcs_mod_t))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "Stats sync failed"
    # Sleep
    time.sleep(5)

    # First snapshot
    pci.write_fields('TXE_CHNL_0', credits_f=0xFFFF)
    pci.write_fields('TXE_CHNL_1', credits_f=0xFFFF)
    pci.write_fields('TXE_CHNL_2', credits_f=0xFFFF)
    get_tx_queue_stats()
    g_cpu_queue_tx_frames_prev[g_tx_port_1] = g_cpu_queue_tx_frames_curr[g_tx_port_1]
    g_cpu_queue_tx_bytes_prev[g_tx_port_1] = g_cpu_queue_tx_bytes_curr[g_tx_port_1]
    g_tx_time_prev = round(time.time(), 6)
    # Second snapshot
    get_tx_queue_stats()
    g_tx_time_curr = round(time.time(), 6)
    g_tx_time_delta = g_tx_time_curr - g_tx_time_prev

    # Calculate delta and rate
    calculate_tx_delta()
    calculate_tx_rate()

    # Display
    table = PrintTable()
    table.add_row([
                    'Tx Pps',
                    'Tx Gbps',
                    'Tx Port 1'
                   ])

    table.add_row(["%.2f" % g_total_tx_frames_rate, "%.2f" % g_total_tx_bytes_rate, "%d" % g_tx_port_1])
    table.print_table(brief=True)
    table.reset_table()

    # Redirect stdout and stderr
    sys.stdout = new_stdout = compat_StringIO()
    sys.stderr = new_stderr = compat_StringIO()
    try:
        snake_obj.run_cmd("diagtest snake unconfig")
        pci.write_fields('txe_chnl_0', credits_f=txe_chnl_0_fields['credits_f'])
        pci.write_fields('TXE_CHNL_1', credits_f=txe_chnl_1_fields['credits_f'])
        pci.write_fields('TXE_CHNL_2', credits_f=txe_chnl_2_fields['credits_f'])
    except Exception as ex:
        log_err("error occurred during diagtest snake config")
        log_dbg(1, "diagtest snake config error {}".format(ex))
        raise ex
    finally:
        # Restore stdout and stderr
        sys.stdout = old_stdout
        sys.stderr = old_stderr
