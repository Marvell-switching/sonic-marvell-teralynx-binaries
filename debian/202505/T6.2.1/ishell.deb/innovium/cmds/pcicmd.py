
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import sys
import shlex
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
ifcs_ctypes=sys.modules['ifcs_ctypes']

from testutil import pci

# Class implements Pci related command


class Pci(Command):
    def __init__(self, cli):
        self.sub_cmds = {'show'        : self.show,
                         'read'        : self.read,
                         'write'       : self.write,
                         'read0'       : self.read0,
                         'write0'      : self.write0,
                         'intr_miss'   : self.intr_miss,
                         'debugdump'   : self.debugdump,
                         'dd'          : self.debugdump,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Pci, self).__init__()

    def run_cmd(self, args):
        log_dbg(1, "in Pci run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except Exception as ex:
            log_dbg(
                1, "Exception in pci [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            log("run cmd: ", type(ex).__name__, ex.args)
            self.help(args)
        except (KeyError):
            log_dbg(
                1, "KeyError in pci [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in pci [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except:
            log_dbg(
                1, "OtherError in pci [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        return ifcs_ctypes.IFCS_INVAL

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    # ------------
    # READ command
    # ------------
    def read(self, args):
        log_dbg(1, "In Pci Read")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        pci_name = self.arg_list.pop(0)
        raw_mode = 1
        try:
            value = self.arg_list.pop(0)
            count = int(value, 0)
            assert count > 0
        except IndexError:
            count = 1
        except ValueError:
            log("pci read: invalid format for count option")
            return ifcs_ctypes.IFCS_INVAL
        except Exception as ex:
            log("pci read: count must be >0 (" + int(count) + " given)")
            return ifcs_ctypes.IFCS_INVAL

        return self.readreg(pci_name, count)

    def readreg(self, pci_name, count=1):
        raw_mode = 1
        try:
            pci_offset = int(pci_name, 0)
        except ValueError:
            pci_offset = eval('ifcs_ctypes.'+pci_name.upper())
            raw_mode = 0
        except Exception as ex:
            log("pci read: ", type(ex).__name__, ex.args)

        log('=== PCI: ' + pci_name.upper() + ' (' + hex(pci_offset) + ')  ===')
        for i in range(0, count):
            try:
                regval = pci.read32(pci_offset)
                if (raw_mode == 0):
                    try:
                        reg_struct = pci.get_reg_struct(pci_name)
                        start = 0
                        shift = {}
                        width = {}
                        mask = {}
                        for i in range(len(reg_struct._fields_)):
                            wd = reg_struct._fields_[i][2]
                            fld = reg_struct._fields_[i][0].lower()
                            msk = 0xffffffff >> (32 - wd)
                            shift[reg_struct._fields_[i][0].lower()] = start
                            width[reg_struct._fields_[i][0].lower()] = reg_struct._fields_[i][2]
                            mask[reg_struct._fields_[i][0].lower()] = msk
                            log((" %-25s" % fld.upper()), '\t', hex((regval >> start) & msk))
                            start += int(reg_struct._fields_[i][2])

                    except:
                        pass

            except Exception as ex:
                log_dbg(
                    1, "Exception in pci read reg with name: {} count: {} : {}".
                    format(pci_name, count, sys.exc_info()))
                self.cli.error()
                log("pci read: ", type(ex).__name__, ex.args)
                return ifcs_ctypes.IFCS_INVAL
            log("READ value", hex(regval), "ok")
            pci_offset += 4
        return ifcs_ctypes.IFCS_SUCCESS

    def read0(self, args):
        log_dbg(1, "In Pci Read0")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        pci_name = self.arg_list.pop(0)
        raw_mode = 1
        try:
            value = self.arg_list.pop(0)
            count = int(value, 0)
            assert count > 0
        except IndexError:
            count = 1
        except ValueError:
            log("pci read: invalid format for count option")
            return ifcs_ctypes.IFCS_INVAL
        except Exception as ex:
            log("pci read: count must be >0 (" + int(count) + " given)")
            return ifcs_ctypes.IFCS_INVAL

        return self.readreg0(pci_name, count)

    def readreg0(self, pci_name, count=1):
        raw_mode = 1
        try:
            pci_offset = int(pci_name, 0)
        except ValueError:
            pci_offset = eval('ifcs_ctypes.'+pci_name.upper())
            raw_mode = 0
        except Exception as ex:
            log("pci read: ", type(ex).__name__, ex.args)

        log('=== PCI: ' + pci_name.upper() + ' (' + hex(pci_offset) + ')  ===')
        for i in range(0, count):
            try:
                regval = pci.read0(pci_offset)
                if (raw_mode == 0):
                    try:
                        reg_struct = pci.get_reg_struct(pci_name)
                        start = 0
                        shift = {}
                        width = {}
                        mask = {}
                        for i in range(len(reg_struct._fields_)):
                            wd = reg_struct._fields_[i][2]
                            fld = reg_struct._fields_[i][0].lower()
                            msk = 0xffffffff >> (32 - wd)
                            shift[reg_struct._fields_[i][0].lower()] = start
                            width[reg_struct._fields_[i][0].lower()] = reg_struct._fields_[i][2]
                            mask[reg_struct._fields_[i][0].lower()] = msk
                            log((" %-25s" % fld.upper()), '\t', hex((regval >> start) & msk))
                            start += int(reg_struct._fields_[i][2])

                    except:
                        pass

            except Exception as ex:
                log_dbg(
                    1, "Exception in pci read reg with name: {} count: {} : {}".
                    format(pci_name, count, sys.exc_info()))
                self.cli.error()
                log("pci read: ", type(ex).__name__, ex.args)
                return ifcs_ctypes.IFCS_INVAL
            log("READ value", hex(regval), "ok")
            pci_offset += 4
        return ifcs_ctypes.IFCS_SUCCESS


    def print_separator(self, arg):
        log("")
        for i in range(15):
            log_no_newline("=")

        log_no_newline("*",arg,"*")

        for i in range(15):
            log_no_newline("=")
        #for i in range(3+len(arg) // 2):
            #log_no_newline("-")
        log("")

    #def banner(text, ch="=", length=78):
        #spaced_text = ' %s ' % text
        #banner = spaced_text.center(length, "=")
        #log(banner)

    def debugdump(self, arg):
        self.print_separator("HW swap registers")
        self.readreg("ENDIAN_SWAP_ENA_PCIE_TAR")
        self.readreg("ENDIAN_SWAP_ENA_MSI_WB")
        self.readreg("ENDIAN_SWAP_ENA_IAC_AXIM")
        self.readreg("RXE_IMSG")
        self.readreg("RXE_IMSG_WRBACK")
        self.readreg("DESC_WRBACK")
        self.readreg("DESC_READ")
        self.readreg("DESC_CIDX_WRBACK")
        self.readreg("ENDIAN_SWAP_ENA_IAC_AXIS")
        self.readreg("ENDIAN_SWAP_ENA_IAC_CNTG")

        self.print_separator("Interrupt registers")
        self.readreg("INTR_INCR")
        self.readreg("INTR_INCS")
        self.readreg("INTR_INMS")
        self.readreg("INTR_INMC")
        return ifcs_ctypes.IFCS_SUCCESS

    # -------------
    # Trigger command
    # -------------
    def trigger(self, args):
        log('Not supported')
        return ifcs_ctypes.IFCS_SUCCESS

    # -------------
    # Write command
    # -------------
    def write(self, args):
        log_dbg(1, "In Pci Write")
        pci_name = self.arg_list[2]
        values = self.arg_list[3:]

        # turn a=1,b=2 into a,1,b,2 by way of a=1=b=2
        # so that either syntax will be accepted
        valuelist = '='.join(values).split('=')

        if len(valuelist) == 1:
            # Raw write of the single supplied value
            try:
                pci_offset = int(pci_name, 16)
            except ValueError:
                pci_offset = eval('ifcs_ctypes.' + pci_name.upper())

            regval = int(valuelist[0], 16)
            log('=== PCI: ' + pci_name.upper() + ' (' + hex(pci_offset) + ')  ===')
            log("Writing {:08x}: 0x{:08x}".format(pci_offset, regval))
            pci.write32(pci_offset, regval)
        else:
            # make dict: (1:2, 3:4, ...)
            fieldsdict = dict(zip(valuelist[::2], valuelist[1::2]))
            pci.write_fields(pci_name, **fieldsdict)
        return ifcs_ctypes.IFCS_SUCCESS

    def write0(self, args):
        log_dbg(1, "In Pci Write")
        pci_name = self.arg_list[2]
        values = self.arg_list[3:]

        # turn a=1,b=2 into a,1,b,2 by way of a=1=b=2
        # so that either syntax will be accepted
        valuelist = '='.join(values).split('=')

        if len(valuelist) == 1:
            # Raw write of the single supplied value
            try:
                pci_offset = int(pci_name, 16)
            except ValueError:
                pci_offset = eval('ifcs_ctypes.' + pci_name.upper())

            regval = int(valuelist[0], 16)
            log('=== PCI: ' + pci_name.upper() + ' (' + hex(pci_offset) + ')  ===')
            log("Writing {:08x}: 0x{:08x}".format(pci_offset, regval))
            pci.write0(pci_offset, regval)
        else:
            # make dict: (1:2, 3:4, ...)
            fieldsdict = dict(zip(valuelist[::2], valuelist[1::2]))
            pci.write_fields(pci_name, **fieldsdict)
        return ifcs_ctypes.IFCS_SUCCESS

    # ------------
    # PCI Interrupt Miss show command
    # ------------
    def intr_miss(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        try:
            learn_miss_intr = pci.learn_intr_miss_cnt(self.cli.node_id)
        except:
            log_dbg(
                1, "Ignored exception in pci intr miss : {}".format(
                    sys.exc_info()))
            learn_miss_intr = 0
        log('Learn Miss INTR: ' + str(learn_miss_intr) + '\n')
        return ifcs_ctypes.IFCS_SUCCESS

    # ------------
    # Show command
    # ------------
    def show(self, args):
        rc = ifcs_ctypes.IFCS_SUCCESS
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            pci_name = self.arg_list.pop(0)
            pci_offset = eval('ifcs_ctypes.' + pci_name.upper())
            reg_struct = pci.get_reg_struct(pci_name)
            try:
                verb_lvl = self.arg_list.pop(0)
            except:
                verb_lvl = 'br'
            log('\n=== PCI: ' + pci_name.upper() + ' (' + hex(pci_offset) + ') ===')
            log(' TYPE: PCI reg')
            log(' offset          : ' , hex(pci_offset))
            log(' width           : ' , 32)

            if ((verb_lvl != 'det') and (verb_lvl != 'ext')):
                return rc

            start = 0
            log('\n=== FIELDS ===')
            log(' fname\t\t\t\tstart\twidth')
            log(' -----\t\t\t\t-----\t-----')
            for i in range(len(reg_struct._fields_)):
                log(" {:<25}".format(reg_struct._fields_[i][0].upper()), '\t', start, '\t', reg_struct._fields_[i][2])
                start += int(reg_struct._fields_[i][2])

            if (verb_lvl != 'ext'):
                return rc

            log('\n=== Extensive show ... ===')

        except Exception as ex:
            log_dbg(
                1,
                "Exception in pci show [{}]: {}".format(args, sys.exc_info()))
            log(type(ex).__name__, ex.args)
            self.help(args)
            return ifcs_ctypes.IFCS_INVAL
        return rc

    def help(self, args):
        self.cli.error()
        log("Usage: \n" + \
              "pci read <pci_id> [count]                - ifcs pci read <pci_id>\n", \
              "pci write <pci_id>                       - ifcs pci write <pci_id>\n", \
              "pci show <pci_name> [ br | det | ext ]   - ifcs pci show <pci_name>\n", \
              "pci help or ?          - show this text\n")
        return ifcs_ctypes.IFCS_SUCCESS

    def help_write(self, args):
        self.cli.error()
        log("Usage: pci <write> <pci_reg> <value>     or ")
        log("       pci <write> <pci_reg> <Field_1> <value_1> ... <Field_n> <value_n>")
        log("Note:  value, value_1, ..., value_ns are hex-base")
        return ifcs_ctypes.IFCS_SUCCESS

    # ----------
    # Pci helper
    # ----------
    def get_pci_offset_from_str(self, pci_str):
        buflen = 32
        namebuf = create_string_buffer(buflen)
        namebuf.value = "unknown"
        pci_name = c_char_p(compat_strToBytes(pci_str)).value
        pci_num = c_int()
        node_get_pci_offset(0, 0, byref(pci_num), pci_name.upper())
        pci_offset = pci_num.value
        if (pci_offset == -1):
            self.cli.error()
            log('Invalid PCI name ' + pci_name)
        return pci_offset
