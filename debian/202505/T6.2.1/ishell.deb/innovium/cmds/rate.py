
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

from __future__ import division
import shlex
import argparse
import itertools
import json
import sys
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes
from ifcs_cmds.all import *
from print_table import PrintTable
import time

# global variables for rate calculation
g_time_prev = None
g_time_curr = None
g_time_delta = None
g_stats_poll_interval = None
g_first_time = 1

g_list_size = 2001
# sysport
g_sysport_input_pkt_count_curr = [0] * g_list_size
g_sysport_input_pkt_count_prev = [0] * g_list_size
g_sysport_input_pkt_count_delta = [0] * g_list_size
g_sysport_in_pkt_rate = [0] * g_list_size
g_sysport_in_pkt_rate_prev = [0] * g_list_size
g_sysport_output_pkt_count_curr = [0] * g_list_size
g_sysport_output_pkt_count_prev = [0] * g_list_size
g_sysport_output_pkt_count_delta = [0] * g_list_size
g_sysport_out_pkt_rate = [0] * g_list_size
g_sysport_out_pkt_rate_prev = [0] * g_list_size
g_sysport_input_bytes_count_curr = [0] * g_list_size
g_sysport_input_bytes_count_prev = [0] * g_list_size
g_sysport_input_bytes_count_delta = [0] * g_list_size
g_sysport_in_rate_mbps = [0] * g_list_size
g_sysport_in_rate_mbps_prev = [0] * g_list_size
g_sysport_output_bytes_count_curr = [0] * g_list_size
g_sysport_output_bytes_count_prev = [0] * g_list_size
g_sysport_output_bytes_count_delta = [0] * g_list_size
g_sysport_out_rate_mbps = [0] * g_list_size
g_sysport_out_rate_mbps_prev = [0] * g_list_size
g_sysport_input_err_count_curr = [0] * g_list_size
g_sysport_input_err_count_prev = [0] * g_list_size
g_sysport_input_err_count_delta = [0] * g_list_size
g_sysport_in_err_rate = [0] * g_list_size
g_sysport_in_err_rate_prev = [0] * g_list_size
g_sysport_output_err_count_curr = [0] * g_list_size
g_sysport_output_err_count_prev = [0] * g_list_size
g_sysport_output_err_count_delta = [0] * g_list_size
g_sysport_out_err_rate = [0] * g_list_size
g_sysport_out_err_rate_prev = [0] * g_list_size

# devport
g_devport_input_pkt_count_curr = [0] * g_list_size
g_devport_input_pkt_count_prev = [0] * g_list_size
g_devport_input_pkt_count_delta = [0] * g_list_size
g_devport_in_pkt_rate = [0] * g_list_size
g_devport_in_pkt_rate_prev = [0] * g_list_size
g_devport_output_pkt_count_curr = [0] * g_list_size
g_devport_output_pkt_count_prev = [0] * g_list_size
g_devport_output_pkt_count_delta = [0] * g_list_size
g_devport_out_pkt_rate = [0] * g_list_size
g_devport_out_pkt_rate_prev = [0] * g_list_size
g_devport_input_bytes_count_curr = [0] * g_list_size
g_devport_input_bytes_count_prev = [0] * g_list_size
g_devport_input_bytes_count_delta = [0] * g_list_size
g_devport_in_rate_mbps = [0] * g_list_size
g_devport_in_rate_mbps_prev = [0] * g_list_size
g_devport_output_bytes_count_curr = [0] * g_list_size
g_devport_output_bytes_count_prev = [0] * g_list_size
g_devport_output_bytes_count_delta = [0] * g_list_size
g_devport_out_rate_mbps = [0] * g_list_size
g_devport_out_rate_mbps_prev = [0] * g_list_size
g_devport_input_err_count_curr = [0] * g_list_size
g_devport_input_err_count_prev = [0] * g_list_size
g_devport_input_err_count_delta = [0] * g_list_size
g_devport_in_err_rate = [0] * g_list_size
g_devport_in_err_rate_prev = [0] * g_list_size
g_devport_output_err_count_curr = [0] * g_list_size
g_devport_output_err_count_prev = [0] * g_list_size
g_devport_output_err_count_delta = [0] * g_list_size
g_devport_out_err_rate = [0] * g_list_size
g_devport_out_err_rate_prev = [0] * g_list_size
g_devport_queue_pkt_tx_count_curr = []
g_devport_queue_pkt_tx_count_prev = []
g_devport_queue_pkt_tx_count_delta = []
g_devport_queue_pkt_tx_count_rate = []
g_devport_queue_bytes_tx_count_curr = []
g_devport_queue_bytes_tx_count_prev = []
g_devport_queue_bytes_tx_count_delta = []
g_devport_queue_bytes_tx_count_rate = []
g_devport_cpu_queue_tx_frames_curr = [0] * g_list_size
g_devport_cpu_queue_tx_frames_prev = [0] * g_list_size
g_devport_cpu_queue_tx_frames_delta = [0] * g_list_size
g_devport_cpu_queue_tx_frames_rate = [0] * g_list_size
g_devport_cpu_queue_tx_bytes_curr = [0] * g_list_size
g_devport_cpu_queue_tx_bytes_prev = [0] * g_list_size
g_devport_cpu_queue_tx_bytes_delta = [0] * g_list_size
g_devport_cpu_queue_tx_bytes_rate = [0] * g_list_size

def initialize_list(g_list):
    for i in range (0, g_list_size):
        new = []
        for j in range (0, 8):
            new.append(0)
        g_list.append(new)

initialize_list(g_devport_queue_pkt_tx_count_curr)
initialize_list(g_devport_queue_pkt_tx_count_prev)
initialize_list(g_devport_queue_pkt_tx_count_delta)
initialize_list(g_devport_queue_pkt_tx_count_rate)
initialize_list(g_devport_queue_bytes_tx_count_curr)
initialize_list(g_devport_queue_bytes_tx_count_prev)
initialize_list(g_devport_queue_bytes_tx_count_delta)
initialize_list(g_devport_queue_bytes_tx_count_rate)


def update_previous_counts(only_queue_stats=False):
    global g_sysport_input_pkt_count_curr, g_sysport_input_pkt_count_prev
    global g_sysport_input_bytes_count_curr, g_sysport_input_bytes_count_prev
    global g_sysport_input_err_count_curr, g_sysport_input_err_count_prev
    global g_sysport_output_pkt_count_curr, g_sysport_output_pkt_count_prev
    global g_sysport_output_bytes_count_curr, g_sysport_output_bytes_count_prev
    global g_sysport_output_err_count_curr, g_sysport_output_err_count_prev
    global g_devport_input_pkt_count_curr, g_devport_input_pkt_count_prev
    global g_devport_input_bytes_count_curr, g_devport_input_bytes_count_prev
    global g_devport_input_err_count_curr, g_devport_input_err_count_prev
    global g_devport_output_pkt_count_curr, g_devport_output_pkt_count_prev
    global g_devport_output_bytes_count_curr, g_devport_output_bytes_count_prev
    global g_devport_output_err_count_curr, g_devport_output_err_count_prev
    global g_devport_queue_pkt_tx_count_curr, g_devport_queue_pkt_tx_count_prev
    global g_devport_queue_bytes_tx_count_curr, g_devport_queue_bytes_tx_count_prev
    global g_devport_cpu_queue_tx_frames_curr, g_devport_cpu_queue_tx_frames_prev
    global g_devport_cpu_queue_tx_bytes_curr, g_devport_cpu_queue_tx_bytes_prev

    for i in range(len(g_devport_queue_pkt_tx_count_curr)):
        for j in range(len(g_devport_queue_pkt_tx_count_curr[0])):
            g_devport_queue_pkt_tx_count_prev[i][j] = g_devport_queue_pkt_tx_count_curr[i][j]

    for i in range(len(g_devport_queue_bytes_tx_count_curr)):
        for j in range(len(g_devport_queue_bytes_tx_count_curr[0])):
            g_devport_queue_bytes_tx_count_prev[i][j] = g_devport_queue_bytes_tx_count_curr[i][j]

    for i in range(len(g_devport_cpu_queue_tx_frames_curr)):
        g_devport_cpu_queue_tx_frames_prev[i] = g_devport_cpu_queue_tx_frames_curr[i]

    for i in range(len(g_devport_cpu_queue_tx_bytes_curr)):
        g_devport_cpu_queue_tx_bytes_prev[i] = g_devport_cpu_queue_tx_bytes_curr[i]

    if only_queue_stats == False:
        for i in range(len(g_sysport_input_pkt_count_curr)):
            g_sysport_input_pkt_count_prev[i] = g_sysport_input_pkt_count_curr[i]
        for i in range(len(g_sysport_input_bytes_count_curr)):
            g_sysport_input_bytes_count_prev[i] = g_sysport_input_bytes_count_curr[i]
        for i in range(len(g_sysport_input_err_count_curr)):
            g_sysport_input_err_count_prev[i] = g_sysport_input_err_count_curr[i]
        for i in range(len(g_sysport_output_pkt_count_curr)):
            g_sysport_output_pkt_count_prev[i] = g_sysport_output_pkt_count_curr[i]
        for i in range(len(g_sysport_output_bytes_count_curr)):
            g_sysport_output_bytes_count_prev[i] = g_sysport_output_bytes_count_curr[i]
        for i in range(len(g_sysport_output_err_count_curr)):
            g_sysport_output_err_count_prev[i] = g_sysport_output_err_count_curr[i]

        for i in range(len(g_devport_input_pkt_count_curr)):
            g_devport_input_pkt_count_prev[i] = g_devport_input_pkt_count_curr[i]
        for i in range(len(g_devport_input_bytes_count_curr)):
            g_devport_input_bytes_count_prev[i] = g_devport_input_bytes_count_curr[i]
        for i in range(len(g_devport_input_err_count_curr)):
            g_devport_input_err_count_prev[i] = g_devport_input_err_count_curr[i]
        for i in range(len(g_devport_output_pkt_count_curr)):
            g_devport_output_pkt_count_prev[i] = g_devport_output_pkt_count_curr[i]
        for i in range(len(g_devport_output_bytes_count_curr)):
            g_devport_output_bytes_count_prev[i] = g_devport_output_bytes_count_curr[i]
        for i in range(len(g_devport_output_err_count_curr)):
            g_devport_output_err_count_prev[i] = g_devport_output_err_count_curr[i]

    # clear out the current counters
    for i in range(len(g_devport_queue_pkt_tx_count_curr)):
        for j in range(len(g_devport_queue_pkt_tx_count_curr[0])):
            g_devport_queue_pkt_tx_count_curr[i][j] = 0

    for i in range(len(g_devport_queue_bytes_tx_count_curr)):
        for j in range(len(g_devport_queue_bytes_tx_count_curr[0])):
            g_devport_queue_bytes_tx_count_curr[i][j] = 0

    for i in range(len(g_devport_cpu_queue_tx_frames_curr)):
        g_devport_cpu_queue_tx_frames_curr[i] = 0

    for i in range(len(g_devport_cpu_queue_tx_bytes_curr)):
        g_devport_cpu_queue_tx_bytes_curr[i] = 0

    if only_queue_stats == False:
        for i in range(len(g_sysport_input_pkt_count_curr)):
            g_sysport_input_pkt_count_curr[i] = 0
        for i in range(len(g_sysport_input_bytes_count_curr)):
            g_sysport_input_bytes_count_curr[i] = 0
        for i in range(len(g_sysport_input_err_count_curr)):
            g_sysport_input_err_count_curr[i] = 0
        for i in range(len(g_sysport_output_pkt_count_curr)):
            g_sysport_output_pkt_count_curr[i] = 0
        for i in range(len(g_sysport_output_bytes_count_curr)):
            g_sysport_output_bytes_count_curr[i] = 0
        for i in range(len(g_sysport_output_err_count_curr)):
            g_sysport_output_err_count_curr[i] = 0

        for i in range(len(g_devport_input_pkt_count_curr)):
            g_devport_input_pkt_count_curr[i] = 0
        for i in range(len(g_devport_input_bytes_count_curr)):
            g_devport_input_bytes_count_curr[i] = 0
        for i in range(len(g_devport_input_err_count_curr)):
            g_devport_input_err_count_curr[i] = 0
        for i in range(len(g_devport_output_pkt_count_curr)):
            g_devport_output_pkt_count_curr[i] = 0
        for i in range(len(g_devport_output_bytes_count_curr)):
            g_devport_output_bytes_count_curr[i] = 0
        for i in range(len(g_devport_output_err_count_curr)):
            g_devport_output_err_count_curr[i] = 0



"""
    Calculates the pkts delta as
    pkt_delta = pkt_current - pkt_prev
"""

def calculate_pkts_delta(only_queue_stats=False):
    global g_sysport_input_pkt_count_delta, g_sysport_input_pkt_count_curr, g_sysport_input_pkt_count_prev
    global g_sysport_input_bytes_count_delta, g_sysport_input_bytes_count_curr, g_sysport_input_bytes_count_prev
    global g_sysport_input_err_count_delta, g_sysport_input_err_count_curr, g_sysport_input_err_count_prev
    global g_sysport_output_pkt_count_delta, g_sysport_output_pkt_count_curr, g_sysport_output_pkt_count_prev
    global g_sysport_output_bytes_count_delta, g_sysport_output_bytes_count_curr, g_sysport_output_bytes_count_prev
    global g_sysport_output_err_count_delta, g_sysport_output_err_count_curr, g_sysport_output_err_count_prev
    global g_devport_input_pkt_count_delta, g_devport_input_pkt_count_curr, g_devport_input_pkt_count_prev
    global g_devport_input_bytes_count_delta, g_devport_input_bytes_count_curr, g_devport_input_bytes_count_prev
    global g_devport_input_err_count_delta, g_devport_input_err_count_curr, g_devport_input_err_count_prev
    global g_devport_output_pkt_count_delta, g_devport_output_pkt_count_curr, g_devport_output_pkt_count_prev
    global g_devport_output_bytes_count_delta, g_devport_output_bytes_count_curr, g_devport_output_bytes_count_prev
    global g_devport_output_err_count_delta, g_devport_output_err_count_curr, g_devport_output_err_count_prev
    global g_devport_queue_pkt_tx_count_curr, g_devport_queue_pkt_tx_count_prev, g_devport_queue_pkt_tx_count_delta
    global g_devport_queue_bytes_tx_count_curr, g_devport_queue_bytes_tx_count_prev, g_devport_queue_bytes_tx_count_delta
    global g_devport_cpu_queue_tx_frames_curr, g_devport_cpu_queue_tx_frames_prev, g_devport_cpu_queue_tx_frames_delta
    global g_devport_cpu_queue_tx_bytes_curr, g_devport_cpu_queue_tx_bytes_prev, g_devport_cpu_queue_tx_bytes_delta

    #ccount for Inter-frame/packet-gap(12B) + preamble(8B)
    IPG_LEN = 12
    PREAMBLE_LEN = 8
    misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

    # calculate queue stats delta as well
    for i in range(len(g_devport_queue_pkt_tx_count_curr)):
        for j in range(len(g_devport_queue_pkt_tx_count_curr[0])):
            if g_devport_queue_pkt_tx_count_curr[i][j] > g_devport_queue_pkt_tx_count_prev[i][j]:
                g_devport_queue_pkt_tx_count_delta[i][j] = g_devport_queue_pkt_tx_count_curr[i][j] - g_devport_queue_pkt_tx_count_prev[i][j]
            else:
                g_devport_queue_pkt_tx_count_delta[i][j] = 0

    for i in range(len(g_devport_queue_bytes_tx_count_curr)):
        for j in range(len(g_devport_queue_bytes_tx_count_curr[0])):
            if g_devport_queue_bytes_tx_count_curr[i][j] > g_devport_queue_bytes_tx_count_prev[i][j]:
                g_devport_queue_bytes_tx_count_delta[i][j] = g_devport_queue_bytes_tx_count_curr[i][j] - g_devport_queue_bytes_tx_count_prev[i][j] + (g_devport_queue_pkt_tx_count_delta[i][j] * misc_delta_bytes)
            else:
                g_devport_queue_bytes_tx_count_delta[i][j] = 0

    g_devport_cpu_queue_tx_frames_delta = compat_listmap(
        (lambda x,
         y: x - y if x > y else 0),
        g_devport_cpu_queue_tx_frames_curr,
        g_devport_cpu_queue_tx_frames_prev)

    g_devport_cpu_queue_tx_bytes_delta = compat_listmap(
        lambda x,
        y, z: x - y + (z * misc_delta_bytes) if x >= y else 0,
        g_devport_cpu_queue_tx_bytes_curr,
        g_devport_cpu_queue_tx_bytes_prev,
        g_devport_cpu_queue_tx_frames_delta)

    if (only_queue_stats == False):
        g_sysport_input_pkt_count_delta = compat_listmap(
            (lambda x,
             y: x - y if x > y else 0),
            g_sysport_input_pkt_count_curr,
            g_sysport_input_pkt_count_prev)
        g_sysport_input_bytes_count_delta = compat_listmap(
            lambda x,
            y, z: x - y + (z * misc_delta_bytes) if x >= y else 0,
            g_sysport_input_bytes_count_curr,
            g_sysport_input_bytes_count_prev,
            g_sysport_input_pkt_count_delta)
        g_sysport_input_err_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_sysport_input_err_count_curr,
            g_sysport_input_err_count_prev)
        g_sysport_output_pkt_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_sysport_output_pkt_count_curr,
            g_sysport_output_pkt_count_prev)
        g_sysport_output_bytes_count_delta = compat_listmap(
            lambda x,
            y, z: x - y + (z * misc_delta_bytes) if x >= y else 0,
            g_sysport_output_bytes_count_curr,
            g_sysport_output_bytes_count_prev,
            g_sysport_output_pkt_count_delta)
        g_sysport_output_err_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_sysport_output_err_count_curr,
            g_sysport_output_err_count_prev)
        g_devport_input_pkt_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_devport_input_pkt_count_curr,
            g_devport_input_pkt_count_prev)
        g_devport_input_bytes_count_delta = compat_listmap(
            lambda x,
            y, z: x - y + (z * misc_delta_bytes) if x >= y else 0,
            g_devport_input_bytes_count_curr,
            g_devport_input_bytes_count_prev,
            g_devport_input_pkt_count_delta)
        g_devport_input_err_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_devport_input_err_count_curr,
            g_devport_input_err_count_prev)
        g_devport_output_pkt_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_devport_output_pkt_count_curr,
            g_devport_output_pkt_count_prev)
        g_devport_output_bytes_count_delta = compat_listmap(
            lambda x,
            y, z: x - y + (z * misc_delta_bytes) if x >= y else 0,
            g_devport_output_bytes_count_curr,
            g_devport_output_bytes_count_prev,
            g_devport_output_pkt_count_delta)
        g_devport_output_err_count_delta = compat_listmap(
            lambda x,
            y: x - y if x >= y else 0,
            g_devport_output_err_count_curr,
            g_devport_output_err_count_prev)


"""
    Calculates packet rate
    Case 1:
       If time_delta < stats_poll_interval:
               rate = current (pkts, bytes, errors) / stats_poll_interval
    Case 2:
       If time_delta == stats_poll_interval:
               rate = current(pkts, bytes, errors) / stats_poll_interval
    Case 3:
       If time_delta > stats_poll_interval:
               rate = delta(pkts, bytes, errors) / ( time_delta/stats_poll_interval)
"""


def calculate_rate(only_queue_stats=False):
    global g_stats_poll_interval, g_time_delta, g_first_time
    global g_sysport_input_pkt_count_delta, g_sysport_input_pkt_count_curr, g_sysport_input_pkt_count_prev
    global g_sysport_input_bytes_count_delta, g_sysport_input_bytes_count_curr, g_sysport_input_bytes_count_prev
    global g_sysport_input_err_count_delta, g_sysport_input_err_count_curr, g_sysport_input_err_count_prev
    global g_sysport_output_pkt_count_delta, g_sysport_output_pkt_count_curr, g_sysport_output_pkt_count_prev
    global g_sysport_output_bytes_count_delta, g_sysport_output_bytes_count_curr, g_sysport_output_bytes_count_prev
    global g_sysport_output_err_count_delta, g_sysport_output_err_count_curr, g_sysport_output_err_count_prev
    global g_devport_input_pkt_count_delta, g_devport_input_pkt_count_curr, g_devport_input_pkt_count_prev
    global g_devport_input_bytes_count_delta, g_devport_input_bytes_count_curr, g_devport_input_bytes_count_prev
    global g_devport_input_err_count_delta, g_devport_input_err_count_curr, g_devport_input_err_count_prev
    global g_sysport_output_pkt_count_delta, g_sysport_output_pkt_count_curr, g_sysport_output_pkt_count_prev
    global g_devport_output_bytes_count_delta, g_devport_output_bytes_count_curr, g_devport_output_bytes_count_prev
    global g_devport_output_err_count_delta, g_devport_output_err_count_curr, g_devport_output_err_count_prev
    global g_devport_queue_pkt_tx_count_curr, g_devport_queue_pkt_tx_count_prev, g_devport_queue_pkt_tx_count_delta
    global g_devport_queue_bytes_tx_count_curr, g_devport_queue_bytes_tx_count_prev, g_devport_queue_bytes_tx_count_delta
    global g_devport_queue_bytes_tx_count_rate
    global g_sysport_in_pkt_rate,g_sysport_in_rate_mbps,g_sysport_in_err_rate
    global g_sysport_out_pkt_rate,g_sysport_out_rate_mbps,g_sysport_out_err_rate
    global g_devport_in_pkt_rate,g_devport_in_rate_mbps,g_devport_in_err_rate
    global g_devport_out_pkt_rate,g_devport_out_rate_mbps,g_devport_out_err_rate
    global g_devport_cpu_queue_tx_frames_rate
    global g_devport_cpu_queue_tx_bytes_rate

    '''
        For devport always use time delta, ignore stats_poll_interval
    '''
    try:
        # calculate the rate for devport queue as well
        for i in range(len(g_devport_queue_pkt_tx_count_curr)):
            for j in range(len(g_devport_queue_pkt_tx_count_curr[0])):
                g_devport_queue_pkt_tx_count_rate[i][j] = float(float(g_devport_queue_pkt_tx_count_delta[i][j]) / float(g_time_delta))

        for i in range(len(g_devport_queue_bytes_tx_count_curr)):
            for j in range(len(g_devport_queue_bytes_tx_count_curr[0])):
                g_devport_queue_bytes_tx_count_rate[i][j] = float(float(g_devport_queue_bytes_tx_count_delta[i][j] * ifcs_ctypes.BITS_PER_BYTE/1000000000) / float(g_time_delta))

        g_devport_cpu_queue_tx_frames_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_devport_cpu_queue_tx_frames_delta)

        g_devport_cpu_queue_tx_bytes_rate = compat_listmap(
            lambda x: float(float(x * ifcs_ctypes.BITS_PER_BYTE/1000000000) / float(g_time_delta)),
            g_devport_cpu_queue_tx_bytes_delta)

        if (only_queue_stats == False):
            g_devport_in_pkt_rate = compat_listmap(
                    lambda x: float(float(x) / float(g_time_delta)),
                    g_devport_input_pkt_count_delta)
            g_devport_in_rate_mbps = compat_listmap(
                lambda x: float(float(x * ifcs_ctypes.BITS_PER_BYTE/1000000000) / float(g_time_delta) ),
                g_devport_input_bytes_count_delta)
            g_devport_in_err_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_devport_input_err_count_delta)
            g_devport_out_pkt_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_devport_output_pkt_count_delta)
            g_devport_out_rate_mbps = compat_listmap(
                lambda x: float(float(x * ifcs_ctypes.BITS_PER_BYTE/1000000000) / float(g_time_delta)),
                g_devport_output_bytes_count_delta)
            g_devport_out_err_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_devport_output_err_count_delta)
    except:
        pass

    '''
        For sysport, ignore stats poll interval
    '''
    try:
        if (only_queue_stats == False):
            g_sysport_in_pkt_rate = compat_listmap(
                    lambda x: float(float(x) / float(g_time_delta)),
                    g_sysport_input_pkt_count_delta)
            g_sysport_in_rate_mbps = compat_listmap(
                lambda x: float(float(x * ifcs_ctypes.BITS_PER_BYTE/1000000000) / float(g_time_delta) ),
                g_sysport_input_bytes_count_delta)
            g_sysport_in_err_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_sysport_input_err_count_delta)
            g_sysport_out_pkt_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_sysport_output_pkt_count_delta)
            g_sysport_out_rate_mbps = compat_listmap(
                lambda x: float(float(x * ifcs_ctypes.BITS_PER_BYTE/1000000000) / float(g_time_delta)),
                g_sysport_output_bytes_count_delta)
            g_sysport_out_err_rate = compat_listmap(
                lambda x: float(float(x) / float(g_time_delta)),
                g_sysport_output_err_count_delta)
    except:
        pass


# Class implements Ifcs related commands
class Rate(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'show' : self.show,
            'help' : self.help,
            '?'    : self.help
        }
        self.rate_display_method = {
            'sysport'   : self.process_sysport_rate,
            'devport'   : self.process_devport_rate,
            'queue'     : self.process_queue_rate,
            'cpu_queue' : self.process_cpu_queue_rate,
        }
        self.supported_operands = ['devport', 'sysport', 'queue', 'cpu_queue']
        self.cli = cli
        self.arg_list = []
        super(Rate, self).__init__()
        self.help_str = "ifcs:        IFCS object cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)

    def __del__(self):
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        log(cmd, remline, line)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper()
                    for i in self.supported_operands if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.supported_operands if i.lower().startswith(text)]

    complete_devport = complete_show
    complete_sysport = complete_show
    complete_queue = complete_show
    complete_cpu_queue = complete_show

    def getCountersType(self, args):
        log_dbg(1, "In getCountersType with args: " + args)

        try:
            counter_type = args.split()[3]
        except BaseException:
            log_err("Need devport, cpu_queue, queue or sysport")
            return

        # This if condition needs to be expanded for other counter types
        if counter_type == 'sysport':
            return 'sysport'
        elif counter_type == 'devport':
            return 'devport'
        elif counter_type == 'queue':
            return 'queue'
        elif counter_type == 'cpu_queue':
            return 'cpu_queue'
        else:
            return 'unsupported'

    def getIfcsType(self, ifcs_obj_name):
        '''Get IFCS Type Object'''
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        ifcsAll = IfcsAll(self.cli)
        return ifcsAll.get_ifcs_obj_from_name(ifcs_obj_name)

    # ------------
    # show command
    # ------------
    def show(self, args, filter_option):
        log_dbg(1, "In port counters show with args: " + args)

        self.filter_option = filter_option
        self.arg_list = args
        global g_first_time

        try:
            counter_type = self.getCountersType(args)
        except IndexError:
            log_err("Counter type not specified")

        while True:
            try:
                rc = self.rate_display_method[counter_type]()
            except BaseException as e:
                log_err("Failed to get counters " + str(e))

            '''
            For the first time rate command called, we don't have previous stats to
            calculate rate. So, sleep for a sec, get stats again and calculate rate.
            '''
            if g_first_time:
                g_first_time = 0
                time.sleep(1)
            else:
                g_first_time = 1
                break

        return rc

    def update_queue_stats(self, queue, all_queues):

        """
            Get the queue level stats for each devport/q_id tuple and calculate
            the rate of each per second and displays it
        """

        # iterate over all queue in the system
        for queueitr in all_queues:
            if queueitr.contents.queue_id > 7:
                continue
            tx_pkt_count = 0
            tx_bytes_count = 0
            stats_list = queue.stats_get(queueitr)

            tx_pkt_count = stats_list[ifcs_ctypes.IFCS_QUEUE_STATS_ID_PACKET_TX_COUNT]

            tx_bytes_count = stats_list[ifcs_ctypes.IFCS_QUEUE_STATS_ID_BYTE_TX_COUNT]

            # set current tx packets/bytes
            g_devport_queue_pkt_tx_count_curr[
                queueitr.contents.devport][queueitr.contents.queue_id] = tx_pkt_count
            g_devport_queue_bytes_tx_count_curr[
                queueitr.contents.devport][queueitr.contents.queue_id] = tx_bytes_count

    def display_cpu_queue_rate(self, all_queues):
        global g_devport_cpu_queue_tx_frames_rate

        table = PrintTable()
        table.add_row([
                      'Queue Id',
                      'Tx Pps',
                      'Tx Gbps'
                      ])

        for queueitr in all_queues:
            tx_pkts_per_sec = g_devport_cpu_queue_tx_frames_rate[queueitr]
            tx_bytes_per_sec = g_devport_cpu_queue_tx_bytes_rate[queueitr]
            if len(self.filter_option.keys()) and ('nz' in self.filter_option['filter'] or ' nz' in self.filter_option['filter']):
                if tx_pkts_per_sec:
                    table.add_row(["%d" % queueitr, "%.2f" % tx_pkts_per_sec, "%.2f" % tx_bytes_per_sec])
            else:
                table.add_row(["%d" % queueitr, "%.2f" % tx_pkts_per_sec, "%.2f" % tx_bytes_per_sec])

        table.print_table(brief=True)
        table.reset_table()


    def display_queue_rate(self, all_queues):
        global g_devport_queue_pkt_tx_count_rate
        global g_devport_queue_bytes_tx_count_rate
        table = PrintTable()

        all_queues = sorted(all_queues, key=lambda x: x.contents.devport)
        table.add_row([
                      'Devport Id',
                      'Queue Id',
                      'Tx Pps',
                      'Tx Gbps'
                      ])
        prev_devport = -1
        for queueitr in all_queues:
            devport = queueitr.contents.devport
            if devport == prev_devport:
                continue
            tx_q0_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][0]
            tx_q1_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][1]
            tx_q2_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][2]
            tx_q3_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][3]
            tx_q4_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][4]
            tx_q5_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][5]
            tx_q6_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][6]
            tx_q7_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][7]

            tx_q0_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][0]
            tx_q1_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][1]
            tx_q2_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][2]
            tx_q3_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][3]
            tx_q4_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][4]
            tx_q5_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][5]
            tx_q6_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][6]
            tx_q7_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][7]

            if len(self.filter_option.keys()) and ('nz' in self.filter_option['filter'] or ' nz' in self.filter_option['filter']):
                if tx_q0_pkts_per_sec:
                    table.add_row(["%d" % devport, "0", "%.2f" % tx_q0_pkts_per_sec, "%.2f" % tx_q0_bytes_per_sec])
                if tx_q1_pkts_per_sec:
                    table.add_row(["%d" % devport, "1", "%.2f" % tx_q1_pkts_per_sec, "%.2f" % tx_q1_bytes_per_sec])
                if tx_q2_pkts_per_sec:
                    table.add_row(["%d" % devport, "2", "%.2f" % tx_q2_pkts_per_sec, "%.2f" % tx_q2_bytes_per_sec])
                if tx_q3_pkts_per_sec:
                    table.add_row(["%d" % devport, "3", "%.2f" % tx_q3_pkts_per_sec, "%.2f" % tx_q3_bytes_per_sec])
                if tx_q4_pkts_per_sec:
                    table.add_row(["%d" % devport, "4", "%.2f" % tx_q4_pkts_per_sec, "%.2f" % tx_q4_bytes_per_sec])
                if tx_q5_pkts_per_sec:
                    table.add_row(["%d" % devport, "5", "%.2f" % tx_q5_pkts_per_sec, "%.2f" % tx_q5_bytes_per_sec])
                if tx_q6_pkts_per_sec:
                    table.add_row(["%d" % devport, "6", "%.2f" % tx_q6_pkts_per_sec, "%.2f" % tx_q6_bytes_per_sec])
                if tx_q7_pkts_per_sec:
                    table.add_row(["%d" % devport, "7", "%.2f" % tx_q7_pkts_per_sec, "%.2f" % tx_q7_bytes_per_sec])

            else:
                table.add_row(["%d" % devport, "0", "%.2f" % tx_q0_pkts_per_sec, "%.2f" % tx_q0_bytes_per_sec])
                table.add_row(["%d" % devport, "1", "%.2f" % tx_q1_pkts_per_sec, "%.2f" % tx_q1_bytes_per_sec])
                table.add_row(["%d" % devport, "2", "%.2f" % tx_q2_pkts_per_sec, "%.2f" % tx_q2_bytes_per_sec])
                table.add_row(["%d" % devport, "3", "%.2f" % tx_q3_pkts_per_sec, "%.2f" % tx_q3_bytes_per_sec])
                table.add_row(["%d" % devport, "4", "%.2f" % tx_q4_pkts_per_sec, "%.2f" % tx_q4_bytes_per_sec])
                table.add_row(["%d" % devport, "5", "%.2f" % tx_q5_pkts_per_sec, "%.2f" % tx_q5_bytes_per_sec])
                table.add_row(["%d" % devport, "6", "%.2f" % tx_q6_pkts_per_sec, "%.2f" % tx_q6_bytes_per_sec])
                table.add_row(["%d" % devport, "7", "%.2f" % tx_q7_pkts_per_sec, "%.2f" % tx_q7_bytes_per_sec])
            prev_devport = devport

        table.print_table(brief=True)
        table.reset_table()


    def display_single_devport_rate(self, devport):
        global g_devport_in_pkt_rate, g_devport_in_rate_mbps, g_devport_in_err_rate
        global g_devport_out_pkt_rate, g_devport_out_rate_mbps, g_devport_out_err_rate
        global g_devport_queue_pkt_tx_count_rate
        global g_devport_queue_bytes_tx_count_rate
        table = PrintTable()

        input_pkts_per_sec = g_devport_in_pkt_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
            devport)]
        input_bytes_per_sec = g_devport_in_rate_mbps[ifcs_ctypes.IFCS_HANDLE_VALUE(
            devport)]
        input_err_per_sec = g_devport_in_err_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
            devport)]
        output_pkts_per_sec = g_devport_out_pkt_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
            devport)]
        output_bytes_per_sec = g_devport_out_rate_mbps[ifcs_ctypes.IFCS_HANDLE_VALUE(
            devport)]
        output_err_per_sec = g_devport_out_err_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
            devport)]

        # get all the queues rates for the devport
        tx_q0_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][0]
        tx_q1_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][1]
        tx_q2_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][2]
        tx_q3_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][3]
        tx_q4_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][4]
        tx_q5_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][5]
        tx_q6_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][6]
        tx_q7_pkts_per_sec = g_devport_queue_pkt_tx_count_rate[devport][7]

        tx_q0_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][0]
        tx_q1_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][1]
        tx_q2_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][2]
        tx_q3_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][3]
        tx_q4_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][4]
        tx_q5_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][5]
        tx_q6_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][6]
        tx_q7_bytes_per_sec = g_devport_queue_bytes_tx_count_rate[devport][7]

        log("Devport Stats")
        if len(self.filter_option.keys()) and ('nz' in self.filter_option['filter'] or ' nz' in self.filter_option['filter']):
            table.add_row(['Devport', str(int(devport))])
            if input_pkts_per_sec:
                table.add_row(['Input Pps', "%.2f" % input_pkts_per_sec])
            if input_bytes_per_sec > 0.001:
                table.add_row(['Input Gbps', "%.2f" % input_bytes_per_sec])
            if input_err_per_sec:
                table.add_row(['Input Err/sec', "%.2f" % input_err_per_sec])
            if output_pkts_per_sec:
                table.add_row(['Output Pps', "%.2f" % output_pkts_per_sec])
            if output_bytes_per_sec > 0.001:
                table.add_row(['Output Gbps', "%.2f" % output_bytes_per_sec])
            if output_err_per_sec:
                table.add_row(['Output Err/sec', "%.2f" % output_err_per_sec])
        else:
            table.add_row(['Devport', str(int(devport))])
            table.add_row(['Input Pps', "%.2f" % input_pkts_per_sec])
            table.add_row(['Input Gbps', "%.2f" % input_bytes_per_sec])
            table.add_row(['Input Err/sec', "%.2f" % input_err_per_sec])
            table.add_row(['Output Pps', "%.2f" % output_pkts_per_sec])
            table.add_row(['Output Gbps', "%.2f" % output_bytes_per_sec])
            table.add_row(['Output Err/sec', "%.2f" % output_err_per_sec])

        table.print_table(brief=False)
        table.reset_table()

        log(" ")
        log("Queue Stats")
        table = PrintTable()
        table.add_row([
                      'Queue Id',
                      'Tx Pps',
                      'Tx Gbps'
                      ])

        if len(self.filter_option.keys()) and ('nz' in self.filter_option['filter'] or ' nz' in self.filter_option['filter']):
            if tx_q0_pkts_per_sec:
                table.add_row(["0", "%.2f" % tx_q0_pkts_per_sec, "%.2f" % tx_q0_bytes_per_sec])
            if tx_q1_pkts_per_sec:
                table.add_row(["1", "%.2f" % tx_q1_pkts_per_sec, "%.2f" % tx_q1_bytes_per_sec])
            if tx_q2_pkts_per_sec:
                table.add_row(["2", "%.2f" % tx_q2_pkts_per_sec, "%.2f" % tx_q2_bytes_per_sec])
            if tx_q3_pkts_per_sec:
                table.add_row(["3", "%.2f" % tx_q3_pkts_per_sec, "%.2f" % tx_q3_bytes_per_sec])
            if tx_q4_pkts_per_sec:
                table.add_row(["4", "%.2f" % tx_q4_pkts_per_sec, "%.2f" % tx_q4_bytes_per_sec])
            if tx_q5_pkts_per_sec:
                table.add_row(["5", "%.2f" % tx_q5_pkts_per_sec, "%.2f" % tx_q5_bytes_per_sec])
            if tx_q6_pkts_per_sec:
                table.add_row(["6", "%.2f" % tx_q6_pkts_per_sec, "%.2f" % tx_q6_bytes_per_sec])
            if tx_q7_pkts_per_sec:
                table.add_row(["7", "%.2f" % tx_q7_pkts_per_sec, "%.2f" % tx_q7_bytes_per_sec])
        else:
            table.add_row(["0", "%.2f" % tx_q0_pkts_per_sec, "%.2f" % tx_q0_bytes_per_sec])
            table.add_row(["1", "%.2f" % tx_q1_pkts_per_sec, "%.2f" % tx_q1_bytes_per_sec])
            table.add_row(["2", "%.2f" % tx_q2_pkts_per_sec, "%.2f" % tx_q2_bytes_per_sec])
            table.add_row(["3", "%.2f" % tx_q3_pkts_per_sec, "%.2f" % tx_q3_bytes_per_sec])
            table.add_row(["4", "%.2f" % tx_q4_pkts_per_sec, "%.2f" % tx_q4_bytes_per_sec])
            table.add_row(["5", "%.2f" % tx_q5_pkts_per_sec, "%.2f" % tx_q5_bytes_per_sec])
            table.add_row(["6", "%.2f" % tx_q6_pkts_per_sec, "%.2f" % tx_q6_bytes_per_sec])
            table.add_row(["7", "%.2f" % tx_q7_pkts_per_sec, "%.2f" % tx_q7_bytes_per_sec])

        table.print_table(brief=True)
        table.reset_table()


    def display_devport_rate(self, all_devports):
        global g_devport_in_pkt_rate, g_devport_in_rate_mbps, g_devport_in_err_rate
        global g_devport_out_pkt_rate, g_devport_out_rate_mbps, g_devport_out_err_rate
        table = PrintTable()

        table.add_row([
                      'Devport',
                      'Input Pps',
                      'Input Gbps',
                      'Input Err/sec',
                      'Output Pps',
                      'Output Gbps',
                      'Output Err/sec'
                      ])

        all_devports = sorted(all_devports)
        for devport in all_devports:
            input_pkts_per_sec = g_devport_in_pkt_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                devport)]
            input_bytes_per_sec = g_devport_in_rate_mbps[ifcs_ctypes.IFCS_HANDLE_VALUE(
                devport)]
            input_err_per_sec = g_devport_in_err_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                devport)]
            output_pkts_per_sec = g_devport_out_pkt_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                devport)]
            output_bytes_per_sec = g_devport_out_rate_mbps[ifcs_ctypes.IFCS_HANDLE_VALUE(
                devport)]
            output_err_per_sec = g_devport_out_err_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                devport)]

            if len(self.filter_option.keys()) and ('nz' in self.filter_option['filter'] or ' nz' in self.filter_option['filter']):
                if (input_pkts_per_sec) or (input_bytes_per_sec > 0.001) or (input_err_per_sec) or (output_pkts_per_sec) or (output_bytes_per_sec > 0.001) or (output_err_per_sec):
                    table.add_row([
                                  str(int(devport)),
                                  "%.2f" % input_pkts_per_sec,
                                  "%.2f"  % input_bytes_per_sec,
                                  "%.2f" % input_err_per_sec,
                                  "%.2f" % output_pkts_per_sec,
                                  "%.2f"  % output_bytes_per_sec,
                                  "%.2f" % output_err_per_sec,
                                  ])
            else:
                table.add_row([
                              str(int(devport)),
                              "%.2f" % input_pkts_per_sec,
                              "%.2f" % input_bytes_per_sec,
                              "%.2f" % input_err_per_sec,
                              "%.2f" % output_pkts_per_sec,
                              "%.2f" % output_bytes_per_sec,
                              "%.2f" % output_err_per_sec,
                              ])
        table.print_table(brief=True)
        table.reset_table()


    def display_sysport_rate(self, all_sysports):
        global g_sysport_in_pkt_rate, g_sysport_in_rate_mbps, g_sysport_in_err_rate
        global g_sysport_out_pkt_rate, g_sysport_out_rate_mbps, g_sysport_out_err_rate
        table = PrintTable()

        table.add_row([
                      'Sysport',
                      'Input Pps',
                      'Input Gbps',
                      'Input Err/sec',
                      'Output Pps',
                      'Output Gbps',
                      'Output Err/sec'
                      ])

        for sysport in all_sysports:
            input_pkts_per_sec = g_sysport_in_pkt_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                sysport)]
            input_bytes_per_sec = g_sysport_in_rate_mbps[ifcs_ctypes.IFCS_HANDLE_VALUE(
                sysport)]
            input_err_per_sec = g_sysport_in_err_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                sysport)]
            output_pkts_per_sec = g_sysport_out_pkt_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                sysport)]
            output_bytes_per_sec = g_sysport_out_rate_mbps[ifcs_ctypes.IFCS_HANDLE_VALUE(
                sysport)]
            output_err_per_sec = g_sysport_out_err_rate[ifcs_ctypes.IFCS_HANDLE_VALUE(
                sysport)]

            if len(self.filter_option.keys()) and ('nz' in self.filter_option['filter'] or ' nz' in self.filter_option['filter']):
                if (input_pkts_per_sec) or (input_bytes_per_sec > 0.001) or (input_err_per_sec) or (output_pkts_per_sec) or (output_bytes_per_sec > 0.001) or (output_err_per_sec):
                    table.add_row([
                                  str(hex(int(sysport))),
                                  "%.2f" % input_pkts_per_sec,
                                  "%.2f" % input_bytes_per_sec,
                                  "%.2f" % input_err_per_sec,
                                  "%.2f" % output_pkts_per_sec,
                                  "%.2f" % output_bytes_per_sec,
                                  "%.2f" % output_err_per_sec,
                                  ])
            else:
                table.add_row([
                              str(hex(int(sysport))),
                              "%.2f" % input_pkts_per_sec,
                              "%.2f" % input_bytes_per_sec,
                              "%.2f" % input_err_per_sec,
                              "%.2f" % output_pkts_per_sec,
                              "%.2f" % output_bytes_per_sec,
                              "%.2f" % output_err_per_sec,
                              ])
        table.print_table(brief=True)
        table.reset_table()


    """
        rate helper function
        This is a decorator and will be called by every
        Rate.display_*_rate function
    """
    def rate_helper(function):
        """
            Captures the current time, stats
            polling interval, and time delta

        """

        def wrapped(self):
            global g_time_curr, g_time_delta, g_time_prev, g_stats_poll_interval, g_first_time
            # First get the stats_poll_interval
            actual_count = c_uint32()
            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_STATS_POLL_INTERVAL
            ifcs_ctypes.ifcs_node_attr_get(
                self.cli.node_id,
                1,
                pointer(attr),
                pointer(actual_count))

            # get the specific devport from arg_list
            devport = self.arg_list.split()[-1]

            g_stats_poll_interval = float(attr.value.u64 / 1000)
            g_stats_poll_interval = 1
            if g_stats_poll_interval == 0:
                log_err("Stats polling not enabled.")

            # perform stats sync
            if devport ==  'sysport':
                mod_list = (ifcs_ctypes.ifcs_mod_t * 1)(ifcs_ctypes.IFCS_MOD_SYSPORT)
            else: #includes devport, queue, cpu_queue
                mod_list = (ifcs_ctypes.ifcs_mod_t * 1)(ifcs_ctypes.IFCS_MOD_QUEUE)

            ret = ifcs_ctypes.ifcs_node_stats_sync_module(0, 1, compat_pointer(mod_list, ifcs_ctypes.ifcs_mod_t))

            # Get the current time
            g_time_curr = round(time.time(), 6)

            # Calculate the time delta
            g_time_delta = 0 if g_time_prev is None else float(g_time_curr - g_time_prev)

            g_time_prev = g_time_curr
            only_queue_stats = False
            only_cpu_queue_stats = False
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "Stats sync failed"
            try:
                if devport == 'queue':
                    function(self, False)
                    only_queue_stats = True
                elif devport == 'cpu_queue':
                    function(self, False)
                    only_cpu_queue_stats = True
                elif devport ==  'sysport':
                    function(self, False)
                elif devport !=  'devport':
                    function(self, False, devport)
                else:
                    function(self, False)
            except Exception as e:
                if type(e).__name__ == 'TypeError' and  'arguments' in e.message:
                    log("Command : " + self.arg_list + " is currently unsupported")
                else:
                    log_err(e.message)
                return None

            if g_first_time == 0:
                #No point displaying rate first time as there is no prev data
                calculate_pkts_delta(only_queue_stats)
                calculate_rate(only_queue_stats)
                if devport == 'queue':
                    function(self, True)
                elif devport == 'cpu_queue':
                    function(self, True)
                elif devport ==  'sysport':
                    function(self, True)
                elif devport !=  'devport':
                    function(self, True, devport)
                else:
                    function(self, True)
            update_previous_counts(only_queue_stats)

        return wrapped

    @rate_helper
    def process_sysport_rate(self, display=False):
        """
            Gets the current packets, bytes, and errors
            for both input and output packets, calculates
            the rate of each per second and displays it
        """
        log_dbg(1, "In display sysport rate show ")

        sysport = self.getIfcsType('sysport')
        if sysport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_sysports = sysport.bulk_get_all_sysport_keys()
        except BaseException:
            log_err("Error retrieving sysports")
            return

        if display:
            self.display_sysport_rate(all_sysports)
            return

        # iterate over all devports in the system
        all_sysports = sorted(all_sysports)
        for port in all_sysports:
            input_pkt_count = input_bytes_count = input_err_count = 0
            output_pkt_count = output_bytes_count = output_err_count = 0
            stats_list = sysport.stats_get(port)

            input_pkt_count = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_RX]
            input_pkt_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_RX]
            input_pkt_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_PKTS_RX]
            input_bytes_count = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_RX]
            input_bytes_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_RX]
            input_bytes_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_BYTES_RX]

            output_pkt_count = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_TX]
            output_pkt_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_TX]
            output_pkt_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_PKTS_TX]
            output_bytes_count = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_TX]
            output_bytes_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_TX]
            output_bytes_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_BYTES_TX]

            input_err_count = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_AFT_CHECK_FAIL]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_HDR_ERR]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_LKUP_MISS]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_SRC_MISS_MOVE]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_HDR_ERR]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_LKUP_MISS]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_NOT_ENABLED]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_TTL_CHECK_FAIL]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_DLP_DROP]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_FWD_OBJ_ERR]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_HW_ERR]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_L2_INTF_CHECK_FAIL]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_PROG_ERR]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_SPANNING_TREE_DROP]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_VNI_MEMBERSHIP_DROP]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_L3MTU_CHECK_FAIL]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_L2L3_HDR_ERR]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_TTL_CHECK_FAIL]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_VNID_LKUP_FAIL]
            input_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_USER_DROP]

            output_err_count = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_BRTTL_CHECK_FAIL]
            output_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_HW_ERR_1]
            output_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_INTF_CHECK_FAIL]
            output_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_L2MTU_CHECK_FAIL]
            output_err_count += stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_VNI_STI_CHECK_FAIL]

            # get current input packets
            g_sysport_input_pkt_count_curr[ifcs_ctypes.IFCS_HANDLE_VALUE(
                port)] = input_pkt_count

            # get current input bytes
            g_sysport_input_bytes_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = input_bytes_count

            # get current input errors
            g_sysport_input_err_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = input_err_count

            # get current output packets
            g_sysport_output_pkt_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = output_pkt_count

            # get current output bytes
            g_sysport_output_bytes_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = output_bytes_count

            # get current output errors
            g_sysport_output_err_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = output_err_count


    @rate_helper
    def process_devport_rate(self, display=False, arg_devport=-1):
        log_dbg(1, "In display devport rate show ")
        """
            Gets the current packets, bytes, and errors
            for both input and output packets, calculates
            the rate of each per second and displays it
        """
        log_dbg(1, "In display devport rate show ")

        devport = self.getIfcsType('devport')
        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_devports = devport.bulk_get_all_devport_keys()
        except BaseException:
            log_err("Error retrieving devports")
            return

        if display:
            if arg_devport == -1:
                self.display_devport_rate(all_devports)
            else:
                self.display_single_devport_rate(int(arg_devport))
            return

        # iterate over all devports in the system
        all_devports = sorted(all_devports)
        for port in all_devports:
            input_pkt_count = input_bytes_count = input_err_count = 0
            output_pkt_count = output_bytes_count = output_err_count = 0
            stats_list = devport.stats_get(port)

            if devport.getType(port) == ifcs_ctypes.IFCS_DEVPORT_TYPE_CPU:
                input_pkt_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ALL]

                input_bytes_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]

                output_pkt_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ALL]

                output_bytes_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
            else:
                input_pkt_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]

                input_bytes_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]

                output_pkt_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]

                output_bytes_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]


            input_err_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]

            output_err_count = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

            # get current input packets
            g_devport_input_pkt_count_curr[ifcs_ctypes.IFCS_HANDLE_VALUE(
                port)] = input_pkt_count

            # get current input bytes
            g_devport_input_bytes_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = input_bytes_count

            # get current input errors
            g_devport_input_err_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = input_err_count

            # get current output packets
            g_devport_output_pkt_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = output_pkt_count

            # get current output bytes
            g_devport_output_bytes_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = output_bytes_count

            # get current output errors
            g_devport_output_err_count_curr[
                ifcs_ctypes.IFCS_HANDLE_VALUE(port)] = output_err_count

        queue = self.getIfcsType('queue')
        if queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_queues = queue.bulk_get_all_queue_keys()
        except BaseException:
            log_err("Error retrieving queues")
            return

        self.update_queue_stats(queue, all_queues)


    @rate_helper
    def process_queue_rate(self, display=False):
        queue = self.getIfcsType('queue')
        if queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_queues = queue.bulk_get_all_queue_keys()
        except BaseException:
            log_err("Error retrieving queues")
            return

        if display:
            self.display_queue_rate(all_queues)
            return

        self.update_queue_stats(queue, all_queues)


    @rate_helper
    def process_cpu_queue_rate(self, display=False):
        cpu_queue = self.getIfcsType('cpu_queue')
        if cpu_queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_queues = cpu_queue.bulk_get_all_cpu_queue_keys()
        except BaseException:
            log_err("Error retrieving cpu_queues")
            return

        if display:
            self.display_cpu_queue_rate(all_queues)
            return

        for queueitr in all_queues:
            tx_pkt_count = 0
            tx_bytes_count = 0
            stats_list = cpu_queue.stats_get(queueitr)

            tx_pkt_count = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_PACKET_TX_COUNT]

            tx_bytes_count = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_BYTE_TX_COUNT]

            # set current tx packets/bytes
            g_devport_cpu_queue_tx_frames_curr[queueitr] = tx_pkt_count
            g_devport_cpu_queue_tx_bytes_curr[queueitr] = tx_bytes_count


    def help(self, args):
        table = PrintTable()

        table.add_row(['IFCS Rate Help', 'Description'])
        table.add_row([
                'ifcs show rate sysport',
                'Displays Input pkts/s, Input Bytes/s, Input errors/s, Output bytes, Output pkts for sysports'])
        table.add_row([
                'ifcs show rate devport',
                'Displays Input pkts/s, Input Bytes/s, Input errors/s, Output bytes, Output pkts for devports'])
        table.add_row([
                'ifcs show rate devport <devport id>',
                'Displays basic devport stats and queue stats for devport'])
        table.add_row([
                'ifcs show rate queue',
                'Displays all the queue stats for all devports'])
        table.add_row([
                'ifcs show rate cpu_queue',
                'Displays all the cpu queue stats'])
        log("")
        table.set_justification('left')
        table.print_table()
        table.reset_table()
