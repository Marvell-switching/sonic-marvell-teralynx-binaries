#-------------------------------------------------------------------------------
# Copyright (c) (2023) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you, your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell"s standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
import argparse
import ctypes
import importlib
import struct
import sys
import time
import traceback

from cmdmgr import Command, CommandError
from testutil import pci
from testutil.torrent import Torrent, TorrentImpl, EyeSurf
from print_table import PrintTable
from verbosity import *

try:
    ifcs_ctypes = sys.modules["ifcs_ctypes"]
except KeyError:
    import ifcs_ctypes

class I2CDevice:
    def __init__(self, bus, addr):
        self.bus = bus
        self.addr = addr
        self.smbus = None
        try:
            self.smbus2 = importlib.import_module("smbus2")
        except ImportError:
            raise ImportError("smbus2 module not found. Please install it using 'pip install smbus2'")
        self.smbus = self.smbus2.SMBus(self.bus)

    def __del__(self):
        if self.smbus:
            self.smbus.close()

    def read_u8(self, reg):
        return self.smbus.read_byte_data(self.addr, reg)

    def write_u8(self, reg, val):
        self.smbus.write_byte_data(self.addr, reg, val)

    def msg_write(self, addr, data):
        return self.smbus2.i2c_msg.write(addr, data)

    def msg_read(self, addr, length):
        return self.smbus2.i2c_msg.read(addr, length)

    def rdwr(self, *args):
        self.smbus.i2c_rdwr(*args)

class I2CSystem:
    I2C_SYS_MAIN = 0x32
    I2C_SYS_MUX70 = 0x70
    I2C_SYS_MUX71 = 0x71
    I2C_VERSION_REQ = 0x07

    def __init__(self, bus):
        self.i2c_main = I2CDevice(bus, self.I2C_SYS_MAIN)
        self.i2c_mux70 = I2CDevice(bus, self.I2C_SYS_MUX70)
        self.i2c_mux71 = I2CDevice(bus, self.I2C_SYS_MUX71)

    def version(self):
        return self.i2c_main.read_u8(0x00)

    def i2c_debug_enable(self):
        # Check the FPGA version
        version = self.version()
        if version < self.I2C_VERSION_REQ:
            log_err("The TL10 DB System FPGA version {} is required. Current version {}".format(
                self.I2C_VERSION_REQ, version))
            raise CommandError("FPGA version is not supported", ifcs_ctypes.IFCS_INVAL)
        # Enable I2C_MISC_MODE
        self.i2c_main.write_u8(0x0e, 0x01)
        # Select MUX71 channel
        self.i2c_mux70.write_u8(0x00, 0x02)
        # Select TL10 7bit I2C channel
        self.i2c_mux71.write_u8(0x00, 0x01)

    def i2c_debug_disable(self):
        self.i2c_mux71.write_u8(0x00, 0x00)
        self.i2c_mux70.write_u8(0x00, 0x00)
        # Disable I2C_MISC_MODE
        self.i2c_main.write_u8(0x0e, 0x00)

    def i2c_cpu_enable(self, i2c_ten):
        # Disable Temperature monitoring because it uses 10bit address I2C
        self.i2c_main.write_u8(0x81, 0x01)
        # Switch CPU_I2C to 7 or 10 bit mode
        pci.write_fields("I2CS_IC_ENABLE", enable_f=0)
        pci.write_fields("I2CS_IC_CON", ic_10bitaddr_slave_f=1 if i2c_ten else 0)
        pci.write_fields("I2CS_IC_ENABLE", enable_f=1)
        # Select MUX71 channel
        self.i2c_mux70.write_u8(0x00, 0x02)
        # Select TL10 10bit I2C channel
        self.i2c_mux71.write_u8(0x00, 0x02)

    def i2c_cpu_disable(self):
        self.i2c_mux71.write_u8(0x00, 0x00)
        self.i2c_mux70.write_u8(0x00, 0x00)
        # Switch CPU_I2C to 10bit mode used by the temperature monitoring
        pci.write_fields("I2CS_IC_ENABLE", enable_f=0)
        pci.write_fields("I2CS_IC_CON", ic_10bitaddr_slave_f=1)
        pci.write_fields("I2CS_IC_ENABLE", enable_f=1)
        # Enable Temperature monitoring
        self.i2c_main.write_u8(0x81, 0x00)

class I2CDebug:
    I2C_ADDR = 0x55

    def __init__(self, bus, i2c_system=None):
        self.i2c = I2CDevice(bus, self.I2C_ADDR)
        self.i2c_system = i2c_system

    def enable(self):
        if self.i2c_system:
            self.i2c_system.i2c_debug_enable()
        return True

    def disable(self):
        if self.i2c_system:
            self.i2c_system.i2c_debug_disable()

    def read_u32(self, reg):
        assert (reg & 0xffff_0000) == 0x0001_0000
        addr = (reg & 0x0000_ffff)
        # 0x00 = addr register, 2 bytes addr, 0x01 = read command, 0x01 = valid
        wr1 = self.i2c.msg_write(self.i2c.addr, [0x00, (addr >> 0) & 0xff, (addr >> 8) & 0xff, 0x01, 0x01])
        # 0x02 = data register, 4 bytes data
        wr2 = self.i2c.msg_write(self.i2c.addr, [0x02])
        rd = self.i2c.msg_read(self.i2c.addr, 4)
        self.i2c.rdwr(wr1, wr2, rd)
        data = ctypes.string_at(rd.buf, 4)
        u32 = struct.unpack("<I", data)[0]
        #log("RD {:08x}: 0x{:08x}".format(addr, u32))
        return u32

    def write_u32(self, reg, reg_val):
        if isinstance(reg_val, int):
            u32 = reg_val
        else:
            if not hasattr(reg_val, "data"):
                raise ValueError("{} has no data attribute".format(reg_val.__name__))
            u32 = reg_val.data
        assert (reg & 0xffff_0000) == 0x0001_0000
        addr = (reg & 0x0000_ffff)
        #log("WR {:08x}: 0x{:08x}".format(addr, u32))
        # 0x01 = addr register, 4 bytes data
        wr1 = self.i2c.msg_write(self.i2c.addr, [0x01, (u32 >> 0) & 0xff, (u32 >> 8) & 0xff, (u32 >> 16) & 0xff, (u32 >> 24) & 0xff])
        # 0x00 = addr register, 2 bytes addr, 0x02 = write command, 0x01 = valid
        wr2 = self.i2c.msg_write(self.i2c.addr, [0x00, (addr >> 0) & 0xff, (addr >> 8) & 0xff, 0x02, 0x01])
        self.i2c.rdwr(wr1, wr2)
        time.sleep(1/1000)

class I2CCPU:
    I2C_M_TEN = 0x0010
    I2C_READ_CMD = 0x01
    I2C_WRITE_CMD = 0x02
    CPU_BASE_ADDR = 0x1000_0000

    def __init__(self, bus, addr, i2c_ten=False, i2c_system = None):
        self.i2c = I2CDevice(bus, addr)
        self.i2c_ten = i2c_ten
        self.i2c_system = i2c_system
        if not self.i2c_system:
            pci.write_fields("I2CS_IC_ENABLE", enable_f=0)
            pci.write_fields("I2CS_IC_CON", ic_10bitaddr_slave_f=1 if i2c_ten else 0)
            pci.write_fields("I2CS_IC_ENABLE", enable_f=1)

    def enable(self):
        if self.i2c_system:
            self.i2c_system.i2c_cpu_enable(self.i2c_ten)
        # Read the PCIe device ID to check if the I2C chip is ready
        val = self.read_u32(ifcs_ctypes.PCI_CFG_I_PCIE_BASE_I_VENDOR_ID_DEVICE_ID)
        retry = 1000
        while (val != 0x010017cd) and (retry > 0):
            time.sleep(1/1000000)
            val = self.read_u32(ifcs_ctypes.PCI_CFG_I_PCIE_BASE_I_VENDOR_ID_DEVICE_ID)
            retry -= 1
        return val == 0x010017cd

    def disable(self):
        if self.i2c_system:
            self.i2c_system.i2c_cpu_disable()

    def read_u32(self, reg):
        assert (reg & 0xf000_0000) == 0x0000_0000
        addr = self.CPU_BASE_ADDR + (reg & 0x0fff_ffff)
        wr = self.i2c.msg_write(self.i2c.addr,
                (self.I2C_READ_CMD,
                 (addr >> 0) & 0xff, (addr >> 8) & 0xff,
                 (addr >> 16) & 0xff, (addr >> 24) & 0xff))
        if self.i2c_ten:
            wr.flags |= self.I2C_M_TEN
        rd = self.i2c.smbus2.i2c_msg.read(self.i2c.addr, 1)
        if self.i2c_ten:
            rd.flags |= self.I2C_M_TEN
        self.i2c.rdwr(wr, rd)
        data = ctypes.string_at(rd.buf, rd.len)
        while data[0] & 0x07 == 0x06:
            time.sleep(1/1000000)
            self.i2c.rdwr(rd)
            data = ctypes.string_at(rd.buf, rd.len)
        if data[0] & 0x07 != 0x00:
            log_dbg(1, "I2C read failed: response code=0x{:02x}".format(data[0]))
            return None
        rd = self.i2c.smbus2.i2c_msg.read(self.i2c.addr, 4)
        self.i2c.rdwr(rd)
        data = ctypes.string_at(rd.buf, rd.len)
        u32 = struct.unpack("<I", data)[0]
        #log("RD {:08x}: 0x{:08x}".format(addr, u32))
        return u32

    def write_u32(self, reg, reg_val):
        if isinstance(reg_val, int):
            u32 = reg_val
        else:
            if not hasattr(reg_val, "data"):
                raise ValueError("{} has no data attribute".format(reg_val.__name__))
            u32 = reg_val.data
        assert (reg & 0xf000_0000) == 0x0000_0000
        addr = self.CPU_BASE_ADDR + (reg & 0x0fff_ffff)
        #log("WR {:08x}: 0x{:08x}".format(addr, u32))
        wr = self.i2c.msg_write(self.i2c.addr,
                (self.I2C_WRITE_CMD,
                 (addr >> 0) & 0xff, (addr >> 8) & 0xff, (addr >> 16) & 0xff, (addr >> 24) & 0xff,
                 (u32 >> 0) & 0xff, (u32 >> 8) & 0xff, (u32 >> 16) & 0xff, (u32 >> 24) & 0xff))
        if self.i2c_ten:
            wr.flags |= self.I2C_M_TEN
        rd = self.i2c.smbus2.i2c_msg.read(self.i2c.addr, 1)
        if self.i2c_ten:
            rd.flags |= self.I2C_M_TEN
        self.i2c.rdwr(wr, rd)
        data = ctypes.string_at(rd.buf, rd.len)
        while data[0] & 0x07 == 0x06:
            time.sleep(1/1000000)
            self.i2c.rdwr(rd)
            data = ctypes.string_at(rd.buf, rd.len)
        if data[0] & 0x07 != 0x00:
            log_dbg(1, "I2C write failed: response code=0x{:02x}".format(data[0]))
            return None
        return True

class PCIEImpl(TorrentImpl):
    PCIE_PHY_BASE_ADDR = 0x1020_0000

    def __init__(self, node_id, i2c_chip):
        self.node_id = node_id
        self.i2c_chip = i2c_chip
        super(PCIEImpl, self).__init__()

    def read(self, reg_addr):
        addr = self.PCIE_PHY_BASE_ADDR + ((reg_addr & 0xffff) << 4)
        pci.write32(ifcs_ctypes.MID_ADR, addr)
        value = pci.read32(ifcs_ctypes.MID_DAT32)
        return value

    def write(self, reg_addr, data):
        addr = self.PCIE_PHY_BASE_ADDR + ((reg_addr & 0xffff) << 4)
        pci.write32(ifcs_ctypes.MID_ADR, addr)
        pci.write32(ifcs_ctypes.MID_DAT32, data)

    def phy_reset(self, lane):
        if not self.i2c_chip.enable():
            self.i2c_chip.disable()
            return False
        self._phy_reset()
        self.i2c_chip.disable()
        return True

    def pma_power_down(self, lane):
        pass

    def pma_power_up(self, lane):
        pass

    def _phy_reset(self):
        pattern = 0x12345678
        self.i2c_chip.write_u32(ifcs_ctypes.SCRATCH_PAD0, pattern)
        val = self.i2c_chip.read_u32(ifcs_ctypes.SCRATCH_PAD0)
        if val != pattern:
            log_err("I2C chip write/read test failed: 0x{:08x} != 0x{:08x}".format(val, pattern))
            return False
        self.i2c_chip.write_u32(ifcs_ctypes.SCRATCH_PAD0, 0x00000000)
        ifcs_ctypes.im_nmgr_mod_lock_all(self.node_id)
        try:
            # Set link training = 0
            chip_ib_csi_pcie_ovrd = ifcs_ctypes.chip_ib_csi_pcie_ovrd_t()
            self.assign(chip_ib_csi_pcie_ovrd, self.i2c_chip.read_u32(ifcs_ctypes.CHIP_IB_CSI_PCIE_OVRD))
            self.set_field(chip_ib_csi_pcie_ovrd, "chip_ovrd_pcie_boot_done_sel_f", 1)
            self.set_field(chip_ib_csi_pcie_ovrd, "chip_ovrd_pcie_boot_done_f", 0)
            self.i2c_chip.write_u32(ifcs_ctypes.CHIP_IB_CSI_PCIE_OVRD, chip_ib_csi_pcie_ovrd)

            chip_ib_cpurst_ovrd = ifcs_ctypes.chip_ib_cpurst_ovrd_t()
            self.assign(chip_ib_cpurst_ovrd, self.i2c_chip.read_u32(ifcs_ctypes.CHIP_IB_CPURST_OVRD))
            self.set_field(chip_ib_cpurst_ovrd, "chip_ovrd_pcie_phy_areset_sel_f", 1)
            self.set_field(chip_ib_cpurst_ovrd, "chip_ovrd_pcie_phy_areset_n_f",  0)
            self.i2c_chip.write_u32(ifcs_ctypes.CHIP_IB_CPURST_OVRD, chip_ib_cpurst_ovrd)
            self.set_field(chip_ib_cpurst_ovrd, "chip_ovrd_pcie_phy_areset_n_f", 1)
            self.i2c_chip.write_u32(ifcs_ctypes.CHIP_IB_CPURST_OVRD, chip_ib_cpurst_ovrd)

            # Wait for some time before asserting LT = 1
            time.sleep(1/1000)

            # Set link training = 1
            self.set_field(chip_ib_csi_pcie_ovrd, "chip_ovrd_pcie_boot_done_f", 1)
            self.i2c_chip.write_u32(ifcs_ctypes.CHIP_IB_CSI_PCIE_OVRD, chip_ib_csi_pcie_ovrd)

            # Wait until PCIe link is up
            chip_ib_pcie_status = ifcs_ctypes.chip_ib_pcie_status_t()
            self.assign(chip_ib_pcie_status, self.i2c_chip.read_u32(ifcs_ctypes.CHIP_IB_PCIE_STATUS))
            while self.get_field(chip_ib_pcie_status, "pcie_link_status_f") != 3:
                time.sleep(1/1000)
                self.assign(chip_ib_pcie_status, self.i2c_chip.read_u32(ifcs_ctypes.CHIP_IB_PCIE_STATUS))

            # Remove all reset override
            self.i2c_chip.write_u32(ifcs_ctypes.CHIP_IB_CPURST_OVRD, 0x00000000)
            self.i2c_chip.write_u32(ifcs_ctypes.CHIP_IB_CSI_PCIE_OVRD, 0x00000000)
        finally:
            ifcs_ctypes.im_nmgr_mod_unlock_all(self.node_id)
        return True

    @staticmethod
    def assign(reg, data):
        if not hasattr(reg, "data"):
            raise ValueError("{} has no data attribute".format(reg.__name__))
        reg.data = data

    @staticmethod
    def set_field(reg, field_name, value):
        if not hasattr(reg, "tl10_flds"):
            raise ValueError("{} has no data attribute".format(reg.__name__))
        if not hasattr(reg.tl10_flds, field_name):
            raise ValueError("{}.tl10_flds has no field named {}".format(reg.__name__, field_name))
        setattr(reg.tl10_flds, field_name, value)

    @staticmethod
    def get_field(reg, field_name):
        if not hasattr(reg, "tl10_flds"):
            raise ValueError("{} has no data attribute".format(reg.__name__))
        if not hasattr(reg.tl10_flds, field_name):
            raise ValueError("{}.tl10_flds has no field named {}".format(reg.__name__, field_name))
        return getattr(reg.tl10_flds, field_name)

class PCIECommand(Command):
    I2C_BUS = 1
    I2C_ADDR = 0x55
    NUM_LANES = 4

    @staticmethod
    def _hex_int(x):
        if x[:2] == "0x":
            return int(x, 16)
        return int(x, 10)

    def __init__(self, node_id):
        self.node_id = node_id
        self.i2c_cpu = I2CCPU(self.I2C_BUS, self.I2C_ADDR, i2c_ten=False, i2c_system=I2CSystem(self.I2C_BUS))
        self.torrent = Torrent(PCIEImpl(node_id, self.i2c_cpu))

        self.parser = parser = argparse.ArgumentParser(prog="diagtest serdes pcie")
        sub_parsers = parser.add_subparsers()

        parser = sub_parsers.add_parser("help")
        parser.add_argument("cmd", nargs="?", default="")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliHelp(self, **kwargs))

        parser = sub_parsers.add_parser("i2c", help="I2C configuration")
        i2c_subparser = parser.add_subparsers()
        parser = i2c_subparser.add_parser("set", help="Set I2C configuration")
        parser.add_argument("--bus", type=int, required=True, help="I2C bus number")
        parser.add_argument("--addr", type=PCIECommand._hex_int, default=self.I2C_ADDR, help="I2C address")
        parser.add_argument("--mode", type=int, choices=(7, 10), required=True, help="I2C mode 7/10 bits")
        parser.add_argument("--system", action="store_true", help="Use system I2C")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliI2CSet(self, **kwargs))

        parser = i2c_subparser.add_parser("get", help="Set I2C configuration")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliI2CGet(self, **kwargs))

        parser = sub_parsers.add_parser("read", help="Read SerDes register")
        parser.add_argument("reg", type=str, help="Register name or address")
        parser.add_argument("--lane", type=int, default=0, help="Lane number")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliRegRead(self, **kwargs))

        parser = sub_parsers.add_parser("write", help="Write SerDes register")
        parser.add_argument("reg", type=str, help="Register name or address")
        parser.add_argument("value", type=PCIECommand._hex_int, help="Value to write")
        parser.add_argument("--lane", type=int, default=0, help="Lane number")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliRegWrite(self, **kwargs))

        parser = sub_parsers.add_parser("bathtub", help="The bathtub eye surf function")
        parser.add_argument("--cycles", type=PCIECommand._hex_int, default=0x2000, help="Number of test cycles")
        parser.add_argument("--delay", type=PCIECommand._hex_int, default=0x000f, help="Eye surf timer delay")
        parser.add_argument("--filename", "-f", type=str, help="Save the data to a file")
        parser.add_argument("--xrange", "-x", type=int, default=31, help="Specify the x range")
        parser.add_argument("--depth", "-d", type=int, default=31, help="Specify the bathtub depth")
        parser.add_argument("--peak", "-p", type=int, help="Specify the peak value")
        parser.add_argument("--lane", help="Lane number <n>[,<n>]/all ")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliEyeSurfBathTub(self, **kwargs))

        parser = sub_parsers.add_parser("eyesurf", help="The full eye surf function")
        parser.add_argument("--cycles", type=PCIECommand._hex_int, default=0x2000, help="Number of test cycles")
        parser.add_argument("--delay", type=PCIECommand._hex_int, default=0x000f, help="Eye surf timer delay")
        parser.add_argument("--filename", "-f", type=str, help="Save the data to a file")
        parser.add_argument("--xyrange", "-r", type=int, default=31, help="Specify the xy range")
        parser.add_argument("--peak", "-p", type=int, help="Specify the peak value")
        parser.add_argument("--lane", help="Lane number <n>[,<n>]/all ")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliEyeSurfFull(self, **kwargs))

        parser = sub_parsers.add_parser("eyeplot", help="Plot eye diagram from the specified data file")
        parser.add_argument("filename", type=str, help="eye data file")
        parser.add_argument("--peak", "-p", type=int, help="Specify the peak value")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliEyePlot(self, **kwargs))

        parser = sub_parsers.add_parser("enable_eyesurf", help="Enable eyesurf")
        parser.add_argument("--reset", action="store_true", help="Reset PCIE phy")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliEnableEyeSurf(self, **kwargs))

        parser = sub_parsers.add_parser("test")
        parser.add_argument("--count", type=int, default=10, help="Number of test cycles")
        parser.add_argument("--delay", type=int, default=500, help="Delay between tests in ms")
        parser.set_defaults(func=lambda kwargs: PCIECommand._cliTest(self, **kwargs))

        self.sub_cmds = self.parser._subparsers._actions[-1].choices

        super(PCIECommand, self).__init__()

    def _cliTest(self, count, delay):
        iteration = 1
        while iteration <= count:
            log("Iteration {}".format(iteration))
            self.torrent.phy_reset(lane=0)
            time.sleep(delay / 1000)
            iteration += 1
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliHelp(self, cmd=""):
        if cmd == "":
            self.parser.print_help()
            return ifcs_ctypes.IFCS_SUCCESS
        parser = self.parser._subparsers._actions[-1].choices.get(cmd)
        if parser is None:
            log_err("Unknown command: {}".format(cmd))
            return ifcs_ctypes.IFCS_INVAL
        parser.print_help()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliI2CSet(self, bus, addr, mode, system):
        i2c_system = I2CSystem(bus) if system else None
        self.i2c_cpu = I2CCPU(bus, addr, i2c_ten=(mode == 10), i2c_system=i2c_system)
        self.torrent = Torrent(PCIEImpl(self.node_id, self.i2c_cpu))
        self._cliI2CGet()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliI2CGet(self):
        mode = 10 if self.i2c_cpu.i2c_ten else 7
        system_fpga = "no" if self.i2c_cpu.i2c_system is None else "yes"
        log("CPU I2C: bus={}, addr={:#x}, mode={} bits, system_fpga={}".format(self.i2c_cpu.i2c.bus, self.i2c_cpu.i2c.addr, mode, system_fpga))
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliRegRead(self, reg, lane):
        try:
            reg = self._hex_int(reg)
        except ValueError:
            pass
        reg_name, reg_addr, reg_val = self.torrent.read(reg, lane)
        table = PrintTable()
        table.set_justification("left")
        table.add_row(["Register", "Address", "Value"])
        table.add_row([reg_name, "{:04x}".format(reg_addr), "{:04x}".format(reg_val)])
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliRegWrite(self, reg, value, lane):
        try:
            reg = self._hex_int(reg)
        except ValueError:
            pass
        reg_name, reg_addr, reg_val = self.torrent.write(reg, value, lane)
        table = PrintTable()
        table.set_justification("left")
        table.add_row(["Register", "Address", "Value"])
        table.add_row([reg_name, "{:04x}".format(reg_addr), "{:04x}".format(reg_val)])
        table.print_table()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEyeSurfBathTub(self, cycles, delay, filename, xrange, depth, peak):
        lanes = self._get_lanes(lane)
        for lane in lanes:
            eyesurf_enabled = self.torrent.is_eyesurf_enabled(lane)
            if not eyesurf_enabled:
                log("Eyesurf is not enabled on lane {}".format(lane))
                log("Please run 'diagtest serdes pcie enable_eyesurf' command to enable it")
                return ifcs_ctypes.IFCS_INVAL

        for lane in lanes:
            eye_data = self.torrent.bathtub(cycles, delay, xrange, depth, lane=lane)
            if filename is not None:
                self._eyesurf_save("{}-{}.tub".format(filename, lane), eye_data)

            eye_surf = EyeSurf(eye_data, peak, is_full=False)
            eye_surf.plot("PCIE lane {}:".format(lane))

        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEyeSurfFull(self, cycles, delay, filename, xyrange, peak, lane):
        lanes = self._get_lanes(lane)
        for lane in lanes:
            eyesurf_enabled = self.torrent.is_eyesurf_enabled(lane)
            if not eyesurf_enabled:
                log("Eyesurf is not enabled on lane {}".format(lane))
                log("Please run 'diagtest serdes pcie enable_eyesurf' command to enable it")
                return ifcs_ctypes.IFCS_INVAL

        for lane in lanes:
            eye_data = self.torrent.eyesurf(cycles, delay, xyrange, lane=lane)
            if filename is not None:
                self._eyesurf_save("{}-{}.eye".format(filename, lane), eye_data)

            eye_surf = EyeSurf(eye_data, peak, is_full=True)
            eye_surf.plot("PCIE lane {}:".format(lane))

        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEyePlot(self, filename, peak):
        with open(filename, "r") as file:
            eye_data = []
            for line in file:
                eye_row = [int(v) for v in line.split(',')]
                eye_data.append(eye_row)
            eye_surf = EyeSurf(eye_data, peak, is_full=filename.endswith(".eye"))
            eye_surf.plot()
        return ifcs_ctypes.IFCS_SUCCESS

    def _cliEnableEyeSurf(self, reset):
        phy_reset = False
        for lane in compat_listrange(PCIECommand.NUM_LANES):
            eyesurf_enabled = self.torrent.is_eyesurf_enabled(lane)
            if not eyesurf_enabled:
                log("Enabling eyesurf on lane {}".format(lane))
                self.torrent.eyesurf_enable(lane, reset=False)
                phy_reset = True
        if reset and phy_reset:
            log_no_newline("Resetting PCIE phy ...")
            self.torrent.phy_reset(lane=0)
            log("done")

    @staticmethod
    def _eyesurf_save(filename, eye_data):
        log('Writing to file {}'.format(filename))
        try:
            with open(filename, 'w') as output:
                for row in eye_data:
                    output.write(",".join(str(value) for value in row))
                    output.write("\n")
        except IOError as err:
            log_err('Failed to write file {}: {}'.format(filename, err))

    @staticmethod
    def _get_lanes(lane):
        if lane is None:
            return compat_listrange(PCIECommand.NUM_LANES)
        if isinstance(lane, int):
            if lane < 0 or lane >= PCIECommand.NUM_LANES:
                raise ValueError("Lane number {} is out of range. Valid range is 0..{}".format(lane, PCIECommand.NUM_LANES - 1))
            return [lane]
        elif isinstance(lane, str):
            if lane == "all":
                return compat_listrange(PCIECommand.NUM_LANES)
            lanes = [int(l) for l in lane.split(",")]
            for l in lanes:
                if l < 0 or l >= PCIECommand.NUM_LANES:
                    raise ValueError("Lane number {} is out of range. Valid range is 0..{}".format(l, PCIECommand.NUM_LANES - 1))
            return lanes
        raise ValueError("Lane must be an integer(*), all or None")

pcie_cmds = {}

def run_cmd(node_id, args_list):
    try:
        pcie_cmd = pcie_cmds.get(node_id)
        if pcie_cmd is None:
            pcie_cmd = PCIECommand(node_id)
            pcie_cmds[node_id] = pcie_cmd
        args = pcie_cmd.parser.parse_args(args_list)
        if not hasattr(args, "func"):
            args_list.append("--help")
            args = pcie_cmd.parser.parse_args(args_list)
            return ifcs_ctypes.IFCS_INVAL
        cmd_func = args.func
        kwargs = vars(args)
        kwargs.pop("func")
        log_dbg(1, "args: {}".format(kwargs))
        return cmd_func(kwargs)
    except CommandError as cmd_err:
        log_err("{}".format(cmd_err))
        return cmd_err.rc
    except Exception as ex:
        log_err(str(ex))
        log(traceback.format_exc())
    return ifcs_ctypes.IFCS_INVAL
