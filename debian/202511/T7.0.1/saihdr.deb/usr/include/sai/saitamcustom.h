/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saitamcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITAMCUSTOM_H_
#define __SAITAMCUSTOM_H_

#include <saitam.h>
#include <saitypes.h>

/**
 * @brief Custom attribute ID range markers for TAM telemetry type objects
 *
 * These enums omit *_CUSTOM_RANGE_* in saitam.h; define them here so
 * ATTR_END + (CUSTOM_RANGE_END - CUSTOM_RANGE_START) matches other SAI objects.
 * Undefine if a future saitam.h adds them as enum members.
 */
#ifndef SAI_TAM_TEL_TYPE_FLOW_TABLE_ATTR_CUSTOM_RANGE_START
#define SAI_TAM_TEL_TYPE_FLOW_TABLE_ATTR_CUSTOM_RANGE_START 0x10000000
#endif
#ifndef SAI_TAM_TEL_TYPE_FLOW_TABLE_ATTR_CUSTOM_RANGE_END
#define SAI_TAM_TEL_TYPE_FLOW_TABLE_ATTR_CUSTOM_RANGE_END \
    (SAI_TAM_TEL_TYPE_FLOW_TABLE_ATTR_CUSTOM_RANGE_START + 1)
#endif

#ifndef SAI_TAM_TEL_TYPE_PROFILE_ATTR_CUSTOM_RANGE_START
#define SAI_TAM_TEL_TYPE_PROFILE_ATTR_CUSTOM_RANGE_START 0x10000000
#endif
#ifndef SAI_TAM_TEL_TYPE_PROFILE_ATTR_CUSTOM_RANGE_END
#define SAI_TAM_TEL_TYPE_PROFILE_ATTR_CUSTOM_RANGE_END \
    (SAI_TAM_TEL_TYPE_PROFILE_ATTR_CUSTOM_RANGE_START + 1)
#endif

typedef enum _sai_tam_report_attr_custom_t
{
    /**
     * @brief Probabilistic rate 'n' for probabilistic mode.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 10000
     * @validonly SAI_TAM_REPORT_ATTR_REPORT_MODE == SAI_TAM_REPORT_MODE_CUSTOM_PROBABILISTIC
     */
    SAI_TAM_REPORT_ATTR_CUSTOM_PROBABILISTIC_RATE = SAI_TAM_REPORT_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Average packet rate (packets/sec) for microburst mode
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 8192
     * @validonly SAI_TAM_REPORT_ATTR_REPORT_MODE == SAI_TAM_REPORT_MODE_CUSTOM_MICROBURST
     */
    SAI_TAM_REPORT_ATTR_CUSTOM_MICROBURST_AVG_RATE,

    /**
     * @brief Maximum number of reports per event for microburst mode
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 256
     * @validonly SAI_TAM_REPORT_ATTR_REPORT_MODE == SAI_TAM_REPORT_MODE_CUSTOM_MICROBURST
     */
    SAI_TAM_REPORT_ATTR_CUSTOM_MICROBURST_MAX_REPORTS,

}sai_tam_report_attr_custom_t;

/**
 * @brief TAM Telemetry custom Tam event type occupancy
 */
typedef enum _sai_tam_event_threshold_type_custom_t
{

    /* Occupancy */
    SAI_TAM_EVENT_THRESHOLD_ATTR_CUSTOM_OCCUPANCY = SAI_TAM_EVENT_THRESHOLD_ATTR_CUSTOM_RANGE_START,

} sai_tam_event_threshold_attr_custom_t;

typedef enum _sai_tam_collector_attr_custom_t
{
    /**
     * @brief Collection Vlan ID
     *
     * Note: Applicable only when SAI_TAM_TRANSPORT_ATTR_TRANSPORT_TYPE != SAI_TAM_TRANSPORT_TYPE_NONE
     *
     * @type sai_uint16_t
     * @flags CREATE_AND_SET
     * @isvlan true
     * @default 1
     */
    SAI_TAM_COLLECTOR_ATTR_CUSTOM_VLAN_ID = SAI_TAM_COLLECTOR_ATTR_CUSTOM_RANGE_START,

} sai_tam_collector_attr_custom_t;

typedef enum _sai_tam_tel_type_attr_custom_t
{

    /**
     * @brief Enable Elephant Flow classification
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     * @validonly SAI_TAM_TEL_TYPE_ATTR_TAM_TELEMETRY_TYPE == SAI_TAM_TELEMETRY_TYPE_FLOW
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_FLOW_CLASSIFICATION_ENABLE = SAI_TAM_TEL_TYPE_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Flow Detection time in Microseconds
     * Time required for the flow to classify as Elephant flow
     *
     * @type uint64_t
     * @flags CREATE_AND_SET
     * @default 1000000
     * @validonly SAI_TAM_TEL_TYPE_ATTR_TAM_TELEMETRY_TYPE == SAI_TAM_TELEMETRY_TYPE_FLOW
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_FLOW_DETECTION_TIME,

    /**
     * @brief Flow Rate in bps
     * Excess Rate required for the flow to classify as Elephant flow
     *
     * @type uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_TAM_TEL_TYPE_ATTR_TAM_TELEMETRY_TYPE == SAI_TAM_TELEMETRY_TYPE_FLOW
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_FLOW_RATE,

    /**
     * @brief Flow Action to be performed for the flow
     * classified as Elephant flow
     *
     * @type sai_tam_tel_type_custom_flow_action_t
     * @flags CREATE_AND_SET     
     * @default SAI_TAM_TEL_TYPE_FLOW_ACTION_REPORT
     * @validonly SAI_TAM_TEL_TYPE_ATTR_TAM_TELEMETRY_TYPE == SAI_TAM_TELEMETRY_TYPE_FLOW
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_FLOW_ACTION,

    /**
     * @brief Flow Aging time in Microseconds
     * Dynamic flow aging time for the flows classified as Elephant flow
     *
     * @type uint64_t
     * @flags CREATE_AND_SET
     * @default 0
     * @validonly SAI_TAM_TEL_TYPE_ATTR_TAM_TELEMETRY_TYPE == SAI_TAM_TELEMETRY_TYPE_FLOW
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_FLOW_AGING_TIME,

    /**
     * @brief Enable IPv4 traffic for Telemetry processing
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_ENABLE_IPV4,

    /**
     * @brief Enable IPv6 traffic for Telemetry processing
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_ENABLE_IPV6,

    /**
     * @brief Enable Non IP traffic for Telemetry processing
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_ENABLE_NON_IP,

    /**
     * @brief IPv4 Filtering Mode
     * Select type of Ipv4 Traffic for Telemetry processing
     *
     * @type sai_tam_tel_type_custom_filtering_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_TAM_TEL_TYPE_FILTERING_MODE_NONE
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_IPV4_FILTERING_MODE,

    /**
     * @brief IPv6 Filtering mode
     * Select type of Ipv6 Traffic for Telemetry processing
     *
     * @type sai_tam_tel_type_custom_filtering_mode_t
     * @flags CREATE_AND_SET
     * @default SAI_TAM_TEL_TYPE_FILTERING_MODE_NONE
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_IPV6_FILTERING_MODE,

    /**
     * @brief TAM Tel Type Flow table object
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM_TEL_TYPE_FLOW_TABLE
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_TAM_TEL_TYPE_ATTR_CUSTOM_FLOW_TABLE,

} sai_tam_tel_type_attr_custom_t;


/**
 * @brief custom SAI TAM TEL TYPE filtering modes.
 */
typedef enum _sai_tam_tel_type_custom_filtering_mode_t
{   
    /* @brief filtering mode None */
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_NONE,

    /* @brief Filtering mode all IP packets */
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_ALL,

    /* @brief Filtering mode all IP UDP packets*/
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_ALL_UDP,

    /* @brief Filtering mode all IP TCP packets*/
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_ALL_TCP,

    /* @brief Filtering mode all IP UDP and TCP packets*/
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_ALL_UDP_TCP,

    /* @brief Filtering mode all IP UDP packets with dest port*/
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_UDP_PORT,

    /* @brief Filtering mode all IP TCP packets with dest port*/
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_TCP_PORT,

    /* @brief Filtering mode all IP UDP and TCP packets with dest port*/
    SAI_TAM_TEL_TYPE_CUSTOM_FILTERING_MODE_IP_UDP_TCP_PORT,

} sai_tam_tel_type_custom_filtering_mode_t;

/**
 * @brief custom SAI TAM TEL TYPE flow action.
 */
typedef enum _sai_tam_tel_type_custom_flow_action_t
{   
    /* @brief Telemetry type flow action is report */
    SAI_TAM_TEL_TYPE_CUSTOM_FLOW_ACTION_REPORT,

    /* @brief Telemetry type flow action Discard */
    SAI_TAM_TEL_TYPE_CUSTOM_FLOW_ACTION_QOS_ACTION,

} sai_tam_tel_type_custom_flow_action_t;

/**
 * @brief custom SAI TAM TEL TYPE profile notification types.
 */
typedef enum _sai_tam_tel_type_custom_profile_notif_t
{
    /* @brief Notification type None */
    SAI_TAM_TEL_TYPE_CUSTOM_PROFILE_NOTIF_TYPE_NONE,

    /* @brief Send First packet as Notification */
    SAI_TAM_TEL_TYPE_CUSTOM_PROFILE_NOTIF_TYPE_FIRST_PACKET,

    /* @brief Send All packets as Notification*/
    SAI_TAM_TEL_TYPE_CUSTOM_PROFILE_NOTIF_TYPE_ALL_PACKETS,

} sai_tam_tel_type_custom_profile_notif_t; 

#endif /* __SAITAMCUSTOM_H_ */
