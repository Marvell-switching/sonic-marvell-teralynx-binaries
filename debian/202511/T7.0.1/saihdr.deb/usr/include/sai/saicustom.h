/**
 *copyright (c) 2025 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saicustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */


#ifndef __SAICUSTOM_H_
#define __SAICUSTOM_H_

#include <sai.h>
#include <saitypes.h>

/** header file to maintain backward compatibility with previous SAI release */
#include "backward_compatibility.h"

/** existing enum custom */
#include "saitypescustom.h"
#include "saiswitchcustom.h"
#include "saiaclcustom.h"
#include "saitamcustom.h"
#include "saiportcustom.h"
#include "saiqueuecustom.h"
#include "saihostifcustom.h"
#include "saibuffercustom.h"
#include "saipolicercustom.h"
#include "sairouterinterfacecustom.h"
#include "saiarsprofilecustom.h"
#include "saiarscustom.h"
#include "sainexthopgroupcustom.h"
#include "sailagcustom.h"
#include "saisrv6custom.h"
#include "saiipmccustom.h"
#include "sail2mccustom.h"

#endif /* __SAICUSTOM_H_ */
