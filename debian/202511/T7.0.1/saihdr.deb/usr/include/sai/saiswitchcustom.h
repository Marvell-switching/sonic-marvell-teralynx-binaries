/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiswitchcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISWITCHCUSTOM_H_
#define __SAISWITCHCUSTOM_H_

#include <saiswitch.h>
#include <saitypes.h>

#ifndef SAI_HASH_ALGORITHM_END
/**
 * @brief Boundary for vendor extensions to #sai_hash_algorithm_t.
 *        Custom algorithms are defined as SAI_HASH_ALGORITHM_END + n below.
 */
#define SAI_HASH_ALGORITHM_END ((int)SAI_HASH_ALGORITHM_ROUND_ROBIN)
#endif

/**
 * @brief Vendor extensions to #sai_hash_algorithm_t
 */
typedef enum _sai_hash_algorithm_custom_t
{
    SAI_HASH_ALGORITHM_CUSTOM_CRC_32E = SAI_HASH_ALGORITHM_END + 1,
    SAI_HASH_ALGORITHM_CUSTOM_CRC_32C = SAI_HASH_ALGORITHM_END + 2,
    SAI_HASH_ALGORITHM_CUSTOM_CRC_32K = SAI_HASH_ALGORITHM_END + 3,
} sai_hash_algorithm_custom_t;

/**
 * @brief SAI switch custom attribute
 */
typedef enum _sai_switch_attr_custom_t
{
    SAI_SWITCH_ATTR_LOSSLESS_FLOOD_CONTROL_ENABLE  = SAI_SWITCH_ATTR_CUSTOM_RANGE_START + 1,

    /**
     * @brief Traffic Class list
     * Drop packets only for specified traffic classes
     * @type sai_u8_list_t
     * @flags CREATE_AND_SET
     * @validonly SAI_TAM_EVENT_ATTR_TYPE == SAI_TAM_EVENT_TYPE_QUEUE_TAIL_DROP
     */
    SAI_SWITCH_ATTR_CUSTOM_TAM_TRAFFIC_CLASSES,

    /**
     * @brief Enable flood control on the given list of TCs
     * Collects list of traffic classes where flood control is required
     * for Broadcast, Unknown Unicast and Multicast traffic
     *
     * @type sai_u8_list_t
     * @flags CREATE_AND_SET
     * @default empty
     * @validonly SAI_HOSTIF_TRAP_ATTR_TRAP_TYPE == SAI_HOSTIF_TRAP_TYPE_CUSTOM_TC_FLOOD_CONTROL_DISCARD
     */
    SAI_SWITCH_ATTR_CUSTOM_TC_FLOOD_CONTROL,

    /**
     * @brief ACL user-based ACL meta data range
     *
     * @type sai_u32_range_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_CUSTOM_ACL_USER_META_DATA_RANGE_2,

    /**
     * @brief Set the PTP Clock Type of the device
     *
     * @type = sai_switch_custom_ptp_clock_type_t
     * @flags CREATE_AND_SET
     * @default SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_NONE
     */
    SAI_SWITCH_ATTR_CUSTOM_PTP_CLOCK_TYPE,

    /**
     * @brief Time correction offset from epoch applied by NOS on system
     *        clock to sync with master clock
     *
     * @type = sai_timespec_t
     * @flags CREATE_AND_SET
     * @default = (0)
     */
    SAI_SWITCH_ATTR_CUSTOM_PTP_TIME_OFFSET,

    /**
     * @brief Used by NOS to program the delta value that needs to be
     *        added to existing clock frequency.
     *        Unit is PPT (Parts Per Trillion)
     *
     * @type = sai_int32_t (Can be negative also)
     * @flags = CREATE_AND_SET
     * @default = (0)
     */
    SAI_SWITCH_ATTR_CUSTOM_PTP_SYNTONIZE_ADJUST,

   /**  
    * @brief Ingress Router Interface user-based meta data range
    *
    * @type sai_u32_range_t
    * @flags READ_ONLY
    */
    SAI_SWITCH_ATTR_CUSTOM_ROUTER_INTERFACE_META_DATA_INGRESS_RANGE,

    /**
     * @brief Egress Router Interface user-based meta data range
     *
     * @type sai_u32_range_t
     * @flags READ_ONLY
     */
    SAI_SWITCH_ATTR_CUSTOM_ROUTER_INTERFACE_META_DATA_EGRESS_RANGE,

    /**
     * @brief TAM Tel Type Profile
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @object SAI_OBJECT_TYPE_TAM_TEL_TYPE_PROFILE
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_SWITCH_ATTR_CUSTOM_TAM_TEL_TYPE_PROFILE,

}sai_switch_attr_custom_t;

/**
 * @brief SAI switch stat custom
 */
typedef enum _sai_switch_stat_custom_t
{



   /** Get the number of packets with egress port change due to flowlet expiry*/
    SAI_SWITCH_STAT_CUSTOM_ARS_FLOWLET_EXPIRED = SAI_SWITCH_STAT_CUSTOM_RANGE_BASE,

    /** Get the number of packets with egress port change due to NHG member update*/
    SAI_SWITCH_STAT_CUSTOM_ARS_NHG_MEM_UPDATE,

    /** Get the number of packets with egress port change due to port failover*/
    SAI_SWITCH_STAT_CUSTOM_ARS_PORT_FAILOVER,

    /** Get the number of packets drop due to all egress ports are down*/
    SAI_SWITCH_STAT_CUSTOM_ARS_PACKET_DROPS,

    /** Get the number of egress port selection considering scored ports*/
    SAI_SWITCH_STAT_CUSTOM_ARS_SCORED_PORT_SELECTED,

    /** Get the number of egress port selection considering unscored ports*/
    SAI_SWITCH_STAT_CUSTOM_ARS_UNSCORED_PORT_SELECTED,

   /** Get the number of packets with egress port change due to flowlet expiry*/
    SAI_SWITCH_STAT_CUSTOM_LAG_ARS_FLOWLET_EXPIRED,

    /** Get the number of packets with egress port change due to NHG member update*/
    SAI_SWITCH_STAT_CUSTOM_LAG_ARS_MEM_UPDATE,

    /** Get the number of packets with egress port change due to port failover*/
    SAI_SWITCH_STAT_CUSTOM_LAG_ARS_PORT_FAILOVER,

    /** Get the number of packets drop due to all egress ports are down*/
    SAI_SWITCH_STAT_CUSTOM_LAG_ARS_PACKET_DROPS,

    /** Get the number of egress port selection considering scored ports*/
    SAI_SWITCH_STAT_CUSTOM_LAG_ARS_SCORED_PORT_SELECTED,

    /** Get the number of egress port selection considering unscored ports*/
    SAI_SWITCH_STAT_CUSTOM_LAG_ARS_UNSCORED_PORT_SELECTED,

    /** Get the number of packets flagged as elephant flow */
    SAI_SWITCH_STAT_CUSTOM_ELEPHANT_FLOWS_FLAGGED_PKTS,

    /** Get the number of flows flagged as elephant flow */
    SAI_SWITCH_STAT_CUSTOM_ELEPHANT_FLOWS_COUNT,

    /** Switch Custom stats END */
    SAI_SWITCH_STAT_CUSTOM_RANGE_END,

} sai_switch_stat_custom_t;

#endif /* __SAISWITCHCUSTOM_H_ */
