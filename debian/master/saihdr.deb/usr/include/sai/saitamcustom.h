/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saitamcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITAMCUSTOM_H_
#define __SAITAMCUSTOM_H_

#include <saitam.h>
#include <saitypes.h>


typedef enum _sai_tam_report_attr_custom_t
{
    /**
     * @brief Probabilistic rate 'n' for probabilistic mode.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 10000
     * @validonly SAI_TAM_REPORT_ATTR_REPORT_MODE == SAI_TAM_REPORT_MODE_CUSTOM_PROBABILISTIC
     */
    SAI_TAM_REPORT_ATTR_CUSTOM_PROBABILISTIC_RATE = SAI_TAM_REPORT_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Average packet rate (packets/sec) for microburst mode
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 8192
     * @validonly SAI_TAM_REPORT_ATTR_REPORT_MODE == SAI_TAM_REPORT_MODE_CUSTOM_MICROBURST
     */
    SAI_TAM_REPORT_ATTR_CUSTOM_MICROBURST_AVG_RATE,

    /**
     * @brief Maximum number of reports per event for microburst mode
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 256
     * @validonly SAI_TAM_REPORT_ATTR_REPORT_MODE == SAI_TAM_REPORT_MODE_CUSTOM_MICROBURST
     */
    SAI_TAM_REPORT_ATTR_CUSTOM_MICROBURST_MAX_REPORTS,

}sai_tam_report_attr_custom_t;

#endif /* __SAITAMCUSTOM_H_ */
