/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saihostifcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIHOSTIFCUSTOM_H_
#define __SAIHOSTIFCUSTOM_H_

#include <saihostif.h>
#include <saitypes.h>


/**
 * @brief SAI hostif packet custom attribute
 */
typedef enum _sai_hostif_packet_attr_custom_t
{
    /**
     * @brief Nexthop OID (for receive-only when packets are routed to CPU)
     *
     * @type sai_object_id_t
     * @flags READ_ONLY
     * @objects SAI_OBJECT_TYPE_NEXTHOP
     */
    SAI_HOSTIF_PACKET_ATTR_CUSTOM_NEXTHOP_OID = SAI_HOSTIF_PACKET_ATTR_CUSTOM_RANGE_START

}sai_hostif_packet_attr_custom_t;

#endif /* __SAIHOSTIFCUSTOM_H_ */
