/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiaclcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIACLCUSTOM_H_
#define __SAIACLHCUSTOM_H_

#include <saiacl.h>
#include <saitypes.h>


/**
 * @brief SAI acl table custom attribute
 */
typedef enum _sai_acl_table_attr_custom_t
{
    /** Custom range Match field base value */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_START = SAI_ACL_TABLE_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Inner IPv6 Flow Label
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_INNER_IPV6_FLOW_LABEL = SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_START,

    /**
     * @brief Inner IPv6 IP DSCP
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_INNER_IP_DSCP,

    /**  
     * @brief Forward layer (switched/routed) of packet
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_FWD_LAYER,

    /**  
     * @brief Metadata carried from previous ACL stage.
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_ACL_USER_META_2,

    /**  
     * @brief Router Interface User metadata
     *
     * @type bool
     * @flags CREATE_ONLY
     * @default false
     */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_ROUTER_INTERFACE_USER_META,

    /** End of custom range match field base */
    SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_END = SAI_ACL_TABLE_ATTR_CUSTOM_FIELD_ROUTER_INTERFACE_USER_META,

}sai_acl_table_attr_custom_t;


/**
 * @brief SAI acl entry custom attribute
 */
typedef enum _sai_acl_entry_attr_custom_t
{
    /** Custom range Match field base value */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_START = SAI_ACL_ENTRY_ATTR_CUSTOM_RANGE_START,

    /**  
     * 
     * @brief Inner IPv6 Flow Label (20 bit)
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_INNER_IPV6_FLOW_LABEL = SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_START,

    /**  
     * @brief Inner IP DSCP
     *
     * @type sai_acl_field_data_t sai_uint8_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_INNER_IP_DSCP,

    /**  
     * @brief Forward layer (switched/routed) of packet
     *
     * @type sai_acl_field_data_t sai_acl_custom_match_fwd_layer_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_FWD_LAYER,

    /**  
     * @brief Metadata carried from previous ACL stage.
     *
     * When an ACL entry set the meta data, the ACL metadata
     * from previous stages are overridden.
     * Value must be in the range defined in
     * #SAI_SWITCH_ATTR_CUSTOM_ACL_USER_META_DATA_RANGE_2
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_ACL_USER_META_2,

    /**
     * @brief Router Interface User metadata
     *
     * Value must be in the range defined in
     * SAI_SWITCH_ATTR_CUSTOM_ROUTER_INTERFACE_META_DATA_INGRESS_RANGE
     * or SAI_SWITCH_ATTR_CUSTOM_ROUTER_INTERFACE_META_DATA_EGRESS_RANGE
     *
     * @type sai_acl_field_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_ROUTER_INTERFACE_USER_META,

    /** End of Custom range Match field base */
    SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_END = 0x10002000,

    /** End of Custom range Action type base value */
    SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_START = SAI_ACL_ENTRY_ATTR_CUSTOM_FIELD_END + 0x1,

    /**  
     * @brief ACL bind point for TAM object
     *
     * Bind (or unbind) a TAM object.
     *
     * @type sai_acl_action_data_t sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_TAM
     * @allownull true
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_TAM_OBJECT = SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_START,

    /**
     * @brief Set metadata to carry forward to next ACL Stage
     *
     * Value Range #SAI_SWITCH_ATTR_CUSTOM_ACL_USER_META_DATA_RANGE_2
     *
     * @type sai_acl_action_data_t sai_uint32_t
     * @flags CREATE_AND_SET
     * @default disabled
     */
    SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_SET_ACL_META_DATA_2,

    /** End of Custom range Action type base value */
    SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_END = SAI_ACL_ENTRY_ATTR_CUSTOM_ACTION_SET_ACL_META_DATA_2

}_sai_acl_entry_attr_custom_t;


/**
 * @brierf custom SAI ACL Match forwarding layer encoding.
 */
typedef enum _sai_acl_custom_match_fwd_layer_t 
{
    SAI_ACL_CUSTOM_MATCH_FWD_LAYER_SWITCHED = 0, ///< SWITCHED
    SAI_ACL_CUSTOM_MATCH_FWD_LAYER_ROUTED   = 1, ///< ROUTED

} sai_acl_custom_match_fwd_layer_t;

#endif /* __SAIACLCUSTOM_H_ */
