
#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import time
from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

from print_table import PrintTable
from ifcs_cmds.node import Node as ifcs_node

# Class implements Node related command
class Node(Command):
    def __init__(self, cli):
        self.sub_cmds = {'show'           : self.show,
                         'id'             : self.id,
                         'create'         : self.create,
                         'delete'         : self.delete,

                         'cut_through'    : self.cut_through,
                         'event_info_get' : self.event_info_get,
                         'help'           : self.help,
                         '?'              : self.help
                        }
        self.cli = cli
        self.arg_list = []
        super(Node, self).__init__()
        self.num_nodes = cli.num_nodes
        self.active_node = None

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def run_cmd(self, args):
        log_dbg(1, "in Node run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (ValueError):
            log_dbg(
                1, "Ignored ValueError in node [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            try:
                if (self.num_nodes == 0):
                    log_err('No nodes detected in the system')
                    return
                node_id = int(self.arg_list[1])
                if (node_id < 0 or node_id >= self.num_nodes):
                    log_err("Valid node ids are between 0 and " + str((self.num_nodes-1)))
                    self.help(args)
                    return
                log_dbg(1, "Setting active node to " + str(node_id))
                self.active_node = node_id
                self.cli.set_node_id(node_id)
            except:
                log_dbg(
                    1, "OtherError when ignoring ValueError in node [{}] run_cmd: {}".format(
                        args, sys.exc_info()))
                log_err('NodeValueTryError')
        except (KeyError):
            log_dbg(
                1, "KeyError in node [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (IndexError):
            log_dbg(
                1, "IndexError in node [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except:
            log_dbg(
                1, "OtherError in node [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        return

    def id(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        node_id = int(self.arg_list.pop(0))
        if (node_id < 0 or node_id > 16):
            log_err("Valid node ids are between 0 and " + str(self.num_nodes))
            return
        log("Setting active node to " + str(node_id))
        self.active_node = node_id
        self.cli.set_node_id(node_id)

    def create(self, args):
        if self.cli.server_mode:
            log_err("Cannot create node via remote shell")
            return

        if self.cli.remote_mode:
            log_err("Cannot create node as remote shell")
            return

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        if (self.num_nodes == 0):
            log_err ('No nodes detected in the system')
            return

        try:
            node_id = int(self.arg_list.pop(0))
            if (node_id < 0 or node_id > 16):
                log_err("Valid node ids are between 0 and " + str(self.num_nodes))
                return
            rc = ifcs_ctypes.ifcs_node_create(node_id, 0, None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                rc = compat_bytesToStr(
                    ifcs_ctypes.ifcs_status_to_string(rc)).split('.')
                rc = rc[len(rc) - 1]
                log_err("Node " +str(node_id) + " couldn't be created, rc: " + rc)
                return

            self.active_node = node_id
            self.cli.set_node_id(node_id)

            node_attr = ifcs_ctypes.ifcs_attr_t()
            rc = ifcs_ctypes.ifcs_attr_t_init(pointer(node_attr))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            ifcs_ctypes.ifcs_attr_t_id_set(pointer(node_attr), ifcs_ctypes.IFCS_NODE_ATTR_ENABLE);
            ifcs_ctypes.ifcs_attr_t_value_data_set(pointer(node_attr), ifcs_ctypes.IFCS_BOOL_TRUE);
            rc = ifcs_ctypes.ifcs_node_attr_set(node_id, 1, pointer(node_attr));
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            log("Node " + str(node_id) + " created and enabled.")
            self.cli.set_prompt()
        except:
            log_err("Usage: node create <node_id | all>")
            return

    def delete(self, args):
        if self.cli.server_mode:
            log_err("Cannot delete node via remote shell")
            return

        if self.cli.remote_mode:
            log_err("Cannot delete node as remote shell")
            return

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        if (self.num_nodes == 0):
            log_err ('No nodes detected in the system')
            return
        try:
            node_id = int(self.arg_list.pop(0))
            if (node_id < 0 or node_id > 16):
                log_err("Valid node ids are between 0 and " + str(self.num_nodes))
                return
            rc = ifcs_ctypes.ifcs_node_delete(node_id)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                rc = compat_bytesToStr(
                    ifcs_ctypes.ifcs_status_to_string(rc)).split('.')
                rc = rc[len(rc) - 1]
                log_err("Node couldn't be deleted, rc: " + rc)
                return

            log("Node " + str(node_id) + " released.")
            self.active_node = None
            self.cli.set_node_id(None)
            self.cli.set_prompt()
        except:
            log_err("Usage: node release <node_id>")
            return


    
    def myCallback(self, node_id, arg, attr_count, attr_list, user_data):
        global devport_list
        devport = arg
        devport_list.append(devport)

    def getAlldevport(self):
        global devport_list

        devport_list = []
        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(self.myCallback)

        try:
            attr = ifcs_ctypes.ifcs_attr_t()
            ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
            ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

            rc = ifcs_ctypes.ifcs_devport_get_all(0, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("Failed to get all devport rc: %d" %(rc))
        except Exception as e:
            log(" Failed to get all devports : %d" %(rc))
            raise e
        return devport_list

    def cut_through(self, args):
        log("node cut_through set")

        self.arg_list.pop(0)
        args_list = args.split()
        dp_list = self.getAlldevport()
        dp_list.sort()

        if len(args_list) < 2:
            log("Usage: node cut_through <enable/disable>")
            return

        enable = 0
        if len(args_list) == 3:
            if args_list[2] == 'enable':
                enable = 1
            elif args_list[2] == 'disable':
                enable = 0

        rc = ifcs_ctypes.ifcs_status_t()

        node_id = self.cli.node_id
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_CUT_THROUGH_ENABLE;
        attr_list_p[0].value.u32 = enable;

        for i in range(len(dp_list)):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, dp_list[i], attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "ERR during port cut-through set:" + str(dp_list[i])

        log("Node cut-through set done")
    
    def event_info_get(self, args):
        log("node event count get")
        self.arg_list.pop(0)
        args_list = args.split()

        if len(args_list) != 3 :
            log("Usage: node event_info_get <event num>/all ")
            return

        if (args_list[2] == 'all'):
            start_event = 0
            end_event = ifcs_ctypes.IM_NUM_EVENT_TYPES
        else:
            start_event = int(args_list[2])
            end_event = start_event + 1

        ev_count = ifcs_ctypes.ifcs_uint64_t()
        ev_err_count = ifcs_ctypes.ifcs_uint64_t()
        ev_queue_size = ifcs_ctypes.ifcs_uint32_t()
        ev_queue_wm = ifcs_ctypes.ifcs_uint32_t()
        rc = ifcs_ctypes.ifcs_status_t()
        table = PrintTable()
        table.add_row(['Event', 'Event count', 'Event error count', 'Event queue size', 'Event queue wm'])

        for event_num in range(start_event, end_event):
            rc = ifcs_ctypes.im_event_count_get(self.cli.node_id, event_num, pointer(ev_count))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("im_event_count_get failed")
                return

            rc = ifcs_ctypes.im_event_err_count_get(self.cli.node_id, event_num, pointer(ev_err_count))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("im_event_err_count_get failed")
                return

            rc = ifcs_ctypes.im_event_queue_size_get(self.cli.node_id, event_num, pointer(ev_queue_size))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("im_event_queue_size_get failed")
                return

            rc = ifcs_ctypes.im_event_queue_watermark_get(self.cli.node_id, event_num, pointer(ev_queue_wm))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("im_event_queue_size_get failed")
                return

            event_name_p = ifcs_ctypes.im_event_num_to_name(self.cli.node_id, event_num)
            if event_name_p == 'IFCS_UNKNOWN':
                continue;

            table.add_row([event_name_p, ev_count.value, ev_err_count.value, ev_queue_size.value, ev_queue_wm.value])
            #log("Event count for event " + self.get_ev_str(event_num) + " is " + str(ev_count_p.value))

        table.print_table()
        table.reset_table()

    def display(self, attr, attr_count, brief=False):
        '''display ifcs object attributes'''
        node_obj = ifcs_node(self.cli)
        table = PrintTable()

        table.add_row(['Name', 'Value'])
        for i in range(attr_count):
            attr_name, attr_type, attr_val, attr_valid = node_obj.get_attr_name_value(attr[i])
            if attr_valid:
                table.add_row([attr_name, attr_val])

        table.print_table(brief)
        table.reset_table()

    def display_temp_sensor(self):
        '''
        Display temp sensor values for the given platform
        '''
        node_obj = ifcs_node(self.cli)
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)

        if device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            num_temp_sensors = 5
            temp_vals = (ifcs_ctypes.ifcs_attr_t * num_temp_sensors)()

            attrCount = 1
            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_MASTER_LAST_TEMP
            actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)
            temp_vals[0] = attr
            time.sleep(0.01)

            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_REMOTE0_LAST_TEMP
            actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)
            temp_vals[1] = attr
            time.sleep(0.01)

            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_REMOTE1_LAST_TEMP
            actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)
            temp_vals[2] = attr
            time.sleep(0.01)

            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_REMOTE2_LAST_TEMP
            actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)
            temp_vals[3] = attr
            time.sleep(0.01)

            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_REMOTE3_LAST_TEMP
            actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)
            temp_vals[4] = attr

            # Print the values
            self.display(temp_vals, num_temp_sensors)

        elif device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            num_temp_sensors = 8

            attrCount = 1
            attr = ifcs_ctypes.ifcs_attr_t()
            attr.id = ifcs_ctypes.IFCS_NODE_ATTR_IB_TEMP_SENSOR
            actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)

            table = PrintTable()

            table.add_row(['Name', 'Value'])
            attr_name, attr_type, attr_val, attr_valid = node_obj.get_attr_name_value(attr)
            for i in range(len(attr_val)):
                if attr_valid:
                    table.add_row(["IB%d"%i, attr_val[i]])

            table.print_table(False)
            table.reset_table()

    def show(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        if (self.num_nodes == 0):
            try:
                self.cli.node_id
            except:
                log_err ('No nodes detected in the system')
                return
        try:
            node_id = int(self.arg_list.pop(0))
            if (node_id < 0 or node_id > 16):
                log_err("Valid node ids are between 0 and " + str(self.num_nodes))
                return

            if (self.num_nodes == 0):
                if (node_id != self.cli.node_id):
                    log_err ('Invalid node')
                    return

            node_obj = ifcs_node(self.cli)

            cmd = self.arg_list.pop(0)
            if(cmd == "linkscan"):
                subcmd = self.arg_list.pop(0)
                if(subcmd == "mbrs"):
                    log("Showing devport_ids participating in linkscan on node %d\n" %(node_id))
                    devport_count = 256
                    devport_list = (ifcs_ctypes.ifcs_devport_t * devport_count)()
                    actual_devport_count = (c_uint32)()
                    ifcs_ctypes.ifcs_linkscan_devports_get(node_id, devport_count, compat_pointer(devport_list, ifcs_ctypes.ifcs_devport_t), pointer(actual_devport_count))
                    #dp = actual_devport_count
                    devportmbrs = []
                    actual_count = actual_devport_count.value
                    for dpn in range(actual_count):
                        devportmbrs.append(devport_list[dpn])
                    log("actual count: %s\n" %str(actual_devport_count.value))
                    log("Devport_ids: %s\n" %str(devportmbrs))

                else:
                    log_err("Sub-command %s not supported" %(subcmd))

            elif(cmd == "info"):

                # Get the required attr values
                attrCount = 4
                attr = ifcs_ctypes.ifcs_attr_t()
                attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()

                attr[0].id = ifcs_ctypes.IFCS_NODE_ATTR_VENDOR_ID
                attr[1].id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE_ID
                attr[2].id = ifcs_ctypes.IFCS_NODE_ATTR_PART_NUMBER
                attr[3].id = ifcs_ctypes.IFCS_NODE_ATTR_REVISION

                actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attrCount)

                # Print the values
                self.display(attr, actual_count.value)

            elif(cmd == "device_health"):
                log("node show device_health")

                dev_err_count = ifcs_ctypes.ifcs_uint64_t()
                rc = ifcs_ctypes.ifcs_status_t()
                table = PrintTable()
                table.add_row(['Health info', 'Value'])

                rc = ifcs_ctypes.im_node_device_error_count_get(node_id, pointer(dev_err_count))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("im_node_device_error_count_get failed")
                    return rc

                if (dev_err_count.value == 0):
                    table.add_row(['Status', 'Green'])
                else:
                    table.add_row(['Status', 'Red'])
                table.add_row(['Error count', dev_err_count.value])

                table.print_table()
                table.reset_table()

            elif(cmd == "temp_sensor"):

                self.display_temp_sensor()

            elif(cmd == "chip_version"):
                log("node show chip_version")
                try:
                    attrCount = 1
                    node_attr = ifcs_ctypes.ifcs_attr_t()
                    node_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE
                    actual_count = node_obj.getAttr(node_attr, compat_pointer(node_attr, ifcs_ctypes.ifcs_attr_t), attrCount)
                    table = PrintTable()
                    table.add_row(['Name', 'Value'])
                    node_attr_name, node_attr_type, node_attr_val, node_attr_valid = node_obj.get_attr_name_value(node_attr)
                    table.add_row([node_attr_name, node_attr_val])
                except:
                    table = PrintTable()
                    table.add_row(['Name', 'Value'])
                    table.add_row(['device', 'TERALYNX7'])

                # Get the required attr values
                attr_count = 3
                attr = ifcs_ctypes.ifcs_attr_t()
                attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

                attr[0].id = ifcs_ctypes.IFCS_NODE_ATTR_SKU
                attr[1].id = ifcs_ctypes.IFCS_NODE_ATTR_REVISION_NUM
                attr[2].id = ifcs_ctypes.IFCS_NODE_ATTR_PART_NUMBER

                actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attr_count)

                # Print the values
                for i in range(attr_count):
                    attr_name, attr_type, attr_val, attr_valid = node_obj.get_attr_name_value(attr[i])
                    table.add_row([attr_name, attr_val])
                table.print_table()

            elif(cmd == "cr_match_list"):
                log("node show cr_match_list")

                attr_count = 1
                attr = ifcs_ctypes.ifcs_attr_t()
                attr.id = ifcs_ctypes.IFCS_NODE_ATTR_DEVICE
                actual_count = node_obj.getAttr(attr, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t), attr_count)
                attr_name, attr_type, attr_val, attr_valid = node_obj.get_attr_name_value(attr)
                if attr_val != "TERALYNX10":
                    log_err("Command not suppoted in " +str(attr_val))
                    return ifcs_ctypes.IFCS_UNSUPPORTED

                cr_match_arr = ifcs_ctypes.ifcs_cr_match_t()
                cr_match_list = ifcs_ctypes.ifcs_cr_match_list_t()
                cr_match_list.arr = compat_pointer(cr_match_arr, ifcs_ctypes.ifcs_cr_match_t())

                attrCount = 1
                node_attr = ifcs_ctypes.ifcs_attr_t()
                node_attr.id = ifcs_ctypes.IFCS_NODE_ATTR_CR_MATCH_LIST
                actual_count = node_obj.getAttr(node_attr, compat_pointer(node_attr, ifcs_ctypes.ifcs_attr_t), attrCount)
                rc = ifcs_ctypes.ifcs_attr_t_value_cr_match_list_get(compat_pointer(node_attr, ifcs_ctypes.ifcs_attr_t), pointer(cr_match_list))
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log("ifcs_attr_t_value_cr_match_list_get failed")
                    return rc

                table = PrintTable()
                table.add_row(['Type', 'IP Protocol', 'SrcPort', 'DestPort'])
                for i in range (cr_match_list.count):
                    if cr_match_list.arr[i].type == ifcs_ctypes.IFCS_CR_MATCH_TYPE_IP_PROTO:
                        table.add_row([cr_match_list.arr[i].type, cr_match_list.arr[i].ip_proto, 0, 0])
                    elif cr_match_list.arr[i].type == ifcs_ctypes.IFCS_CR_MATCH_TYPE_IP_PROTO_L4_SRC_PORT:
                        table.add_row([cr_match_list.arr[i].type, cr_match_list.arr[i].ip_proto, cr_match_list.arr[i].src_port, 0])
                    elif cr_match_list.arr[i].type == ifcs_ctypes.IFCS_CR_MATCH_TYPE_IP_PROTO_L4_DEST_PORT:
                        table.add_row([cr_match_list.arr[i].type, cr_match_list.arr[i].ip_proto, 0, cr_match_list.arr[i].dest_port])
                    elif cr_match_list.arr[i].type == ifcs_ctypes.IFCS_CR_MATCH_TYPE_IP_PROTO_L4_SRC_DEST_PORT:
                        table.add_row([cr_match_list.arr[i].type, cr_match_list.arr[i].ip_proto, cr_match_list.arr[i].src_port, cr_match_list.arr[i].dest_port])
                    else:
                        log("Invalid CR_MATCH_TYPE {}".format(cr_match_list.arr[i].type))
                table.print_table(brief=True)

            else:
                log_err("Command %s not supported" %(subcmd))
        except:
            log_err("Usage: node show <node_id> <linkscan> <mbrs> / node show <node_id> <device_health> / node show <node_id> <temp_sensor> / node show <node_id> <chip_version>")
        return ifcs_ctypes.IFCS_SUCCESS

    def get_active_node(self):
        if (self.active_node != -1):
            return self.active_node

    def set_active_node(self, node_id):
        self.active_node = node_id

    def help(self, args):
        self.cli.error()
        table = PrintTable()
        table.set_justification('left')
        table.add_row(["Node commands","Help"])
        table.add_row(["node create <node_id>"," ifcs node join <node_id>"])
        table.add_row(["node delete <node_id>"," ifcs node release <node_id>"])
        table.add_row(["node show <node_id> device_health"," ifcs node show node"])
        table.add_row(["node show <node_id> temp_sensor"," show temp sensor data"])
        table.add_row(["node show <node_id> chip_version"," show chip version data"])

        table.add_row(["node cut_through <enable/disable>"," ifcs node cut_through <enable/disable>"])
        table.add_row(["node event_info_get <ev num/all>"," ifcs node event_info_get <ev num/all>"])
        table.add_row(["node help or ?", " show this text"])
        table.print_table()
        table.reset_table()
