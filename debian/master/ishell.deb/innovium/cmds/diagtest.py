#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']
from ctypes import *
from testutil import pci
from serdes import Serdes
from snake import Snake
from stress import Stress
from snake_flood import Snake as SnakeFlood
from l3snake_mp import L3snake
from spst import Spst
from l3spst import L3spst
from tunspst import Tunspst
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from netdev_test import Netdev
from watson import Watson
from ifcs_cmds.node import Node as ifcs_node
from ifcs_cmds.linkscan import Linkscan as ifcs_linkscan
from mbist import Mbist
from memrw import Memrw
from tcam_test import Tcam_test

def DEVICE_PEN_IDMAP_PY(node_id, pen_id, is_mapped=False):
    if(is_mapped is True):
        return pen_id
    else:
        return ifcs_ctypes.device_pen_map(node_id, pen_id)

def DEVICE_FLD_IDMAP_PY(node_id, fld_id, is_mapped=False):
    if(is_mapped is True):
        return fld_id
    else:
        return ifcs_ctypes.device_fld_map(node_id, fld_id)

def getSysportHandleFromDevPort(node_id, devPort):
    attr = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_ctypes.ifcs_devport_attr_get(node_id, devPort, 1, pointer(attr),
                            pointer(actual_count))
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle

def create_ctc_trap(node_id):
    ctc_trap_handle = ifcs_ctypes.ifcs_handle_t()
    ctc_trap_handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

    attr = (ifcs_ctypes.ifcs_attr_t * 1 )()

    attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM
    attr[0].value.u32 = 0

    rc = ifcs_ctypes.ifcs_hostif_trap_create(node_id, pointer(ctc_trap_handle), 1, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "COPY to CPU trap creation FAILED"

    return ctc_trap_handle

def delete_ctc_trap(node_id, ctc_trap_handle):
    rc = ifcs_ctypes.ifcs_hostif_trap_delete(node_id, ctc_trap_handle);
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "COPY to CPU trap deletion FAILED"
    return

def gen_async_event_cb(node_id, user_data, data):
    global async_return_str
    global async_pen
    global async_field
    global async_fieldtype
    global async_seed
    global async_num_entries

    async_rentry = cast(data, POINTER(ifcs_ctypes.bentry_t))

    err = 0
    rd_val = c_int(0)
    for i in range (0, async_num_entries):
        exp = async_seed + i
        ifcs_ctypes.bentry_get_item(node_id, async_pen, i, async_field, async_fieldtype, async_rentry, pointer(rd_val))
        #log("async rd_val 0x%x" %(rd_val.value))
        if (rd_val.value != exp):
            async_return_str = 'FAILED'
            err = 1
            #break

    if (err == 0):
            async_return_str = 'PASSED'

    return ifcs_ctypes.IFCS_SUCCESS

def rx_verify(node_id, user_data, packet):
    global rx_verify_status

    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    rx_queue = packet.contents.queue_num
    packet_data = cast(buf, POINTER(c_char))
    packet_data = packet_data[:buf_len]

    if (compat_ord(packet_data[0]) == 0xaa and compat_ord(packet_data[1]) == 0xbb and \
            compat_ord(packet_data[2]) == 0xcc and compat_ord(packet_data[3]) == 0xdd):
        rx_verify_status = 'PASSED'
    else:
        rx_verify_status = 'FAILED'

def rx_verify_lb(node_id, user_data, packet):
    global rx_verify_status_lb
    global lb_pkt_cnt

    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    rx_queue = packet.contents.queue_num
    packet_data = cast(buf, POINTER(c_char))
    packet_data = packet_data[:buf_len]

    if (compat_ord(packet_data[0]) == 0x0 and compat_ord(packet_data[1]) == 0x0 and \
            compat_ord(packet_data[2]) == 0x0 and compat_ord(packet_data[3]) == 0x0):
        lb_pkt_cnt = lb_pkt_cnt + 1
        rx_verify_status_lb = 'PASSED'
    else:
        rx_verify_status_lb = 'FAILED'

def ports_in_lb(node_id, first_port, num_ports, lb_type):
    attr_count = 1
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()
    # Disable all the ports
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
    attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

    for devport in range(first_port, num_ports):
        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                         attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
            "ERR during port admin disable:" +\
            str(devport)

    # Set all the ports in loopback
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK;
    attr_list_p[0].value.u32 = lb_type;

    for devport in range(first_port, num_ports):
        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                         attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
            "ERR during port loopback set:" +\
            str(devport)

    # Enable all the ports
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
    attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

    for devport in range(first_port, num_ports):
        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                         attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
            "ERR during port admin enable:" +\
            str(devport)

def ports_out_of_lb(node_id, first_port, num_ports):
    attr_count = 1
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()
    # Disable all the ports
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
    attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

    for devport in range(first_port, num_ports):
        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                         attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
            "ERR during port admin disable:" +\
            str(devport)

    # Set all the ports in loopback
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK;
    attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE;

    for devport in range(first_port, num_ports):
        rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                         attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
            "ERR during port loopback set:" +\
            str(devport)
    return

def wait_for_linkup(node_id, first_port, num_ports):
    attr_count = 1
    attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()
    # Wait for all ports to go link-up for 5 secs
    wait_time=0
    attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS;
    attr_list_p[0].value.u32 = 0;
    actual_count = c_uint32()
    link_status=True
    while wait_time<5:
        link_status=True
        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_get (node_id, devport, 1,
                             compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t), pointer(actual_count));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin enable:" +\
                str(devport)

            if (attr_list_p[0].value.u32 != 1):
                link_status=False
        if link_status:
            break;
        else:
            wait_time+=0.1
            time.sleep(0.1)

    assert link_status == True, "Not all devports are up"

# Class implements Diagtest related command
class Diagtest(Command):
    def __init__(self, cli):
        self.sub_cmds = {'pci'          : self.pci,
                         'pen'          : self.pen,
                         'intr'         : self.intr,
                         'pkt'          : self.pkt,
                         'netdev'       : self.netdev,
                         'serdes'       : self.serdes,
                         'snake'        : self.snake,
                         'snake_flood'  : self.snake_flood,
                         'l3snake'      : self.l3snake,
                         'stress'       : self.stress,
                         'spst'         : self.spst,
                         'l3spst'       : self.l3spst,
                         'tunspst'      : self.tunspst,
                         'mbist'        : self.mbist,
                         'memrw'        : self.memrw,
                         'tcam'         : self.tcam_test,
                         'oly_dbg'      : self.oly_dbg,
                         'watson'       : self.watson,
#ifdef OLY_MISC_DBG_ACCESS
                         'i2c'              : self.i2c,
#endif

                         'all'              : self.alltests,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        super(Diagtest, self).__init__()
        self.num_nodes = cli.num_nodes
        self.active_node = 0
        self.watson_obj = None

    def run_cmd(self, args):
        log_dbg(1, "in diagtest run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            return self.sub_cmds[self.arg_list[1]](args)
        except (KeyError):
            log_dbg(
                1, "KeyError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except Exception:
            log_dbg(
                1, "OtherError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_netdev(self, text):
        netdev = Netdev(self.cli)
        return [j for j in netdev.sub_cmds.keys() if j.startswith(text)]

    def complete_snake(self, text):
        snake = Snake(self.cli)
        return [j for j in snake.sub_cmds.keys() if j.startswith(text)]

    def complete_spst(self, text):
        snake = Spst(self.cli)
        return [j for j in snake.sub_cmds.keys() if j.startswith(text)]

    def complete_l3spst(self, text):
        snake = L3spst(self.cli)
        return [j for j in snake.sub_cmds.keys() if j.startswith(text)]

    def complete_tunspst(self, text):
        snake = Tunspst(self.cli)
        return [j for j in snake.sub_cmds.keys() if j.startswith(text)]

    def complete_snake_flood(self, text):
        snake = SnakeFlood(self.cli)
        return [j for j in snake.sub_cmds.keys() if j.startswith(text)]

    def complete_l3snake(self, text):
        l3snake = L3snake(self.cli)
        return [j for j in l3snake.sub_cmds.keys() if j.startswith(text)]

    def complete_watson(self, text):
        if self.watson_obj is None:
            self.watson_obj = Watson(self.cli)
        return [j for j in self.watson_obj.sub_cmds.keys() if j.startswith(text)]

    # PCI access testing: Includes read and write tests
    # Read test:  Read from a standard PCI register (Vendor ID Device ID)
    #             and make sure the register value is a standard value
    # Write test: Write to PCI scratch register, read back and make sure
    #             the value matches what we wrote
    def pci(self, args):
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            cmd_name = self.arg_list.pop(0)
        except:
            cmd_name = 'all'

        log("######## Running PCI tests: #########")
        if cmd_name == 'read' or cmd_name == 'all':
            try:
                regval = pci.read32(ifcs_ctypes.PCI_CFG_I_PCIE_BASE_I_VENDOR_ID_DEVICE_ID)
                if (regval != 0x10017cd):
                    log("PCI read test\t\t\t:\tFAILED")
                else:
                    log("PCI read test\t\t\t:\tPASSED")

            except Exception as ex:
                self.cli.error()
                log("pci read: ", type(ex).__name__, ex.args)
                return ifcs_ctypes.IFCS_INVAL

        if cmd_name == 'write' or cmd_name == 'all':
            try:
                count = pci.read32(ifcs_ctypes.TXQ_6_DESC_RING)
                regval = pci.write32(ifcs_ctypes.TXQ_6_DESC_RING, 1)
                regval = pci.read32(ifcs_ctypes.TXQ_6_DESC_RING)
                if (regval != 1):
                    log("PCI write test\t\t\t:\tFAILED")
                else:
                    log("PCI write test\t\t\t:\tPASSED")
                regval = pci.write32(ifcs_ctypes.TXQ_6_DESC_RING, count)

            except Exception as ex:
                self.cli.error()
                log("pci write test read: ", type(ex).__name__, ex.args)
                return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR
        pass

    def gen_block_sync_test(self, pen, field, fieldtype, num_entries):
        seed = 0x1
        node_id = self.cli.node_id

        w_entry = ifcs_ctypes.bentry_new(node_id, pen, num_entries)
        ifcs_ctypes.bentry_alloc(node_id, w_entry)

        for i in range (0, num_entries):
            wr_val = c_uint32()
            wr_val.value = seed + i
            ifcs_ctypes.bentry_set_item(node_id, pen, i, field, fieldtype, w_entry, pointer(wr_val))

        rc = ifcs_ctypes.node_isn_pen_block_write(node_id, 0, pen, 0,\
                                      num_entries, 0, w_entry)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.bentry_st_free(w_entry)
            return 'FAILED'

        r_entry = ifcs_ctypes.bentry_new(node_id, pen, num_entries)
        rd_val = c_int(0)
        ifcs_ctypes.bentry_alloc(node_id, r_entry)

        rc = ifcs_ctypes.node_isn_pen_block_read(node_id, 0, pen, 0,\
                                     num_entries, 0, r_entry)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.bentry_st_free(w_entry)
            ifcs_ctypes.bentry_st_free(r_entry)
            return 'FAILED'

        return_str = 'PASSED'
        for i in range (0, num_entries):
            exp = seed + i
            ifcs_ctypes.bentry_get_item(node_id, pen, i, field, fieldtype, r_entry, pointer(rd_val))
            #log("rd_val 0x%x" %(rd_val.value))
            if (rd_val.value != exp):
                return_str = 'FAILED'
                break

        ifcs_ctypes.bentry_st_free(w_entry)
        ifcs_ctypes.bentry_st_free(r_entry)
        return return_str

    def gen_block_async_test(self, pen, field, fieldtype, num_entries):
        global async_wentry
        global async_return_str
        global async_pen
        global async_field
        global async_fieldtype
        global async_num_entries
        global async_seed
        async_seed = 0x2
        async_num_entries = num_entries
        async_pen = pen
        async_field = field
        async_fieldtype = fieldtype
        node_id = self.cli.node_id
        ev_info = ifcs_ctypes.im_event_info_t()
        ifcs_ctypes.im_event_info_t_init(byref(ev_info))
        ev_info.event_cb_p = ifcs_ctypes.im_event_cb_t(gen_async_event_cb)
        ev_info.user_data  = None
        ev_info.new_thread = 1

        rc = ifcs_ctypes.im_event_enable(node_id, ifcs_ctypes.IM_EVENT_TEST)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("IM_EVENT_TEST event enable FAILED")
            return 'FAILED'
        rc = ifcs_ctypes.im_event_register(node_id, ifcs_ctypes.IM_EVENT_TEST, byref(ev_info))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("IM_EVENT_TEST event registration FAILED")
            return 'FAILED'

        async_return_str = None
        async_wentry = ifcs_ctypes.bentry_new(node_id, pen, num_entries)
        ifcs_ctypes.bentry_alloc(node_id, async_wentry)

        for i in range (0, num_entries):
            wr_val = c_uint32()
            wr_val.value = async_seed + i
            ifcs_ctypes.bentry_set_item(node_id, pen, i, field, fieldtype, async_wentry, pointer(wr_val))

        status = c_uint32()
        ok     = c_uint32()
        fail   = c_uint32()
        ifcs_ctypes.node_isn_async_group_start(node_id, pointer(ok), pointer(fail))
        rc = ifcs_ctypes.node_isn_pen_block_write_async(node_id, 0, pen, 0,\
                                      num_entries, async_wentry, ifcs_ctypes.IM_EVENT_INVALID, \
                                      None, pointer(status))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.bentry_st_free(async_wentry)
            ifcs_ctypes.node_isn_async_group_end(node_id)
            return 'FAILED'

        ifcs_ctypes.node_isn_async_group_end(node_id)

        ifcs_ctypes.node_isn_async_group_start(node_id, pointer(ok), pointer(fail))
        rc = ifcs_ctypes.node_isn_pen_block_read_async(node_id, 0, pen, 0,\
                                     num_entries, 0, ifcs_ctypes.IM_EVENT_TEST,
                                     None, pointer(status))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.node_isn_async_group_end(node_id)
            ifcs_ctypes.bentry_st_free(async_wentry)
            return 'FAILED'

        ifcs_ctypes.node_isn_async_group_end(node_id)

        retry_cnt = 0
        while async_return_str == None:
            #Wait for the return status
            time.sleep(0.1)
            retry_cnt = retry_cnt + 1
            if (retry_cnt > 25):
                async_return_str = 'FAILED'
                break

        ifcs_ctypes.bentry_st_free(async_wentry)
        return async_return_str

    def sync_read_test(self):
        node_id = self.cli.node_id
        rw_entry = ifcs_ctypes.tentry_new(DEVICE_PEN_IDMAP_PY(node_id,ifcs_ctypes.IPRS1_SIP_CCSCRUB_TIMER_CLIFF), -1, -1)
        rc = ifcs_ctypes.node_isn_pen_read(node_id, 0, DEVICE_PEN_IDMAP_PY(0, ifcs_ctypes.IPRS1_SIP_CCSCRUB_TIMER_CLIFF), 0, 0, rw_entry)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.tentry_free(rw_entry)
            return

        rd_val = c_uint32(0)
        rc = ifcs_ctypes.tentry_get_item(node_id, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.IPRS1_SIP_CCSCRUB_TIMER_CLIFF),\
                             DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.TMRF),\
                             ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,\
                             rw_entry, pointer(rd_val))
        # If the API ifcs_ctypes.node_isn_pen_read succeeds, no need to check the value
        # the test can be declared a PASS
        return_str = 'PASSED'

        ifcs_ctypes.tentry_free(rw_entry)
        return return_str

    def sync_write_test(self):
        node_id = self.cli.node_id
        rw_entry = ifcs_ctypes.tentry_new(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), -1, -1)
        wr_val = c_int(0xab)
        rc = ifcs_ctypes.tentry_set_item(node_id, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP),\
			                 DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_TRAP_ID_F), \
                             ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, rw_entry, \
                             pointer(wr_val))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN tentry set FAILED: rc = " + str(rc)

        rc = ifcs_ctypes.node_isn_pen_write(node_id, 0, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), 0, 0, rw_entry)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.tentry_free(rw_entry)
            return 'FAILED'

        ifcs_ctypes.tentry_free(rw_entry)

        rw_entry = ifcs_ctypes.tentry_new(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), -1, -1)
        rd_val = c_int(0)
        rc = ifcs_ctypes.node_isn_pen_read(node_id, 0, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), 0, 0, rw_entry)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.tentry_free(rw_entry)
            return 'FAILED'

        rc = ifcs_ctypes.tentry_get_item(node_id, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP),\
                             DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_TRAP_ID_F),\
                             ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,\
                             rw_entry, pointer(rd_val))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN tentry get FAILED: rc = " + str(rc)

        if rd_val.value != wr_val.value:
            log("pen write test FAILED rd_val = ",rd_val," wr_val = ",wr_val)
            ifcs_ctypes.tentry_free(rw_entry)
            return 'FAILED'

        ifcs_ctypes.tentry_free(rw_entry)

        # Broadcast
        rw_entry = ifcs_ctypes.tentry_new(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), -1, -1)
        wr_val = c_int(0xab)
        rc = ifcs_ctypes.tentry_set_item(node_id, DEVICE_PEN_IDMAP_PY(node_id,ifcs_ctypes.CPU_METADATA_MAP),\
                             DEVICE_FLD_IDMAP_PY(node_id,ifcs_ctypes.DATA_TRAP_ID_F), \
                             ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, rw_entry, \
                             pointer(wr_val))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN tentry set FAILED: rc = " + str(rc)

        rc = ifcs_ctypes.node_isn_pen_write(node_id, ifcs_ctypes.IFCS_ALL_IBS, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), 0, 0, rw_entry)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("pen read FAILED with rc = " + str(rc))
            ifcs_ctypes.tentry_free(rw_entry)
            return 'FAILED'

        ifcs_ctypes.tentry_free(rw_entry)

        for ib in range(0, ifcs_ctypes.im_node_num_ibs(node_id) - 1):
            rw_entry = ifcs_ctypes.tentry_new(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), -1, -1)
            rd_val = c_int(0)
            rc = ifcs_ctypes.node_isn_pen_read(node_id, 0, DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.CPU_METADATA_MAP), 0, 0, rw_entry)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log("pen read FAILED with rc = " + str(rc))
                ifcs_ctypes.tentry_free(rw_entry)
                return 'FAILED'

            rc = ifcs_ctypes.tentry_get_item(node_id, DEVICE_PEN_IDMAP_PY(node_id,ifcs_ctypes.CPU_METADATA_MAP),\
                                 DEVICE_FLD_IDMAP_PY(node_id,ifcs_ctypes.DATA_TRAP_ID_F),\
                                 ifcs_ctypes.TENTRY_FLD_TYPE_UINT32,\
                                 rw_entry, pointer(rd_val))
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "PEN tentry get FAILED: rc = " + str(rc)

            if rd_val.value != wr_val.value:
                log("pen write test FAILED rd_val = " + str(rd_val))
                ifcs_ctypes.tentry_free(rw_entry)
                return 'FAILED'
            ifcs_ctypes.tentry_free(rw_entry)

        return 'PASSED'

    # PEN access tests: These tests include read and write tests on different
    #                   types of PENs: Index, Indirect, TCAM and Hash tables
    #                   using different types of accesses: sync, async, block sync
    #                   and block async
    #        sync test: Read - Read from a standard PEN with sync access and
    #                          check to make sure it maches the default value
    #                   Write - Write to a writeable PEN, read back and make sure
    #                           it matches the written value
    #                   Multi IB / Broadcast - Perform the Write test to Multiple IBs
    #
    # Block sync test: Write a certain pattern to PENs of types Index, Indirect,
    #                  TCAM and Hashtable with Block sync access and read back
    #                  using Block sync access and make sure the pattern
    #                  matches
    #
    #Block async test: Write a certain pattern to PENs of types Index, Indirect,
    #                  TCAM and Hashtable with Block async access and read back
    #                  using Block async access and make sure the pattern
    #                  matches
    #
    def pen(self, args):
        node_id = self.cli.node_id
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            cmd_name = self.arg_list.pop(0)
        except:
            cmd_name = 'all'

        log("######## Running PEN tests: ########")
        if cmd_name == 'sync' or cmd_name == 'all':
            try:
                sub_cmd_name = self.arg_list.pop(0)
            except:
                sub_cmd_name = 'all'

            if sub_cmd_name == 'read' or sub_cmd_name == 'all':
                try:
                    return_str = self.sync_read_test()
                    log("Pen sync read test\t\t:\t" + return_str)
                except Exception as ex:
                    self.cli.error()
                    log("pen read: ", type(ex).__name__, ex.args)
                    return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR
            if sub_cmd_name == 'write' or sub_cmd_name == 'all':
                try:
                    return_str = self.sync_write_test()
                    log("Pen sync write test\t\t:\t" + return_str)
                except Exception as ex:
                    self.cli.error()
                    log("pen write: ", type(ex).__name__, ex.args)
                    return ifcs_ctypes.IFCS_DEVICE_ACCESS_ERROR

        if cmd_name == 'blocksync' or cmd_name == 'all':
            try:
                sub_cmd_name = self.arg_list.pop(0)
            except:
                sub_cmd_name = 'all'

            num_entries = 8
            if sub_cmd_name == 'index' or sub_cmd_name == 'all':
                pass_str = self.gen_block_sync_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.TIERB_L3QOS_MAP),\
                                                   DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_DSCP_F), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                log("Blocksync index test\t\t:\t" + pass_str)

            if sub_cmd_name == 'indirect' or sub_cmd_name == 'all':
                pass_str = self.gen_block_sync_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.EADB_1X),\
                                                    DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DEPF), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                log("Blocksync indirect test\t\t:\t" + pass_str)

            #if sub_cmd_name == 'tcam' or sub_cmd_name == 'all':
            if sub_cmd_name == 'tcam':
                pass_str = self.gen_block_sync_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.IMT1001),\
                                                    DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_ECC_F), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                log("Blocksync tcam test\t\t:\t" + pass_str)

            if sub_cmd_name == 'hash':
                log("Blocksync hash test\t\t:\tNot supported")

        if cmd_name == 'blockasync' or cmd_name == 'all':
            try:
                sub_cmd_name = self.arg_list.pop(0)
            except:
                sub_cmd_name = 'all'

            num_entries = 8
            if sub_cmd_name == 'index' or sub_cmd_name == 'all':
                # TODO: The async callback is not getting called the first time; need to debug why!! Until then, as a work-around calling the async_test twice
                pass_str = self.gen_block_async_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.TIERB_L3QOS_MAP),\
                                                     DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_DSCP_F), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                pass_str = self.gen_block_async_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.TIERB_L3QOS_MAP),\
                                                     DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_DSCP_F), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                log("Pen Block Async index test\t:\t" + pass_str)

            if sub_cmd_name == 'indirect' or sub_cmd_name == 'all':
                pass_str = self.gen_block_sync_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.EADB_1X),\
                                                     DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DEPF), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                log("Pen Block Async indirect test\t:\t" + pass_str)

            #if sub_cmd_name == 'tcam' or sub_cmd_name == 'all':
            if sub_cmd_name == 'tcam':
                pass_str = self.gen_block_async_test(DEVICE_PEN_IDMAP_PY(node_id, ifcs_ctypes.IMT1001),\
                                                     DEVICE_FLD_IDMAP_PY(node_id, ifcs_ctypes.DATA_ECC_F), ifcs_ctypes.TENTRY_FLD_TYPE_UINT32, num_entries)
                log("Pen Block Async TCAM test\t:\t" + pass_str)

            if sub_cmd_name == 'hash':
                log("Pen Block Async Hash test\t:\tNot supported\n")
        pass

    # Interrupt tests: There are four types of Interrupt tests
    #                  Async/Block, packet, learn and ECC
    #
    #    Async/Block: These are verified as a part of PEN access
    #                 so we just mark it successful
    #         Packet: These are verified as a part of packet tests
    #                 so we just mark it successful
    #         Learn:  We temporarily mark it passed, we can test
    #                 these interrupts using the loopback path
    #           ECC:  We temporarily mark it passed, we will
    #                 add the tests once the ECC IFCS changes are ready
    def intr(self, args):
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            cmd_name = self.arg_list.pop(0)
        except:
            cmd_name = 'all'
        log("Interrupt tests not supported\n")
        '''
        log("######## Running INTERRUPT tests: ########")
        if cmd_name == 'async' or cmd_name == 'block' or cmd_name == 'all':
            log("Running Async/Block Interrupt test ...\n")
            log("Async/Block Interrupt test passed\n\n")
        if cmd_name == 'packet' or cmd_name == 'all':
            log("Running Packet DMA Interrupt test ...\n")
            log("Packet DMA Interrupt test passed\n\n")
        if cmd_name == 'learn' or cmd_name == 'all':
            log("Running Learn Interrupt test ...\n")
            log("Learn Interrupt test passed\n\n")
        if cmd_name == 'ecc' or cmd_name == 'all':
            log("Running ECC Interrupt test ...\n")
            log("ECC Interrupt test passed\n\n")

        log("\n")
        '''
        pass

    def cpucpu(self):
        global rx_verify_status

        node_id = self.cli.node_id
        node_obj = ifcs_node(self.cli)
        rx_verify_status = None
        # Set up the listener
        cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_verify)
        ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(node_id, None, cbfn)

        # create the trap
        attr_count = 1
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        attr[0].id = ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE

        # Any handle
        trap_handle = ifcs_ctypes.ifcs_handle_t()
        trap_handle.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(ifcs_ctypes.IFCS_HOSTIF_TRAP_SWITCH_TO_CPU)
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(node_id, trap_handle,
                                       attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert (rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST), "STC Trap enable FAILED: rc = [" + str(rc) + "]"

        data_bytes = compat_chr(0xaa) + compat_chr(0xbb) + compat_chr(0xcc) + compat_chr(0xdd);
        length = 100
        rx_queue = 0
        for j in range(length - 4):
            data_bytes += compat_chr(0xff)

        cpu_sp = node_obj.getCpuSysport()
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            packet.dsp = cpu_sp
            packet.pkt_buf = cast(data_bytes, c_void_p)
            packet.pkt_buf_len = length
        except Exception as e:
            log("exc", e)

        rc = ifcs_ctypes.ifcs_hostif_send_packet(node_id, pointer(packet))
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log_err('Packet send to switch FAILED')

        retry_cnt = 0
        while rx_verify_status == None:
            time.sleep(0.1)
            retry_cnt = retry_cnt + 1
            if (retry_cnt > 10):
                rx_verify_status = 'FAILED'
                break

        # clear traps & handlers
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
        rc = ifcs_ctypes.ifcs_hostif_trap_attr_set(node_id, trap_handle,
                                       attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS, "STC Trap disable FAILED: rc = [" + str(rc) + "]"

        ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(node_id)
        return rx_verify_status

    def cpufp(self):
        node_id = self.cli.node_id
        port_cnt  = 4
        first_port = 1
        num_ports = first_port + port_cnt
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        # Enable all the ports
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin disable:" +\
                str(devport)

        # Put the ports in loopback mode
        ports_in_lb(node_id, first_port, num_ports, ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS)
        #Wait for link up
        wait_for_linkup(node_id, first_port, num_ports)


        # Send packets
        for devport in range(first_port, num_ports):

            dst_sp_hdl = getSysportHandleFromDevPort(node_id, devport)
            data_bytes = compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(1)
            data_bytes += compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(devport+1)
            data_bytes += compat_chr(0x81) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x64)
            length = 100
            rx_queue = 0
            for j in range(length - 16):
                data_bytes += compat_chr(0xff)

            # Allocate space for counters
            count = 1
            counter_ids = (ifcs_ctypes.ifcs_devport_stats_id_t * count)()
            counters_bef = (ctypes.c_uint64 * count)()
            counters_aft = (ctypes.c_uint64 * count)()
            actual_count = ctypes.c_uint32()
            counter_ids[0] = ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK

            rc = ifcs_ctypes.ifcs_devport_stats_get(
                node_id, devport, count,
                compat_pointer(counter_ids,
                               ifcs_ctypes.ifcs_devport_stats_id_t),
                compat_pointer(counters_bef, ctypes.c_uint64),
                pointer(actual_count))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

            # Read the existing statistics


            '''
            # CPU packet: set the vf2 queue for proper operation
            packet = pkt.ldh_vf2(0, devport-1, rx_queue) + data_bytes
            length += 12

            p = cast(packet, POINTER(c_uint8));
            tx_ring = 0
            rc = ifcs_ctypes.im_hostif_send_packet_zcopy(node_id, tx_ring, p, length)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log('send_packet FAILED')
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete Trap entry FAILED: rc = [" + str(rc) + "]"
            '''
            try:
                packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
                ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
                packet.tx_type = 1
                packet.trap_handle = 0 # is ignored
                packet.ssp = 0 #dst_sp_hdl # is ignored
                packet.dsp = dst_sp_hdl
                packet.queue_num = 0 # is ignored
                packet.ring_num = 0
                packet.pkt_buf = cast(data_bytes, c_void_p)
                packet.pkt_buf_len = length
            except Exception as e:
                log("exc", e)
            rc = ifcs_ctypes.ifcs_hostif_send_packet(node_id, pointer(packet))
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err('Packet send to switch FAILED')

            # read counters afterwards
            rc = ifcs_ctypes.ifcs_devport_stats_get(
                node_id, devport, count,
                compat_pointer(counter_ids,
                               ifcs_ctypes.ifcs_devport_stats_id_t),
                compat_pointer(counters_aft, ctypes.c_uint64),
                pointer(actual_count))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            assert counters_aft[0] == (counters_bef[0] + 1)

        #Put the ports out of loopback
        ports_out_of_lb(node_id, first_port, num_ports)
        #log("MAC counter incremented",rdb_val.value,rda_val.value)
        return 'PASSED'

    def pktlb(self):
        global lb_pkt_cnt
        global rx_verify_status_lb
        node_id = self.cli.node_id
        attr = ifcs_ctypes.ifcs_attr_t()
        vni_attr = ifcs_ctypes.ifcs_attr_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        stp_hdl = ifcs_ctypes.ifcs_handle_t()
        mac_addr_t = c_uint8 * 6

        lb_pkt_cnt = 0
        try:
            per_port_pkt_cnt = int(self.arg_list.pop(0))
        except:
            per_port_pkt_cnt = 1
        rx_verify_status_lb = None
        port_cnt  = 4
        first_port = 1
        num_ports = first_port + port_cnt
        attr_count = 1
        attr_list_p = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        # Disable all the ports
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin disable:" +\
                str(devport)

        # Set all the ports in loopback
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port loopback set:" +\
                str(devport)

        # Enable all the ports
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin enable:" +\
                str(devport)

        # Wait for all ports to go link-up for 5 secs
        wait_time=0
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS;
        attr_list_p[0].value.u32 = 0;
        actual_count = c_uint32()
        link_status=True
        while wait_time<5:
            link_status=True
            for devport in range(first_port, num_ports):
                rc = ifcs_ctypes.ifcs_devport_attr_get (node_id, devport, 1,
                                 compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t), pointer(actual_count));
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin enable:" +\
                    str(devport)

                if (attr_list_p[0].value.u32 != 1):
                    link_status=False
            if link_status:
                break;
            else:
                wait_time+=0.1
                time.sleep(0.1)

        #assert link_status == True, "Not all devports are up"

        # Set up the listener
        cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(rx_verify_lb)
        ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(node_id, None, cbfn)

        l2vni = 0x64

        ###### VNI CONFIG ######
        # Create VNI and add members
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(l2vni)
        ret = ifcs_ctypes.ifcs_l2vni_create(node_id, pointer(l2vni_hdl), 0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
               "ERR during L2VNI creation " + str(l2vni)

        ctc_trap_handle = create_ctc_trap(node_id)

        ####### STEP0 #######
        ###### STP CONFIG #######
        stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
        ret = ifcs_ctypes.ifcs_stp_create(node_id, pointer(stp_hdl),
                                         0, pointer(attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST, "STP instance creation FAILED"

        dst_sp_hdl = getSysportHandleFromDevPort(node_id, 0)
        dst_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(dst_sp_hdl)
        mbr1 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        member_count = 1
        member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

        member_attr_count = 0
        member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

        member_list[0] = mbr1

        ret = ifcs_ctypes.ifcs_l2vni_member_add(node_id, l2vni_hdl,
                                     member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                     member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
               "ERR during L2VNI mbr add " + str(l2vni)

        stp_attr_count = 1
        stp_attr = ifcs_ctypes.ifcs_attr_t()
        stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
        stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;

        ret = ifcs_ctypes.ifcs_stp_port_add(node_id, stp_hdl, member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),\
                                     stp_attr_count, pointer(stp_attr))
        #ret = ifcs_ctypes.ifcs_stp_port_attr_set(node_id, stp_hdl, mbr1,\
        #                             stp_attr_count, pointer(stp_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
               "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                str(l2vni) + ", Port Hdl: " + str(hex(mbr1.value))


        # 1.2
        ###### FDB Config #######
        attr_count = 4
        attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 1)
        dst_port_hdl = ifcs_ctypes.ifcs_handle_t()
        dst_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(dst_sp)

        l2entry_dst = ifcs_ctypes.ifcs_l2_entry_key_t
        l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
        l2_entry.key_type = ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
        l2_entry.key.mac_l2vni.mac_addr = mac_addr
        l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
        l2entry_dst = l2_entry

        attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
        attr[0].value.handle = dst_port_hdl
        attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
        attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
        attr[2].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY
        attr[2].value.fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_DROP
        attr[3].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY
        attr[3].value.ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
        attr[3].value.ctc_policy.trap_handle = ctc_trap_handle
        rc = ifcs_ctypes.ifcs_l2_entry_create(node_id, pointer(l2entry_dst), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        assert rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "Create FDB entry FAILED: rc = [" + str(rc) + "]"

        l2entry_array = (ifcs_ctypes.ifcs_l2_entry_key_t * num_ports)()
        src_port_hdl = ifcs_ctypes.ifcs_handle_t()

        # Set up an L2entry with CTC
        for devport in range(first_port, num_ports):
            src_sp_hdl = getSysportHandleFromDevPort(node_id, devport)
            src_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(src_sp_hdl)

            ####### STEP1 #######
            # 1.1

            mbr2 = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)

            member_count = 1
            member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

            member_attr_count = 0
            member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()

            member_list[0] = mbr2

            ret = ifcs_ctypes.ifcs_l2vni_member_add(node_id, l2vni_hdl,
                                         member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                         member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
            assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
                   "ERR during L2VNI mbr add " + str(l2vni)

            stp_attr_count = 1
            stp_attr = ifcs_ctypes.ifcs_attr_t()
            stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;
            #ret = ifcs_ctypes.ifcs_stp_port_attr_set(node_id, stp_hdl, mbr2,\
            #                             stp_attr_count, pointer(stp_attr))
            ret = ifcs_ctypes.ifcs_stp_port_add(node_id, stp_hdl, member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),\
                                         stp_attr_count, pointer(stp_attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS or ret == ifcs_ctypes.IFCS_EXIST,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni) + ", Port Hdl: " + str(hex(mbr2.value))

            mac_addr = mac_addr_t(0, 0, 0, 0, 0, devport+1)
            src_port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(src_sp)
            attr_count = 2

            l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
            l2_entry.key_type = ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI
            l2_entry.key.mac_l2vni.mac_addr = mac_addr
            l2_entry.key.mac_l2vni.l2vni = l2vni_hdl
            l2entry_array[devport] = l2_entry
            attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
            attr[0].value.handle = src_port_hdl
            attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
            attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
            rc = ifcs_ctypes.ifcs_l2_entry_create(node_id, compat_pointerAtIndex(l2entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, devport), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            assert rc == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "Create FDB entry FAILED: rc = [" + str(rc) + "]"


            ssp_attr = ifcs_ctypes.ifcs_attr_t()
            ssp_attr.id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
            ssp_attr.value.u32 = l2vni
            ret = ifcs_ctypes.ifcs_sysport_attr_set(node_id, src_sp_hdl, 1, pointer(ssp_attr))
            assert ret == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "SSP default PVID set FAILED: ret = [" + str(ret) + "]"


        # Set STP instance for created VNI
        vni_attr.id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
        vni_attr.value.handle = stp_hdl
        ret = ifcs_ctypes.ifcs_l2vni_attr_set(node_id, l2vni_hdl, 1, pointer(vni_attr))
        assert ret == ifcs_ctypes.IFCS_SUCCESS or rc == ifcs_ctypes.IFCS_EXIST, "STP instance vni attr set FAILED"

        # Send packets
        for devport in range(first_port, num_ports):
            dst_sp_hdl = getSysportHandleFromDevPort(node_id, devport)
            data_bytes = compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(1)
            data_bytes += compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(devport+1)
            data_bytes += compat_chr(0x81) + compat_chr(0x00) + compat_chr(0x00) + compat_chr(0x64)
            length = 100
            rx_queue = 0
            for j in range(length - 16):
                data_bytes += compat_chr(0xff)

            '''
            # CPU packet: set the vf2 queue for proper operation
            packet = pkt.ldh_vf2(0, devport-1, rx_queue) + data_bytes
            length += 12

            p = cast(packet, POINTER(c_uint8));
            tx_ring = 0
            rc = ifcs_ctypes.im_hostif_send_packet_zcopy(node_id, tx_ring, p, length)
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log('send_packet FAILED')
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete Trap entry FAILED: rc = [" + str(rc) + "]"
            '''
            try:
                packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
                ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
                packet.tx_type = 1
                packet.trap_handle = 0 # is ignored
                packet.ssp = 0 #dst_sp_hdl # is ignored
                packet.dsp = dst_sp_hdl
                packet.queue_num = 0 # is ignored
                packet.ring_num = 0
                packet.pkt_buf = cast(data_bytes, c_void_p)
                packet.pkt_buf_len = length
            except Exception as e:
                log("exc", e)

            pkt_cnt = 0;

            while pkt_cnt < per_port_pkt_cnt:
                rc = ifcs_ctypes.ifcs_hostif_send_packet(node_id, pointer(packet))
                if (rc != ifcs_ctypes.IFCS_SUCCESS):
                    log_err('Packet send to switch FAILED')
                pkt_cnt = pkt_cnt + 1

        retry_cnt = 0;
        # Verify if the packets were received
        while rx_verify_status_lb == None or lb_pkt_cnt < ((num_ports-first_port)*per_port_pkt_cnt):
            time.sleep(0.1)
            retry_cnt = retry_cnt + 1
            if (retry_cnt > 10):
                rx_verify_status_lb = 'FAILED'
                break

        # Disable all the ports
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
        attr_count = 1

        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port admin disable:" +\
                str(devport)

        # Take all the ports out of loopback
        attr_list_p[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK;
        attr_list_p[0].value.u32 = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE;
        attr_count = 1
        for devport in range(first_port, num_ports):
            rc = ifcs_ctypes.ifcs_l2_entry_delete(node_id, compat_pointerAtIndex(l2entry_array, ifcs_ctypes.ifcs_l2_entry_key_t, devport))
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during l2entry delete on devport :" +\
                str(devport)

            rc = ifcs_ctypes.ifcs_devport_attr_set (node_id, devport,
                             attr_count, compat_pointer(attr_list_p, ifcs_ctypes.ifcs_attr_t));
            assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during port loopback remove:" +\
                str(devport)

        rc = ifcs_ctypes.ifcs_l2_entry_delete(node_id, pointer(l2entry_dst))
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                "ERR during l2entry delete on devport :" +\
                str(0)

        rc = ifcs_ctypes.ifcs_l2vni_delete(node_id, l2vni_hdl)
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
              "ERR during l2vni delete:" +\
              str(l2vni)

        rc = ifcs_ctypes.ifcs_stp_delete(node_id, stp_hdl)
        assert rc == ifcs_ctypes.IFCS_SUCCESS,\
              "ERR during stp delete:" +\
              str(ifcs_ctypes.IFCS_HANDLE_VALUE(stp_hdl))

        delete_ctc_trap(node_id, ctc_trap_handle)
        # Delete eveeything that we created
        return rx_verify_status_lb

    # Packet tests: There are four types of packet tests
    #
    #      CPU-CPU: This test checks if CPU RX and TX are fine
    #               This test also requires RX/TX DMA and RX/TX
    #               interrupts to be working
    #
    #       CPU-FP: This test checks if a packet from CPU goes
    #               to the MAC that is connected to a Front port
    #
    #     Loopback: This test puts ports in loopback, sends packets
    #               to those ports and checks if the packets are received
    #               back, using the CPU RX path
    #
    def pkt(self, args):
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            cmd_name = self.arg_list.pop(0)
        except:
            cmd_name = 'all'

        #node_model_server_dbglvl_set(0, 0, 5)

        log("######## Running PACKET tests: ########")
        if cmd_name == 'cpucpu' or cmd_name == 'all':
            return_str = self.cpucpu()
            log("CPU RX/TX packet test\t\t:\t" + return_str)
        if cmd_name == 'lb' or cmd_name == 'all':
            return_str = self.pktlb()
            log("Packet Loopback test\t\t:\t" + return_str)
        #if cmd_name == 'cpufp' or cmd_name == 'all':
        if cmd_name == 'cpufp':
            return_str = self.cpufp()
            log("CPU FP packet test\t\t:\t" + return_str)
        pass

    def snake(self, args):
        snake_obj = Snake(self.cli)
        return snake_obj.run_cmd(args)

    def spst(self, args):
        try:
            snake_obj = Spst(self.cli)
            snake_obj.run_cmd(args)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                log_err("{}".format(ve))
            else:
                # Unlikely: re-raise unexpected exception
                log_dbg(1, "spst: {}".format(ve))
                raise ve

    def l3spst(self, args):
        try:
            snake_obj = L3spst(self.cli)
            snake_obj.run_cmd(args)
        except ValueError as ve:
            if L3spst.device_access_error_exc_msg in "{}".format(ve):
                log_err("{}".format(ve))
            else:
                # Unlikely: re-raise unexpected exception
                log_dbg(1, "L3spst: {}".format(ve))
                raise ve

    def tunspst(self, args):
        try:
            snake_obj = Tunspst(self.cli)
            snake_obj.run_cmd(args)
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                log_err("{}".format(ve))
            else:
                # Unlikely: re-raise unexpected exception
                log_dbg(1, "Tunspst: {}".format(ve))
                raise ve

    def stress(self, args):
        stress_obj = Stress(self.cli)
        stress_obj.run_cmd(args)
        pass

    def snake_flood(self, args):
        snake_obj = SnakeFlood(self.cli)
        snake_obj.run_cmd(args)
        pass

    def l3snake(self, args):
        l3snake_obj = L3snake(self.cli)
        l3snake_obj.run_cmd(args)
        pass

    def netdev(self, args):
        netdev_obj = Netdev(self.cli)
        netdev_obj.run_cmd(args)

    def serdes(self, args):
        serdes_obj = Serdes(self.cli)
        return serdes_obj.run_cmd(args)

    def watson(self, args):
        device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        if device_type != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            log_err("watson command is not supported for chip type {}".format(device_type))
            return ifcs_ctypes.IFCS_INVAL

        if self.watson_obj is None:
            self.watson_obj = Watson(self.cli)
        return self.watson_obj.run_cmd(args)

    def mbist(self, args):
        '''
        Run SMS MBIST Commands
        '''
        mbist_obj = Mbist(self.cli)
        return mbist_obj.run_cmd(args)

    def memrw(self, args):
        memrw_obj = Memrw(self.cli)
        memrw_obj.run_cmd(args)
        pass

    def tcam_test(self, args):
        tcam_test_obj = Tcam_test(self.cli)
        tcam_test_obj.run_cmd(args)
        pass

    def oly_dbg(self, args):
        '''
        Set the OLY MISC access mode
        '''

        if self.cli.node_id is None:
            log("Err: Invalid node ID, trying to run mbist prior to node create")
            return
        arg_list = shlex.split(args)

        rc = ifcs_ctypes.ifcs_status_t()
        try:
            enable = int(arg_list[2])
        except:
            log("Invalid param")
            self.help()

        if(enable == 1):
            mode = "DBG I2C"
        else:
            mode = "GPIO"

        rc = ifcs_ctypes.im_node_set_oly_dbg(self.cli.node_id, enable)
        if (rc != ifcs_ctypes.IFCS_SUCCESS):
            log("Error setting %s mode" % mode)
        else:
            log("OLY %s selected" % mode)

#ifdef OLY_MISC_DBG_ACCESS
    def i2c(self, args):
        '''
        Set the OLY MISC access mode
        '''
        try:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            cmd_name = self.arg_list.pop(0)
        except:
            cmd_name = 'all'

        log("######## Running I2C tests: #########")
        if cmd_name == 'read' or cmd_name == 'all':
            try:
                #Read the JTAG IDCODE reg
                regval = pci.read32(ifcs_ctypes.JTAG_IDCODE_O);

                log("JTAG ID CODE: 0x%x" % regval)

                if (regval != 0x68c057f):
                    log("OLY MISC i2c read test\t\t:\tFAILED")
                else:
                    log("OLY MISC i2c read test\t\t:\tPASSED")

            except Exception as ex:
                self.cli.error()
                log("i2c read: ", type(ex).__name__, ex.args)
                return

        if cmd_name == 'write' or cmd_name == 'all':
            try:
                #Write to the scratch pad register
                pci.write32(ifcs_ctypes.SCRATCH_PAD0, 0xAAAA5555);

                #Read and verify the scratch pad contents
                regval = pci.read32(ifcs_ctypes.SCRATCH_PAD0);
                if (regval != 0xAAAA5555):
                    log("OLY MISC i2c write test\t\t:\tFAILED")
                else:
                    log("OLY MISC i2c write test\t\t:\tPASSED")

            except Exception as ex:
                self.cli.error()
                log("i2c write test read: ", type(ex).__name__, ex.args)
                return
        pass
#endif


    def alltests(self, args):
        self.pci(args)
        self.pen(args)
        #self.intr(args)
        self.pkt(args)
        # TODO - enable or not
        #self.i2c(args)

        pass

    def show(self, args):
        pass

    def diag_help(self, args):
        self.cli.error()
        log("Usage: \n", \
              "PCI    diag tests - diagtest pci  <read/write>\n", \
              "Pen    diag tests - diagtest pen  <sync/blocksync/blockasync>\n", \
              "Intr   diag tests - diagtest intr <async/pkt/ecc>\n", \
              "Pkt    diag tests - diagtest pkt  <cpucpu/cpufp/lb>\n", \
              "Serdes diag tests - diagtest serdes <prbs/aapl/mapping/eth/mgmt>\n", \
              "Snake  diag tests - diagtest snake <config/config_show/start_traffic/stop_traffic/gen_report/verify/unconfig>\n", \
              "Snake_Flood  diag tests - diagtest snake_flood <config/config_show/start_traffic/stop_traffic/gen_report/verify/unconfig>\n", \
              "L3snake diag tests - diagtest l3snake <config/config_show/start_traffic/stop_traffic/gen_report/verify/unconfig>\n", \
              "Stress diag tests  - diagtest stress <start/stop>\n", \
              "Spst    diag tests - diagtest spst <config/start_traffic/stop_traffic/unconfig>\n", \
              "L3spst  diag tests - diagtest l3spst <config/start_traffic/stop_traffic/unconfig>\n", \
              "Tunspst diag tests - diagtest tunspst <config/start_traffic/stop_traffic/unconfig>\n", \
              "mbist  diag tests - diagtest mbist\n", \
              "All    diag tests - diagtest all\n", \
              "Show this text  - diagtest help or ?\n")

    def help(self, args):
        help_menu = {
            'serdes': self.serdes,
            'snake': self.snake,
            'snake_flood': self.snake_flood,
            'l3snake': self.l3snake,
            'watson': self.watson,
        }

        self.arg_list = args.split()
        try:
            help_menu[self.arg_list[1]](args)
        except BaseException:
            self.diag_help(args)
