#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import fnmatch
from utils.compat_util import *
from verbosity import *
from ctypes import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.node import Node as node
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']
from testutil.penrw import *
from functools import cmp_to_key
from testutil import pci

global ib_list
global bist
global repair
global stuck1
global stuck0
global verbose
global log_redirect
global cli

cli = None  # CLI object

log_redirect = True

MEM_INIT_PEN_RETRY_COUNT = 1000

# Test status codes
TCAM_TEST_PASS  = 0
TCAM_TEST_FAIL  = 1
TCAM_TEST_ABORT = 2

TCAM_BIST_TRIG_PEN_LIST  = []
TCAM_BIST_TRIG_PEN_LIST_TL7 = [
#('EMT20_ABB0_TCAM_BIST_CTRL'   , 'EMT20_ABB0_TCAM_BIST_STATUS'    ),
(1756                           , 1757),
#('IMT10_TCAM_BIST_CTRL'        , 'IMT10_TCAM_BIST_STATUS'         ),
(175                            , 176),
#('IMT20_TCAM_BIST_CTRL'        , 'IMT20_TCAM_BIST_STATUS'         ),
(299                            , 300),
#('IMT30_TCAM_BIST_CTRL'        , 'IMT30_TCAM_BIST_STATUS'         ),
(478                            , 479),
#('IMT40_ABB0_TCAM_BIST_CTRL'   , 'IMT40_ABB0_TCAM_BIST_STATUS'    ),
(843                            , 844),
#('IMT40_ABB1_TCAM_BIST_CTRL'   , 'IMT40_ABB1_TCAM_BIST_STATUS'    ),
(882                            , 883),
#('IMT40_ABB2_TCAM_BIST_CTRL'   , 'IMT40_ABB2_TCAM_BIST_STATUS'    ),
(1002                           , 1003),
#('IPRS1_PARSER_TCAM_BIST_CTRL' , 'IPRS1_PARSER_TCAM_BIST_STATUS'  ),
(39                             , 40),
#('IPRS2_PARSER_TCAM_BIST_CTRL' , 'IPRS2_PARSER_TCAM_BIST_STATUS'  ),
(92                             , 93),
#('LCM_TCAM_BIST_CTRL'          , 'LCM_TCAM_BIST_STATUS'           ),
(1127                           , 1128),
#('PRS2_TCAM_BIST_CTRL'         , 'PRS2_TCAM_BIST_STATUS'          ),
(255                            , 256),
]

TCAM_PEN_LIST = []
TCAM_PEN_LIST_TL7 = [
51,     #IPRS1_SIP_CC
52,     #IPRS1_DIP_CC
104,    #IPRS2_SIP_CC,
105,    #IPRS2_DIP_CC,
180,    #IMT1001,
181,    #IMT1002_IPV4_L2VNI,
264,    #ENTROPY_HASHKEY_CTRL,
373,    #IMT20_MKC,
374,    #IMT2003,
616,    #IMT30_MKC,
618,    #IMT3003_FIXED,
619,    #IMT3008A_EPD,
621,    #IMT3009A_EPD,
623,    #IMT3008B_1X_EPD,
627,    #IMT3009B_1X_EPD,
1143,   #CM_CTRL,
#ABB tcams
845,    #IMT40_ABB0_ABB_A1X,
847,    #IMT40_ABB0_ABB_B1X,
849,    #IMT40_ABB0_ABB_C1X,
851,    #IMT40_ABB0_ABB_D1X,
884,    #IMT40_ABB1_ABB_A1X,
886,    #IMT40_ABB1_ABB_B1X,
888,    #IMT40_ABB1_ABB_C1X,
890,    #IMT40_ABB1_ABB_D1X,
1004,   #IMT40_ABB2_ABB_C1X,
1006,   #IMT40_ABB2_ABB_D1X,
1758,   #EMT20_ABB0_ABB_A1X,
1760,   #EMT20_ABB0_ABB_B1X,
1762,   #EMT20_ABB0_ABB_C1X,
1764,   #EMT20_ABB0_ABB_D1X,
]

TCAM_PEN_LIST_TL10 = [
53,     #IPRS1_SIP_CC
55,     #IPRS1_DIP_CC
110,    #IPRS2_SIP_CC,
112,    #IPRS2_DIP_CC,
200,    #IMT1001,
201,    #IMT1002_IPV4_L2VNI,
288,    #ENTROPY_HASHKEY_CTRL,
427,    #IMT20_MKC,
429,    #IMT2003_1X
431,    #IMT2004_1X
694,    #IMT30_MKC,
696,    #IMT3003_FIXED,
697,    #IMT3008A_EPD,
699,    #IMT3009A_EPD,
701,    #IMT3008B_1X_EPD,
713,    #IMT3012_1X,
#707,   #IMT3009B_1X_EPD --> Not inited by default to TCAM LTU in TL10
1514,   #CM_CTRL,
#ABB tcams
1656,   #IMT40_ABB0_ABB_A1X,
1658,   #IMT40_ABB0_ABB_B1X,
1660,   #IMT40_ABB0_ABB_C1X,
1662,   #IMT40_ABB0_ABB_D1X,
1693,   #IMT40_ABB1_ABB_A1X,
1695,   #IMT40_ABB1_ABB_B1X,
1697,   #IMT40_ABB1_ABB_C1X,
1699,   #IMT40_ABB1_ABB_D1X,
1730,   #IMT40_ABB2_ABB_C1X,
1732,   #IMT40_ABB2_ABB_D1X,
2565,   #EMT20_ABB0_ABB_A1X,
2567,   #EMT20_ABB0_ABB_B1X,
2569,   #EMT20_ABB0_ABB_C1X,
2571,   #EMT20_ABB0_ABB_D1X,
]

MEM_INIT_PEN_LIST = []
MEM_INIT_PEN_LIST_TL7 = [
1739,   #EMT20_ABB0_ABB_MEM_INIT,
1374,   #EPRS_PRS_MEM_INIT,
232,    #PRS2_MEM_INIT
138,    #IMT10_MEM_INIT,
268,    #IMT20_MEM_INIT,
427,    #IMT30_MEM_INIT,
826,    #IMT40_ABB0_ABB_MEM_INIT,
865,    #IMT40_ABB1_ABB_MEM_INIT,
985,    #IMT40_ABB2_ABB_MEM_INIT,
0,      #IPRS1_PRS_MEM_INIT,
53,     #IPRS2_PRS_MEM_INIT,
1044,   #LCM_MEM_INIT,
]

MEM_INIT_PEN_LIST_TL10 = [
2544,   #EMT20_ABB0_ABB_MEM_INIT,
1953,   #EPRS_PRS_MEM_INIT,
252,    #PRS2_MEM_INIT
152,    #IMT10_MEM_INIT,
292,    #IMT20_MEM_INIT,
502,    #IMT30_MEM_INIT,
1639,   #IMT40_ABB0_ABB_MEM_INIT,
1676,   #IMT40_ABB1_ABB_MEM_INIT,
1713,   #IMT40_ABB2_ABB_MEM_INIT,
0,      #IPRS1_PRS_MEM_INIT,
57,     #IPRS2_PRS_MEM_INIT,
1379,   #LCM_MEM_INIT,
]

# To do only for TL10 while doing mem_init
MEM_INIT_SKIP_PEN_FLD = []
MEM_INIT_SKIP_PEN_FLD_TL7 = []
MEM_INIT_SKIP_PEN_FLD_TL10 = [
502, #IMT30_MEM_INIT,
]

IMT3008B_1X_EPD_PEN_ID = []
IMT3008B_1X_EPD_PEN_ID_TL7 = [ '623' ]
IMT3008B_1X_EPD_PEN_ID_TL10 = [ '701' ]

# To do only for TL10 while doing mem_init
skip_tcam_mem_init_flds_tl10 = [
1186,   #IMT3009B_TCAM_F
1187,   #IMT3009B_POLICY_F
]
#no skip fields in TL7 in mem_init
skip_tcam_mem_init_flds_tl7 = []

entry_vld_f_names = []
addr_f_names = []

# Obfuscated and non obfuscated names
entry_vld_f_names_tl7 = ['ENTRY_VLD_F', 'ENTRY_VLD_0_F', 'ENTRY_VLD_1_F', 'ENTRY_VLD_A0_F',
                     'ENTRY_VLD_B0_F', 'ENTRY_VLD_C0_F', 'ENTRY_VLD_D0_F',
                     '_TL_F129', '_TL_F417', '_TL_F498', '_TL_F1629', '_TL_F1828', '_TL_F1840', '_TL_F1853']
addr_f_names_tl7 = [ 'ADDR_F', '_TL_F168']

entry_vld_f_names_tl10 = ['ENTRY_VLD_F', 'ENTRY_VLD_0_F', 'ENTRY_VLD_1_F', 'ENTRY_VLD_A0_F',
                     'ENTRY_VLD_B0_F', 'ENTRY_VLD_C0_F', 'ENTRY_VLD_D0_F',
                     '_TL10_F130', '_TL10_F461', '_TL10_F544', '_TL10_F2795', '_TL10_F2991',
                     '_TL10_F3005', '_TL10_F3020']
addr_f_names_tl10 = [ 'ADDR_F', '_TL10_F188']


class Tcam_test(Command):
    def __init__(self, cli):

        self.cli = cli
        self.arg_list = []
        super(Tcam_test, self).__init__()


    def __del__(self):
        return

    def run_cmd(self, args):

        test_rc_msg = "PASSED"
        self.arg_list = shlex.split(args)
        self.arg_list.pop(0)
        self.arg_list.pop(0)

        mem_parser = argparse.ArgumentParser(
            prog="diagtest tcam",
            description="TCAM memory test",
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)

        mem_parser.add_argument("-i",
                                "--ib",
                                dest="ib_list",
                                default="0,1,2,3,4,5",
                                help="List of IBs to run the mem test, 0x1f for all IBs (broadcast)")

        mem_parser.add_argument("-b",
                                "--bist",
                                dest="bist",
                                help="Run BIST on TCAM memory (no soft repair)",
                                action="store_true")

        mem_parser.add_argument("-r",
                                "--repair",
                                dest="repair",
                                help="Run BIST on TCAM memory with soft repair",
                                action="store_true")

        mem_parser.add_argument("-1",
                                "--stuck-1",
                                dest="stuck1",
                                help="Run STL test for stuck-1",
                                action="store_true")

        mem_parser.add_argument("-0",
                                "--stuck-0",
                                dest="stuck0",
                                help="Run STL test for stuck-0",
                                action="store_true")

        mem_parser.add_argument("-v",
                                "--verbose",
                                dest="verbose",
                                help="Enable verbose output",
                                action="store_true")


        args = mem_parser.parse_args(self.arg_list)
        global cli
        cli = self.cli
        rc = TCAM_TEST_PASS
        try:
            rc = run_tcam_tests(self, args)
        except Exception as ex:
            return rc

        return rc

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

def get_tcam_status_str(rc):
    if rc == TCAM_TEST_ABORT:
        err_str = "ABORT"
    elif rc == TCAM_TEST_FAIL:
        err_str = "FAIL"
    elif rc == TCAM_TEST_PASS:
        err_str = "PASS"
    else:
        err_str = ""

    return err_str

def test_err_log(err, msg):
    err_type = get_tcam_status_str(err)
    msg = err_type + ": " + msg
    log_err(msg)

def get_pen_info(pen_id):
    peninfo = ifcs_ctypes.pen_t()
    ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
    return peninfo

# Given a pen, return it basepen
def get_base_pen(pen_id):
    base_pen = pen_id       # Default
    peninfo = ifcs_ctypes.get_pen_info(pen_id)
    if peninfo.pen_prop:
       ppinfo = cast(peninfo.pen_prop, POINTER(ifcs_ctypes.pen_prop_t))
       base_pen = ppinfo.contents.resource
    return base_pen

# Given a pen, return it full
def get_full_pen(pen_id):
    full_pen = pen_id       # Default
    peninfo = ifcs_ctypes.get_pen_info(pen_id)
    if peninfo.pen_prop:
       ppinfo = cast(peninfo.pen_prop, POINTER(ifcs_ctypes.pen_prop_t))
       full_pen = ppinfo.contents.full_pen
    return full_pen

def get_pen_id(pen_str):
    try:
        pen_id = int(pen_str)
    except ValueError:
        try:
            pen_id = penstr_num_dict[pen_str.upper()]
        except KeyError:
            pen_id = -1
    return pen_id

def get_field_id(field_str):
    try:
        field_id = int(field_str)
    except ValueError:
        try:
            field_id = penfldstr_num_dict[field_str.upper()]
        except KeyError:
            field_id = -1
    return field_id

def get_pen_name(pen_id):
    ''' Return Pen name from Pen num '''

    if pen_id == -1:
        return "PEN_INVALID"

    pen_str = c_char_p(b" " * 64)
    rc = ifcs_ctypes.node_get_pen_name(0, pen_id, pen_str, 64)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Pen:" + str(pen_id)
    return compat_bytesToStr(pen_str.value)


def get_pen_num_entries(pen_id, pen_name):
    """
    Retrieve the number of entries for a given Pen.

    This function queries the hardware or SDK for the number of entries associated with the specified pen_id.
    If the initial query returns 1 entry and additional pen properties are available, it fetches the actual
    number of entries from the pen's property structure. Returns -1 and logs an error if the pen_id is invalid
    or if any query fails.

    Args:
        pen_id (int): The numeric identifier for the Pen.
        pen_name (str): The human-readable name of the Pen, used for logging.

    Returns:
        int: The number of entries for the Pen, or -1 if an error occurs.
    """

    if pen_id < 0:
        log_err("Invalid pen id {} pen name {}".format(pen_id, pen_name))
        return -1

    peninfo = ifcs_ctypes.pen_t()
    rc = ifcs_ctypes.node_get_pen_info(0, pen_id, pointer(peninfo))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Get pen info failed with rc {} for pen id {} pen name {}".format(
                rc, pen_id, pen_name))
        return -1
    num_entries = peninfo.num_entries

    if num_entries == 1 and peninfo.pen_prop:
        propinfo = ifcs_ctypes.pen_prop_t()
        rc = ifcs_ctypes.node_get_pen_prop(0, pen_id, pointer(peninfo),
                                           pointer(propinfo))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Get pen prop failed with rc {} for pen id {} pen name {}".
                    format(rc, pen_id, pen_name))
            return -1
        num_entries = propinfo.size
    return num_entries


def get_field_name(field_id):
    ''' Return Field name from Field num '''

    if field_id == -1:
        return "PEN_FNAME_INVALID"

    fld_str = c_char_p(b" " * 32)
    rc = node_get_pen_field_name(0, field_id, fld_str, 32)
    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Couldnt get name for Field:" + str(field_id)
    return compat_bytesToStr(fld_str.value)

def get_fld_values(pen_id, value):

    num_flds, fldinfo = get_flds_from_pen_id(pen_id)

    flds = []
    for findx in range(num_flds.value):
        fname = fldinfo[findx].fname
        fstr = get_field_name(fname)
        fwidth = fldinfo[findx].width

        flds.append((fname, value))

    return flds

def remove_tcam_flds(rm_ids, fld):
    result = []
    for pair in fld:
        id_value = pair[0]
        if id_value not in rm_ids:
            result.append(pair)
    return result

def pen_write(pen_id, index, fld_vals, ib):
    global log_redirect
    if log_redirect:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = new_stdout = compat_StringIO()
        sys.stderr = new_stderr = compat_StringIO()

    try:
        write_platform_pen(pen_id, index, fld_vals, ib=ib)
    except Exception as ex:
        if log_redirect:
            response = new_stdout.getvalue()
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            log_err(response)
        raise ex

    if log_redirect:
        response = new_stdout.getvalue()
        sys.stdout = old_stdout
        sys.stderr = old_stderr

def write_pen_data(pen_id, index, ib_list, fld_val):
    index = 0
    pen_name = get_pen_name(pen_id)
    num_flds, fldinfo = get_flds_from_pen_id(pen_id)

    # Populate all flds with fld_val
    fld_vals = get_fld_values(pen_id, fld_val)

    # Only for TCAM Fields exclude few MEM_INIT fields
    if (pen_id in MEM_INIT_SKIP_PEN_FLD_TL10):
        fld_vals_post_skip = remove_tcam_flds(skip_tcam_mem_init_flds, fld_vals)
        fld_vals = fld_vals_post_skip
    if verbose:
        log("Writing pen %s fld_vals: %s" %(pen_name, fld_vals))
    for ib in ib_list:
        try:
            # Write the pen with data (fld_vals)
            pen_write(pen_id, index, fld_vals, ib=ib)
        except Exception as ex:
            test_err_log(TCAM_TEST_ABORT, str(ex))
            raise ex

def pen_read(pen_id, index, ib):
    pen_name = get_pen_name(pen_id)
    global log_redirect
    if log_redirect:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = new_stdout = compat_StringIO()
        sys.stderr = new_stderr = compat_StringIO()

    try:
        read_data = read_platform_pen(pen_id, index, ib=ib)
    except Exception as ex:
        if log_redirect:
            response = new_stdout.getvalue()
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            log_err(response)
        msg = ("Error reading from pen %s on IB%d"% (pen_name, ib))
        log_err(msg)
        raise ex

    if log_redirect:
        response = new_stdout.getvalue()
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    return read_data

def execute_cmd(cmd, return_output=True, log_to_file=True):
    """ Runs a command and capture output.
    Args:
        cmd: command to execute
        return_output: whether to return output
        log_to_file: whether to save output to file
    Returns:
        command output
    Raises:
        none
    """
    global cli
    ret_buf = {}
    cmd_str = "SHELL:: CMD:: {}".format(cmd)
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    old_cli_stdout = cli.stdout
    sys.stdout = new_stdout = compat_StringIO()
    sys.stderr = new_stderr = compat_StringIO()
    cli.stdout = new_cli_stdout = compat_StringIO()
    rc = cli.onecmd(cmd)
    reply = new_stdout.getvalue()
    stderr_reply = new_stderr.getvalue()
    cli_stdout_reply = new_cli_stdout.getvalue()
    sys.stdout = old_stdout
    sys.stderr = old_stderr
    cli.stdout = old_cli_stdout
    ret_buf['cmd'] = cmd
    ret_buf['response'] = reply
    ret_buf['cli_out'] = cli_stdout_reply
    ret_buf['stderr'] = stderr_reply
    if return_output:
        return ret_buf

def test_tcam_bist(ib_list, repair=False):

    rc = TCAM_TEST_PASS
    for ctrl_pen, sts_pen in TCAM_BIST_TRIG_PEN_LIST:
        num_flds, fldinfo = get_flds_from_pen_id(sts_pen)
        ctrl_pen_name = get_pen_name(ctrl_pen)
        sts_pen_name = get_pen_name(sts_pen)
        index = 0

        if verbose:
            log(">>>>>Setting up BIST, CTRL pen: %s" %(ctrl_pen_name))
        # Write 0 to all flds
        try:
            write_pen_data(ctrl_pen, index, ib_list, 0)
        except Exception as ex:
            rc = TCAM_TEST_ABORT
            msg = ("Error writing to pen %s"% (ctrl_pen_name))
            test_err_log(rc, msg)
            return rc

        for ib in ib_list:
            try:
                if verbose:
                    log("Verifying pen fld == 0, IB%d pen: %s" %(ib, sts_pen_name))
                read_data = pen_read(sts_pen, index, ib=ib)

                for findx in range(num_flds.value):
                    fname = fldinfo[findx].fname
                    fstr = get_field_name(fname)
                    fwidth = fldinfo[findx].width
                    # Check if any field is set
                    if fwidth < 32:
                        if read_data[findx][1] != 0:
                            msg = ("Status pen fld non zero for IB%d pen: %s fld: %s fld_val: 0x%x" \
                                    %(ib, sts_pen_name, fstr, read_data[findx][1]))
                            rc = TCAM_TEST_FAIL
                            test_err_log(rc, msg)
                    else:
                        num_bytes = compat_division(fwidth + 7, 8)
                        for n in range(num_bytes):
                            # Check if any bit is set
                            if read_data[findx][1][n] != 0:
                                msg = ("Status pen fld non zero for IB%d pen: %s fld: %s index: %d fld_val: 0x%x" \
                                        %(ib, sts_pen_name, fstr, n, read_data[findx][1][n]))
                                rc = TCAM_TEST_FAIL
                                test_err_log(rc, msg)

            except Exception as ex:
                rc = TCAM_TEST_ABORT
                msg = ("Error reading pen %s on %s"% (sts_pen_name, ib))
                test_err_log(rc, msg)
                return rc

        if repair == True:
            # Set repair mode
            if verbose:
                log("Setting repair mode pen: %s" %(ctrl_pen_name))
            try:
                write_pen_data(ctrl_pen, index, ib_list, 0x4)
            except Exception as ex:
                rc = TCAM_TEST_ABORT
                msg = ("Error writing to ctrl pen %s for repair mode"% (ctrl_pen_name))
                test_err_log(rc, msg)
                return rc

            # Start BIST
            if verbose:
                log("Starting BIST, ctrl pen: %s" %(ctrl_pen_name))
            try:
                write_pen_data(ctrl_pen, index, ib_list, 0x5)
            except Exception as ex:
                rc = TCAM_TEST_ABORT
                msg = ("Error writing to ctrl pen %s for BIST start"% (ctrl_pen_name))
                test_err_log(rc, msg)
                return rc

            # Wait for 10 ms
            time.sleep(0.01)
        else:
            # Start BIST
            if verbose:
                log("Starting BIST pen: %s" %(ctrl_pen_name))
            try:
                write_pen_data(ctrl_pen, index, ib_list, 1)
            except Exception as ex:
                rc = TCAM_TEST_ABORT
                msg = ("Error writing to ctrl pen %s for BIST start"% (ctrl_pen_name))
                test_err_log(rc, msg)
                return rc
            # Wait for 1 ms
            time.sleep(0.001)


        for ib in ib_list:
            try:
                if verbose:
                    log("Reading BIST status on IB%d pen: %s" %(ib, sts_pen_name))
                read_data = pen_read(sts_pen, index, ib=ib)
                for findx in range(num_flds.value):
                    fname = fldinfo[findx].fname
                    fstr = get_field_name(fname)
                    fwidth = fldinfo[findx].width
                    if fwidth < 32:
                        # Check if any even bit is set
                        if (read_data[findx][1] & 0x5555) != 0:
                            rc = TCAM_TEST_FAIL
                            msg = ("Status pen fld non zero for IB%d pen: %s fld: %s fld_val: 0x%x" \
                                    %(ib, sts_pen_name, fstr, read_data[findx][1]))
                            test_err_log(rc, msg)

                    else:
                        num_bytes = compat_division(fwidth + 7, 8)
                        for n in range(num_bytes):
                            # Check if any even bit is set
                            if (read_data[findx][1][n] & 0x55) != 0:
                                rc = TCAM_TEST_FAIL
                                msg = ("Status pen fld non zero for IB%d pen: %s fld: %s index: %d fld_val: 0x%x" \
                                    %(ib, sts_pen_name, fstr, n, read_data[findx][1][n]))
                                test_err_log(rc, msg)
            except Exception as ex:
                rc = TCAM_TEST_ABORT
                msg = ("Error reading pen %s on %s for BIST status"% (sts_pen_name, ib))
                test_err_log(rc, msg)
                return rc

        # Write 0 to all flds - reset control
        if verbose:
            log("Resetting BIST on IB%d pen: %s" %(ib, ctrl_pen_name))

        try:
            write_pen_data(ctrl_pen, index, ib_list, 0)
        except Exception as ex:
            rc = TCAM_TEST_ABORT
            msg = ("Error writing to ctrl pen %s for BIST reset"% (ctrl_pen_name))
            test_err_log(rc, msg)
            return rc

        if verbose:
            log("<<<<<Done BIST pen: %s\n" %(ctrl_pen_name))

    return rc

def _build_fld_dict(flds):
    fld_dict = {}
    for x in flds:
        key = x.split()[0][:-1].replace('"', '')
        """
        if key not in ['ENTRY_VLD_F', 'ENTRY_VLD_0_F', 'ENTRY_VLD_1_F',
                       'ENTRY_VLD_A0_F', 'ENTRY_VLD_B0_F',
                       'ENTRY_VLD_C0_F', 'ENTRY_VLD_D0_F', 'ADDR_F', '_TL_F129',
		       '_TL_F417', '_TL_F498', '_TL_F1629', '_TL_F1828', '_TL_F1840', '_TL_F1853', '_TL_F168']:
        """
        keys = entry_vld_f_names + addr_f_names
        if key not in keys:
            continue
        val = int(x.split()[1][:-1])
        fld_dict[key] = val

    return fld_dict

def test_tcam_slt_stuck1():
    rc = TCAM_TEST_PASS
    pen_name = ""
    ib = ""
    try:
        for pen_id in TCAM_PEN_LIST:
            pen_name = get_pen_name(pen_id)
            # Get number of entries from the PEN
            num_entries = get_pen_num_entries(pen_id, pen_name)
            if num_entries == -1:
                msg = "Stuck at 1 failure, get pen num entries failed for pen {}".format(
                    pen_name)
                rc = TCAM_TEST_ABORT
                test_err_log(rc, msg)
                return rc
            if pen_id in IMT3008B_1X_EPD_PEN_ID: # IMT3008B_1X_EPD
                # Profile A allocated 24k entries for IMT3008B_1X_EPD and 0 entries to IMT3009B_1X_EPD
                # Test script is overriding this to 12k for IMT3008B_1X_EPD and 12k to IMT3009B_1X_EPD
                num_entries = 12288

            if verbose:
                log("pen {} size {}".format(pen_name, num_entries))

            vld_fld_name = get_entry_vld_field_str(pen_id)
            for ib in ib_list:
                all_entries_passed = False
                # check for VALID BIT for all TCAM entries
                failing_entries = []
                loop_count = 0
                while all_entries_passed == False:
                    index = 0

                    cmd = "pen lookup ib %d %s %d" %(ib, pen_name, index)
                    if verbose:
                        log("PEN cmd: %s" % cmd)
                    output = execute_cmd(cmd)
                    flds = output['response'].split('\n')[3:-4]
                    if verbose:
                        log("pen lookup output: %s" % output['response'])

                    fld_dict = _build_fld_dict(flds)
                    entry_vld_f_key = compat_listkeys(fld_dict)[0] if compat_listkeys(fld_dict)[0] in entry_vld_f_names else compat_listkeys(fld_dict)[1]
                    addr_f_key = compat_listkeys(fld_dict)[1] if compat_listkeys(fld_dict)[1] in addr_f_names else compat_listkeys(fld_dict)[0]

                    if verbose:
                        log("Verifying IB%d pen %s %s %s ADDR_F %s" %(ib, pen_name, entry_vld_f_key, fld_dict[entry_vld_f_key], fld_dict[addr_f_key]))

                    # Check ENTRY_VLD_F
                    if fld_dict[entry_vld_f_key] == 1:
                        if fld_dict[addr_f_key] in failing_entries:
                            # if the stuck is seen again at the same address, its a genuine stuck at 1
                            rc = TCAM_TEST_FAIL
                            msg = ("Stuck at 1 failure, IB%d pen %s %s %s ADDR_F %s" %(ib, pen_name, entry_vld_f_key, fld_dict[entry_vld_f_key], fld_dict[addr_f_key]))
                            test_err_log(rc, msg)
                            # Do a Pen Read and report in the log file
                            cmd = "pen read ib {} {} {} {} 0".format(
                                ib, pen_name, fld_dict[addr_f_key],
                                vld_fld_name)
                            output = execute_cmd(cmd)
                            msg = "Stuck at 1 failure, Read output: {}".format(
                                output)
                            test_err_log(rc, msg)
                            return rc
                        else:
                            # Continue checking if there is another tcam entry has stuck-at-1
                            failing_entries.append(fld_dict[addr_f_key])
                            if verbose:
                                log("pen ib {} {} {} {} 0 appended to local array"
                                    .format(ib, pen_name, fld_dict[addr_f_key],
                                            vld_fld_name))

                        if len(failing_entries) > num_entries:
                            rc = TCAM_TEST_FAIL
                            msg = "Stuck at 1 failure on IB {}: captured {} entries, but pen '{}' reports size {}.".format(
                                ib, len(failing_entries), pen_name, num_entries)
                            test_err_log(rc, msg)
                            return rc

                        # clear the entry_vld_f_key and do another look up
                        if verbose:
                            log("loop count {} original pen lookup output: {}".
                                format(loop_count, output['response']))
                            log("Failure seen for IB{} pen {} {} {} ADDR_F {}".
                                format(ib, pen_name, entry_vld_f_key,
                                       fld_dict[entry_vld_f_key],
                                       fld_dict[addr_f_key]))
                        write_index = fld_dict[addr_f_key]
                        cmd = "pen write ib {} {} {} {} 0".format(
                            ib, pen_name, write_index, vld_fld_name)
                        if verbose:
                            log("clearing the failing Valid Entry using PEN cmd: {}"
                                .format(cmd))
                        output = execute_cmd(cmd)
                        if verbose:
                            log("after doing pen write / clearing the entry_vld_f_key / addr_f_key output of execute-cmd is: {}"
                                .format(output['response']))
                        loop_count += 1
                    else:
                        if verbose:
                            log("PEN cmd: {}".format(cmd))
                        all_entries_passed = True
                # if at least one entry was cleared and a lookup was done, print informational stats
                if len(failing_entries) > 0:
                    msg = "Additional {} lookups performed for IB {}: pen '{}' size {} total loops {}.".format(
                                len(failing_entries), ib, pen_name, num_entries, loop_count)
                    log (msg)

            if verbose:
                log("<<<<<Done CTRL pen: %s\n" %(pen_name))

        if verbose:
            log("\n")
    except Exception as ex:
        log("Full exception details:")
        import traceback
        traceback.print_exc()
        rc = TCAM_TEST_ABORT
        msg = "Stuck at 1 failure, Error for pen {} on ib {}, Exception: {} Exc_info: {}".format(
            pen_name, ib, ex, sys.exc_info())
        test_err_log(rc, msg)
        return rc

    return rc

def get_entry_vld_field_str(pen_id):
    pen_name = get_pen_name(pen_id)
    num_flds, fldinfo = get_flds_from_pen_id(pen_id)
    for findx in range(num_flds.value):
        fname  = fldinfo[findx].fname
        fstr   = get_field_name(fname)

        if fstr in entry_vld_f_names:
            idx = entry_vld_f_names.index(fstr)
            fld_name = entry_vld_f_names[idx]
            return fld_name

    log_err("ENTRY_VLD_*_F field not found!")
    raise Exception("ENTRY_VLD_*_F field not found!")

def test_tcam_slt_stuck0():
    rc = TCAM_TEST_PASS
    try:
        for pen_id in TCAM_PEN_LIST:
            pen_name = get_pen_name(pen_id)
            pen_info = get_pen_info(pen_id)
            vld_fld_name = get_entry_vld_field_str(pen_id)
            num_flds, fldinfo = get_flds_from_pen_id(pen_id)
            if verbose:
                log("PEN %s pen_info.num_entries: %d" % (pen_name, pen_info.num_entries))

            for ib in ib_list:
                for index in range(pen_info.num_entries):
                    cmd = "pen write ib %d %s %d %s 1" %(ib, pen_name, index, vld_fld_name)
                    if verbose:
                        log("PEN cmd: %s" % cmd)
                    output = execute_cmd(cmd)

                    cmd = "pen lookup ib %d %s %d" %(ib, pen_name, index)
                    if verbose:
                        log("PEN cmd: %s" % cmd)
                    output = execute_cmd(cmd)
                    flds = output['response'].split('\n')[3:-4]
                    fld_dict = _build_fld_dict(flds)
                    entry_vld_f_key = compat_listkeys(fld_dict)[0] if compat_listkeys(fld_dict)[0] in entry_vld_f_names else compat_listkeys(fld_dict)[1]
                    addr_f_key = compat_listkeys(fld_dict)[1] if compat_listkeys(fld_dict)[1] in addr_f_names else compat_listkeys(fld_dict)[0]

                    if verbose:
                        log("Verifying IB%d pen %s %s %s ADDR_F %s" %(ib, pen_name, entry_vld_f_key, fld_dict[entry_vld_f_key], fld_dict[addr_f_key]))

                    # Check ENTRY_VLD_F
                    if fld_dict[entry_vld_f_key] != 1 or fld_dict[addr_f_key] != index:
                        rc = TCAM_TEST_FAIL
                        msg = ("Stuck at 0 failure, IB%d pen %s %s %s ADDR_F %s" %(ib, pen_name, entry_vld_f_key, fld_dict[entry_vld_f_key], fld_dict[addr_f_key]))
                        test_err_log(rc, msg)

                    cmd = "pen write ib %d %s %d %s 0" %(ib, pen_name, index, vld_fld_name)
                    if verbose:
                        log("PEN cmd: %s" % cmd)
                    output = execute_cmd(cmd)

            if verbose:
                log("<<<<<Done CTRL pen: %s\n" %(pen_name))

        if verbose:
            log("\n")
    except Exception as ex:
        rc = TCAM_TEST_ABORT
        msg = ("Error TCAM operation pen %s"% (pen_name))
        test_err_log(rc, msg)
        return rc

    return rc

def test_tcam_slt_stuck01(ib_list, test):
    rc_pass = True
    for pen_id in MEM_INIT_PEN_LIST:
        num_flds, fldinfo = get_flds_from_pen_id(pen_id)
        pen_name = get_pen_name(pen_id)
        index = 0
        if verbose:
            log(">>>>>Initializing TCAM and Policy memories, CTRL pen: %s fld value 1" %(pen_name))
        # Write 1 to all flds
        try:
            write_pen_data(pen_id, index, ib_list, 1)
        except Exception as ex:
            rc = TCAM_TEST_ABORT
            msg = ("Error initializing TCAM and Policy memories, CTRL pen: %s fld value 1" %(pen_name))
            test_err_log(rc, msg)
            return rc

    for pen_id in MEM_INIT_PEN_LIST:
        num_flds, fldinfo = get_flds_from_pen_id(pen_id)
        pen_name = get_pen_name(pen_id)
        index = 0

        try:
            for ib in ib_list:
                retry_count = MEM_INIT_PEN_RETRY_COUNT
                if verbose:
                    log("Verifying pen fld == 0, IB%d pen: %s" %(ib, pen_name))

                goto_while = False
                while(retry_count):
                    # Check if all flds have been verified
                    if goto_while == False and retry_count != MEM_INIT_PEN_RETRY_COUNT:
                        break
                    read_data = pen_read(pen_id, index, ib=ib)
                    retry_count = retry_count - 1
                    goto_while = False
                    for findx in range(num_flds.value):
                        # Found a fld with non zero value, read again
                        if goto_while == True:
                            break
                        fname = fldinfo[findx].fname
                        fstr = get_field_name(fname)
                        fwidth = fldinfo[findx].width
                        if fwidth < 32:
                            if (read_data[findx][1] & 0x1) != 0:
                                if verbose:
                                    log("Status pen fld non zero for IB%d pen: %s fld: %s fld_val: 0x%x" \
                                        %(ib, pen_name, fstr, read_data[findx][1]))
                                # Found a fld with non zero value, read again
                                goto_while = True
                                break
                        else:
                            num_bytes = compat_division(fwidth + 7, 8)
                            for n in range(num_bytes):
                                # Check if any byte is set
                                if (read_data[findx][1][n] & 0x1) != 0:
                                    if verbose:
                                        log("Status pen fld non zero for IB%d pen: %s fld: %s index: %d fld_val: 0x%x" \
                                            %(ib, pen_name, fstr, n, read_data[findx][1][n]))
                                # Found a fld with non zero value, read again
                                goto_while = True
                                break
                if (retry_count == 0):
                    rc = TCAM_TEST_ABORT
                    msg = ("Time out waiting for flds to become 0 for pen %s on IB%d" %(pen_name, ib))
                    test_err_log(rc, msg)
                    return rc

        except Exception as ex:
            rc = TCAM_TEST_ABORT
            msg = ("Error reading pen %s on %s"% (pen_name, ib))
            test_err_log(rc, msg)
            return rc

    # Start doing tcam lookup and check if any hit
    if test == 0:
        rc = test_tcam_slt_stuck0()
    elif test == 1:
        rc = test_tcam_slt_stuck1()

    return rc

def run_tcam_tests(self, parse_args):
    """
    Run tests and exit.
    Args:
        parse_args: parsed arguments
    Returns:
        none
    Raises:
        none
    """
    global ib_list
    global bist
    global repair
    global stuck1
    global stuck0
    global verbose
    global log_redirect
    global cli
    global MEM_INIT_PEN_LIST
    global TCAM_PEN_LIST
    global skip_tcam_mem_init_flds
    global entry_vld_f_names
    global addr_f_names
    global MEM_INIT_SKIP_PEN_FLD
    global IMT3008B_1X_EPD_PEN_ID

    test_rc = TCAM_TEST_PASS


    ib_list  = parse_args.ib_list
    bist   = True if parse_args.bist else False
    repair = True if parse_args.repair else False
    stuck1 = True if parse_args.stuck1 else False
    stuck0 = True if parse_args.stuck0 else False
    verbose = True if parse_args.verbose else False
    rc = TCAM_TEST_PASS

    ib_list = [int(x, 16) for x in ib_list.split(",")]

    if verbose:
        log("Stopping event threads")
    ret = ifcs_ctypes.im_event_stop_all_threads(cli.node_id)
    if ret != ifcs_ctypes.IFCS_SUCCESS:
        rc = TCAM_TEST_ABORT
        test_err_log(rc, "Event thread stop failed")

    if verbose:
        log("Stopping driver threads")
    ret = ifcs_ctypes.im_driver_threads_stop(cli.node_id)
    if ret != ifcs_ctypes.IFCS_SUCCESS:
        rc = TCAM_TEST_ABORT
        test_err_log(rc, "Driver thread stop failed")

    if verbose:
        log("Stopping linkscan")
    attrCount = 1
    attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()
    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_LINKSCAN_ATTR_ENABLE)
    ifcs_ctypes.ifcs_attr_t_value_data_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_BOOL_FALSE)
    ret = ifcs_ctypes.ifcs_linkscan_attr_set(0, 1, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
    if ret != ifcs_ctypes.IFCS_SUCCESS:
        rc = TCAM_TEST_ABORT
        test_err_log(rc, "Linkscan disable failed")

    if rc != TCAM_TEST_PASS:
        return rc
    device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
    if (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10):
        log("This is TL10 device")
        LTU_CTRL_PEN_ID = 608
        MODE_F = 201
        LKUP_ID_F = 1245
        BLOCK_ID_F = 1246
        SCRUB_HALT_CTRL_F = 1248
        TCAM_BIST_TRIG_PEN_LIST = []
        TCAM_PEN_LIST = TCAM_PEN_LIST_TL10
        MEM_INIT_PEN_LIST = MEM_INIT_PEN_LIST_TL10
        MEM_INIT_SKIP_PEN_FLD = MEM_INIT_SKIP_PEN_FLD_TL10
        skip_tcam_mem_init_flds  = skip_tcam_mem_init_flds_tl10
        entry_vld_f_names   = entry_vld_f_names_tl10
        addr_f_names  = addr_f_names_tl10
        IMT3008B_1X_EPD_PEN_ID = IMT3008B_1X_EPD_PEN_ID_TL10
    else:
        log("This is TL7 device")
        IMT3008_BANK_CTRL_PEN_ID = 538
        TCAM_BIST_TRIG_PEN_LIST = TCAM_BIST_TRIG_PEN_LIST_TL7
        TCAM_PEN_LIST = TCAM_PEN_LIST_TL7
        MEM_INIT_PEN_LIST = MEM_INIT_PEN_LIST_TL7
        MEM_INIT_SKIP_PEN_FLD = MEM_INIT_SKIP_PEN_FLD_TL7
        skip_tcam_mem_init_flds  = skip_tcam_mem_init_flds_tl7
        entry_vld_f_names   = entry_vld_f_names_tl7
        addr_f_names  = addr_f_names_tl7
        IMT3008B_1X_EPD_PEN_ID = IMT3008B_1X_EPD_PEN_ID_TL7
    try:

        if (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10):
#            TENTRY_SET_ITEM(MODE_F, 0);
#            TENTRY_SET_ITEM(LKUP_ID_F, 1);
#            TENTRY_SET_ITEM(BLOCK_ID_F, 0);
#            TENTRY_SET_ITEM(SCRUB_HALT_CTRL_F, 1);
            pen_id = LTU_CTRL_PEN_ID
            index = 0
            fld_lst = []
            fld_lst.append((MODE_F, 0x0))
            fld_lst.append((LKUP_ID_F, 0x1))
            fld_lst.append((BLOCK_ID_F, 0x0))
            fld_lst.append((SCRUB_HALT_CTRL_F, 0x1))
            for ib in ib_list:
                write_platform_pen(pen_id, index, fld_lst, ib=ib)

#            TENTRY_SET_ITEM(MODE_F, 0);
#            TENTRY_SET_ITEM(LKUP_ID_F, 1);
#            TENTRY_SET_ITEM(BLOCK_ID_F, 1);
#            TENTRY_SET_ITEM(SCRUB_HALT_CTRL_F, 1);
            index = 1
            fld_lst.append((MODE_F, 0x0))
            fld_lst.append((LKUP_ID_F, 0x1))
            fld_lst.append((BLOCK_ID_F, 0x1))
            fld_lst.append((SCRUB_HALT_CTRL_F, 0x1))
            for ib in ib_list:
                write_platform_pen(pen_id, index, fld_lst, ib=ib)

#            TENTRY_SET_ITEM(MODE_F, 0);
#            TENTRY_SET_ITEM(LKUP_ID_F, 2);
#            TENTRY_SET_ITEM(BLOCK_ID_F, 0);
#            TENTRY_SET_ITEM(SCRUB_HALT_CTRL_F, 1);
            index = 2
            fld_lst.append((MODE_F, 0x0))
            fld_lst.append((LKUP_ID_F, 0x2))
            fld_lst.append((BLOCK_ID_F, 0x0))
            fld_lst.append((SCRUB_HALT_CTRL_F, 0x1))
            for ib in ib_list:
                write_platform_pen(pen_id, index, fld_lst, ib=ib)

            if (verbose):
                log("TCAM TEST BANK CTRL: TL10  Allocation.. 16K vs 8K")
        elif (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX):
            pen_id = IMT3008_BANK_CTRL_PEN_ID
            index = 0
            write_pen_data(pen_id, index, ib_list, 0)
            if (verbose):
                log("TCAM TEST BANK CTRL: TL7  Allocation.. 12K vs 12K")
        else:
            if verbose:
                log("TCAM TEST BANK CTRL: Default Bank Allocation..")

    except Exception as ex:
        rc = TCAM_TEST_ABORT
        msg = "Failed to program BANK_CTRL tcam mode"
        test_err_log(rc, msg)
        log("TCAM TEST: %s" % get_tcam_status_str(rc))
        return rc
    try:
        # Run the selected tests
        if bist:
            #log("Running TCAM BIST")
            if (device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX):
                rc = test_tcam_bist(ib_list, repair=False)
                log("TCAM BIST: %s" % get_tcam_status_str(rc))
            else:
                msg = "TCAM BIST for TL10 not supported in this cmd. Pls use diagtest mbist run"
                test_err_log(rc, msg)

        if repair:
            #log("Running TCAM BIST with repair")
            rc = test_tcam_bist(ib_list, repair=True)
            log("TCAM BIST REPAIR: %s" % get_tcam_status_str(rc))

        if stuck0:
            #log("Running TCAM SLT Stuck-1 Test")
            rc = test_tcam_slt_stuck01(ib_list, 0)
            log("TCAM STUCK-0: %s" % get_tcam_status_str(rc))

        if stuck1:
            #log("Running TCAM SLT Stuck-0 Test")
            rc = test_tcam_slt_stuck01(ib_list, 1)
            log("TCAM STUCK-1: %s" % get_tcam_status_str(rc))

    except Exception as ex:
        rc = TCAM_TEST_ABORT
        msg = "TCAM Test failed with exception, %s" % str(ex)
        test_err_log(rc, msg)
        log("TCAM TEST: %s" % get_tcam_status_str(rc))

    return rc
