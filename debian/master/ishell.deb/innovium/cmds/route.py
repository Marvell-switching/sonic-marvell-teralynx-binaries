
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

from __future__ import division
import sys
import shlex
import argparse
import itertools
import json
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.all import *
from print_table import PrintTable
import time
ifcs_ctypes = sys.modules['ifcs_ctypes']

# Class implements Ifcs related commands
class Route(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'show': self.show,
            'help': self.help,
            '?': self.help
        }
        self.route_display_method = {
            'info': self.route_nh,
        }
        self.supported_operands = ['info']
        self.cli = cli
        self.arg_list = []
        super(Route, self).__init__()
        self.help_str = "ifcs:        IFCS object cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)

    def __del__(self):
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        log(cmd, remline, line)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper()
                    for i in self.supported_operands if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.supported_operands if i.lower().startswith(text)]

    complete_info = complete_show

    def getOperandType(self, args):
        log_dbg(1, "In getOperandType with args: " + args)

        try:
            operand_type = args.split()[3]
        except BaseException:
            log_err("Need info")
            return

        # This if condition needs to be expanded for other counter types
        if operand_type == 'info':
            return 'info'
        else:
            return 'unsupported'

    # ------------
    # show command
    # ------------
    def show(self, args, filter_option):
        log_dbg(1, "In Route show with args: " + args)

        self.filter_option = filter_option

        try:
            operand_type = self.getOperandType(args)
        except IndexError:
            log_err("Operand type not specified")

        try:
            rc = self.route_display_method[operand_type]()
        except BaseException:
            log_err("Failed to display route")

        return rc

    def route_nh(self):
        allobjs = IfcsAll(self.cli)
        re = allobjs.get_ifcs_obj_from_name('route_entry')
        ''' Displays summary of all instance of type route_entry'''

        log_dbg(1, "In show route info method")

        try:
            rc, all_route_entry = re.bulk_get_all_route_entry_keys()
        except BaseException:
            log_err(" Failed to get all route_entry")
            return

        table = PrintTable()

        field_names = [
            'ip_addr',
            'ip_mask',
            'l3vni',
            'fwd_action',
            'ctc_action',
            'trap_handle',
            'user_cookie',
            'nexthop_handle',
            'local_destination']
        table.add_row(field_names)

        all_route_entry = sorted(
            all_route_entry,
            key=lambda x: x.contents.key.ip_dest_l3vni.l3vni)
        log("Total route_entry count: {0} ".format(len(all_route_entry)))
        count = 0
        for route_entry in all_route_entry:
            row = []
            try:
                nexthop = re.getNexthop(route_entry, True)
                nh = None
                if 'ecmp' in re.handle_to_str(nexthop):
                    local_destination = 'ECMP'
                elif nexthop == 0:
                    local_destination = '*'
                else:
                    nh = allobjs.get_ifcs_obj_from_name('nexthop')
                    local_destination = re.handle_to_str(
                        nh.getLocalDestination(nexthop, True))
                fwd_action = re.getFwdPolicy(route_entry, True)
                trap_handle, ctc_action = re.getCtcPolicy(route_entry, True)
                user_cookie = re.getUserCookie(route_entry, True)
                l3vni = re.get_l3vni_from_route_entry(route_entry)
                ip_addr = re.get_ip_addr_from_route_entry(route_entry)
                ip_mask = re.get_ip_mask_from_route_entry(route_entry)
            except KeyError:
                einfo = "{}".format(sys.exc_info())
                log_dbg(
                    1,
                    "KeyError in show route info. route_entry: {}, error: {}".
                    format(route_entry, einfo))
                if re.not_found_exc_msg.format(
                        ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                elif nh and nh.not_found_exc_msg.format(
                        ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                    # Skip the instance as the object is not found.
                    continue
                # Re-raise other exceptions for handling.
                raise
            row.append(ip_addr)
            row.append(ip_mask)
            row.append(l3vni)
            row.append(fwd_action)
            row.append(ctc_action)
            row.append(re.handle_to_str(trap_handle))
            row.append(user_cookie)
            row.append(re.handle_to_str(nexthop))
            row.append(local_destination)
            table.add_row(row)
            count += 1
        table.print_table(brief=True)
        table.reset_table()
        log("Total route_entry count: {0} ".format(count))


    def help(self, args):
        table = PrintTable()

        table.add_row(['IFCS Route Help', 'Description'])
        table.add_row([
                'ifcs show route info',
                'Displays routes information'])
        log("")
        table.set_justification('left')
        table.print_table()
        table.reset_table()
