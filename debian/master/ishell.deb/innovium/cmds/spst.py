#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

HOSTIF_SEND_PKT_BUSY_RETRY_CNT = 500

'''
L2snake test is used to setup forwarding rules to test unidirectional snake test
and bi-directional flow snake test

Unidirectional flow snake config:
=================================
-    Each port set to internal loopback
-    Packet on port (i), sent to port (i+1)
-    Last port fwds packet to first port


IVM:0>diagtest spst config -p 1-4 -lb 'PCS'

IVM:0>ifcs show sysport

Total sysport count: 33
+---------------------------------------------------------------------+
|             sysport_handle | default_cvid | egress_untagged_vlan_id |
|---------------------------------------------------------------------|
| (sysport:   1), 0x68200001 |            2 |                       1 |  --- For 1->2
| (sysport:   2), 0x68200002 |            3 |                       2 |  --- For 2->3
| (sysport:   3), 0x68200003 |            4 |                       3 |  --- For 3->4
| (sysport:   4), 0x68200004 |            1 |                       4 |  --- For 4->1

IVM:0>ifcs show l2_entry
Total l2_entry count: 8
+----------------------------------------------------------------------------
|          mac_addr |                    l2vni |                destination |
|----------------------------------------------------------------------------
| 00:00:00:00:00:bb | (l2vni:   1), 0x3c200001 | (sysport:   4), 0x68200004 |     ----- BB SRC MAC
| 00:00:00:00:00:aa | (l2vni:   1), 0x3c200001 | (sysport:   1), 0x68200001 |     ----- AA DST MAC for 4->1
| 00:00:00:00:00:aa | (l2vni:   2), 0x3c200002 | (sysport:   2), 0x68200002 |     ----- AA DST MAC for 1->2
| 00:00:00:00:00:bb | (l2vni:   2), 0x3c200002 | (sysport:   1), 0x68200001 |
| 00:00:00:00:00:bb | (l2vni:   3), 0x3c200003 | (sysport:   2), 0x68200002 |
| 00:00:00:00:00:aa | (l2vni:   3), 0x3c200003 | (sysport:   3), 0x68200003 |     ----- AA DST MAC for 2->3
| 00:00:00:00:00:bb | (l2vni:   4), 0x3c200004 | (sysport:   3), 0x68200003 |
| 00:00:00:00:00:aa | (l2vni:   4), 0x3c200004 | (sysport:   4), 0x68200004 |     ----- AA DST MAC for 3->4
+----------------------------------------------------------------------------
'''
import os

import shlex
import argparse
import itertools
import time
import random
import json
from ctypes import *
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.queue import Queue as Queue
from ifcs_cmds.node import Node as Node
from print_table import PrintTable
from testutil.util import hexdump
from spst_tests_version import *
from spst_tests_common import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

MAX_DEV_PORTS = 520
MAX_PKTS = 2000
MAX_ACL_CATCH_ALL_TABLES = 3
cpu_port = 0

acl_debug_logs = 0 #1: enable, 0: disable

L2HDR_SZ=14
L2HDR_ETV4_BYTES=[0x00, 0x00, 0x00, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB, 0x08, 0x00]
L2HDR_ETV6_BYTES=[0x00, 0x00, 0x00, 0x00, 0x00, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB, 0x86, 0xDD]

MIN_VLAN_ID = 1
MAX_VLAN_ID = 4095
MIN_LAG_ID = 1
MAX_LAG_ID = 1023

PROT_IPV4_TCP = 0
PROT_IPV4_UDP = 1
PROT_IPV6_TCP = 2
PROT_IPV6_UDP = 3
PROT_MAX = 4

L4SRCPORT = 0xAA55
L4DSTPORT = 0x55AA

# Protocol field offsets
L2_ETYPE_OFFSET = 12
IPV4_VER_IHL_OFFSET = 14
IPV4_LEN_OFFSET = 16
IPV4_TTL_OFFSET = 22
IPV4_NXT_HDR = 23

IPV6_VER_OFFSET = 14
IPV6_LEN_OFFSET = 18
IPV6_NXT_HDR = 20
IPV6_HOP_OFFSET = 21

rng = None

def ace_get_packets(node_id, ace):
    attr = ifcs_ctypes.ifcs_attr_t()
    attr_p = pointer(attr)
    attr.id = ifcs_ctypes.IFCS_ACE_ATTR_PACKETS
    attr_count=1
    actual_count = c_uint32()
    actual_count_p = pointer(actual_count)

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_ace_attr_get(
             node_id, ace,
             attr_count, attr_p,
             actual_count_p))

    spstcommon_handle_device_access_error(rc, "ifcs_ace_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get ace stats for ace %d" % ace)
        return

    if (attr.bitmap.u64) != 1:
        return None
    return attr.value.u64

def ace_clear_packets_bytes(node_id, ace):
    attr = (ifcs_ctypes.ifcs_attr_t * 2)()
    attr_count = 0
    attr[0].id = ifcs_ctypes.IFCS_ACE_ATTR_PACKETS
    attr[0].bitmap.u64 = 1
    attr[0].value.u64 = 0
    attr_count += 1

    attr[1].id = ifcs_ctypes.IFCS_ACE_ATTR_BYTES
    attr[1].bitmap.u64 = 1
    attr[1].value.u64 = 0
    attr_count += 1

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_ace_attr_set(
             node_id, ace,
             attr_count,
             compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)))

    spstcommon_handle_device_access_error(rc, "ifcs_ace_attr_set")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to clear ace stats for ace %d" % ace)

    return rc

#Get ACE count in ACL
def get_acl_ace_count(node_id, acl):
    attr = ifcs_ctypes.ifcs_attr_t()
    attr_p = pointer(attr)
    attr.id = ifcs_ctypes.IFCS_ACL_ATTR_ACE_COUNT
    attr_count=1
    actual_count = c_uint32()
    actual_count_p = pointer(actual_count)

    rc = ifcs_ctypes.IFCS_STATUS_REASON(
        ifcs_ctypes.ifcs_acl_attr_get(
             node_id, acl,
             attr_count, attr_p,
             actual_count_p))

    spstcommon_handle_device_access_error(rc,"ifcs_acl_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get ace count for acl %d" % acl)
        return

    if (attr.bitmap.u32) != 1:
        return None
    return attr.value.u32

def _get_ib_from_devport(node_id, devport):
    '''
        Utility function that takes a devport
        and returns IB for the devport
    '''
    attr = ifcs_ctypes.ifcs_attr_t()
    count  = ifcs_ctypes.c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_IB
    attr_count = 1
    rc = ifcs_ctypes.ifcs_devport_attr_get(node_id, devport, attr_count, pointer(attr),
                               pointer(count))
    spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IB for devport %d" % devport)
        return

    return attr.value

def _get_ibport_from_devport(node_id, devport):
    '''
        Utility function that takes a devport
        and returns IB port for the devport
    '''
    attr = ifcs_ctypes.ifcs_attr_t()
    count  = ifcs_ctypes.c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_IBPORT
    attr_count = 1
    rc = ifcs_ctypes.ifcs_devport_attr_get(node_id, devport, attr_count, pointer(attr),
                               pointer(count))
    spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_get")
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IB port for devport %d" % devport)
        return

    return attr.value.u32

def pkt_vos_cb(node_id, user_data, packet):
    global L2HDR_SZ
    mismatch = 0
    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    packet = cast(buf, POINTER(c_char))
    packet = packet[:buf_len]
    prot_sel = -1
    apphdr_offset = 0
    #gen_pkt = Spst.vos_gen_pkt

    
    if compat_ord(packet[L2_ETYPE_OFFSET]) == 0x08 and compat_ord(packet[L2_ETYPE_OFFSET+1]) == 0x00:
        # ipv4 pkt
        ihl = compat_ord(packet[IPV4_VER_IHL_OFFSET]) & 0xf
        apphdr_offset = L2HDR_SZ + ihl*4 + 4
        if compat_ord(packet[IPV4_NXT_HDR]) == 0x06:
            prot_sel = PROT_IPV4_TCP
        elif compat_ord(packet[IPV4_NXT_HDR]) == 0x11:
            prot_sel = PROT_IPV4_UDP
    elif compat_ord(packet[L2_ETYPE_OFFSET]) == 0x86 and compat_ord(packet[L2_ETYPE_OFFSET+1]) == 0xDD:
        # ipv6 pkt
        apphdr_offset = L2HDR_SZ + 40 + 4
        if compat_ord(packet[IPV6_NXT_HDR]) == 0x06:
            prot_sel = PROT_IPV6_TCP
        elif compat_ord(packet[IPV6_NXT_HDR]) == 0x11:
            prot_sel = PROT_IPV6_UDP

    if apphdr_offset == 0:
        log("Received ethertype invalid;pkt[L2_ETYPE_OFFSET]: {} pkt[L2_ETYPE_OFFSET+1]: {}. Received pkt:".format(packet[12], packet[13]))
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Spst-id) as we don't know the snake-id here
        Spst.vos_glob_mismatch += 1
        return

    if prot_sel == -1:
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Spst-id) as we don't know the snake-id here
        Spst.vos_glob_mismatch += 1
        return

    if compat_ord(packet[apphdr_offset]) == 0xBE and compat_ord(packet[apphdr_offset+1]) == 0xBA and \
       compat_ord(packet[apphdr_offset+2]) == 0xFE and compat_ord(packet[apphdr_offset+3]) == 0xCA:
        log_dbg(1, "Received packet signature verified")
    else:
        log("Received packet signature invalid. Received pkt:")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Spst-id) as we don't know the snake-id here
        Spst.vos_glob_mismatch += 1
        return

    snake_id_idx = apphdr_offset + 4
    pkt_id_idx = snake_id_idx + 1
    snake_id = compat_ord(packet[snake_id_idx])
    find = False
    for instance in Spst.sinsts:
        if instance.id == snake_id:
            sinst_info = instance
            find = True
            break
    if find == False:
        log("Spst with id {0} doesn't exist".format(snake_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        Spst.vos_glob_mismatch += 1
        return

    pkt_id = compat_ord(packet[pkt_id_idx]) | (compat_ord(packet[pkt_id_idx + 1]) << 8) | (compat_ord(packet[pkt_id_idx + 2]) << 16)

    log_dbg(1, "Received pkt_id {}".format(pkt_id))

    if pkt_id >= MAX_PKTS:
        # Invalid pkt_id
        log("Invalid pkt_id: {}".format(pkt_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        Spst.vos_glob_mismatch += 1
        return

    gen_pkt = sinst_info.vos_gen_pkts[pkt_id]
    sinst_info.vos_num_rcvd_total += 1
    sinst_info.vos_rcv_pktids[pkt_id] += 1

    if isinstance(gen_pkt, int):
        # Why is it of type int; if it is a valid pkt it should be of type bytes.
        # pkt_id not expected
        log("Unexpected pkt_id: {}".format(pkt_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        sinst_info.vos_num_rcvd_bad += 1
        return

    if len(gen_pkt) != len(packet):
        mismatch = 1
        sent_received = (gen_pkt, packet)
        sinst_info.len_mismatch.append(sent_received)

    if mismatch == 0:
        # now compare the content
        for i in range(len(gen_pkt)):
            if packet[i] != gen_pkt[i]:
                mismatch = 1
                snake_pkt_byte = (snake_id, pkt_id, i, gen_pkt, packet)
                sinst_info.byte_mismatch.append(snake_pkt_byte)

    if mismatch == 0:
        sinst_info.vos_num_rcvd_good += 1
        sinst_info.vos_prot_sel_good_rcv_cnt[prot_sel] += 1
    else:
        sinst_info.vos_num_rcvd_bad += 1
    return

def getSysportHandleFromDevPort(node_id, devPort):
    attr = ifcs_ctypes.ifcs_attr_t()
    actual_count = c_uint32()

    attr.id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
    ret = ifcs_ctypes.ifcs_devport_attr_get(node_id, devPort, 1, pointer(attr),
                            pointer(actual_count))
    spstcommon_handle_device_access_error(ret, "ifcs_devport_attr_get")
    assert ret == ifcs_ctypes.IFCS_SUCCESS, "port sysport handle get: ret = [" + str(ret) + "]"

    return attr.value.handle


def auto_int(x):
    return int(x, 0)

class PortFwdInst():
    def __init__(self):
        self.sp_hdl              = 0
        self.l2vni_hdl           = 0
        self.lag_hdl             = 0
        self.l3vni_hdl           = 0
        self.intf_hdl            = 0
        self.sp_cookie           = 0
        self.l2vni_cookie        = 0
        self.l3vni_cookie        = 0
        self.intf_cookie         = 0


# Object to store A "run" devport stats.
class SnakeInstInfo():
    def __init__(self):
        self.devport_rx_frames = [0] * MAX_DEV_PORTS
        self.devport_rx_bytes = [0] * MAX_DEV_PORTS
        self.devport_rx_gbps = [0] * MAX_DEV_PORTS
        self.devport_tx_frames = [0] * MAX_DEV_PORTS
        self.devport_tx_bytes = [0] * MAX_DEV_PORTS
        self.devport_tx_gbps = [0] * MAX_DEV_PORTS
        self.devport_rx_errors = [0] * MAX_DEV_PORTS
        self.devport_tx_errors = [0] * MAX_DEV_PORTS
        self.timestamp = [0] * MAX_DEV_PORTS
        self.devport_list = []
        self.lb_type = 0
        self.sdd = 0
        #self.num_pkt = OrderedDict()
        self.node_id = 0
        self.verbose = 0
        self.time = 0
        self.dmac_l2_entry_array = []
        self.smac_l2_entry_array = []
        self.cpu_sp_hdl          = ifcs_ctypes.ifcs_handle_t()
        self.stp_hdl             = ifcs_ctypes.ifcs_handle_t()
        self.port_fwd_inst_list  = [0] * MAX_DEV_PORTS
        #ACL handles
        self.ingress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]

        self.ingress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]

        self.ingress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        self.egress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        self.ingress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]

        self.ing_acl_list_for_table1 = []
        self.ing_acl_list_for_table2 = []
        self.egr_acl_list_for_table1 = []
        self.egr_acl_list_for_table2 = []

        self.ing_ace_list_for_table1 = []
        self.ing_ace_list_for_table2 = []
        self.egr_ace_list_for_table1 = []
        self.egr_ace_list_for_table2 = []

        self.list_of_acl_table_hdl = []
        self.list_of_mp_hdl = []
        self.list_of_ap_hdl = []

        self.ace_priority = 199

        #per port, per table, per ace ACL stats
        self.devport_acl_stats = [[[0 for i in range(MAX_DEV_PORTS)] for j in range(4)] for k in range(MAX_DEV_PORTS)]
        self.devport_acl_catch_all_stats  = [0] * MAX_ACL_CATCH_ALL_TABLES

        self.id = 0
        self.type = "None"
        self.payload_type = ""
        self.vos = 0
        self.vos_gen_pkts        = [0] * MAX_PKTS
        self.vos_rcv_pktids      = [0] * MAX_PKTS
        self.vos_num_gen_pkts    = 0
        self.vos_num_rcvd_total  = 0
        self.vos_num_rcvd_good   = 0
        self.vos_num_rcvd_bad    = 0
        self.vos_prot_sel_gen_cnt = [0] * PROT_MAX
        self.vos_prot_sel_good_rcv_cnt = [0] * PROT_MAX
        self.dbg1 = 0
        self.stress_prot_sel = 0
        self.stress_data_bytes = None
        self.state = SNAKE_STOPPED

        self.len_mismatch = []
        self.byte_mismatch = []

    def display(self):
        log("\nSpst id         : %d" %(self.id))
        log("Loopback type    : %s" %(self.lb_type))
        log("Spst type       : %s" %(self.type))
        log("Number of packets:")
        #for size, num in compat_iteritems(self.num_pkt):
            #log("    Size: %4s, Packets: %s" %(size, num))

        header = []
        header.append('Devport')
        header.append('RX(frames)')
        header.append('RX(bytes)')
        header.append('RX(Gbps)')
        header.append('RX(error frames)')
        header.append('TX(frames)')
        header.append('TX(bytes)')
        header.append('TX(Gbps)')
        header.append('TX(error frames)')
        table = PrintTable()
        table.add_row(header)
        for p in range(MAX_DEV_PORTS):
            if p not in self.devport_list:
                continue
            devport_row = []
            devport_row.append(str(p))
            devport_row.append(str(self.devport_rx_frames[p]))
            devport_row.append(str(self.devport_rx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_rx_gbps[p]))
            devport_row.append(str(self.devport_rx_errors[p]))
            devport_row.append(str(self.devport_tx_frames[p]))
            devport_row.append(str(self.devport_tx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_tx_gbps[p]))
            devport_row.append(str(self.devport_tx_errors[p]))
            table.add_row(devport_row)
        table.print_table()
        table.reset_table()

    def display_config(self, id):
        for instance in Spst.sinsts:
            if instance.id == id:
                sinst_info = instance
                table = PrintTable()
                header = []
                header.append("Devports")
                header.append("Loopback type")
                header.append("Spst id")
                header.append("Spst type")
                table.add_row(header)

                data = []
                data.append(str(sinst_info.devport_list)[1:-1])
                data.append(str(sinst_info.lb_type))
                data.append(str(id))
                data.append(str(sinst_info.type))
                table.add_row(data)
                table.print_table()
                table.reset_table()
                break

SNAKE_UNCONFIG = 0
SNAKE_CONFIGD = 1
SNAKE_RUNNING = 2
SNAKE_STOPPED = 3

#Spst: This test injects a packet on a port and the forwarding
#       rules are configured in such a way that the packet loops
#       through all the ports and then back to CPU.
#       This is a work in progress, so we pass it for now
#
class Spst(Command):
    #Version of the snake.py file
    snake_file_version = 0
    ver_disp = "" # nomenclature: <ifcs_version>_<snake_version>

    state = SNAKE_UNCONFIG
    #Global across all Spst objects.

    cpu_queue_num = 3
    trap_id = 65
    trap_hdl = ifcs_ctypes.ifcs_handle_t()
    #All run's devport stats are saved in below list
    sinsts = []

    #Class variables
    dmac_l2_entry_array = []
    smac_l2_entry_array = []
    cpu_sp_hdl          = ifcs_ctypes.ifcs_handle_t()
    stp_hdl             = ifcs_ctypes.ifcs_handle_t()

    rx_cbfn             = 0
    vos_glob_mismatch   = 0
    #Incremented for each run config (diagtest snake config)
    run = -1
    device_access_error_exc_msg = DEVICE_ACCESS_ERROR_EXC_MSG

    def __init__(self, cli, quiet="false"):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'gen_report'   : self.gen_report,
                         'verify'       : self.verify,
                         'show_vos_stats'  : self.show_vos_stats,
                         'show_acl_stats'  : self.show_acl_stats,
                         'clear_vos_stats' : self.clear_vos_stats,
                         'clear_acl_stats' : self.clear_acl_stats,
                         'unconfig'     : self.unconfig,
                         'show_version' : self.show_ver,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.quiet = quiet
        self.arg_list = []
        self.node_id = 0
        self.node_device_type = 0

        
        version_num = [0] * 6
        for idx in range(len(SPST_TESTS_VERSION)):
            version_num[idx] = SPST_TESTS_VERSION[idx]
        self.ver_disp = "{}.{}.{}.{}.{}.{}".format(
            version_num[0], version_num[1], version_num[2], version_num[3],
            version_num[4], version_num[5])
        self.ver_disp = "{}_{}".format(self.ver_disp, self.snake_file_version)
        super(Spst, self).__init__()

    def __del__(self):
        return

    def _get_ib_ibp(self, ib, ibp):
        '''
        Utility routine to get ib+ibp encoding
        '''
        if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
            return (((ib & 0x7) << 6) | (ibp & 0x3f))
        elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            return (((ib & 0x7) << 7) | (ibp & 0x7f))
        else:
            assert False, "Not supported on this device type {}".format(self.node_device_type)

    def show_ver(self, args):
        table = PrintTable()
        table.add_row(['IFCS Spst Version',"%s"%(self.ver_disp)])
        table.print_table()
        table.reset_table()

    def run_cmd(self, args):
        self.node_device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError) as kex:
            log_err("Invalid cmd; Exception: {}".format(kex))
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            self.cli.error()
            log_err("Exception: {}".format(ve))
        except Exception as ex:
            self.cli.error()
            log_err("Exception: {}".format(ex))

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure snake test'])
        table.add_row(['config_show', 'Show snake test configuration'])
        table.add_row(['start_traffic', 'Start snake test traffic'])
        table.add_row(['stop_traffic', 'Stop snake test traffic'])
        table.add_row(['gen_report', 'Generate snake test report for given sampling time'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        table.add_row(['show_vos_stats', 'Display vos statistics'])
        table.add_row(['show_acl_stats', 'Display acl statistics'])
        table.add_row(['clear_vos_stats', 'Clear vos statistics'])
        table.add_row(['clear_acl_stats', 'Clear acl statistics'])
        table.add_row(['unconfig', 'Unconfigure snake test'])
        table.add_row(['show_version', 'Show Spst file version'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        snake_help_string = """
Usage::

    Type "diagtest snake <command>" followed by -h to see command's sub-options.
"""
        log(snake_help_string)

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        Spst.run += 1
        Spst.sinsts.append(run_data)

    def get_run_data(self, run):
        return Spst.sinsts[run]

    def get_cur_run_data(self):
        run = Spst.run
        return Spst.sinsts[run]

    def get_max_devport(self, node_id=0):
        #Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):

            devport = arg

            devport_list.append(devport)
        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            spstcommon_handle_device_access_error(rc,"ifcs_devport_get_all")
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err("Failed to get all devport rc: {0}".format(rc))
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("In except of devport get_all")
        except:
            log_err("In except of devport get_all")

        return (len(devport_list))

    def config_snake_unidir(self, sinst_info):
       '''
       1. Packets are initiated from CPU to port 1
       2. Port 1 forwards and port 2
       3. Port 2 is internal loopbacked and gets packet
       4. Port 2 forwards it to port 3 and so on till 128
       5. Port 128 forwards to port 1
       6. Port 1, because of loopback gets packet again and cycle repeats
       +--------+
       | CPU    |
       +---+----+
           |
         +-------------------------------------------------------+
         | |    +----------------------------------------------+ |
         | |    |                                              | |
         | |    |  +-------  +-------  +---+   +---+ +------+  | |
         | |    |  |      |  |      |  |   |       | |      |  | |
         | +> +-v--++    +v--+     +v--+   v      +v-++    +v--+ |
         |    |   1 |    | 2 |     | 3 |          |127|    |128| |
         +----+-+-+-+----++-++-----++-++-----------+-+------+-+--+
                | ^       | ^       | ^            | ^      | ^
                | |       | |       | |            | |      | |
                +>+       +>+       +-+            +-+      +-+
       '''
       mac_addr_t = c_uint8 * 6
       devport_list = sinst_info.devport_list
       l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
       dmac_l2_entry_array = sinst_info.dmac_l2_entry_array
       smac_l2_entry_array = sinst_info.smac_l2_entry_array
       port_fwd_inst_list = sinst_info.port_fwd_inst_list

       # SRC MAC config
       try:
           attr_count = 2
           attr = (ifcs_ctypes.ifcs_attr_t * attr_count)()

           for i, port in enumerate(sinst_info.devport_list):
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[port].sp_hdl)
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xBB)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               if port == devport_list[-1]:
                   next_devport = devport_list[0]
               else:
                   next_devport = devport_list[i+1]
               l2vni_hdl.value = port_fwd_inst_list[next_devport].l2vni_hdl

               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               lag_hdl = ifcs_ctypes.ifcs_handle_t()
               lag_hdl.value  = port_fwd_inst_list[port].lag_hdl
               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = lag_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               spstcommon_handle_device_access_error(rc,"ifcs_l2_entry_create")
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create SMAC entry FAILED!!: rc = [" + str(rc) + "]"
               smac_l2_entry_array.append(l2_entry)
       except ValueError as ve:
           if Spst.device_access_error_exc_msg in "{}".format(ve):
               # Re-raise exception for handling.
               raise ve
           log_dbg(1, "{}".format(ve))
           src_l2entry_create_failed = 1
           log_err("Hit except (SMAC) config 1")
       except:
           src_l2entry_create_failed = 1
           log_err("Hit except (SMAC) config 1")

       # Dest MAC config
       try:
           for i, port in enumerate(sinst_info.devport_list):
               count = port
               port_hdl = ifcs_ctypes.ifcs_handle_t()
               port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[port].sp_hdl)
               mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
               port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
               l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
               ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
               l2vni_hdl.value = port_fwd_inst_list[port].l2vni_hdl


               ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                       ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
               ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                       l2_entry.key.mac_l2vni)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                       mac_addr)
               ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                       l2vni_hdl)

               lag_hdl = ifcs_ctypes.ifcs_handle_t()
               lag_hdl.value  = port_fwd_inst_list[port].lag_hdl
               attr[0].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_DEST
               attr[0].value.handle = lag_hdl
               attr[1].id = ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_TYPE
               attr[1].value.u32 = ifcs_ctypes.IFCS_L2_ENTRY_TYPE_STATIC
               rc = ifcs_ctypes.ifcs_l2_entry_create(self.cli.node_id, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
               spstcommon_handle_device_access_error(rc,"ifcs_l2_entry_create")
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "Create DMAC entry FAILED!!: rc = [" + str(rc) + "]"
               dmac_l2_entry_array.append(l2_entry)
       except ValueError as ve:
           if Spst.device_access_error_exc_msg in "{}".format(ve):
               # Re-raise exception for handling.
               raise ve
           log_dbg(1, "{}".format(ve))
           log_err("Hit except (DMAC) config 1")
           dst_l2entry_create_failed = 1
       except:
           log_err("Hit except (DMAC) config 1")
           dst_l2entry_create_failed = 1

       try:
           # SYSPORT attr set
           #Build Sysport attr for Default VID config
           sp_attr_ct = 4
           sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

           for i, port in enumerate(sinst_info.devport_list):
               if port == sinst_info.devport_list[-1]:
                   next_devport = sinst_info.devport_list[0]
               else:
                   next_devport = sinst_info.devport_list[i + 1]
               default_vid = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].l2vni_hdl)
               egress_vid = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[port].l2vni_hdl)
               sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
               sp_attr[0].value.u16 = default_vid
               sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
               sp_attr[1].value.u16 = egress_vid
               sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
               sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_TRUE
               sp_attr[3].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_USER_COOKIE
               sp_attr[3].value.u32 = rng.randint(1, 1023)
               port_fwd_inst_list[port].sp_cookie = sp_attr[3].value.u32
               rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, port_fwd_inst_list[port].sp_hdl, sp_attr_ct, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
               spstcommon_handle_device_access_error(rc,"ifcs_sysport_attr_set")
               assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
       except ValueError as ve:
           if Spst.device_access_error_exc_msg in "{}".format(ve):
               # Re-raise exception for handling.
               raise ve
           log_dbg(1, "{}".format(ve))
           log_err("Hit except (Sysport) config")
           sysport_attr_set_failed = 1
       except:
           log_err("Hit except (Sysport) config")
           sysport_attr_set_failed = 1

    def config(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test config', prog='snake config', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="all", help='Port list')
        parser.add_argument('-lb', type=str, choices=['NONE', 'PCS', 'PMA'], default='NONE', help='Loopback type')
        parser.add_argument('-sdd', help='Disable serdes tx on ports; used if lb is not NONE', action="store_true")
        parser.add_argument('-id', type=int, default=None, help='User defined snake id  [1-1023]')
        parser.add_argument('-seed', type=int, default=0, help='Optional seed value')
        parser.add_argument('-v', help='Verbose', action="store_true")

        global rng

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        seed = 0
        if res.seed == 0:
            seed = random.randrange(sys.maxsize)
        else:
            seed = res.seed

        log("Seed used: {}".format(seed))
        rng = random.Random(seed)

        '''
        If -p arg not given, default port range is all ports.
        '''
        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res.p == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res.p
                devport_arg_list = res.p.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config and stats
        sinst_info = SnakeInstInfo()
        devport_list = sinst_info.devport_list

        find = False
        if res.id != None:
            for instance in Spst.sinsts:
                if instance.id == res.id:
                    log_err('Spst id already in use!\n')
                    return 'FAILED'
            sinst_info.id = res.id
        else:
            for index in range(1, 1024):
                find = False
                for instance in Spst.sinsts:
                    if instance.id == index:
                        find = True
                        break
                if find == False:
                    sinst_info.id = index
                    break
                if index == 1023:
                    log_err("Can not alloc snake id")
                    return 'FAILED'

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    sinst_info.devport_list.append(j)
            else:
                sinst_info.devport_list.append(int(dp))

        # check if devport_list of new snake is overlapping with devport list of existing snake(s), if yes, return FAILED
        new_devport_list = sinst_info.devport_list
        new_devport_set = set(new_devport_list)
        port_overlap = False
        for instance in Spst.sinsts:
            if instance:
                existing_devport_list = instance.devport_list
                existing_devport_set = set(existing_devport_list)
                if (existing_devport_set & new_devport_set):
                    port_overlap = True
                    break;
        if port_overlap:
            log_err("one or more ports in the devport list is already part of an existing snake. use ports that are not part of any existing snake(s)")
            return 'FAILED'

        allowed_lb_types = ['none', 'pcs', 'pma']
        if (res.lb.upper() not in map(str.upper, allowed_lb_types)):
            log_err("Invalid Loopback type specified: ", lb_type)
            return 'FAILED'
        lb_type = res.lb
        sinst_info.lb_type = res.lb

        verbose = res.v
        sinst_info.verbose = res.v

        sdd = res.sdd
        sinst_info.sdd = sdd

        sinst_info.type = "unidir"

        config_fdb_methods = {"unidir": self.config_snake_unidir
        }

        # locals
        sysport_hdl_get_failed = 0
        stp_create_failed = 0
        stp_port_set_failed = 0
        l2vni_create_failed = 0
        l2vni_stp_config_failed = 0
        l2vni_member_config_failed = 0
        lag_create_failed = 0
        lag_member_config_failed = 0
        src_l2entry_create_failed = 0
        dst_l2entry_create_failed = 0
        sysport_attr_set_failed = 0
        devport_lb_config_failed = 0
        devport_shp_config_failed = 0
        queue_shp_config_failed = 0
        l3_config_failed        = 0
        mac_addr_t = c_uint8 * 6

        # Configure
        dport = sinst_info.devport_list[0]
        ret = ifcs_ctypes.ifcs_status_t()
        vni_hdl = ifcs_ctypes.ifcs_handle_t()
        attr = (ifcs_ctypes.ifcs_attr_t * 1)()
        vni_attr = (ifcs_ctypes.ifcs_attr_t * 2)()

        attr[0].id = ifcs_ctypes.IFCS_LINKSCAN_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

        maxPorts = MAX_DEV_PORTS

        dmac_l2_entry_array = sinst_info.dmac_l2_entry_array
        smac_l2_entry_array = sinst_info.smac_l2_entry_array
        cpu_sp_hdl = sinst_info.cpu_sp_hdl
        stp_hdl = sinst_info.stp_hdl
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        try:
            for port in sinst_info.devport_list:
                port_inst = PortFwdInst()
                port_inst.sp_hdl = getSysportHandleFromDevPort(sinst_info.node_id, port)
                port_fwd_inst_list[port] = port_inst
                port_fwd_inst_list[port].l2_entry_dst_mac_user_cookie = 0
            port = cpu_port
            cpu_sp_hdl.value = getSysportHandleFromDevPort(sinst_info.node_id, cpu_port)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Sysport get FAILED for devport {}".format(port))
            sysport_hdl_get_failed = 1
            return
        except:
            log_err("Sysport get FAILED for devport {}".format(port))
            sysport_hdl_get_failed = 1
            return

        ####### STEP0 #######
        ###### STP CONFIG #######
        try:
            stp_hdl.value = ifcs_ctypes.IFCS_NULL_HANDLE
            ret = ifcs_ctypes.ifcs_stp_create(0, pointer(stp_hdl), 0, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(ret, "ifcs_stp_create")
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance creation FAILED!!"
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("STP create FAILED!!")
            stp_create_failed = 1
        except:
            log_err("STP create FAILED!!")
            stp_create_failed = 1

        try:
            member_count = len(sinst_info.devport_list)
            member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()
            member_attr_count = 0
            member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()
            count=0
            for port in sinst_info.devport_list:
                member_list[count] = port_fwd_inst_list[port].sp_hdl
                count += 1

            stp_attr_count = 1
            stp_attr = ifcs_ctypes.ifcs_attr_t()
            stp_attr.id        = ifcs_ctypes.IFCS_STP_PORT_ATTR_STP_STATE;
            stp_attr.value.u32 = ifcs_ctypes.IFCS_STP_PORT_STATE_FORWARDING;

            ret = ifcs_ctypes.ifcs_stp_port_add(0, stp_hdl, count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t), stp_attr_count, pointer(stp_attr))
            spstcommon_handle_device_access_error(ret, "ifcs_stp_port_add")
            assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                   "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
                    str(l2vni)
            #for mbr in mbrs:
            #    ret = ifcs_ctypes.ifcs_stp_port_attr_set(0, stp_hdl, mbrs[mbr], stp_attr_count, pointer(stp_attr))
            #    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
            #           "ERR during L2VNI mbr stp state set to FWD. STP id:" +\
            #            str(l2vni)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            stp_port_set_failed = 1
            log_err("STP port set FAILED!!")
        except:
            stp_port_set_failed = 1
            log_err("STP port set FAILED!!")

        ###### VNI CONFIG ######
        # Create VNI and add members
        try:
            ###### VNI CONFIG ######
            # Create VNI and add members
            rand_l2vni_list = rng.sample(compat_listrange(MIN_VLAN_ID, MAX_VLAN_ID), len(sinst_info.devport_list))
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
            for ind,i in enumerate(sinst_info.devport_list):
                l2vni_attr_count = 1
                l2vni_attr = ifcs_ctypes.ifcs_attr_t()
                l2vni_attr.id         = ifcs_ctypes.IFCS_L2VNI_ATTR_USER_COOKIE
                l2vni_attr.value.u32  = rng.randint(1, 255)
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(rand_l2vni_list[ind])
                ret = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), l2vni_attr_count, compat_pointer(l2vni_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_l2vni_create")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI creation " + str(i)
                port_fwd_inst_list[i].l2vni_hdl = l2vni_hdl.value
                port_fwd_inst_list[i].l2vni_cookie = l2vni_attr.value.u32
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except L2VNI create config")
            l2vni_create_failed = 1
        except:
            log_err("Hit except L2VNI create config")
            l2vni_create_failed = 1

        try:
            # Set STP instance for created VNI ===> TODO:Ayyappa why only stp instance created ??
            vni_attr[0].id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
            vni_attr[0].value.handle = stp_hdl
            ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(ret, "ifcs_l2vni_attr_set")
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set FAILED!!"
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            l2vni_stp_config_failed = 1
            log_err("Hit except L2VNI stp config")
        except:
            l2vni_stp_config_failed = 1
            log_err("Hit except L2VNI stp config")

        ### Create LAG and add each sysport to a lag #####
        try:
            lag_hdl = ifcs_ctypes.ifcs_handle_t()
            rand_lag_list = rng.sample(compat_listrange(MIN_LAG_ID, MAX_LAG_ID), len(sinst_info.devport_list))
            for ind,i in enumerate(sinst_info.devport_list):
                lag_hdl.value = ifcs_ctypes.IFCS_HANDLE_LAG(rand_lag_list[ind])
                ret = ifcs_ctypes.ifcs_lag_create(0, pointer(lag_hdl), 0, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_lag_create")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during LAG creation " + str(i)
                port_fwd_inst_list[i].lag_hdl = lag_hdl.value
                lag_member_count = 1
                lag_member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()
                lag_member_list[0] = port_fwd_inst_list[i].sp_hdl
                ret = ifcs_ctypes.ifcs_lag_member_add(0, lag_hdl,
                                                      1, compat_pointer(lag_member_list, ifcs_ctypes.ifcs_handle_t),
                                                      member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_lag_member_add")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during LAG mbr add " + str(lag_hdl) + str(port_fwd_inst_list[i].sp_hdl)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            lag_create_failed = 1
            log_err("Hit except LAG create config")
        except:
            lag_create_failed = 1
            log_err("Hit except LAG create config")

        try:
            for i, port in enumerate(sinst_info.devport_list):
                if port == sinst_info.devport_list[0]:
                    next_devport = sinst_info.devport_list[-1]
                else:
                    next_devport = sinst_info.devport_list[i - 1]

                member_count = 2
                member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()
                member_list[0]  = port_fwd_inst_list[port].lag_hdl
                member_list[1]  = port_fwd_inst_list[next_devport].lag_hdl
                l2vni_hdl.value = port_fwd_inst_list[port].l2vni_hdl
                ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                             member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_l2vni_member_add")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni_hdl)

                #Add CPU port to VNI membership if not already
                if cpu_port not in sinst_info.devport_list:
                    ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                                1, pointer(cpu_sp_hdl),
                                                member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                    spstcommon_handle_device_access_error(ret, "ifcs_l2vni_member_add")
                    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during L2VNI mbr add for CPU port" + str(l2vni_hdl)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except L2VNI member config")
            l2vni_member_config_failed = 1
        except:
            log_err("Hit except L2VNI member config")
            l2vni_member_config_failed = 1

        ####### Create L3 Config ########
        # Create Random L3VNI with random user cookie
        # Create SVI with Random User Cookie and attach the corresponding L2VNI & L3VNI
        try:
            rand_l3vni_list = rng.sample(compat_listrange(1, 255), len(sinst_info.devport_list))
            rand_intf_list = rng.sample(compat_listrange(1, 60415), len(sinst_info.devport_list))
            for ind,i in enumerate(sinst_info.devport_list):
                l3vni_attr_count = 1
                l3vni_attr = ifcs_ctypes.ifcs_attr_t()
                l3vni_attr.id        = ifcs_ctypes.IFCS_L3VNI_ATTR_USER_COOKIE
                l3vni_attr.value.u32 = rng.randint(1, 1023)
                l3vni_hdl = ifcs_ctypes.ifcs_handle_t()
                l3vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L3VNI(rand_l3vni_list[ind])
                ret = ifcs_ctypes.ifcs_l3vni_create(0, pointer(l3vni_hdl), l3vni_attr_count, compat_pointer(l3vni_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_l3vni_create")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L3VNI creation " + str(i)
                port_fwd_inst_list[i].l3vni_hdl = l3vni_hdl.value
                port_fwd_inst_list[i].l3vni_cookie = l3vni_attr.value.u32

                trans_mac_addr = mac_addr_t(0, 0, 0, 0, 0xBB, 0xAA)
                intf_attr_count = 5
                intf_attr = (ifcs_ctypes.ifcs_attr_t * intf_attr_count)()
                intf_attr[0].id = ifcs_ctypes.IFCS_INTF_ATTR_TYPE
                intf_attr[0].value.u32 = ifcs_ctypes.IFCS_INTF_TYPE_SVI
                intf_attr[1].id = ifcs_ctypes.IFCS_INTF_ATTR_FORWARDING_INSTANCE
                intf_attr[1].value.handle = l3vni_hdl
                intf_attr[2].id  = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_INSTANCE
                intf_attr[2].value.handle = port_fwd_inst_list[i].l2vni_hdl
                intf_attr[3].id = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_MAC
                intf_attr[3].value.mac = trans_mac_addr
                intf_attr[4].id = ifcs_ctypes.IFCS_INTF_ATTR_USER_COOKIE
                intf_attr[4].value.u32 = rng.randint(1,1023)
                intf_hdl = ifcs_ctypes.ifcs_handle_t()
                intf_hdl.value = ifcs_ctypes.IFCS_HANDLE_INTF(rand_intf_list[ind])
                ret = ifcs_ctypes.ifcs_intf_create(0, pointer(intf_hdl), intf_attr_count, compat_pointer(intf_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_intf_create")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during intf creation " + str(i)
                port_fwd_inst_list[i].intf_hdl = intf_hdl.value
                port_fwd_inst_list[i].intf_cookie = intf_attr[4].value.u32
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            l3_config_failed = 1
            log_err("Hit except L3 create config")
        except:
            l3_config_failed = 1
            log_err("Hit except L3 create config")

        ####### config FDB based on unidir topo #######
        config_fdb_methods['unidir'](sinst_info)

        ##### Config Loopback mode #######
        if (lb_type.upper() != 'NONE'):
            try:
                # Disable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

                for port in sinst_info.devport_list:
                    if port == cpu_port:
                        continue
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)

                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                for port in sinst_info.devport_list:
                    if port == cpu_port:
                        continue
                    if (lb_type.upper() == 'PCS'):
                        lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
                    elif (lb_type.upper() == 'PMA'):
                        lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
                    else:
                        lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
                    devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                    devport_attr[0].value.u32 = lb
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Set port loopback FAILED!!: rc = [" + str(rc) + "]"

                # Enable all the ports
                devport_attr_ct = 0
                devport_attr = (ifcs_ctypes.ifcs_attr_t * 2)()
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
                devport_attr_ct += 1
                if sinst_info.sdd == 1:
                    devport_attr[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SD_TX_OUTPUT_ENABLE;
                    devport_attr[1].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
                    devport_attr_ct += 1

                for port in sinst_info.devport_list:
                    if port == cpu_port:
                        continue
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin disable:" + str(port)
            except ValueError as ve:
                if Spst.device_access_error_exc_msg in "{}".format(ve):
                    # Re-raise exception for handling.
                    raise ve
                log_dbg(1, "{}".format(ve))
                log_err("Hit except (Devport loopback) config")
                devport_lb_config_failed = 1
            except:
                log_err("Hit except (Devport loopback) config")
                devport_lb_config_failed = 1
        else:
             try:
                # Enable all the ports
                devport_attr_ct = 1
                devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
                devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;

                for port in sinst_info.devport_list:
                    if port == cpu_port:
                        continue
                    rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                    spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during port admin enable:" + str(port)
             except ValueError as ve:
                if Spst.device_access_error_exc_msg in "{}".format(ve):
                    # Re-raise exception for handling.
                    raise ve
                log_dbg(1, "{}".format(ve))
                log_err("Hit except (Devport loopback NONE) config")
                devport_lb_config_failed = 1
             except:
                log_err("Hit except (Devport loopback NONE) config")
                devport_lb_config_failed = 1

        nodeObj = Node(self.cli)
        nodeObj.set("ifcs set node stats_poll_interval 1000")
        queueObj = Queue(self.cli)
        for port in sinst_info.devport_list:
            queueObj.set("ifcs set queue devport {} queue_id 0 uc_dynamic_threshold_factor 8".format(port))
            queueObj.set("ifcs set queue devport {} queue_id 0 nonuc_dynamic_threshold_factor 8".format(port))


        # Create trap hdl on first snake config; used when validate_on_stop is specified
        if self.run == -1:
            self.trap_hdl.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(self.trap_id)
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 1)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), self.cpu_queue_num)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_hostif_trap_create(self.cli.node_id,
                                                     pointer(self.trap_hdl),
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc,"ifcs_hostif_trap_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Hostif trap create failed for cpu queue {} with rc: {}".
                    format(self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create; rc: {}".format(rc)

            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 3)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_THRESHOLD_MODE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_THRESHOLD_MODE_STATIC)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_UC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 39000)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_NONUC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 39000)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc,"ifcs_cpu_queue_attr_set")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

            devportObj = Devport(self.cli)
            for port in sinst_info.devport_list:
                devportObj.set("ifcs set devport {} cut_through_enable 1".format(port))


        if sysport_hdl_get_failed or stp_create_failed or stp_port_set_failed or \
           l2vni_create_failed or l2vni_stp_config_failed or l2vni_member_config_failed or \
           src_l2entry_create_failed or dst_l2entry_create_failed or sysport_attr_set_failed or \
           devport_lb_config_failed or devport_shp_config_failed or queue_shp_config_failed:
            log_err("Spst test configuration failed")
            return 'FAILED'
        else:
            # Config success, save the config data useful for report generation
            self.insert_run_data(sinst_info)

        Spst.state = SNAKE_CONFIGD

        if (self.quiet == "false"):
            #display config
            sinst_info.display_config(sinst_info.id)

        # Wait for all ports to go link-up for 5 secs
        if (lb_type.upper() != 'NONE'):
            timer_val=5
        else:
            timer_val=15
        wait_time=0
        devport_attr_ct = 1
        devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
        devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS;
        devport_attr[0].value.u32 = 0;
        actual_count = c_uint32()
        link_status=True
        while wait_time<timer_val:
            link_status=True
            for devport in sinst_info.devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_get (sinst_info.node_id, devport, 1,
                                 compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t), pointer(actual_count));
                spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_get")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err(
                        "link status attribute get for devport {} failed with rc: {}"
                        .format(devport, rc))
                    assert 0, "ERR during port admin enable: {}".format(devport)

                if (devport_attr[0].value.u32 != 1):
                    link_status=False
            if link_status:
                break;
            else:
                wait_time+=0.1
                time.sleep(0.1)

        # Create and enable all ACL tables
        self.configAclCreateIngress(sinst_info)
        self.configAclCreateEgress(sinst_info)

        if link_status != True:
            log_err("Not all devports are up")
            assert 0, "Not all devports are up"

        # the snake-id and pkt-id followed by payload are added in start_traffic
        return 'PASS'


    def config_show(self, args):
        for instance in Spst.sinsts:
            sinst_info = instance
            table = PrintTable()
            header = []
            header.append("Devports")
            header.append("Loopback type")
            header.append("Spst id")
            header.append("Spst type")
            table.add_row(header)

            data = []
            data.append(str(sinst_info.devport_list)[1:-1])
            data.append(str(sinst_info.lb_type))
            data.append(str(sinst_info.id))
            data.append(str(sinst_info.type))
            table.add_row(data)
            table.print_table()
            table.reset_table()
        return 'PASS'

    def _gen_pkt_helper(self, sinst_info, res, size, pktid):
        data = []
        rem_size = size - L2HDR_SZ
        prot_sel = -1

        # Generate a stream of bits of rem_size*8 size and create a hex string
        randbits='{:08x}'.format((rng.getrandbits(rem_size*8)))
        x = 2
        # Convert the long hex string to list of bytes
        rand_bytes = [int(randbits[y - x:y], 16) for y in range(x, len(randbits) + x, x)]

        if len(rand_bytes) < rem_size:
            # It can so happen the leading bit in randbits could be 0s and the total num of bytes
            # could be less than anticipated. In such case, do padding
            pad = rem_size - len(rand_bytes)
            for pcur in range(pad):
                # Appending 0xAA
                rand_bytes.append(170)
                sinst_info.dbg1 += 1

        
        if size <= 102:
            data = L2HDR_ETV4_BYTES[:]
            data.extend(rand_bytes)

            #version,IHL field
            data[IPV4_VER_IHL_OFFSET] = 0x45
            # Total length field; +4 coz crc size should also be included
            data[IPV4_LEN_OFFSET] = (((rem_size + 4) & 0xff00) >> 8)
            data[IPV4_LEN_OFFSET+1] = ((rem_size + 4) & 0xff)
            # Make sure TTL > 1
            if data[IPV4_TTL_OFFSET] <= 1:
                data[IPV4_TTL_OFFSET] += 2
            # Set protocol to TCP
            data[IPV4_NXT_HDR] = 0x06
            l4sport_offset = 34
            prot_sel = PROT_IPV4_TCP
            log_dbg(1, "IPv4 TCP pkt; l4sport_off {}".format(l4sport_offset))
        else:
            
            tmp = rand_bytes[0]
            #Bits 0,1 for selecting from above protocol combination
            prot_sel = (tmp & 0x3)
            # Bits 2,3,4 for options
            ihl = ((tmp & 0x1c)>>2) + 5 # +5 because the minimum IHL is 5

            if prot_sel == PROT_IPV4_TCP or prot_sel == PROT_IPV4_UDP:
                data = L2HDR_ETV4_BYTES[:]
                data.extend(rand_bytes)

                l4sport_offset = L2HDR_SZ + ihl*4

                #version,IHL field
                data[IPV4_VER_IHL_OFFSET] = (((0x4 << 4) | ihl) & 0xff)
                # Total length field; +4 coz crc size should also be included
                data[IPV4_LEN_OFFSET] = (((rem_size + 4) & 0xff00) >> 8)
                data[IPV4_LEN_OFFSET+1] = ((rem_size + 4) & 0xff)
                # Make sure TTL > 1
                if data[IPV4_TTL_OFFSET] <= 1:
                    data[IPV4_TTL_OFFSET] += 2
                # Set protocol
                if prot_sel == PROT_IPV4_TCP:
                    data[IPV4_NXT_HDR] = 0x06
                    log_dbg(1, "IPv4 TCP pkt; l4sport_off {}".format(l4sport_offset))
                else:
                    data[IPV4_NXT_HDR] = 0x11
                    log_dbg(1, "IPv4 UDP pkt; l4sport_off {}".format(l4sport_offset))

            elif prot_sel == PROT_IPV6_TCP or prot_sel == PROT_IPV6_UDP:
                data = L2HDR_ETV6_BYTES[:]
                data.extend(rand_bytes)

                l4sport_offset = L2HDR_SZ + 40

                # version
                data[IPV6_VER_OFFSET] |= 0x60
                # Payload length field; +4 coz crc size should also be included
                data[IPV6_LEN_OFFSET] = (((rem_size - 40 + 4) & 0xff00) >> 8)
                data[IPV6_LEN_OFFSET+1] = ((rem_size - 40 + 4) & 0xff)
                # Set protocol
                if prot_sel == PROT_IPV6_TCP:
                    data[IPV6_NXT_HDR] = 0x06
                    log_dbg(1, "IPv6 TCP pkt; l4sport_off {}".format(l4sport_offset))
                else:
                    data[IPV6_NXT_HDR] = 0x11
                    log_dbg(1, "IPv6 TCP pkt; l4sport_off {}".format(l4sport_offset))
                # Make sure Hoplimit > 1
                if data[IPV6_HOP_OFFSET] <= 1:
                    data[IPV6_HOP_OFFSET] += 2

            else:
                log_err("Prot_sel invalid: {}".format(prot_sel))
                return -1,-1,None

        data[l4sport_offset] = ((L4SRCPORT & 0xff00) >> 8)
        data[l4sport_offset+1] = (L4SRCPORT & 0xff)
        data[l4sport_offset+2] = ((L4DSTPORT & 0xff00) >> 8)
        data[l4sport_offset+3] = (L4DSTPORT & 0xff)
        apphdr_offset = l4sport_offset + 4

        data[apphdr_offset] = 0xBE
        data[apphdr_offset + 1] = 0xBA
        data[apphdr_offset + 2] = 0xFE
        data[apphdr_offset + 3] = 0xCA
        #Snake-id
        data[apphdr_offset + 4] = sinst_info.id
        # pkt-id
        data[apphdr_offset + 5] = ((pktid) & 0xff)
        data[apphdr_offset + 6] = (((pktid) & 0xff00) >> 8)
        data[apphdr_offset + 7] = (((pktid) & 0xff0000) >> 16)

        log_dbg(1, "Sz: {} len(data): {}".format(size, len(data)))

        data_bytes = b''
        for c in range(len(data)):
            data_bytes += compat_chr(data[c])

        return 0,prot_sel,data_bytes

    def _gen_pkt(self, sinst_info, res, size, pktid):
        if res.payload == "rrstress":
            return self._gen_pkt_helper(sinst_info, res, size, pktid)
        elif res.payload == "stress":
            rc = 0
            if sinst_info.stress_data_bytes == None:
                ret,prot_sel,data_bytes = self._gen_pkt_helper(sinst_info, res, size, pktid)
                if ret < 0 or prot_sel < 0:
                    return ret,prot_sel,data_bytes

                sinst_info.stress_data_bytes = data_bytes
                sinst_info.stress_prot_sel = prot_sel
                rc = ret

            return rc,sinst_info.stress_prot_sel,sinst_info.stress_data_bytes


    def _send_packet(self, sinst_info, pdata, res, size):
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = sinst_info.devport_list[0]
            packet.dsp = getSysportHandleFromDevPort(sinst_info.node_id, dport)
            packet.pkt_buf = pdata
            packet.pkt_buf_len = size
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception when building pkt: {}".format(ve))
            return -1
        except Exception as e:
            log_err("Exception when building pkt: {}".format(e))
            return -1

        tx_busy_count = 0
        while (1):
            rc = ifcs_ctypes.ifcs_hostif_send_packet(sinst_info.node_id, pointer(packet))
            spstcommon_handle_device_access_error(rc,"ifcs_hostif_send_packet")
            if (rc == ifcs_ctypes.IFCS_SUCCESS):
                break
            if (rc != ifcs_ctypes.IFCS_BUSY):
                log_err("Packet send to pcie failed rc: {}".format(rc))
                return -1
            tx_busy_count += 1

            if tx_busy_count >= HOSTIF_SEND_PKT_BUSY_RETRY_CNT:
                log_err("Packet send failed after {} retries; rc: {}".format(HOSTIF_SEND_PKT_BUSY_RETRY_CNT, rc))
                return -1

            time.sleep(0.001)

        return 0

    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test start_traffic', prog='snake start_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')
        parser.add_argument('-s', type=str, default="1500:1", help='Comma separated pktsizes; a pktsize can be given a count. Ex: 1500:20,9216:10 results in 20 pkts of size 1500bytes and 10 pkts of 9216bytes')
        #parser.add_argument('-payload', type=str, choices=['rrstress', 'custom'], default='rrstress', help='Packet payload')
        parser.add_argument('-payload', type=str, choices=['rrstress', 'stress'], default='rrstress', help='Packet payload')
        #parser.add_argument('-custom_value', type=auto_int, default=None, help='16-bit custom payload. Used if payload is of type custom')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-vos', default=None, help='Validate-on-stop. If selected, upon stop_traffic, the traffic is terminated back to CPU and compared against injected packets. Supported only for uni-dir, loopback=PCS or PMA, single snake only', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to start traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        # Basic validations
        '''
        # Only rrstress supported, for now
        payload_data = res.custom_value
        if payload_data and res.payload != 'custom':
            log_err("ERROR: custom_value can be used only with payload of type custom")
            return 'FAILED'

        if (res.payload == 'custom') and (payload_data == None):
            log_err("ERROR: custom_value is mandatory for payload type custom")
            return 'FAILED'

        max_custom_val = 0xffff
        sinst_info.payload_type = res.payload
        if payload_data and payload_data not in range(max_custom_val):
            log_err("ERROR: custom_value valid range is 0-{0}".format(max_custom_val))
            return 'FAILED'
        '''

        if res.vos:
            if sinst_info.lb_type == 'NONE':
                log_err("ERROR: Validate-on-stop is not supported for loopback-type NONE")
                return 'FAILED'
            sinst_info.vos = 1
        else:
            sinst_info.vos = 0

        pktsizes = res.s.split(',')
        sinst_info.vos_gen_pkts = []
        sinst_info.vos_gen_pkts = [0] * MAX_PKTS
        sinst_info.vos_rcv_pktids = [0] * MAX_PKTS
        sinst_info.stress_prot_sel = 0
        sinst_info.stress_data_bytes = None

        # Only one packet size allowed for payload-type 'stress'
        if res.payload == 'stress' and len(pktsizes) > 1:
            log_err("Only one packet size allowed for payload-type=stress".format(MAX_PKTS))
            return 'FAILED'

        numpkts = 0
        for szitem in pktsizes:
            if numpkts >= MAX_PKTS:
                log_err("Max pkts supported: {}".format(MAX_PKTS))
                return 'FAILED'

            curcnt = 0
            cursize = 0
            if ':' in szitem:
                toks = szitem.split(':')
                cursize = int(toks[0])
                curcnt = int(toks[1])
            else:
                cursize = int(szitem)
                curcnt = 1

            if cursize < 64:
                cursize = 64

            cursize = cursize - 4
            for cc in range(curcnt):

                ret,prot_sel,data_bytes = self._gen_pkt(sinst_info, res, cursize, numpkts)
                if ret < 0 or prot_sel < 0:
                    log_err("Generate packet failed ret: {}".format(ret));
                    return 'FAILED'

                pdata = cast(data_bytes, c_void_p)
                ret = self._send_packet(sinst_info, pdata, res, cursize)
                if ret < 0:
                    log_err("Send packet failed ret: {}".format(ret));
                    return 'FAILED'

                if sinst_info.vos == 1:
                    sinst_info.vos_num_gen_pkts += 1
                    sinst_info.vos_prot_sel_gen_cnt[prot_sel] += 1
                    sinst_info.vos_gen_pkts.insert(numpkts, data_bytes)

                if(res.v == True):
                    log("Sent Packet-id {}(len:{}):".format(numpkts, len(data_bytes)))
                    log(":".join("{:02x}".format(compat_ord(c)) for c in data_bytes))

                numpkts += 1

        Spst.state = SNAKE_RUNNING
        sinst_info.state = SNAKE_RUNNING
        log('Started traffic on snake id %d' %(sinst_info.id))
        return 'PASS'

    def stop_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test stop_traffic', prog='snake stop_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')
        parser.add_argument('-d', type=int, default=10, dest='delay', help='Delay - how much time do we want to sleep after l2 attr_sets')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()
        type = sinst_info.type

        dmac_l2_entry_array = sinst_info.dmac_l2_entry_array
        smac_l2_entry_array = sinst_info.smac_l2_entry_array
        cpu_sp_hdl = sinst_info.cpu_sp_hdl
        stp_hdl = sinst_info.stp_hdl

        mac_addr_t = c_uint8 * 6
        devport_obj = Devport(self.cli)

        verbose = sinst_info.verbose
        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        ##################################
        # stop unidir traffic
        ##################################
        port = devport_list[0]
        #l2vni_hdl_list = sinst_info.l2vni_hdl_list
        port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[port].sp_hdl)
        port_hdl = ifcs_ctypes.ifcs_handle_t()
        l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
        mac_addr = mac_addr_t(0, 0, 0, 0, 0, 0xAA)
        port_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
        l2_entry = ifcs_ctypes.ifcs_l2_entry_key_t()
        ifcs_ctypes.ifcs_l2_entry_key_t_init(pointer(l2_entry))
        l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(port_fwd_inst_list[port].l2vni_hdl)

        ifcs_ctypes.ifcs_l2_entry_key_t_key_type_set(pointer(l2_entry),
                ifcs_ctypes.IFCS_L2_ENTRY_KEY_TYPE_MAC_L2VNI)
        ifcs_ctypes.ifcs_l2_entry_key_t_mac_l2vni_set(pointer(l2_entry),
                l2_entry.key.mac_l2vni)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_mac_addr_set(pointer(l2_entry.key.mac_l2vni),
                mac_addr)
        ifcs_ctypes.ifcs_l2_entry_key_mac_l2vni_t_l2vni_set(pointer(l2_entry.key.mac_l2vni),
                l2vni_hdl)

        attr_count = 0
        attr = (ifcs_ctypes.ifcs_attr_t * 2)()
        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        ifcs_ctypes.ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_DROP
        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_ctypes.ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(fwd_policy))
        attr_count += 1

        if sinst_info.vos == 1:
            # Register rx callback
            Spst.rx_cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(pkt_vos_cb)
            rc = ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(self.cli.node_id, None, Spst.rx_cbfn)
            spstcommon_handle_device_access_error(rc,"ifcs_hostif_register_rx_packet_notify")
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err("ERROR: Registering Packet Callback Function")

            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY)
            ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
            ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
            ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
            if self.trap_hdl.value == 0:
                log_err("ctc policy trap handle is 0")
                assert 0, "ctc policy trap handle is 0"
            ctc_policy.trap_handle = self.trap_hdl

            ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
            attr_count += 1

        rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        spstcommon_handle_device_access_error(rc,"ifcs_l2_entry_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "l2 entry attribute set for Drop FDB failed with rc: {}".format(
                    rc))
            assert 0, "Attr set to Drop FDB entry FAILED!!: rc = [{}]".format(
                rc)

        # Check sent packets against received packets - keep sleeping for 100ms until they match
        # Only sleep up to a max time of res.delay
        received = False
        maxNumSleeps = res.delay * 10
        for x in range (maxNumSleeps):
            all_received_packets = Spst.vos_glob_mismatch + sinst_info.vos_num_rcvd_total
            all_sent_packets = sinst_info.vos_num_gen_pkts
            if all_received_packets == all_sent_packets:
                received = True
                break
            time.sleep(0.1)
        time.sleep(2) # Need to sleep for two extra seconds to let sysport polling catch up

        if not received:
            log("Stop traffic did not receive all packets in {} seconds".format(res.delay))

        attr_count = 0
        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        ifcs_ctypes.ifcs_fwd_policy_t_init(pointer(fwd_policy))
        fwd_policy.fwd_action = ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_FWD_POLICY)
        ifcs_ctypes.ifcs_attr_t_value_fwd_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(fwd_policy))
        attr_count += 1

        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_L2_ENTRY_ATTR_ENTRY_CTC_POLICY)
        ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
        ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
        ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_DISABLE
        ctc_policy.trap_handle = self.trap_hdl

        ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
        attr_count += 1

        rc = ifcs_ctypes.ifcs_l2_entry_attr_set(0, pointer(l2_entry), attr_count, compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
        spstcommon_handle_device_access_error(rc,"ifcs_l2_entry_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err(
                "l2 entry attribute set for Fwd FDB failed with rc: {}".format(
                    rc))
            assert 0, "Attr set back to Fwd FDB entry FAILED!!: rc = [{}]".format(
                rc)

        if sinst_info.vos == 1:
            rc = ifcs_ctypes.ifcs_hostif_unregister_rx_packet_notify(self.cli.node_id)
            spstcommon_handle_device_access_error(rc,"ifcs_hostif_unregister_rx_packet_notify")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("ERROR: Unregistering Packet Callback Function")

        #get ACL stats
        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        #resetting to defaults
        sinst_info.vos = 0
        sinst_info.payload_type = 'incremental'

        Spst.state = SNAKE_STOPPED
        sinst_info.state = SNAKE_STOPPED
        log('Stopped traffic on snake id %d' %(sinst_info.id))
        return 'PASS'


    def gen_report(self, args, display = True, skipPop = False):
        if not skipPop:
            self.arg_list.pop(0)
            self.arg_list.pop(0)
            self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test gen_report', prog='snake gen_report', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-t', type=int, default=10, help='Time in seconds to collect stats')
        parser.add_argument('-v', type=int, default=0, help=argparse.SUPPRESS)
        parser.add_argument('-c', help='Clear the counter for this snake config', action="store_true")
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')
        pre_timestamp = [0] * MAX_DEV_PORTS
        new_timestamp = [0] * MAX_DEV_PORTS

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to generate report for a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()
        sinst_info.time = res.t
        verbose = res.v

        #Account for Inter-frame/packet-gap(12B) + preamble(8B)
        IPG_LEN = 12
        PREAMBLE_LEN = 8
        misc_delta_bytes = IPG_LEN + PREAMBLE_LEN

        devport_obj = Devport(self.cli)

        for p in range(MAX_DEV_PORTS):
            # Get current stats
            if p not in sinst_info.devport_list:
                continue

            port_stats = devport_obj.stats_get(p)
            pre_timestamp[p] = round(time.time(),4)
            sinst_info.devport_rx_frames[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            if p != cpu_port:
                sinst_info.devport_rx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            else:
                sinst_info.devport_rx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
            sinst_info.devport_tx_frames[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            if p != cpu_port:
                sinst_info.devport_tx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]
            else:
                sinst_info.devport_tx_bytes[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
            sinst_info.devport_rx_errors[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]
            sinst_info.devport_tx_errors[p] = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]

        # Sleep for given time and get stats again to calculate rate
        rx_rate = [0] * MAX_DEV_PORTS
        tx_rate = [0] * MAX_DEV_PORTS

        if display:
            log("Devport stats rate calculation being done, please wait %d secs" %(sinst_info.time))

        if (verbose):
            sinst_info.display()

        #Sleeping
        time.sleep(sinst_info.time)

        for p in range(MAX_DEV_PORTS):
            if p not in sinst_info.devport_list:
                continue
            port_stats = devport_obj.stats_get(p)
            new_timestamp[p] = round(time.time(),4)
            new_devport_rx_frames = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            if p != cpu_port:
                new_devport_rx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            else:
                new_devport_rx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
            new_devport_tx_frames = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            if p != cpu_port:
                new_devport_tx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]
            else:
                new_devport_tx_bytes = port_stats[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]

            #Calculate Delta
            delta_rx_frames = new_devport_rx_frames - sinst_info.devport_rx_frames[p]
            delta_tx_frames = new_devport_tx_frames - sinst_info.devport_tx_frames[p]
            delta_rx_bytes = new_devport_rx_bytes - sinst_info.devport_rx_bytes[p]
            delta_tx_bytes = new_devport_tx_bytes - sinst_info.devport_tx_bytes[p]
            delta_timestamp = float(new_timestamp[p] - pre_timestamp[p])

            delta_tx_bytes += (delta_tx_frames * misc_delta_bytes)
            delta_rx_bytes += (delta_rx_frames * misc_delta_bytes)

            rx_rate[p] = float(float(delta_rx_bytes * 8)/float(1000*1000*1000*delta_timestamp))
            tx_rate[p] = float(float(delta_tx_bytes * 8)/float(1000*1000*1000*delta_timestamp))

            sinst_info.devport_rx_frames[p] = new_devport_rx_frames
            sinst_info.devport_rx_bytes[p] = new_devport_rx_bytes
            sinst_info.devport_tx_frames[p] = new_devport_tx_frames
            sinst_info.devport_tx_bytes[p] = new_devport_tx_bytes
            sinst_info.devport_rx_gbps[p] = rx_rate[p]
            sinst_info.devport_tx_gbps[p] = tx_rate[p]

        if display:
            sinst_info.display()

        if res.c:
            for p in range(MAX_DEV_PORTS):
                # Clear current stats
                if p not in sinst_info.devport_list:
                    continue
                port_stats = devport_obj.stats_clear(p)
                #if sinst_info.state == SNAKE_STOPPED:
                    #sinst_info.num_pkt.clear()

        '''
        for i in range(len(Spst.sinsts)):
            log("Run %d config and stats:" %(i+1))
            log("-----------------------")
            Spst.sinsts[i].display()
        '''
        pass

    def configAclCreate(self, direction, lookupStage, scope, maxWidth, size, numTables, tableStartPriority, catchAll, fillTable, sinst_info):
        global ingress_delete_acls, egress_delete_acls

        for table_count in range(numTables):
            log_dbg(1, "Creating ACL Match Profile")
            matchProfile = ifcs_ctypes.ifcs_handle_t()
            attrList = (ifcs_ctypes.ifcs_attr_t * 9)()
            for index in range(9):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            match_types = ifcs_ctypes.ifcs_u32_list_t()
            if direction == 0:
                match_types.count = 23
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT_LAG
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L2VNI_ID
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3VNI
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE
                match_types.arr[5] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION_TYPE
                match_types.arr[6] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION
                match_types.arr[7] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FWD_LAYER
                match_types.arr[8] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_HIT
                match_types.arr[9] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_MAC_HIT
                match_types.arr[10] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L2_INTERFACE_USER_COOKIE
                match_types.arr[11] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2VNI_USER_COOKIE
                match_types.arr[12] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE_USER_COOKIE
                match_types.arr[13] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3VNI_USER_COOKIE
                match_types.arr[14] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2_ENTRY_DESTINATION_MAC_USER_COOKIE
                match_types.arr[15] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2_TYPE
                match_types.arr[16] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                match_types.arr[17] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_TYPE
                match_types.arr[18] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_DETECTED
                match_types.arr[19] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_TERMINATED
                match_types.arr[20] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_1_TYPE
                match_types.arr[21] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_2_TYPE
                match_types.arr[22] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_STP_STATE
            elif direction == 1:
                match_types.count = 5
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_ADDRESS
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_L2VNI_ID
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT_LAG
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_DIB_DIBP
            elif direction == 2:
                match_types.count = 6
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                match_types.arr[1] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT_LAG
                match_types.arr[2] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_SIB_SIBP
                match_types.arr[3] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L4_PROTOCOL
                match_types.arr[4] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_L4_PORT
                match_types.arr[5] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
            elif direction == 3:
                match_types.count = 1
                match_types.arr = (c_uint32 * match_types.count)()
                match_types.arr[0] = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
            else:
                log_err("Invalid direction: %d"%direction)

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_MATCH_TYPES
            attrList[index].value.u32_list = match_types
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_LOOKUP_STAGE
            attrList[index].value.u32 = lookupStage
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_DIRECTION
            if direction < 2:
                attrList[index].value.u32 = direction
            elif direction == 2:
                #Egress
                attrList[index].value.u32 = 1
            else:
                #ingress
                attrList[index].value.u32 = 0

            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_MAX_WIDTH
            attrList[index].value.u32 = maxWidth
            index += 1

            if direction == 0:
                attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_PROFILE_ATTR_PORT_SHARING
                attrList[index].value.data = ifcs_ctypes.IFCS_BOOL_TRUE
                index += 1

            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.im_acl_match_profile_create(
                    self.node_id, pointer(matchProfile), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc,"im_acl_match_profile_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to create ACL Match Profile: %d"%rc)
            else:
                sinst_info.list_of_mp_hdl.append(matchProfile)
                log_dbg(1, "Successfully created ACL Match Profile")

            log_dbg(1, "Creating ACL Action Profile")
            actionProfile = ifcs_ctypes.ifcs_handle_t()
            attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
            for index in range(4):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            action_types = ifcs_ctypes.ifcs_u32_list_t()
            action_types.count = 1
            action_types.arr = (c_uint32 * action_types.count)()
            action_types.arr[0] = ifcs_ctypes.IFCS_ACL_ACTION_TYPE_DROP
            attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_PROFILE_ATTR_ACTION_TYPES
            attrList[index].value.u32_list = action_types
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_PROFILE_ATTR_LOOKUP_STAGE
            attrList[index].value.u32 = lookupStage
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_ACTION_PROFILE_ATTR_DIRECTION
            if direction < 2:
                attrList[index].value.u32 = direction
            elif direction == 2:
                #Egress
                attrList[index].value.u32 = 1
            else:
                #Ingress
                attrList[index].value.u32 = 0
            index += 1

            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_action_profile_create(
                    self.node_id, pointer(actionProfile), attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc,"ifcs_acl_action_profile_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to create ACL Action Profile: %d"%rc)
            else:
                sinst_info.list_of_ap_hdl.append(actionProfile)
                log_dbg(1, "Successfully created ACL Action Profile")

            log_dbg(1, "Creating ACL Table")
            aclTable = ifcs_ctypes.ifcs_handle_t()
            attrList = (ifcs_ctypes.ifcs_attr_t * 10)()
            for index in range(10):
                rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                assert rc == ifcs_ctypes.IFCS_SUCCESS
            index = 0

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_MATCH_PROFILE
            attrList[index].value.handle = matchProfile
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_ACTION_PROFILE
            attrList[index].value.handle = actionProfile
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_LOOKUP_STAGE
            attrList[index].value.u32 = lookupStage
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_DIRECTION
            if direction < 2:
                attrList[index].value.u32 = direction
            elif direction == 2:
                #Egress
                attrList[index].value.u32 = 1
            else:
                #Ingress
                attrList[index].value.u32 = 0
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_SCOPE
            attrList[index].value.u32 = scope
            index += 1

            priority = table_count + tableStartPriority
            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_PRIORITY
            attrList[index].value.u32 = priority
            index += 1

            attrList[index].id = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_SIZE
            attrList[index].value.u32 = size
            index += 1

            attrCount = index
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_acl_table_create(
                    self.node_id,
                    pointer(aclTable),
                    attrCount,
                    compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

            spstcommon_handle_device_access_error(rc,"ifcs_acl_table_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to create ACL Table:%d"%rc)
            else:
                sinst_info.list_of_acl_table_hdl.append(aclTable)
                log_dbg(1, "Successfully created ACL Table {}".format(direction))

            devport_list = sinst_info.devport_list
            port_fwd_inst_list = sinst_info.port_fwd_inst_list

            nxt = 0
            for devport in devport_list:
                log_dbg(1, "Creating ACL matches for port {}".format (devport))
                if devport == devport_list[-1]: #last port
                    next_devport = devport_list[0]
                else:
                    next_devport = devport_list[nxt+1]

                if devport == devport_list[0]:
                    prev_devport = devport_list[-1]
                else:
                    prev_devport = devport_list[nxt-1]

                prev_port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[prev_devport].sp_hdl)
                next_port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].sp_hdl)

                prev_port_lag = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[prev_devport].lag_hdl)
                next_port_lag = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].lag_hdl)

                nxt += 1

                if direction == 0:
                    #INGRESS
                    #1 match ingress sysport
                    match_number = 1
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress sysport %d for port %d"%(match_number, port_sp, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #2 match ingress lag
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT_LAG
                    index += 1
                    lag_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_lag = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].lag_hdl)
                    lag_hdl.value = ifcs_ctypes.IFCS_HANDLE_LAG(port_lag)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), lag_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"im_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress lag %d for port %d"%(match_number, lag_hdl.value, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #3 match ingress_l2vni_id
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L2VNI_ID
                    index += 1
                    l2vni_id_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_l2vni_id = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].l2vni_hdl)

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_l2vni_id & 0x1F00) >> 8)
                    value.arr[1]= (port_l2vni_id & 0xFF)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress l2nvi id %d for port %d"%(match_number, port_l2vni_id, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)

                    #4 match ingres_l3vni
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3VNI
                    index += 1
                    l3vni_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_l3vni = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].l3vni_hdl)
                    l3vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L3VNI(port_l3vni)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), l3vni_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d l3vni %d for port %d"%(match_number, port_l3vni, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #5 match ingres_l3_interface
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE
                    index += 1
                    l3_interface_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_l3_interface = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].intf_hdl)
                    l3_interface_hdl.value = ifcs_ctypes.IFCS_HANDLE_INTF(port_l3_interface)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), l3_interface_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d ingress l3 interface %d for port %d"%(match_number, l3_interface_hdl.value, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #6 match forward_destination_type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION_TYPE
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=2
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #7 match forwarding destination
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FORWARD_DESTINATION
                    index += 1
                    lag_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_lag = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[next_devport].lag_hdl)
                    lag_hdl.value = ifcs_ctypes.IFCS_HANDLE_LAG(port_lag)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), lag_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #8 match fwd_layer
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_FWD_LAYER
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: switched, 1: routed
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #9 match destination_mac_hit
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_HIT
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: not hit, 1: hit
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #10 match source_mac_hit
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_MAC_HIT
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: not hit, 1: hit
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #11 match ingress l2 interface user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L2_INTERFACE_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_fwd_inst_list[devport].sp_cookie & 0x300) >> 8)
                    value.arr[1]= (port_fwd_inst_list[devport].sp_cookie & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #12 match ingress l2vni user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2VNI_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=port_fwd_inst_list[next_devport].l2vni_cookie
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #13 match ingress l3 interface user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_L3_INTERFACE_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_fwd_inst_list[next_devport].intf_cookie & 0x300) >> 8)
                    value.arr[1]= (port_fwd_inst_list[next_devport].intf_cookie & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("Create AclMatch %d l2vni user cookie %d for port %d failed"%(match_number, port_fwd_inst_list[devport].intf_cookie, devport))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d l2vni user cookie %d for port %d"%(match_number, port_fwd_inst_list[devport].intf_cookie, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #14 match ingress l3vni user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3VNI_USER_COOKIE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_fwd_inst_list[next_devport].l3vni_cookie & 0x300) >> 8)
                    value.arr[1]= (port_fwd_inst_list[next_devport].l3vni_cookie & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #15 match l2 entry destination mac user cookie
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2_ENTRY_DESTINATION_MAC_USER_COOKIE

                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #TODO@ACL set per port
                    value.arr[0]=port_fwd_inst_list[devport].l2_entry_dst_mac_user_cookie
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #16 match l2 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L2_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 0: none 1: Ethernet2, 2:LLC-SNAP 3:LLC
                    value.arr[0]=1
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #17 match l3 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                    index += 1

                    #set value
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 4: ipv4 5: ipv4_ext, 6: ipv6 7:ipv6_ext
                    value.arr[0]=4
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    #set mask
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0x4
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #18 match destination mac type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 0: UC  1: IPMC 2: L2MC 3: BC
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #19 match tunnel detected
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_DETECTED
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #20 match tunnel terminated
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_TUNNEL_TERMINATED
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1


                    #21 match ip ext hdr1 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_1_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: none
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #22 match ip ext hdr2 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_IP_EXT_HDR_2_TYPE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: none
                    value.arr[0]=0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #23 match ingress stp state
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_STP_STATE
                    index += 1

                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    #0: blocking 1: listen 2: learn 3: forward
                    value.arr[0]=3
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.ingress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    match_set = sinst_info.ingress_match_list_hdls[devport]

                elif direction == 1:
                    #EGRESS Table 1
                    match_number = 1
                    #1 match dest mac address
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_DESTINATION_MAC_ADDRESS
                    index += 1

                    #TODO@ACL: confirm dmac
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 6
                    value.arr = (c_uint8 * 6)()
                    value.arr[0]=0
                    value.arr[1]=0
                    value.arr[2]=0
                    value.arr[3]=0
                    value.arr[4]=0
                    value.arr[5]=0xAA

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d dest mac addr for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d dest mac addr for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #2 match egress_l2vni_id
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_L2VNI_ID
                    index += 1

                    l2vni_id_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_l2vni_id = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].l2vni_hdl)
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((port_l2vni_id & 0x1F00) >> 8)
                    value.arr[1]= (port_l2vni_id & 0xFF)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d egress l2vni id for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d egress l2vni id for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)

                    #3 match egress sysport
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d egress sysport for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d egress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #4 match egress lag
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT_LAG
                    index += 1
                    lag_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_lag = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].lag_hdl)
                    lag_hdl.value = ifcs_ctypes.IFCS_HANDLE_LAG(port_lag)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), lag_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d egress LAG for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d egress LAG for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    #5 match destination ib, destination ibp
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_DIB_DIBP
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    #get destination IB and IBP
                    ib_obj = _get_ib_from_devport(self.node_id, devport)
                    ib = ib_obj.ib
                    ibp = _get_ibport_from_devport(self.node_id, devport)
                    ib_ibp = self._get_ib_ibp(ib, ibp)
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((ib_ibp >> 8) & 0xff)
                    value.arr[1]= (ib_ibp & 0xff)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"im_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d destination IB and IBP for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d destination IB and IBP for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls[devport].append(aclMatch1)
                        match_number += 1

                    match_set = sinst_info.egress_match_list_hdls[devport]
                elif direction == 2:
                    #EGRESS Table 2
                    match_number = 1
                    #1 match ingress sysport
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT
                    index += 1
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(prev_port_sp)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), sp_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress sysport for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress sysport for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #2 match ingress lag
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT_LAG
                    index += 1
                    lag_hdl = ifcs_ctypes.ifcs_handle_t()
                    lag_hdl.value = ifcs_ctypes.IFCS_HANDLE_LAG(prev_port_lag)
                    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), ifcs_ctypes.IFCS_ACL_MATCH_ATTR_OBJECT);
                    ifcs_ctypes.ifcs_attr_t_value_handle_set(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index), lag_hdl);
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d ingress lag for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d ingress lag for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #3 match source ib, source ibp
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_INT_SIB_SIBP
                    index += 1

                    #get source IB and IBP
                    ib_obj = _get_ib_from_devport(self.node_id, prev_devport)
                    ib = ib_obj.ib
                    ibp = _get_ibport_from_devport(self.node_id, prev_devport)
                    ib_ibp = self._get_ib_ibp(ib, ibp)
                    if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 1
                        value.arr = (c_uint8 * 1)()
                        value.arr[0]= (ibp & 0x3f)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1
                    elif self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
                        value = ifcs_ctypes.ifcs_u8_list_t()
                        value.count = 2
                        value.arr = (c_uint8 * 2)()
                        value.arr[0]= ((ib_ibp >> 8) & 0xff)
                        value.arr[1]= (ib_ibp & 0xff)
                        attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                        attrList[index].value.u8_list = value
                        index += 1
                    else:
                        assert False, "Not supported on this device type {}".format(self.node_device_type)

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.im_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"im_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d sib and sibp for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d sib and sibp for devport %d prev_devport %d IBP %d value %d nxt %d sysport %d"%(match_number, devport, prev_devport, ibp, value.arr[0], nxt, sp_hdl.value))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #4 match l3 type
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
                    for index in range(4):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L3_TYPE
                    index += 1

                    #set value
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    # 4: ipv4 5: ipv4_ext, 6: ipv6 7:ipv6_ext
                    value.arr[0]=4
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    #set mask
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MASK
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 1
                    value.arr = (c_uint8 * 1)()
                    value.arr[0]=0x4
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create AclMatch %d for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created AclMatch %d for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #5 match source L4 port
                    aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    for index in range(3):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_SOURCE_L4_PORT
                    index += 1
                    value = ifcs_ctypes.ifcs_u8_list_t()
                    value.count = 2
                    value.arr = (c_uint8 * 2)()
                    value.arr[0]= ((L4SRCPORT & 0xFF00) >> 8)
                    value.arr[1]= (L4SRCPORT & 0xFF)
                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    attrList[index].value.u8_list = value
                    index += 1

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    attrList[index].value.handle = matchProfile
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_match_create(
                                self.node_id,
                                pointer(aclMatch1),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create egress AclMatch %d source L4 port for port %d rc %d"%(match_number, devport, rc))
                    else:
                        log_dbg(1, "Successfully created egress AclMatch %d source L4 port for port %d"%(match_number, devport))
                        sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                        match_number += 1

                    #6 match L4 protocol
                    #aclMatch1 = ifcs_ctypes.ifcs_handle_t()
                    #attrList = (ifcs_ctypes.ifcs_attr_t * 3)()
                    #for index in range(3):
                    #    rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                    #    assert rc == ifcs_ctypes.IFCS_SUCCESS
                    #index = 0
                    #attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_TYPE
                    #attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_MATCH_TYPE_L4_PROTOCOL
                    #index += 1
                    #value = ifcs_ctypes.ifcs_u8_list_t()
                    #value.count = 2
                    #value.arr = (c_uint8 * 2)()
                    #TODO@ACL: fill L4 protocol 6: tcp 17: udp
                    #value.arr[0]= 0
                    #value.arr[0]= 17
                    #attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_VALUE
                    #attrList[index].value.u8_list = value
                    #index += 1

                    #attrList[index].id = ifcs_ctypes.IFCS_ACL_MATCH_ATTR_MATCH_PROFILE
                    #attrList[index].value.handle = matchProfile
                    #index += 1

                    #attrCount = index
                    #rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    #        ifcs_ctypes.ifcs_acl_match_create(
                    #            self.node_id,
                    #            pointer(aclMatch1),
                    #            attrCount,
                    #            compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    #if rc != ifcs_ctypes.IFCS_SUCCESS:
                    #    log_err("failed to create egress AclMatch %d L4 protocol for port %d rc %d"%(match_number, devport, rc))
                    #else:
                    #    log_dbg(1, "Successfully created egress AclMatch %d L4 protocol for port %d"%(match_number, devport))
                    #    sinst_info.egress_match_list_hdls2[devport].append(aclMatch1)
                    #    match_number += 1

                    match_set = sinst_info.egress_match_list_hdls2[devport]

                # NULL ACL Action handle
                aclAction = ifcs_ctypes.ifcs_handle_t()

                log_dbg(1, "Creating ACE")
                aceList = []
                #numAces = 245 #7 * 35
                numAces = 1

                for i in range(numAces):
                    ace = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 8)()
                    for index in range(8):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0

                    sinst_info.ace_priority += 1
                    priority = sinst_info.ace_priority
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_PRIORITY
                    attrList[index].value.u32 = priority
                    index += 1

                    if direction == 0:
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_SCOPE
                        attrList[index].value.u32 = ifcs_ctypes.IFCS_ACL_SCOPE_PER_IB
                        index += 1

                        ib_obj = _get_ib_from_devport(self.node_id, devport)
                        ib = ib_obj.ib

                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_IB
                        attrList[index].value.u32 = ib
                        index += 1

                    if direction == 3:
                        empty_match_set = []
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                        matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                        matchSetHandleList.count = len(empty_match_set)
                        matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                        tindex = 0
                        for element in empty_match_set:
                            matchSetHandleList.list[tindex] = element
                            tindex += 1
                        attrList[index].value.handle_list = matchSetHandleList
                        index += 1
                    else:
                        attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                        matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                        matchSetHandleList.count = len(match_set)
                        matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                        tindex = 0
                        for element in match_set:
                            matchSetHandleList.list[tindex] = element
                            tindex += 1
                        attrList[index].value.handle_list = matchSetHandleList
                        index += 1

                    action_set = []
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_ACTION_SET
                    actionSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                    actionSetHandleList.count = len(action_set)
                    actionSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * actionSetHandleList.count)()
                    tindex = 0
                    for element in action_set:
                        actionSetHandleList.list[tindex] = element
                        tindex += 1
                    attrList[index].value.handle_list = actionSetHandleList
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_ace_create(
                                self.node_id,
                                pointer(ace),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))


                    spstcommon_handle_device_access_error(rc,"ifcs_ace_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create ACE for %d"%(rc))
                    else:
                        if direction == 0:
                            sinst_info.ingress_ace_list_hdls[devport].append(ace)
                            sinst_info.ing_ace_list_for_table1.append(ace)
                        elif direction == 1:
                            sinst_info.egress_ace_list_hdls[devport].append(ace)
                            sinst_info.egr_ace_list_for_table1.append(ace)
                        elif direction == 2:
                            sinst_info.egress_ace_list_hdls2[devport].append(ace)
                            sinst_info.egr_ace_list_for_table2.append(ace)
                        else:
                            sinst_info.ingress_ace_list_hdls2[devport].append(ace)
                            sinst_info.ing_ace_list_for_table2.append(ace)
                        log_dbg(1, "Successfully created all ACEs ")

                log_dbg(1, "Creating ACL ")
                acl = ifcs_ctypes.ifcs_handle_t()
                attrList = (ifcs_ctypes.ifcs_attr_t * 6)()
                for index in range(6):
                    rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                    assert rc == ifcs_ctypes.IFCS_SUCCESS

                index = 0
                attrList[index].id = ifcs_ctypes.IFCS_ACL_ATTR_SCOPE
                attrList[index].value.u32 = scope
                index += 1

                if direction == 0:
                    ib_obj = _get_ib_from_devport(self.node_id, devport)
                    ib = ib_obj.ib

                    attrList[index].id = ifcs_ctypes.IFCS_ACL_ATTR_IB
                    attrList[index].value.u32 = ib
                    index += 1

                attrCount = index

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_create(
                        self.node_id,
                        pointer(acl),
                        attrCount,
                        compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                spstcommon_handle_device_access_error(rc,"ifcs_acl_create")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to create ACL for  %d"%(rc))
                else:
                    if direction == 0:
                        sinst_info.ingress_acl_list_hdls[devport].append(acl)
                        sinst_info.ing_acl_list_for_table1.append(acl)
                    elif direction == 1:
                        sinst_info.egress_acl_list_hdls[devport].append(acl)
                        sinst_info.egr_acl_list_for_table1.append(acl)
                    elif direction == 2:
                        sinst_info.egress_acl_list_hdls2[devport].append(acl)
                        sinst_info.egr_acl_list_for_table2.append(acl)
                    else:
                        sinst_info.ingress_acl_list_hdls2[devport].append(acl)
                        sinst_info.ing_acl_list_for_table2.append(acl)
                    log_dbg(1, "Successfully created ACL")

                log_dbg(1, "Adding ACL to ACL Table")
                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = acl
                memberCount = 1
                attrCount = 0
                attrList = (ifcs_ctypes.ifcs_attr_t * 0)()

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_add(
                        self.node_id,
                        aclTable,
                        memberCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t),
                        attrCount,
                        compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_table_acl_add")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to add ACL to ACLTable: %d"%rc)
                else:
                    log_dbg(1, "Successfully added ACL to ACLTable")

                if direction == 0:
                    log_dbg(1, "Add port sharing to ACL")
                    sp_hdl = ifcs_ctypes.ifcs_handle_t()
                    port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                    sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                    portHandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                    portHandleList[0] = sp_hdl
                    portCount = 1
                    attrCount = 0
                    attrList = (ifcs_ctypes.ifcs_attr_t * 0)()

                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_port_add(
                            self.node_id,
                            acl,
                            portCount,
                            compat_pointer(portHandleList, ifcs_ctypes.ifcs_handle_t),
                            attrCount,
                            compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_port_add")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to add PORT to ACL: %d"%rc)
                    else:
                        log_dbg(1, "Successfully added PORT to ACL")

                log_dbg(1, "Adding ACEs to ACL")
                if direction == 0:
                    aceList = sinst_info.ingress_ace_list_hdls[devport]
                elif direction == 1:
                    aceList = sinst_info.egress_ace_list_hdls[devport]
                elif direction == 2:
                    aceList = sinst_info.egress_ace_list_hdls2[devport]
                else:
                    aceList = sinst_info.ingress_ace_list_hdls2[devport]

                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(aceList))()
                for idx in compat_xrange(len(aceList)):
                    acehandleList[idx] = aceList[idx]
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_add(
                        self.node_id,
                        acl,
                        len(aceList),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t),
                        0,
                        None))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_ace_add")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to add ACEs to ACL:  %d"%rc)
                else:
                     log_dbg(1, "Successfully added ACEs to ACL")
                     if direction == 0:
                          ingress_delete_acls = True
                     else:
                          egress_delete_acls = True
                if direction == 3:
                    break

            if direction == 1 or direction == 2:
                log_dbg(1, "Adding catch all Egress ACE to ACL")
                # NULL ACL match handle
                aclMatch = ifcs_ctypes.ifcs_handle_t()

                # NULL ACL Action handle
                aclAction = ifcs_ctypes.ifcs_handle_t()

                log_dbg(1, "Creating egress catch all ACE")
                aceList = []
                numAces = 1

                for i in range(numAces):
                    ace = ifcs_ctypes.ifcs_handle_t()
                    attrList = (ifcs_ctypes.ifcs_attr_t * 6)()
                    for index in range(6):
                        rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
                        assert rc == ifcs_ctypes.IFCS_SUCCESS
                    index = 0

                    sinst_info.ace_priority += 1
                    priority = sinst_info.ace_priority
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_PRIORITY
                    attrList[index].value.u32 = priority
                    index += 1

                    match_set = []
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_MATCH_SET
                    matchSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                    matchSetHandleList.count = len(match_set)
                    matchSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * matchSetHandleList.count)()
                    tindex = 0
                    for element in match_set:
                        matchSetHandleList.list[tindex] = element
                        tindex += 1
                    attrList[index].value.handle_list = matchSetHandleList
                    index += 1

                    action_set = []
                    attrList[index].id = ifcs_ctypes.IFCS_ACE_ATTR_ACTION_SET
                    actionSetHandleList = ifcs_ctypes.ifcs_handle_list_t()
                    actionSetHandleList.count = len(action_set)
                    actionSetHandleList.list = ( ifcs_ctypes.ifcs_handle_t * actionSetHandleList.count)()
                    tindex = 0
                    for element in action_set:
                        actionSetHandleList.list[tindex] = element
                        tindex += 1
                    attrList[index].value.handle_list = actionSetHandleList
                    index += 1

                    attrCount = index
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_ace_create(
                                self.node_id,
                                pointer(ace),
                                attrCount,
                                compat_pointer(attrList, ifcs_ctypes.ifcs_attr_t)))

                    spstcommon_handle_device_access_error(rc,"ifcs_ace_create")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to create catch all egress ACE:  %d"%rc)
                    else:
                        log_dbg(1, "Successfully created catch all egress ACE")
                        if direction == 1 :
                            sinst_info.egress_ace_list_hdls[devport].append(ace)
                            sinst_info.egr_ace_list_for_table1.append(ace)
                        elif direction == 2 :
                            sinst_info.egress_ace_list_hdls2[devport].append(ace)
                            sinst_info.egr_ace_list_for_table2.append(ace)
                        else:
                            log_err("Invalid direction: %d for catch all entry"%direction)
                        log_dbg(1, "Adding catch all egress ACE to ACL")
                        aceList.append(ace)

                        acehandleList = (ifcs_ctypes.ifcs_handle_t * len(aceList))()
                        for idx in compat_xrange(len(aceList)):
                            acehandleList[idx] = aceList[idx]
                        rc = ifcs_ctypes.IFCS_STATUS_REASON(
                            ifcs_ctypes.ifcs_acl_ace_add(
                                self.node_id,
                                acl,
                                len(aceList),
                                compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t),
                                0,
                                None))
                        spstcommon_handle_device_access_error(rc,"ifcs_acl_ace_add")
                        if rc != ifcs_ctypes.IFCS_SUCCESS:
                             log_err("failed to add catch all egress ACE to ACL:  %d"%rc)
                        else:
                             log_dbg(1, "Successfully added catch all egress ACE to ACL")

    def configAclDeleteAll(self, sinst_info):
        global ingress_delete_acls, egress_delete_acls
        log_dbg(1, "Starting ACL config delete")

        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list
        for devport in devport_list:
############################################################################
#################### ING TABLE 1 ###########################################
############################################################################
            if (len(sinst_info.ingress_ace_list_hdls[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls[devport][0],
                        len(sinst_info.ingress_ace_list_hdls[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 1")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 1: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully delete ACE from ING TABLE 1")

                sysporthandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                sp_hdl = ifcs_ctypes.ifcs_handle_t()
                port_sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[devport].sp_hdl)
                sp_hdl.value = ifcs_ctypes.IFCS_HANDLE_SYSPORT(port_sp)

                sysporthandleList[0] = sp_hdl
                portCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_port_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls[devport][0],
                        portCount,
                        compat_pointer(sysporthandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_port_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove SYSPORT from ACL ING TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed SYSPORT from ACL ING TABLE 1")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[0],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 1")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 1: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 1")

                log_dbg(1, "Deleting ACL MATCH from ING TABLE 1")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 1: rc=%d"%rc)


############################################################################
#################### ING TABLE 2 ###########################################
############################################################################

            if (len(sinst_info.ingress_ace_list_hdls2[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.ingress_ace_list_hdls2[devport]))()
                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls2[devport])):
                    acehandleList[loop] = sinst_info.ingress_ace_list_hdls2[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.ingress_acl_list_hdls2[devport][0],
                        len(sinst_info.ingress_ace_list_hdls2[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL ING TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL ING TABLE 2")

                for loop in compat_xrange(len(sinst_info.ingress_ace_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.ingress_ace_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from ING TABLE 2: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from ING TABLE 2")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.ingress_acl_list_hdls2[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[1],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL ING TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL ING TABLE 2")

                for loop in compat_xrange(len(sinst_info.ingress_acl_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.ingress_acl_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from ING TABLE 2: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from ING TABLE 2")

                log_dbg(1, "Deleting ACL MATCH from ING TABLE 2")
                for loop in compat_xrange(len(sinst_info.ingress_match_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.ingress_match_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from ING TABLE 2: rc=%d"%rc)

############################################################################
#################### EGR TABLE 1 ###########################################
############################################################################

            if (len(sinst_info.egress_ace_list_hdls[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.egress_ace_list_hdls[devport]))()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls[devport])):
                    acehandleList[loop] = sinst_info.egress_ace_list_hdls[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.egress_acl_list_hdls[devport][0],
                        len(sinst_info.egress_ace_list_hdls[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL EGR TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL EGR TABLE 1")

                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.egress_ace_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from EGR TABLE 1: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from EGR TABLE 1")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.egress_acl_list_hdls[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[2],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL EGR TABLE 1: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL EGR TABLE 1")

                for loop in compat_xrange(len(sinst_info.egress_acl_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from EGR TABLE 1: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from EGR TABLE 1")

                log_dbg(1, "Deleting ACL MATCH from EGR TABLE 1")
                for loop in compat_xrange(len(sinst_info.egress_match_list_hdls[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.egress_match_list_hdls[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from EGR TABLE 1: rc=%d"%rc)

############################################################################
#################### EGR TABLE 2 ###########################################
############################################################################

            if (len(sinst_info.egress_ace_list_hdls2[devport])) :
                acehandleList = (ifcs_ctypes.ifcs_handle_t * len(sinst_info.egress_ace_list_hdls2[devport]))()
                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls2[devport])):
                    acehandleList[loop] = sinst_info.egress_ace_list_hdls2[devport][loop]

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_ace_remove(
                        self.node_id,
                        sinst_info.egress_acl_list_hdls2[devport][0],
                        len(sinst_info.egress_ace_list_hdls2[devport]),
                        compat_pointer(acehandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_ace_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACEs from ACL EGR TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACES from ACL EGR TABLE 2")

                for loop in compat_xrange(len(sinst_info.egress_ace_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_ace_delete(
                            self.node_id,
                            sinst_info.egress_ace_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_ace_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                        log_err("failed to delete ACE from EGR TABLE 2: rc=%d"%rc)
                    else:
                        log_dbg(1, "Successfully deleted ACES from EGR TABLE 2")

                aclhandleList = (ifcs_ctypes.ifcs_handle_t * 1)()
                aclhandleList[0] = sinst_info.egress_acl_list_hdls2[devport][0]
                aclCount = 1

                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_acl_remove(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[3],
                        aclCount,
                        compat_pointer(aclhandleList, ifcs_ctypes.ifcs_handle_t)))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_table_acl_remove")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                    log_err("failed to remove ACL from ACL EGR TABLE 2: rc=%d"%rc)
                else:
                    log_dbg(1, "Successfully removed ACL from ACL EGR TABLE 2")

                for loop in compat_xrange(len(sinst_info.egress_acl_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_delete(
                            self.node_id,
                            sinst_info.egress_acl_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL from EGR TABLE 2: rc=%d"%rc)
                    else:
                         log_dbg(1, "Successfully deleted ACL from EGR TABLE 2")

                log_dbg(1, "Deleting ACL MATCH from EGR TABLE 2")
                for loop in compat_xrange(len(sinst_info.egress_match_list_hdls2[devport])) :
                    rc = ifcs_ctypes.IFCS_STATUS_REASON(
                        ifcs_ctypes.ifcs_acl_match_delete(
                            self.node_id,
                            sinst_info.egress_match_list_hdls2[devport][loop]))
                    spstcommon_handle_device_access_error(rc,"ifcs_acl_match_delete")
                    if rc != ifcs_ctypes.IFCS_SUCCESS:
                         log_err("failed to delete ACL MATCH from EGR TABLE 2: rc=%d"%rc)

            # end of devport with configs check
        # end of devport iterartor

        log_dbg(1, "Deleting all ACL Tables")
        for loop in compat_xrange(len(sinst_info.list_of_acl_table_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_table_delete(
                        self.node_id,
                        sinst_info.list_of_acl_table_hdl[loop]))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_table_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete ACL Tables: rc=%d"%rc)

        log_dbg(1, "Deleting all Match Profiles")
        for loop in compat_xrange(len(sinst_info.list_of_mp_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_match_profile_delete(
                        self.node_id,
                        sinst_info.list_of_mp_hdl[loop]))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_match_profile_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete all Match Profiles: rc=%d"%rc)

        log_dbg(1, "Deleting all Action Profiles")
        for loop in compat_xrange(len(sinst_info.list_of_ap_hdl)) :
                rc = ifcs_ctypes.IFCS_STATUS_REASON(
                    ifcs_ctypes.ifcs_acl_action_profile_delete(
                        self.node_id,
                        sinst_info.list_of_ap_hdl[loop]))
                spstcommon_handle_device_access_error(rc,"ifcs_acl_action_profile_delete")
                if rc != ifcs_ctypes.IFCS_SUCCESS:
                     log_err("failed to delete all Match Profiles: rc=%d"%rc)

        #ACL handles
        sinst_info.ingress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_ace_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_ace_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]

        sinst_info.ingress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_match_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_match_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]

        sinst_info.ingress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_acl_list_hdls = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.egress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]
        sinst_info.ingress_acl_list_hdls2 = [[] for i in range (MAX_DEV_PORTS)]

        sinst_info.ing_acl_list_for_table1 = []
        sinst_info.ing_acl_list_for_table2 = []
        sinst_info.egr_acl_list_for_table1 = []
        sinst_info.egr_acl_list_for_table2 = []

        sinst_info.ing_ace_list_for_table1 = []
        sinst_info.ing_ace_list_for_table2 = []
        sinst_info.egr_ace_list_for_table1 = []
        sinst_info.egr_ace_list_for_table2 = []

        sinst_info.list_of_acl_table_hdl = []
        sinst_info.list_of_mp_hdl = []
        sinst_info.list_of_ap_hdl = []

        sinst_info.ace_priority = 199

        sinst_info.devport_acl_stats = [[[0 for i in range(MAX_DEV_PORTS)] for j in range(4)] for k in range(MAX_DEV_PORTS)]
        sinst_info.devport_acl_catch_all_stats  = [0] * MAX_ACL_CATCH_ALL_TABLES

        log_dbg(1, "ACL config cleanup done")

    def configAclCreateIngress(self, sinst_info):
        # post-fwd ingress
        self.configAclCreate(ifcs_ctypes.IFCS_ACL_DIRECTION_INGRESS, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_PER_IB, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_480_BITS, 256, 1, 1, 0, 0, sinst_info)
        self.configAclCreate(3, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_80_BITS, 256, 1, 2, 0, 0, sinst_info)

    def configAclCreateEgress(self, sinst_info):
        # post-fwd egress
        self.configAclCreate(ifcs_ctypes.IFCS_ACL_DIRECTION_EGRESS, ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_160_BITS, 256, 1, 1, 0, 0, sinst_info)
        self.configAclCreate((ifcs_ctypes.IFCS_ACL_DIRECTION_EGRESS+1), ifcs_ctypes.IFCS_ACL_LOOKUP_STAGE_POST_FWD, ifcs_ctypes.IFCS_ACL_SCOPE_NODE, ifcs_ctypes.IFCS_ACL_MATCH_MAX_WIDTH_160_BITS, 256, 1, 2, 0, 0, sinst_info)

    def show_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test show_vos_stats', prog='snake show_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        log("Total CPU packets sent                   : {}".format(sinst_info.vos_num_gen_pkts))
        log("Total CPU packets received               : {}".format(sinst_info.vos_num_rcvd_total))
        log("Good CPU packets received                : {}".format(sinst_info.vos_num_rcvd_good))
        log("Bad CPU packets received                 : {}".format(sinst_info.vos_num_rcvd_bad))
        if Spst.vos_glob_mismatch > 0:
            log("Global (across all snakes) errors    : {}".format(Spst.vos_glob_mismatch))

        log("\nSpecifics:")
        log("IPV4 TCP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV4_TCP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV4_TCP]))
        log("IPV4 UDP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV4_UDP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV4_UDP]))
        log("IPV6 TCP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV6_TCP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV6_TCP]))
        log("IPV6 UDP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV6_UDP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV6_UDP]))

        # Print PASS/FAIL
        if sinst_info.vos_num_gen_pkts == 0:
            log("\nVOS_PFSTATUS: FAIL (Traffic not sent yet)")
            return 'FAILED'

        #TODO: Spst.vos_glob_mismatch is conceptually a global counter (across multiple snakes)
        # Revisit the second condition below when multi-snake support is needed
        if sinst_info.vos_num_rcvd_bad != 0 or Spst.vos_glob_mismatch != 0:
            # signature is good but payload is corrupted is caught here
            log("\nVOS_PFSTATUS: FAIL (Bad packets received)")

            for mismatch in sinst_info.len_mismatch:
                gen_pkt = mismatch[0]
                packet = mismatch[1]
                log("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
                log("Sent pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
                log("Received pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

            for mismatch in sinst_info.byte_mismatch:
                snake_id = mismatch[0]
                pkt_id = mismatch[1]
                i = mismatch[2]
                gen_pkt = mismatch [3]
                packet = mismatch [4]
                log("ID: {} pktid: {} mismatch; byte: {} sent: 0x{:02x} rcvd: 0x{:02x} xor: 0x{:02x}".format( \
                snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

            return 'FAILED'

        if sinst_info.vos_num_rcvd_total != sinst_info.vos_num_gen_pkts:
            
            log("\nVOS_PFSTATUS: FAIL (Mismatch between sent and received pkts OR some packets with bad hdr received)")

            missing_packets_printed = 0
            for i in range(sinst_info.vos_num_gen_pkts):
                print_pkt = 0
                if sinst_info.vos_rcv_pktids[i] == 0:
                    log("Didn't receive pktid: {}".format(i))
                    print_pkt = 1
                if sinst_info.vos_rcv_pktids[i] > 1:
                    log("Received pktid: {} {} times".format(i, sinst_info.vos_rcv_pktids[i]))
                    print_pkt = 1

                if print_pkt == 1:
                    log(" ".join("{:02x}".format(compat_ord(c)) for c in sinst_info.vos_gen_pkts[i]))
                    missing_packets_printed += 1
                if missing_packets_printed == 10:
                    log("Truncating our missing packets output to 10 packets for space saving purposes")
                    break

            for mismatch in sinst_info.len_mismatch:
                gen_pkt = mismatch[0]
                packet = mismatch[1]
                log("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
                log("Sent pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
                log("Received pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

            for mismatch in sinst_info.byte_mismatch:
                snake_id = mismatch[0]
                pkt_id = mismatch[1]
                i = mismatch[2]
                gen_pkt = mismatch [3]
                packet = mismatch [4]
                log("ID: {} pktid: {} mismatch; byte: {} sent: 0x{:02x} rcvd: 0x{:02x} xor: 0x{:02x}".format( \
                snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

            return 'FAILED'

        log("\nVOS_PFSTATUS: PASS")
        return 'PASS'

    def show_acl_stats(self, args):
        global sinst_info
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test show_acl_stats', prog='snake show_acl_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        ingress_acl_table_catch_all_stats = 0
        ingress_acl_all_devport_stats = 0
        for p in range(MAX_DEV_PORTS):
            # Get current stats
            if p not in sinst_info.devport_list:
                continue

            #Get ACE stats
            if p != cpu_port:
                table_id = 0
                for ace_list in [sinst_info.ingress_ace_list_hdls, sinst_info.ingress_ace_list_hdls2, sinst_info.egress_ace_list_hdls, sinst_info.egress_ace_list_hdls2]:
                    ace_id = p
                    ace = ace_list[ace_id]
                    if ace == []:
                       table_id += 1
                       continue
                    try:
                        sinst_info.devport_acl_stats[p][table_id][ace_id] = ace_get_packets(0, ace[0])
                    except:
                        table_id += 1
                        continue
                    if table_id == 0 :
                        ingress_acl_all_devport_stats += sinst_info.devport_acl_stats[p][table_id][ace_id]
                        log("ACL CP 1: Devport {} stats: {} packets".format(p, sinst_info.devport_acl_stats[p][table_id][ace_id]))
                    elif table_id == 1:
                        ingress_acl_table_catch_all_stats = sinst_info.devport_acl_stats[p][table_id][ace_id]
                    elif table_id == 2:
                        log("ACL CP 2: Devport {} stats: {} packets".format(p, sinst_info.devport_acl_stats[p][table_id][ace_id]))
                    elif table_id == 3:
                        log("ACL CP 3: Devport {} stats: {} packets".format(p, sinst_info.devport_acl_stats[p][table_id][ace_id]))
                    #log("Get port {} ACL table {} ace {} stats: {} packets".format(p, table_id, ace_id,sinst_info.devport_acl_stats[p][table_id][ace_id]))
                    table_id += 1

        #update ACE catch all stats
        sinst_info.devport_acl_catch_all_stats[0] = ingress_acl_table_catch_all_stats - ingress_acl_all_devport_stats
        log("ACL CP 1: catch-all stats: {} packets".format(sinst_info.devport_acl_catch_all_stats[0]))
        #sinst_info.devport_acl_catch_all_stats[0] = sinst_info.devport_acl_stats[1][1][1] - ingress_acl_table_catch_all_stats
        #log("Ingress ACL table1 catch all stats diff: {} packets".format(sinst_info.devport_acl_catch_all_stats[0]))

        for acl in sinst_info.egress_acl_list_hdls:
            if acl == []:
                continue
            ace_count = get_acl_ace_count(0, acl[0])
            if ace_count == 2:
                act_ace_count = c_uint32()
                ace_handle_list = (ifcs_ctypes.ifcs_handle_t * 2)()

                # Get ACE list
                rc = ifcs_ctypes.ifcs_acl_ace_get(self.cli.node_id, acl[0], 2, compat_pointer(ace_handle_list, ifcs_ctypes.ifcs_handle_t), pointer(act_ace_count))
                assert rc == ifcs_ctypes.IFCS_SUCCESS

                ace_handle_list = sorted(ace_handle_list)

                sinst_info.devport_acl_catch_all_stats[1] = ace_get_packets(0, ace_handle_list[1])
                log("ACL CP 2: catch-all stats: {} packets".format(sinst_info.devport_acl_catch_all_stats[1]))

        for acl in sinst_info.egress_acl_list_hdls2:
            if acl == []:
                continue
            ace_count = get_acl_ace_count(0, acl[0])
            if ace_count == 2:
                act_ace_count = c_uint32()
                ace_handle_list = (ifcs_ctypes.ifcs_handle_t * 2)()

                # Get ACE list
                rc = ifcs_ctypes.ifcs_acl_ace_get(self.cli.node_id, acl[0], 2, compat_pointer(ace_handle_list, ifcs_ctypes.ifcs_handle_t), pointer(act_ace_count))
                assert rc == ifcs_ctypes.IFCS_SUCCESS

                ace_handle_list = sorted(ace_handle_list)

                sinst_info.devport_acl_catch_all_stats[2] = ace_get_packets(0, ace_handle_list[1])
                log("ACL CP 3: catch all stats: {} packets".format(sinst_info.devport_acl_catch_all_stats[2]))

        return 'PASS'

    def clear_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test clear_vos_stats', prog='snake clear_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        sinst_info.vos_num_gen_pkts = 0
        sinst_info.vos_num_rcvd_total = 0
        sinst_info.vos_num_rcvd_good = 0
        sinst_info.vos_num_rcvd_bad = 0
        sinst_info.vos_prot_sel_gen_cnt = [0] * PROT_MAX
        sinst_info.vos_prot_sel_good_rcv_cnt = [0] * PROT_MAX
        sinst_info.len_mismatch = []
        sinst_info.byte_mismatch = []
        Spst.vos_glob_mismatch = 0
        sinst_info.vos_gen_pkts = [0] * MAX_PKTS
        sinst_info.vos_rcv_pktids = [0] * MAX_PKTS
        sinst_info.stress_prot_sel = 0
        sinst_info.stress_data_bytes = None
        return 'PASS'

    def clear_acl_stats(self, args):
        global sinst_info
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test clear_acl_stats', prog='snake clear_acl_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Spst.sinsts:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        for ace in sinst_info.ing_ace_list_for_table1:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.ing_ace_list_for_table2:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.egr_ace_list_for_table1:
            ace_clear_packets_bytes(0, ace)

        for ace in sinst_info.egr_ace_list_for_table2:
            ace_clear_packets_bytes(0, ace)

        sinst_info.devport_acl_catch_all_stats[0] = 0
        sinst_info.devport_acl_catch_all_stats[1] = 0
        sinst_info.devport_acl_catch_all_stats[2] = 0
        return 'PASS'


    def verify(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Spst test verify_traffic', prog='snake verify', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-rate', type=float, default=0, help='rx in gbps')
        parser.add_argument('-display', type=int, default=1, help='Log verbose')
        parser.add_argument('-ports', nargs='+', type=int, help=argparse.SUPPRESS)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAIL"
        rate = res.rate

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(Spst.sinsts):
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log("More than one snake configured. Use snake id to verify a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()
            res.id = -1

        # Caluculate rate
        self.gen_report(args, display = res.display, skipPop = True)
        ret = "PASS"

        num_ports = 0
        if res.ports is not None:
            num_ports = len(res.ports)

        # Verify the Tx and Rx rate for a given port pair
        if num_ports != 0:
            tx_port = res.ports[0]
            rx_port = res.ports[1]
            if (sinst_info.devport_tx_gbps[tx_port] == 0) or sinst_info.devport_rx_gbps[rx_port] == 0:
                ret = "FAIL"
                log(ret)
                return ret

            if rate != 0:
               #if (sinst_info.devport_rx_gbps[p] < (rate - 1)) or (sinst_info.devport_rx_gbps[p] > (rate + 1)):
               #400G and 200G line rate traffic test failing with above validation. Modifying as below to be generic
               if (abs(sinst_info.devport_rx_gbps[rx_port]-rate)/rate > 0.01):
                   ret = "FAIL"
                   log(ret)
                   return ret
        else:
            for p in sinst_info.devport_list:
                # If any of the configured ports rate is 0, snake test has problem
                if (sinst_info.devport_rx_gbps[p] == 0):
                    ret = "FAIL"
                    break
                if rate != 0:
                   #if (sinst_info.devport_rx_gbps[p] < (rate - 1)) or (sinst_info.devport_rx_gbps[p] > (rate + 1)):
                   if (abs(sinst_info.devport_rx_gbps[p]-rate)/rate > 0.01):
                       ret = "FAIL"
                       break
        log(ret)
        return ret

    def unconfig(self, args):
        parser = argparse.ArgumentParser(description='Spst unconfig', prog='snake unconfig', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Spst id needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(Spst.sinsts):
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log_err("Spst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Spst.sinsts:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to unconfig a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()
            res.id = -1

        verbose = sinst_info.verbose
        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        dmac_l2_entry_array = sinst_info.dmac_l2_entry_array
        smac_l2_entry_array = sinst_info.smac_l2_entry_array
        cpu_sp_hdl = sinst_info.cpu_sp_hdl
        stp_hdl = sinst_info.stp_hdl

        # Set Loopback state to NONE
        try:
            # Disable all the ports
            devport_attr_ct = 0
            devport_attr = (ifcs_ctypes.ifcs_attr_t * 2)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;
            devport_attr_ct += 1
            if sinst_info.sdd == 1:
                devport_attr[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_SD_TX_OUTPUT_ENABLE;
                devport_attr[1].value.u32 = ifcs_ctypes.IFCS_BOOL_TRUE;
                devport_attr_ct += 1

            for port in sinst_info.devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            for port in sinst_info.devport_list:
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Loopback set FAILED!!: rc = [" + str(rc) + "]"

        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except (Devport loopback) config")
        except:
            log_err("Hit except (Devport loopback) config")

        member_count = len(sinst_info.devport_list)
        member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()

        for count, port in enumerate(sinst_info.devport_list):
            member_list[count] = port_fwd_inst_list[port].sp_hdl

        # deleteing ACL configs
        self.configAclDeleteAll(sinst_info)

        if verbose:
            log("Removing L2 entry")

        try:
            #for l2_entry in smac_l2_entry_array:
            while smac_l2_entry_array:
                l2_entry = smac_l2_entry_array.pop(0)
                rc = ifcs_ctypes.ifcs_l2_entry_delete(0, pointer(l2_entry))
                spstcommon_handle_device_access_error(rc,"ifcs_l2_entry_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete SMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except (SMAC L2entry) delete")
        except:
            log_err("Hit except (SMAC L2entry) delete")

        try:
            #for l2_entry in dmac_l2_entry_array:
            while dmac_l2_entry_array:
                l2_entry = dmac_l2_entry_array.pop(0)
                rc = ifcs_ctypes.ifcs_l2_entry_delete(0, pointer(l2_entry))
                spstcommon_handle_device_access_error(rc,"ifcs_l2_entry_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Delete DMAC L2 entry FAILED!!: rc = [" + str(rc) + "]"
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except (DMAC L2entry) delete")
        except:
            log_err("Hit except (DMAC L2entry) delete")

        ####### Delete L3 Config ########
        try:
            for i in sinst_info.devport_list:
                intf_hdl = ifcs_ctypes.ifcs_handle_t()
                intf_hdl.value = port_fwd_inst_list[i].intf_hdl
                ret = ifcs_ctypes.ifcs_intf_delete(0, intf_hdl)
                spstcommon_handle_device_access_error(ret, "ifcs_intf_delete")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during intf delete " + str(i)


                l3vni_hdl = ifcs_ctypes.ifcs_handle_t()
                l3vni_hdl = port_fwd_inst_list[i].l3vni_hdl
                ret = ifcs_ctypes.ifcs_l3vni_delete(0, l3vni_hdl)
                spstcommon_handle_device_access_error(ret, "ifcs_l3vni_delete")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L3VNI delete " + str(i)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            l3_config_failed = 1
            log_err("Hit except L3 delete config")
        except:
            l3_config_failed = 1
            log_err("Hit except L3 delete config")

        if verbose:
            log("Removing L2VNI members")
        try:
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
            for i, port in enumerate(sinst_info.devport_list):
                if port == sinst_info.devport_list[0]:
                    next_devport = sinst_info.devport_list[-1]
                else:
                    next_devport = sinst_info.devport_list[i - 1]

                member_count = 2
                member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()
                member_list[0]  = port_fwd_inst_list[port].lag_hdl
                member_list[1]  = port_fwd_inst_list[next_devport].lag_hdl

                l2vni_hdl.value = port_fwd_inst_list[port].l2vni_hdl
                ret = ifcs_ctypes.ifcs_l2vni_member_remove(0, l2vni_hdl,
                                             member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t))
                spstcommon_handle_device_access_error(ret, "ifcs_l2vni_member_remove")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr remove " + str(l2vni_hdl)

                #Add CPU port to VNI membership if not already
                if cpu_port not in sinst_info.devport_list:
                    ret = ifcs_ctypes.ifcs_l2vni_member_remove(0, l2vni_hdl,
                                                1, pointer(cpu_sp_hdl))
                    spstcommon_handle_device_access_error(ret, "ifcs_l2vni_member_remove")
                    assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                        "ERR during L2VNI mbr remove for CPU port" + str(l2vni_hdl)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except L2VNI member delete")
        except:
            log_err("Hit except L2VNI member delete")

        ### Delete LAG #####
        try:
            lag_hdl = ifcs_ctypes.ifcs_handle_t()
            for i in sinst_info.devport_list:
                lag_hdl.value = port_fwd_inst_list[i].lag_hdl
                ret = ifcs_ctypes.ifcs_lag_delete(0, lag_hdl)
                spstcommon_handle_device_access_error(ret, "ifcs_lag_delete")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during LAG deletion " + str(i)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except LAG delete")
        except:
            log_err("Hit except LAG delete")


        try:
            for i in devport_list:
                sp = ifcs_ctypes.IFCS_HANDLE_VALUE(port_fwd_inst_list[i].sp_hdl)
                l2vni_hdl.value = port_fwd_inst_list[i].l2vni_hdl
                try:
                    vni_attr = (ifcs_ctypes.ifcs_attr_t * 1)()
                    vni_attr[0].id = ifcs_ctypes.IFCS_L2VNI_ATTR_STP_INSTANCE
                    vni_attr[0].value.handle = 0
                    ret = ifcs_ctypes.ifcs_l2vni_attr_set(0, l2vni_hdl, 1, compat_pointer(vni_attr, ifcs_ctypes.ifcs_attr_t))
                    spstcommon_handle_device_access_error(ret, "ifcs_l2vni_attr_set")
                    assert ret == ifcs_ctypes.IFCS_SUCCESS, "STP instance vni attr set FAILED!!"
                except ValueError as ve:
                    if Spst.device_access_error_exc_msg in "{}".format(ve):
                        # Re-raise exception for handling.
                        raise ve
                    log_dbg(1, "{}".format(ve))
                    log_err("L2VNI STP reset failed")
                except:
                    log_err("L2VNI STP reset failed")

                ret = ifcs_ctypes.ifcs_l2vni_delete(0, l2vni_hdl.value)
                spstcommon_handle_device_access_error(ret, "ifcs_l2vni_delete")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI delete " + str(i)
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except L2VNI delete")
        except:
            log_err("Hit except L2VNI delete")

        try:
            ret = ifcs_ctypes.ifcs_stp_delete(0, stp_hdl)
            spstcommon_handle_device_access_error(ret, "ifcs_stp_delete")
            assert ret == ifcs_ctypes.IFCS_SUCCESS, "ERR during STP delete"
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except STP delete")
        except:
            log_err("Hit except STP delete")

        # set sysport cvid attr to default
        sp_attr_ct = 4
        sp_attr = (ifcs_ctypes.ifcs_attr_t * sp_attr_ct)()

        try:
            for i, port in enumerate(sinst_info.devport_list):
                sp_attr[0].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_CVID
                sp_attr[0].value.u16 = 0
                sp_attr[1].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID
                sp_attr[1].value.u16 = 0
                sp_attr[2].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_EGRESS_UNTAGGED_VLAN_ID_ENABLE
                sp_attr[2].value.data = ifcs_ctypes.IFCS_BOOL_FALSE
                sp_attr[3].id = ifcs_ctypes.IFCS_SYSPORT_ATTR_USER_COOKIE
                sp_attr[3].value.u32 = 0

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id, port_fwd_inst_list[port].sp_hdl, sp_attr_ct, compat_pointer(sp_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc,"ifcs_sysport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"
        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except sysport cvid default")
        except:
            log_err("Hit except sysport cvid default")

        # Set Loopback state to NONE
        try:
            # Disable all the ports
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE;
            devport_attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE;

            for port in sinst_info.devport_list:
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS,\
                    "ERR during port admin disable:" + str(port)

            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            for port in sinst_info.devport_list:
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc,"ifcs_devport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "SSP default PVID set FAILED!!: rc = [" + str(rc) + "]"

        except ValueError as ve:
            if Spst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Hit except (Devport loopback) config")
        except:
            log_err("Hit except (Devport loopback) config")

        Spst.state = SNAKE_UNCONFIG

        if res.id != -1:
            del Spst.sinsts[res.id]
        else:
            Spst.sinsts.pop()
        Spst.run -= 1

        if self.run == -1:
            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 3)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_THRESHOLD_MODE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_THRESHOLD_MODE_DYNAMIC)
            attr_count += 1
            '''
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_UC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 0)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_NONUC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 0)
            attr_count += 1
            '''
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc,"ifcs_cpu_queue_attr_set")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(sinst_info.id, self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

            # Delete the trap on last snake unconfig
            rc = ifcs_ctypes.ifcs_hostif_trap_delete(self.cli.node_id, self.trap_hdl)
            spstcommon_handle_device_access_error(rc,"ifcs_hostif_trap_delete")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: hostif trap delete failed for cpu queue {} with rc: {}"
                    .format(sinst_info.id, self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create"

            devportObj = Devport(self.cli)
            for port in sinst_info.devport_list:
                devportObj.set("ifcs set devport {} cut_through_enable 0".format(port))

        log('Unconfigured snake id %d' %(sinst_info.id))
        return 'PASS'
