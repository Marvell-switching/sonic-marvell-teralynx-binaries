#------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#------------------------------------------------------------------------------
#

HOSTIF_SEND_PKT_BUSY_RETRY_CNT = 500

import os
import shlex
import argparse
import itertools
import time
import random
import json
from verbosity import *
from ctypes import *
from utils.common_util import strToList
from utils.compat_util import *
from cmdmgr import Command
from collections import OrderedDict
from ifcs_cmds.sysport import Sysport as sysport
from ifcs_cmds.devport import Devport as Devport
from ifcs_cmds.queue import Queue as Queue
from ifcs_cmds.tc import Tc as Tc
from ifcs_cmds.node import Node as Node
from print_table import PrintTable
from spst_tests_version import *
from spst_tests_common import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

PROT_IPV4_TCP = 0
PROT_IPV4_UDP = 1
PROT_IPV6_TCP = 2
PROT_IPV6_UDP = 3
PROT_MAX = 4

L2HDR_SZ=18
# Protocol field offsets
L2_ETYPE_OFFSET = 16

TUN_IPV4_VER_IHL_OFFSET = 18
TUN_IPV4_DSCP_OFFSET = 19
TUN_IPV4_LEN_OFFSET = 20
TUN_IPV4_IDENT_OFFSET = 22
TUN_IPV4_FLAGFRAG_OFFSET = 24
TUN_IPV4_TTL_OFFSET = 26
TUN_IPV4_NXT_HDR = 27
TUN_IPV4_CSUM_OFFSET = 28
TUN_IPV4_SIP_OFFSET = 30
TUN_IPV4_DIP_OFFSET = 34

IPV4_VER_IHL_OFFSET = 38
IPV4_DSCP_OFFSET = 39
IPV4_LEN_OFFSET = 40
IPV4_FLAGFRAG_OFFSET = 44
IPV4_TTL_OFFSET = 46
IPV4_NXT_HDR = 47
IPV4_CSUM_OFFSET = 48
IPV4_SIP_OFFSET = 50
IPV4_DIP_OFFSET = 54

IPV6_VER_OFFSET = 38
IPV6_LEN_OFFSET = 42
IPV6_NXT_HDR = 44
IPV6_HOP_OFFSET = 45
IPV6_SIP_OFFSET = 46
IPV6_DIP_OFFSET = 62

MIN_VLAN_ID = 1
MAX_VLAN_ID = 4095

MAX_DEV_PORTS = 520
MAX_PKTS = 2000

rng = None

'''
Tunspst Class - Initialize and Setup the switch for Tunspst.

Configuration:
  IVM:0>diagtest tunspst config -p 1-32 -lb 'PCS' -id 2
  -p : list of ports is a comma-separated list or hyphen separated
  -lb: {NONE,PCS,PMA}    Loopback type (default: NONE)
  -id: ID                User defined snake id [1-1023] (default: None)
  Ixia traffic can ingress on any port
  The other ports must be configured in internal loopback or have external loopback module
  The script does the following forwarding setup
    1. Ports put in internal loopback if specified using -lb option
    2. Sysports configured as L3PORT
    3. VRFs (L3VNIs) created, one per port
    4. L3 Interfaces created one per Sysport
    5. Nexthops created one per L3 interface
    6. Host Route entries (VRF, IP) -> NH (Intf, Dest Sysport) created.
       Packet snakes with below Routes:
       Route entry (VRF1, IP) -> NH1(Intf1, SP2)
       Route entry (VRF2, IP) -> NH2(Intf2, SP3)
       ..
       Route entry (VRF128, IP) -> NH0(Intf0, SP1)

Start traffic:
    IVM:0>diagtest tunspst start_traffic

Stop traffic:
    IVM:0>diagtest tunspst stop_traffic

Unconfig:
    IVM:0>diagtest tunspst unconfig

UNIDIR
******
It is assumed that each port has a loopback connection connecting its ingress to its egress.
The loopbacks can be either internal (PCS, PMA) or external (via a loopback module).
Since there are no physical connections between different ports, rules A and B do not apply and
hence we can specify any random subset out of the set of loopback connected ports.

External Traffic Stream Configuration
*************************************
If external traffic generator is used, the streams must be configured as follows:

UNIDIR
-- All ports have internal or external loopback
-- Ingress port will have external connection to traffic generator, so must have internal loopback
-- FWD: Ingress at any port

Packet headers are as follows:

L2 Header
=========
For FWD flows (bidir cross, unidir):
    dst_mac     : 00:03:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For FWD flows (bidir straight):
    dst_mac     : 00:05:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For REV flows (bidir cross, unidir):
    dst_mac     : 00:05:00:00:00:01
    src_mac     : 00:03:00:00:00:02
For REV flows (bidir straight):
    dst_mac     : 00:03:00:00:00:01
    src_mac     : 00:03:00:00:00:02

L3 Header
=========
For FWD flows:
    version        : 4
    ttl            : 255
    src            : 13.0.0.1
    dst            : 12.0.0.1
For REV flows:
    version        : 4
    ttl            : 255
    src            : 12.0.0.1
    dst            : 13.0.0.1
'''

def auto_int(x):
    return int(x, 0)

def config_show_sort_key(x):
    return x.id

SNAKE_UNCONFIG = 0
SNAKE_CONFIGD  = 1
SNAKE_RUNNING  = 2
SNAKE_STOPPED  = 3
NUM_NH_PER_PORT  = 4

def pkt_vos_cb(node_id, user_data, packet):
    global L2HDR_SZ
    mismatch = 0
    buf_len = packet.contents.pkt_buf_len
    buf = c_char_p(packet.contents.pkt_buf)
    packet = cast(buf, POINTER(c_char))
    packet = packet[:buf_len]
    prot_sel = -1
    apphdr_offset = 0

    
    if ((compat_ord(packet[IPV4_VER_IHL_OFFSET]) & 0xf0) >> 4) == 0x4:
        # ipv4 pkt
        ihl = compat_ord(packet[IPV4_VER_IHL_OFFSET]) & 0xf
        apphdr_offset = L2HDR_SZ + ihl*4 + 4 + 20
        if compat_ord(packet[IPV4_NXT_HDR]) == 0x06:
            prot_sel = PROT_IPV4_TCP
        elif compat_ord(packet[IPV4_NXT_HDR]) == 0x11:
            prot_sel = PROT_IPV4_UDP
    elif ((compat_ord(packet[IPV4_VER_IHL_OFFSET]) & 0xf0) >> 4)== 0x6:
        # ipv6 pkt
        apphdr_offset = L2HDR_SZ + 40 + 4 + 20
        if compat_ord(packet[IPV6_NXT_HDR]) == 0x06:
            prot_sel = PROT_IPV6_TCP
        elif compat_ord(packet[IPV6_NXT_HDR]) == 0x11:
            prot_sel = PROT_IPV6_UDP

    if apphdr_offset == 0:
        log("Received ethertype invalid;pkt[L2_ETYPE_OFFSET]: {} pkt[L2_ETYPE_OFFSET+1]: {}. Received pkt: {}".format(packet[L2_ETYPE_OFFSET], packet[L2_ETYPE_OFFSET+1]))
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Tunspst-id) as we don't know the snake-id here
        Tunspst.vos_glob_mismatch += 1
        return

    if prot_sel == -1:
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Tunspst-id) as we don't know the snake-id here
        Tunspst.vos_glob_mismatch += 1
        return

    if compat_ord(packet[apphdr_offset]) == 0xBE and compat_ord(packet[apphdr_offset+1]) == 0xBA and \
       compat_ord(packet[apphdr_offset+2]) == 0xFE and compat_ord(packet[apphdr_offset+3]) == 0xCA:
        log_dbg(1, "Received packet signature verified")
    else:
        log("Received packet signature invalid. Received pkt:")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        # Incrementing global mismatch counter id (not per Tunspst-id) as we don't know the snake-id here
        Tunspst.vos_glob_mismatch += 1
        return

    snake_id_idx = apphdr_offset + 4
    pkt_id_idx = snake_id_idx + 1
    snake_id = compat_ord(packet[snake_id_idx])
    find = False
    for instance in Tunspst.sinst_info_runs:
        if instance.id == snake_id:
            sinst_info = instance
            find = True
            break
    if find == False:
        log("Tunspst with id {0} doesn't exist".format(snake_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        Tunspst.vos_glob_mismatch += 1
        return

    pkt_id = compat_ord(packet[pkt_id_idx]) | (compat_ord(packet[pkt_id_idx + 1]) << 8) | (compat_ord(packet[pkt_id_idx + 2]) << 16)

    log_dbg(1, "Received pkt_id {}".format(pkt_id))

    if pkt_id >= MAX_PKTS:
        # Invalid pkt_id
        log("Invalid pkt_id: {}".format(pkt_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        Tunspst.vos_glob_mismatch += 1
        return

    gen_pkt = sinst_info.vos_gen_pkts[pkt_id]
    sinst_info.vos_num_rcvd_total += 1
    sinst_info.vos_rcv_pktids[pkt_id] += 1

    if isinstance(gen_pkt, int):
        # Why is it of type int; if it is a valid pkt it should be of type bytes.
        # pkt_id not expected
        log("Unexpected pkt_id: {}".format(pkt_id))
        log("Received pkt")
        log(":".join("{:02x}".format(compat_ord(c)) for c in packet))
        sinst_info.vos_num_rcvd_bad += 1
        return

    if len(gen_pkt) != len(packet):
        mismatch = 1
        sent_received = (gen_pkt, packet)
        sinst_info.len_mismatch.append(sent_received)

    #log(" ".join("{:02x}".format(compat_ord(c)) for c in packet))
    #log(" ".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))

    if mismatch == 0:
        # now compare the content
        for i in range(len(gen_pkt)):
           if packet[i] != gen_pkt[i]:
               mismatch = 1
               snake_pkt_byte = (snake_id, pkt_id, i, gen_pkt, packet)
               sinst_info.byte_mismatch.append(snake_pkt_byte)

    if mismatch == 0:
        sinst_info.vos_num_rcvd_good += 1
        sinst_info.vos_prot_sel_good_rcv_cnt[prot_sel] += 1
    else:
        sinst_info.vos_num_rcvd_bad += 1

    return

class PortFwdInst():
    def __init__(self):
        self.sp_hdl                   = 0
        self.l2vni_hdl                = 0
        self.l2vni_cookie             = 0
        self.l3vni_hdl                = 0
        self.intf_hdl                 = 0
        self.nh_hdls                  = OrderedDict()
        self.nh4_picked_hdl           = 0
        self.tun_nh_hdl               = 0
        self.v4_tun_dip               = 0x0
        self.tun_intf_hdl             = 0
        self.tun_dscp                 = 0
        self.tun_cross_intf_hdl       = 0
        self.tun_cross_intf_cookie    = 0
        self.v4_tun_sip               = 0x0
        self.tun_nh_cookie            = 0
        self.sp_def_tc                = 0
        self.sp_def_dp                = 0
        self.sp_cookie                = 0



# Object to store A "run" devport stats.
class SnakeInstInfo():
    def __init__(self):
        self.devport_rx_frames = [0] * MAX_DEV_PORTS
        self.devport_rx_bytes = [0] * MAX_DEV_PORTS
        self.devport_rx_gbps = [0] * MAX_DEV_PORTS
        self.devport_tx_frames = [0] * MAX_DEV_PORTS
        self.devport_tx_bytes = [0] * MAX_DEV_PORTS
        self.devport_tx_gbps = [0] * MAX_DEV_PORTS
        self.devport_rx_errors = [0] * MAX_DEV_PORTS
        self.devport_tx_errors = [0] * MAX_DEV_PORTS
        self.timestamp = [0] * MAX_DEV_PORTS
        self.devport_list = []
        self.lb_type = 0
        self.sdd = 0
        self.num_pkt = OrderedDict()
        self.node_id = 0
        self.verbose = 0
        self.time = 0
        self.port_fwd_inst_list  = [0] * MAX_DEV_PORTS
        self.ip1 = 0x0
        self.ip2 = 0x0
        self.id = 0
        self.type = 'None'
        self.intfmac1 = None
        self.intfmac2 = None
        self.tun_v4_dscp = 0
        self.tun_v4_flags = 0
        self.tun_v4_frag = 0
        self.tun_v4_ttl = 0
        self.tun_sip1 = 0x0
        self.tun_sip2 = 0x0
        self.tun_dip_base = 0x0
        self.v4_dscp = 0
        self.v4_flags = 0
        self.v4_frag = 0
        self.v4_ttl = 0
        self.v6_tc = 0
        self.dot1q_pcp = 0
        self.dot1q_dei = 0
        self.v6_hoplimit = 0
        self.v6_sip = []
        self.v6_dip = []
        self.l4_sport = 0
        self.l4_dport = 0
        self.l2hdr_etv4 = []
        self.l2hdr_etv6 = []
        self.payload_type = ""
        self.vos = 0
        self.vos_gen_pkts        = [0] * MAX_PKTS
        self.vos_rcv_pktids      = [0] * MAX_PKTS
        self.vos_num_gen_pkts    = 0
        self.vos_num_rcvd_total  = 0
        self.vos_num_rcvd_good   = 0
        self.vos_num_rcvd_bad    = 0
        self.vos_prot_sel_gen_cnt = [0] * PROT_MAX
        self.vos_prot_sel_good_rcv_cnt = [0] * PROT_MAX
        self.dbg1 = 0
        self.stress_prot_sel = 0
        self.stress_data_bytes = None
        self.state = SNAKE_UNCONFIG
        self.len_mismatch = []
        self.byte_mismatch = []

    def display(self):
        log("\nSnake id           : %d" %(self.id))
        log("Loopback type      : %s" %(self.lb_type))
        log("Snake type         : %s" %(self.type))
        log("Number of packets:")
        for size, num in compat_iteritems(self.num_pkt):
            log("    Size: %4s, Packets: %s" %(size, num))

        header = []
        header.append('Devport')
        header.append('RX(frames)')
        header.append('RX(bytes)')
        header.append('RX(Gbps)')
        header.append('RX(error frames)')
        header.append('TX(frames)')
        header.append('TX(bytes)')
        header.append('TX(Gbps)')
        header.append('TX(error frames)')
        table = PrintTable()
        table.add_row(header)
        for p in range(MAX_DEV_PORTS):
            if p not in self.devport_list:
                continue
            devport_row = []
            devport_row.append(str(p))
            devport_row.append(str(self.devport_rx_frames[p]))
            devport_row.append(str(self.devport_rx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_rx_gbps[p]))
            devport_row.append(str(self.devport_rx_errors[p]))
            devport_row.append(str(self.devport_tx_frames[p]))
            devport_row.append(str(self.devport_tx_bytes[p]))
            devport_row.append(str('%.2f' %self.devport_tx_gbps[p]))
            devport_row.append(str(self.devport_tx_errors[p]))
            table.add_row(devport_row)
        table.print_table()
        table.reset_table()

    def display_config(self, id):
        for instance in Tunspst.sinst_info_runs:
            if instance.id == id:
                sinst_info = instance
                table = PrintTable()
                header = []
                header.append("Devports")
                header.append("Loopback type")
                header.append("Snake id")
                header.append("Snake type")
                table.add_row(header)

                data = []
                data.append(str(sinst_info.devport_list)[1:-1])
                data.append(str(sinst_info.lb_type))
                data.append(str(id))
                data.append(str(sinst_info.type))
                table.add_row(data)
                table.print_table()
                table.reset_table()
                break


class Tunspst(Command):
    # All runs' devport stats are saved in below list
    sinst_info_runs = []
    snake_file_version = 0
    ver_disp = "" # nomenclature: <ifcs_version>_<snake_version>

    cpu_queue_num = 3
    trap_id = 65
    trap_hdl = ifcs_ctypes.ifcs_handle_t()
    rx_cbfn             = 0
    vos_glob_mismatch   = 0
    # Incremented for each run config (diagtest Tunspst config)
    run = -1
    device_access_error_exc_msg = DEVICE_ACCESS_ERROR_EXC_MSG

    def __init__(self, cli, quiet="false"):
        self.sub_cmds = {
                         'config'       : self.config,
                         'config_show'  : self.config_show,
                         'start_traffic': self.start_traffic,
                         'stop_traffic' : self.stop_traffic,
                         'show_vos_stats'  : self.show_vos_stats,
                         'clear_vos_stats' : self.clear_vos_stats,
                         'unconfig'     : self.unconfig,
                         'show_version' : self.show_ver,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.quiet = quiet
        self.arg_list = []
        self.node_device_type = 0
        version_num = [0] * 6
        for idx in range(len(SPST_TESTS_VERSION)):
            version_num[idx] = SPST_TESTS_VERSION[idx]
        self.ver_disp = "{}.{}.{}.{}.{}.{}".format(
            version_num[0], version_num[1], version_num[2], version_num[3],
            version_num[4], version_num[5])
        self.ver_disp = "{}_{}".format(self.ver_disp, self.snake_file_version)
        super(Tunspst, self).__init__()

    def __del__(self):
        return

    def show_ver(self, args):
        table = PrintTable()
        table.add_row(['IFCS TunSpst Version',"%s"%(self.ver_disp)])
        table.print_table()
        table.reset_table()

    def run_cmd(self, args):
        self.node_device_type = ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id)
        self.arg_list = shlex.split(args)
        try:
            rc = self.sub_cmds[self.arg_list[2]](args)
            return rc
        except (KeyError) as kex:
            log_err("Invalid cmd; Exception: {}".format(kex))
            self.help(args)
            return ifcs_ctypes.IFCS_PARAM
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            self.cli.error()
            log_err("Exception: {}".format(ve))
        except Exception as ex:
            self.cli.error()
            log_err("Exception: {}".format(ex))

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['config', 'Configure Tunspst test'])
        table.add_row(['config_show', 'Show Tunspst test configuration'])
        table.add_row(['start_traffic', 'Start Tunspst test traffic'])
        table.add_row(['stop_traffic', 'Stop Tunspst test traffic'])
        table.add_row(['show_vos_stats', 'Display vos statistics'])
        table.add_row(['clear_vos_stats', 'Clear vos statistics'])
        table.add_row(['verify', 'Verify if traffic is running on all configured ports'])
        table.add_row(['unconfig', 'Unconfigure Tunspst test'])
        table.add_row(['show_version', 'Show Spst file version'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        tunspst_help_string = """
Usage::

    Type "diagtest Tunspst <command>" followed by -h to see command's sub-options.
"""
        log(tunspst_help_string)

    def insert_run_data(self, run_data):
        # Increment run and insert run data
        Tunspst.run += 1
        Tunspst.sinst_info_runs.append(run_data)

    def get_run_data(self, run):
        return Tunspst.sinst_info_runs[run]

    def get_cur_run_data(self):
        run = Tunspst.run
        return Tunspst.sinst_info_runs[run]

    def get_max_devport(self, node_id=0):
        # Do get all devport to figure out max devports configured
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            devport = arg
            devport_list.append(devport)

        devport_list = []

        callback_type = CFUNCTYPE(
            ifcs_ctypes.UNCHECKED(None),
            ifcs_ctypes.ifcs_node_id_t,
            ifcs_ctypes.ifcs_devport_t,
            c_uint32,
            POINTER(ifcs_ctypes.ifcs_attr_t),
            POINTER(None))
        callback = callback_type(myCallback)

        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE)
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH)

        try:
            rc = ifcs_ctypes.ifcs_devport_get_all(node_id, 1, pointer(attr), compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
            spstcommon_handle_device_access_error(rc, "ifcs_devport_get_all")
            if ( rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err("Failed to get all devport rc: {0}".format(rc))
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("In except of devport get_all")
            pass

        return (len(devport_list))

    def configDevportGetSysportHandle(self, devport):
        '''
            Utility function that takes a devport
            and returns the handle to its corresponding
            sysport
        '''
        attr        =  ifcs_ctypes.ifcs_attr_t()
        count       =  c_uint32()
        attr.id     =  ifcs_ctypes.IFCS_DEVPORT_ATTR_SYSPORT
        attr_count  =  1
        rc = ifcs_ctypes.ifcs_devport_attr_get(self.cli.node_id, devport, attr_count, pointer(attr),
                                   pointer(count))
        spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_get")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get sysport for devport %d" % devport)
            return

        return attr.value.handle

    def configDevportSetAdminState(self, sinst_info, devport, admin_state):
        '''
            Utility function to configure devport's admin_state
        '''
        err = 0
        try:
            # Enable devport
            attr_list = (ifcs_ctypes.ifcs_attr_t * 3)()
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
            assert rc == ifcs_ctypes.IFCS_SUCCESS

            attr_count = 0
            attr_list[attr_count].id         = ifcs_ctypes.IFCS_DEVPORT_ATTR_ADMIN_STATE
            attr_list[attr_count].value.data = admin_state
            attr_count += 1

            if admin_state == ifcs_ctypes.IFCS_BOOL_TRUE:
                if self.node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
                    attr_list[attr_count].id        = ifcs_ctypes.IFCS_DEVPORT_ATTR_RX_EQ_FINE_TUNE
                    attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_DEVPORT_SERDES_RX_EQ_FINE_TUNE_CONTINUOUS
                    attr_count += 1
                if sinst_info.sdd:
                    attr_list[attr_count].id        = ifcs_ctypes.IFCS_DEVPORT_ATTR_SD_TX_OUTPUT_ENABLE
                    attr_list[attr_count].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE
                    attr_count += 1

            rc = ifcs_ctypes.ifcs_devport_attr_set(self.cli.node_id,
                                       devport,
                                       attr_count,
                                       compat_pointer(attr_list, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_set")
            assert rc == ifcs_ctypes.IFCS_SUCCESS, "ifcs_devport_attr_set ADMIN_STATE failed: rc={0} ".format(rc)
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Set devport admin state failed")
            err = 1

        return err

    def configSysportSetFwdMode(self, sinst_info, mode=ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L3_ONLY):
        '''
            Utility function to config sysports FWD MODE. Default mode in this API is L3_ONLY
        '''
        err = 0
        try:
            log_dbg(1, "Configure sysports as L3PORT")
            #sysport_hdls = sinst_info.sysport_hdls
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            # Set sysport's PORT_FWD_MODE to given mode
            for port in sinst_info.devport_list:
                attr = ifcs_ctypes.ifcs_attr_t()
                rc = ifcs_ctypes.ifcs_attr_t_init(pointer(attr))
                assert rc == ifcs_ctypes.IFCS_SUCCESS

                # Get PORT_FWD_MODE
                attr.id        = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_FWD_MODE
                actual_count   = c_uint32()
                actual_count_p = pointer(actual_count)

                rc = ifcs_ctypes.ifcs_sysport_attr_get(self.cli.node_id,
                                           port_fwd_inst_list[port].sp_hdl,
                                           1,
                                           pointer(attr),
                                           actual_count_p)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_get")
                if attr.value.u32 == mode:
                    continue

                # Set PORT_FWD_MODE
                attr_list  = (ifcs_ctypes.ifcs_attr_t * 1)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_PORT_FWD_MODE
                attr_list[attr_count].value.u32    = mode
                attr_count += 1

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id,
                                                port_fwd_inst_list[port].sp_hdl,
                                                attr_count,
                                                attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "sysport setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

                log_dbg(1, "   Configured sysports as L3PORT successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting devport fwd mode to L3")
            err = 1

        return err

    def configSysport(self, sinst_info, config = 1):
        '''
            Utility function to config sysports default TC/DP. Default mode in this API is L3_ONLY
        '''

        global rng
        err = 0
        try:
            log_dbg(1, "Configure sysports as L3PORT")
            #sysport_hdls = sinst_info.sysport_hdls
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            # Set sysport's PORT_FWD_MODE to given mode
            for port in sinst_info.devport_list:

                if config == 1:
                    port_fwd_inst_list[port].sp_def_tc = rng.randint(0,15)
                    port_fwd_inst_list[port].sp_def_dp = rng.randint(0,3)
                    port_fwd_inst_list[port].sp_cookie = rng.randint(1, 1023)
                else:
                    port_fwd_inst_list[port].sp_def_tc = 0
                    port_fwd_inst_list[port].sp_def_dp = 0
                    port_fwd_inst_list[port].sp_cookie = 0


                attr_list  = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_TC
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].sp_def_tc
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_DEFAULT_DP
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].sp_def_dp
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_USER_COOKIE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].sp_cookie
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_IPV4_TUNNEL_ENABLE
                attr_list[attr_count].value.data   = True
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_SYSPORT_ATTR_IPV6_TUNNEL_ENABLE
                attr_list[attr_count].value.data   = True
                attr_count += 1

                rc = ifcs_ctypes.ifcs_sysport_attr_set(self.cli.node_id,
                                                port_fwd_inst_list[port].sp_hdl,
                                                attr_count,
                                                attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_sysport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "sysport setAttr failed: port: {0}, rc :{1}".format(
                     port, rc)

                log_dbg(1, "   Configured sysports successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting sysport params")
            err = 1

        return err


    def configDevportsEnable(self, sinst_info):
        #Set devport admin state back to UP
        err = 0
        try:
            log_dbg(1, "Enabling devports")
            for port in sinst_info.devport_list:
                self.configDevportSetAdminState(sinst_info, port, ifcs_ctypes.IFCS_BOOL_TRUE)
            log_dbg(1, "   Enabled devports successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting devport admin state to UP")
            err = 1
        return err

    def configDevportsDisable(self, sinst_info):
        #Set devport admin state to DOWN
        err = 0
        try:
            log_dbg(1, "Disabling ports")
            for port in sinst_info.devport_list:
                self.configDevportSetAdminState(sinst_info, port, ifcs_ctypes.IFCS_BOOL_FALSE)
            log_dbg(1, "   Disabled devports successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error setting devport admin state to DOWN")
            err = 1
        return err

    def configDevportsLoopback(self, sinst_info, loopback_type='NONE'):
        log_dbg(1, "Setting Loopback type for all ports")
        err = 0
        try:
            devport_attr_ct = 1
            devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
            if (loopback_type == 'PCS'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PCS
            elif (loopback_type == 'PMA'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_PMA
            elif (loopback_type == 'NONE'):
                lb = ifcs_ctypes.IFCS_DEVPORT_LOOPBACK_NONE
            else:
                log_err("Invalid loopback type specified: {0}".format(loopback_type))
                lb_config_failed = 1
                return lb_config_failed

            # Set loopback type for all devports
            for port in sinst_info.devport_list:
                devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LOOPBACK
                devport_attr[0].value.u32 = lb
                rc = ifcs_ctypes.ifcs_devport_attr_set(0, port, devport_attr_ct, compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_set")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Devport loopback set to {0} FAILED. port={1} rc=[{2}]".format(loopback_type, port, rc)
            log_dbg(1, "   Set loopback type successfully")

        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Hit except (Devport loopback) config")
            err = 1

        return err

    def configL2vniCreate(self, sinst_info):
        '''
            Utility function to create one L2VNI per port
        '''
        global rng
        err = 0
        try:
            log_dbg(1, "Creating L2VNIs")
            ###### VNI CONFIG ######
            # Create VNI and add members
            rand_l2vni_list = rng.sample(compat_listrange(MIN_VLAN_ID, MAX_VLAN_ID), len(sinst_info.devport_list))
            l2vni_hdl = ifcs_ctypes.ifcs_handle_t()
            port_fwd_inst_list = sinst_info.port_fwd_inst_list

            for ind,port in enumerate(sinst_info.devport_list):
                ## Create L2VNI ##
                l2vni_attr_count = 1
                l2vni_attr = ifcs_ctypes.ifcs_attr_t()
                l2vni_attr.id         = ifcs_ctypes.IFCS_L2VNI_ATTR_USER_COOKIE
                l2vni_attr.value.u32  = rng.randint(1, 255)
                l2vni_hdl.value = ifcs_ctypes.IFCS_HANDLE_L2VNI(rand_l2vni_list[ind])
                ret = ifcs_ctypes.ifcs_l2vni_create(0, pointer(l2vni_hdl), l2vni_attr_count, compat_pointer(l2vni_attr, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_l2vni_create")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI creation " + str(port)
                port_fwd_inst_list[port].l2vni_hdl = l2vni_hdl.value
                port_fwd_inst_list[port].l2vni_cookie = l2vni_attr.value.u32
                log_dbg(1, "   Created L2VNIs successfully")

                ## Add L2VNI to current port and next port ##
                if port == sinst_info.devport_list[0]:
                    next_devport = sinst_info.devport_list[-1]
                else:
                    next_devport = sinst_info.devport_list[ind - 1]

                member_attr_count = 0
                member_attr_list = (ifcs_ctypes.ifcs_attr_t * member_attr_count)()
                member_count = 2
                member_list = (ifcs_ctypes.ifcs_handle_t * member_count)()
                member_list[0]  = port_fwd_inst_list[port].sp_hdl
                member_list[1]  = port_fwd_inst_list[next_devport].sp_hdl
                l2vni_hdl.value = port_fwd_inst_list[port].l2vni_hdl
                ret = ifcs_ctypes.ifcs_l2vni_member_add(0, l2vni_hdl,
                                             member_count, compat_pointer(member_list, ifcs_ctypes.ifcs_handle_t),
                                             member_attr_count, compat_pointer(member_attr_list, ifcs_ctypes.ifcs_attr_t))
                spstcommon_handle_device_access_error(ret, "ifcs_l2vni_member_add")
                assert ret == ifcs_ctypes.IFCS_SUCCESS,\
                       "ERR during L2VNI mbr add " + str(l2vni_hdl)
                log_dbg(1, "Added/Updated L2VNI membership successfully")

        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("L2vni create failed")
            err = 1

        return err


    def configL3vniCreate(self, sinst_info):
        '''
            Utility function to create one L3VNI per port
        '''
        global rng
        err = 0
        try:
            log_dbg(1, "Creating L3VNIs")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            rand_l3vni_list = rng.sample(compat_listrange(1, 255), len(sinst_info.devport_list))
            for ind,port in enumerate(sinst_info.devport_list):
                l3vni_attr_count = 0
                l3vni_attr = ifcs_ctypes.ifcs_attr_t()
                handle       = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_HANDLE_L3VNI(rand_l3vni_list[ind])
                rc = ifcs_ctypes.ifcs_l3vni_create(self.cli.node_id,
                                       pointer(handle),
                                       l3vni_attr_count,
                                       pointer(l3vni_attr))
                spstcommon_handle_device_access_error(rc, "ifcs_l3vni_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create l3vni {0} ret: {1}".format(port, rc)
                port_fwd_inst_list[port].l3vni_hdl = handle.value

            log_dbg(1, "   Created L3VNIs successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("L3vni create failed")
            err = 1

        return err

    def configIntfCreate(self, sinst_info):
        '''
            Utility function to create L3 Interfaces
        '''
        err = 0
        global rng
        try:
            log_dbg(1, "Creating L3 interfaces")

            flag = True
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for ind,port in enumerate(sinst_info.devport_list):
                if flag is True:
                    transportMac = sinst_info.intfmac1
                    flag = False
                else:
                    transportMac = sinst_info.intfmac2
                    flag = True


                attr_list  = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_TYPE_SVI
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_FORWARDING_INSTANCE
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].l3vni_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_INSTANCE
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].l2vni_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_MAC
                attr_list[attr_count].value.mac    = transportMac
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_IPV4_UNICAST_ENABLE
                attr_list[attr_count].value.data   = True
                attr_count += 1

                handle = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_intf_create(self.cli.node_id, pointer(handle), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].intf_hdl = handle.value


            log_dbg(1, "   Created L3 interfaces successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating L3 interfaces")
            err = 1

        return err

    def configNexthopCreate(self, sinst_info):
        '''
            Utility function to create Nexthops
        '''
        err = 0
        try:
            log_dbg(1, "Creating Nexthops")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for nh_iter in range(NUM_NH_PER_PORT):
                flag = True
                for port in sinst_info.devport_list:
                    if flag is False:
                        dest_mac = sinst_info.intfmac1
                        flag = True
                    else:
                        dest_mac = sinst_info.intfmac2
                        flag = False

                    attr_list = (ifcs_ctypes.ifcs_attr_t * 10)()
                    attr_count = 0
                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_INTF
                    attr_list[attr_count].value.handle = port_fwd_inst_list[port].intf_hdl
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DEST_MAC
                    attr_list[attr_count].value.mac    = dest_mac
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_LOCAL_DESTINATION
                    attr_list[attr_count].value.handle = port_fwd_inst_list[port].sp_hdl
                    attr_count += 1

                    attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_NO_DECREMENT_TTL
                    attr_list[attr_count].value.u8     = 1
                    attr_count += 1

                    handle       = ifcs_ctypes.ifcs_handle_t()
                    handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                    rc = ifcs_ctypes.ifcs_nexthop_create(self.cli.node_id,
                                             pointer(handle),
                                             attr_count,
                                             attr_list)
                    spstcommon_handle_device_access_error(rc, "ifcs_nexthop_create")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create nexthop {0} ret: {1}".format(port, rc)
                    port_fwd_inst_list[port].nh_hdls[nh_iter] = handle.value

            log_dbg(1, "   Created Nexthops successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating nexthops")
            err = 1

        return err

    def configTxTnlIntfCreate(self, sinst_info):
        '''
            Utility function to create Txonly Tunnel Interfaces
        '''
        err = 0
        global rng
        try:
            log_dbg(1, "Creating Txonly Tunnel interfaces")

            flag = True
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            ip_addr   = ifcs_ctypes.ifcs_ip_address_t()
            for ind,port in enumerate(sinst_info.devport_list):
                if flag is True:
                    ip_addr.addr.ipv4 = sinst_info.tun_sip1
                    flag = False
                else:
                    ip_addr.addr.ipv4 = sinst_info.tun_sip2
                    flag = True

                port_fwd_inst_list[port].v4_tun_dip = (sinst_info.tun_dip_base & 0xffffff00) | (port & 0xff)


                attr_list  = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_MODE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_MODE_P2P
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_DIRECTION
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_DIRECTION_TXONLY
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_IPADDR
                attr_list[attr_count].value.ip_addr = ip_addr
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_FORWARDING_INSTANCE
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].l3vni_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TUNNEL_ENCAP_DSCP_MODE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_TUNNEL_DSCP_MODE_USE_VALUE
                attr_count += 1

                '''
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TUNNEL_DSCP_VALUE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].tun_dscp = rng.randint(1,63)
                attr_count += 1
                '''

                handle = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_intf_create(self.cli.node_id, pointer(handle), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].tun_intf_hdl = handle.value
                port_fwd_inst_list[port].v4_tun_sip = ip_addr.addr.ipv4

            log_dbg(1, "   Created Tunnel tx only interfaces successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating Tx only tunnel interfaces")
            err = 1

        return err


    def configTnlNexthopCreate(self, sinst_info):
        '''
            Utility function to create Tunnel Nexthops
        '''
        err = 0
        try:
            log_dbg(1, "Creating Tunnel Nexthops")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            port_list = sinst_info.devport_list
            ip_addr   = ifcs_ctypes.ifcs_ip_address_t()
            for ind, port in enumerate(sinst_info.devport_list):
                nh = port_fwd_inst_list[port].nh_hdls[rng.randint(0, NUM_NH_PER_PORT-1)]
                port_fwd_inst_list[port].nh4_picked_hdl = nh
                ip_addr.addr.ipv4 = port_fwd_inst_list[port].v4_tun_dip

                '''
                if port == sinst_info.devport_list[-1]:
                    ip_addr.addr.ipv4 = port_fwd_inst_list[port_list[0]].v4_tun_dip
                else:
                    ip_addr.addr.ipv4 = port_fwd_inst_list[port_list[ind+1]].v4_tun_dip
                '''
                '''
                if port == sinst_info.devport_list[-1]:
                    port_fwd_inst_list[port_list[0]].v4_tun_dip = ip_addr.addr.ipv4 = (sinst_info.tun_dip_base & 0xffffff00) | (port & 0xff)
                else:
                    port_fwd_inst_list[port_list[ind+1]].v4_tun_dip = ip_addr.addr.ipv4 = (sinst_info.tun_dip_base & 0xffffff00) | (port & 0xff)
                '''

                attr_list = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_INTF
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].tun_intf_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DEST_IP
                attr_list[attr_count].value.ip_addr = ip_addr
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DIRECTION
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_NEXTHOP_DIRECTION_TXONLY
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_LOCAL_DESTINATION
                attr_list[attr_count].value.handle = port_fwd_inst_list[port].nh4_picked_hdl
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_NO_DECREMENT_TTL
                attr_list[attr_count].value.u8     = 1
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_USER_COOKIE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].tun_nh_cookie = rng.randint(1,15)
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_NEXTHOP_ATTR_DF_CONTROL
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_NEXTHOP_DF_CONTROL_ENABLE
                attr_count += 1

                handle       = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_nexthop_create(self.cli.node_id,
                                         pointer(handle),
                                         attr_count,
                                         attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_nexthop_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create Tunnel nexthop {0} ret: {1}".format(port, rc)
                port_fwd_inst_list[port].tun_nh_hdl = handle.value

            log_dbg(1, "   Created Tunnel Nexthops successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating Tunnel nexthops")
            err = 1

        return err

    def configTnlXCnctIntfCreate(self, sinst_info):
        '''
            Utility function to create Cross connect Interfaces
        '''
        err = 0
        global rng
        try:
            log_dbg(1, "Creating Cross Connect Tunnel interfaces")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            port_list          = sinst_info.devport_list
            ip_addr   = ifcs_ctypes.ifcs_ip_address_t()
            for ind,port in enumerate(port_list):

                if port == sinst_info.devport_list[-1]:
                    tnl_nh = port_fwd_inst_list[port_list[0]].tun_nh_hdl
                else:
                    tnl_nh = port_fwd_inst_list[port_list[ind+1]].tun_nh_hdl

                #tnl_nh = port_fwd_inst_list[port].tun_nh_hdl

                ip_addr.addr.ipv4 = port_fwd_inst_list[port].v4_tun_dip


                attr_list  = (ifcs_ctypes.ifcs_attr_t * 10)()
                attr_count = 0
                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TYPE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_TYPE_IP_IN_IPV4
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_MODE
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_MODE_SHARED
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_DIRECTION
                attr_list[attr_count].value.u32    = ifcs_ctypes.IFCS_INTF_DIRECTION_RXONLY
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_TRANSPORT_IPADDR
                attr_list[attr_count].value.ip_addr = ip_addr
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_CROSS_CONNECT
                attr_list[attr_count].value.data   = True
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_NEXTHOP
                attr_list[attr_count].value.handle = tnl_nh
                attr_count += 1

                attr_list[attr_count].id           = ifcs_ctypes.IFCS_INTF_ATTR_USER_COOKIE
                attr_list[attr_count].value.u32    = port_fwd_inst_list[port].tun_cross_intf_cookie = rng.randint(1,1023)
                attr_count += 1

                handle = ifcs_ctypes.ifcs_handle_t()
                handle.value = ifcs_ctypes.IFCS_NULL_HANDLE
                rc = ifcs_ctypes.ifcs_intf_create(self.cli.node_id, pointer(handle), attr_count, attr_list)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_create")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Failed to create intf " + str(port) + "ret: " + str(rc)
                port_fwd_inst_list[port].tun_cross_intf_hdl = handle.value


            log_dbg(1, "   Created Tunnel Cross connect interfaces successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error creating Cross connect interfaces")
            err = 1

        return err

    def configXCnctIntfDroprule(self, sinst_info, port_fwd_inst_list, drop_port):
        err = 0

        attr_list                              = (ifcs_ctypes.ifcs_attr_t * 10)()
        attr_count                             = 0

        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        fwd_policy.fwd_action                  = ifcs_ctypes.IFCS_FWD_ACTION_DROP
        attr_list[attr_count].id               = ifcs_ctypes.IFCS_INTF_ATTR_FWD_POLICY
        attr_list[attr_count].value.fwd_policy = fwd_policy
        attr_count += 1
        if sinst_info.vos == 1:
            ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
            ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
            ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_ENABLE
            if self.trap_hdl.value == 0:
                log_err("ctc policy trap handle is 0")
                assert 0, "ctc policy trap handle is 0"
            ctc_policy.trap_handle = self.trap_hdl
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_INTF_ATTR_CTC_POLICY)
            ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
            attr_count += 1

        rc = ifcs_ctypes.ifcs_intf_attr_set(self.cli.node_id,
                                       port_fwd_inst_list[drop_port].tun_cross_intf_hdl,
                                       attr_count,
                                       attr_list)
        spstcommon_handle_device_access_error(rc, "ifcs_intf_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to set intf attr to drop for port {0}, ret:{1}".format(drop_port, rc))
            err = 1

        return err

    def clearXCnctIntfDroprule(self, sinst_info, drop_port):
        err = 0
        port_fwd_inst_list = sinst_info.port_fwd_inst_list
        # Use previously created route_entry key, change fwd_policy attr action to forward
        attr_list                              =   (ifcs_ctypes.ifcs_attr_t * 10)()
        attr_count                             =   0

        fwd_policy = ifcs_ctypes.ifcs_fwd_policy_t()
        fwd_policy.fwd_action                  =   ifcs_ctypes.IFCS_FWD_ACTION_FORWARD
        attr_list[attr_count].id               =   ifcs_ctypes.IFCS_INTF_ATTR_FWD_POLICY
        attr_list[attr_count].value.fwd_policy =   fwd_policy
        attr_count += 1

        if sinst_info.vos == 1:
            ctc_policy = ifcs_ctypes.ifcs_ctc_policy_t()
            ifcs_ctypes.ifcs_ctc_policy_t_init(pointer(ctc_policy))
            ctc_policy.ctc_action = ifcs_ctypes.IFCS_COPY_TO_CPU_DISABLE
            ctc_policy.trap_handle = 0
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_INTF_ATTR_CTC_POLICY)
            ifcs_ctypes.ifcs_attr_t_value_ctc_policy_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, attr_count), pointer(ctc_policy))
            attr_count += 1

        rc = ifcs_ctypes.ifcs_intf_attr_set(self.cli.node_id,
                                            port_fwd_inst_list[drop_port].tun_cross_intf_hdl,
                                            attr_count,
                                            attr_list)
        spstcommon_handle_device_access_error(rc, "ifcs_intf_attr_set")
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to set intf attr to forward for port {0}, ret: {1}".format(drop_port, rc))
            err = 1

        return err

    '''
    def clearV4RouteDroprule(self, sinst_info, route_entry_key):
        return self.clearRouteDropruleInternal(sinst_info, route_entry_key, 1)

    def clearV6RouteDroprule(self, sinst_info, route_entry_key):
        return self.clearRouteDropruleInternal(sinst_info, route_entry_key, 0)
    '''

    def configTnlXCnctIntfDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting CrossConnect Tunnel interfaces")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].tun_cross_intf_hdl
                rc = ifcs_ctypes.ifcs_intf_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "CrossConnect Tunnel Intf: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted Cross Connect Tunnel interfaces successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting Cross Connect Tunnel interfaces: {}".format(e))
            err = 1
        return err


    def configTnlNexthopDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting Tunnel nexthops")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].tun_nh_hdl
                rc = ifcs_ctypes.ifcs_nexthop_delete(self.cli.node_id,
                                         handle)
                spstcommon_handle_device_access_error(rc, "ifcs_nexthop_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Tunnel Nexthop: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted Tunnel nexthops successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting tunnel nexthops: {}".format(e))
            err = 1
        return err

    def configNexthopDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting nexthops")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for nh_iter in range(NUM_NH_PER_PORT):
                for port in sinst_info.devport_list:
                    handle = port_fwd_inst_list[port].nh_hdls[nh_iter]
                    rc = ifcs_ctypes.ifcs_nexthop_delete(self.cli.node_id,
                                             handle)
                    spstcommon_handle_device_access_error(rc, "ifcs_nexthop_delete")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "Nexthop: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted nexthops successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting nexthops: {}".format(e))
            err = 1
        return err

    def configTxTnlIntfDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting Txonly Tunnel interfaces")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].tun_intf_hdl
                rc = ifcs_ctypes.ifcs_intf_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Tx only Tunnel Intf: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted Tx only Tunnel interfaces successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting Tx only Tunnel interfaces: {}".format(e))
            err = 1
        return err

    def configIntfDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting interfaces")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].intf_hdl
                rc = ifcs_ctypes.ifcs_intf_delete(self.cli.node_id,
                                      handle)
                spstcommon_handle_device_access_error(rc, "ifcs_intf_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "Intf: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted interfaces successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting L3 interfaces: {}".format(e))
            err = 1
        return err

    def configL2vniDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting L2VNIs")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].l2vni_hdl
                rc = ifcs_ctypes.ifcs_l2vni_delete(self.cli.node_id,
                                       handle)
                spstcommon_handle_device_access_error(rc, "ifcs_l2vni_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "L2VNI: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted L2VNIs successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting L2 vnis: {}".format(e))
            err = 1
        return err

    def configL3vniDelete(self, sinst_info):
        err = 0
        try:
            log_dbg(1, "Deleting L3VNIs")
            port_fwd_inst_list = sinst_info.port_fwd_inst_list
            for port in sinst_info.devport_list:
                handle = port_fwd_inst_list[port].l3vni_hdl
                rc = ifcs_ctypes.ifcs_l3vni_delete(self.cli.node_id,
                                       handle)
                spstcommon_handle_device_access_error(rc, "ifcs_l3vni_delete")
                assert rc == ifcs_ctypes.IFCS_SUCCESS, "L3VNI: port {0}, handle {1} delete failed: rc {2}".format(port, handle, rc)
            log_dbg(1, "   Deleted L3VNIs successfully")
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Error deleting L3 vnis: {}".format(e))
            err = 1
        return err

    def compute_l3_header_checksum(self, header, header_size):
        num_bytes = header_size
        offset = 0
        checksum = 0
        while num_bytes > 0:
            data_16_bit = 0
            data_16_bit += (header[offset] << 8) & 0xff00
            data_16_bit += header[offset+1] & 0xff

            offset += 2
            num_bytes -= 2

            #log("data %d"%(data_16_bit))
            checksum += data_16_bit
            checksum = (checksum >> 16) + (checksum & 0xffff)

        return (~checksum & 0xffff)

    def saveL2hdr(self, sinst_info):
        '''
        Utility routine to save the L2hdr content. Will be used in start_traffic while building pkts
        '''
        l2hdr = []
        global rng
        l2hdr.extend(list(sinst_info.intfmac2))
        l2hdr.extend(list(sinst_info.intfmac1))
        # Add TPID,vlanid
        l2hdr.append(0x81)
        l2hdr.append(0x00)
        fdp = sinst_info.devport_list[0]
        vid = ifcs_ctypes.IFCS_HANDLE_VALUE(sinst_info.port_fwd_inst_list[fdp].l2vni_hdl)
        tmp = ((sinst_info.dot1q_pcp << 13) | (sinst_info.dot1q_dei << 12) | vid) & 0xffff
        # until packet issue with pcp and dei is resolved, using only vid in the 8021q hdr
        tmp = vid
        l2hdr.append((tmp & 0xff00)>>8)
        l2hdr.append(tmp & 0xff)

        sinst_info.l2hdr_etv4 = l2hdr[:]
        sinst_info.l2hdr_etv4.append(0x08)
        sinst_info.l2hdr_etv4.append(0x00)

        #sinst_info.l2hdr_etv6 = l2hdr[:]
        #sinst_info.l2hdr_etv6.append(0x86)
        #sinst_info.l2hdr_etv6.append(0xDD)
        sinst_info.l2hdr_etv6 = l2hdr[:]
        sinst_info.l2hdr_etv6.append(0x08)
        sinst_info.l2hdr_etv6.append(0x00)
        return 0

    def show_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Tunspst test show_vos_stats', prog='snake show_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Tunspst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Tunspst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("Tunspst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Tunspst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        log("Total CPU packets sent                   : {}".format(sinst_info.vos_num_gen_pkts))
        log("Total CPU packets received               : {}".format(sinst_info.vos_num_rcvd_total))
        log("Good CPU packets received                : {}".format(sinst_info.vos_num_rcvd_good))
        log("Bad CPU packets received                 : {}".format(sinst_info.vos_num_rcvd_bad))
        if Tunspst.vos_glob_mismatch > 0:
            log("Global (across all snakes) errors    : {}".format(Tunspst.vos_glob_mismatch))

        log("\nSpecifics:")
        log("IPV4 TCP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV4_TCP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV4_TCP]))
        log("IPV4 UDP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV4_UDP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV4_UDP]))
        log("IPV6 TCP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV6_TCP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV6_TCP]))
        log("IPV6 UDP packets sent: {}  received: {}".format(sinst_info.vos_prot_sel_gen_cnt[PROT_IPV6_UDP], sinst_info.vos_prot_sel_good_rcv_cnt[PROT_IPV6_UDP]))

        # Print PASS/FAIL
        if sinst_info.vos_num_gen_pkts == 0:
            log("\nVOS_PFSTATUS: FAIL (Traffic not sent yet)")
            return 'FAILED'

        #TODO: Tunspst.vos_glob_mismatch is conceptually a global counter (across multiple snakes)
        # Revisit the second condition below when multi-snake support is needed
        if sinst_info.vos_num_rcvd_bad != 0 or Tunspst.vos_glob_mismatch != 0:
            # signature is good but payload is corrupted is caught here
            log("\nVOS_PFSTATUS: FAIL (Bad packets received)")

            for mismatch in sinst_info.len_mismatch:
                gen_pkt = mismatch[0]
                packet = mismatch[1]
                log("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
                log("Sent pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
                log("Received pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

            for mismatch in sinst_info.byte_mismatch:
                snake_id = mismatch[0]
                pkt_id = mismatch[1]
                i = mismatch[2]
                gen_pkt = mismatch [3]
                packet = mismatch [4]
                log("ID: {} pktid: {} mismatch; byte: {} sent: 0x{:02x} rcvd: 0x{:02x} xor: 0x{:02x}".format( \
                snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

            return 'FAILED'

        if sinst_info.vos_num_rcvd_total != sinst_info.vos_num_gen_pkts:
            
            log("\nVOS_PFSTATUS: FAIL (Mismatch between sent and received pkts OR some packets with bad hdr received)")

            missing_packets_printed = 0
            for i in range(sinst_info.vos_num_gen_pkts):
                print_pkt = 0
                if sinst_info.vos_rcv_pktids[i] == 0:
                    log("Didn't receive pktid: {}".format(i))
                    print_pkt = 1
                if sinst_info.vos_rcv_pktids[i] > 1:
                    log("Received pktid: {} {} times".format(i, sinst_info.vos_rcv_pktids[i]))
                    print_pkt = 1

                if print_pkt == 1:
                    log(" ".join("{:02x}".format(compat_ord(c)) for c in sinst_info.vos_gen_pkts[i]))
                    missing_packets_printed += 1
                if missing_packets_printed == 10:
                    log("Truncating our missing packets output to 10 packets for space saving purposes")
                    break

            for mismatch in sinst_info.len_mismatch:
                gen_pkt = mismatch[0]
                packet = mismatch[1]
                log("Length mismatch; Sent pkt len {} Rcvd pkt len {}".format(len(gen_pkt), len(packet)))
                log("Sent pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in gen_pkt))
                log("Received pkt")
                log(":".join("{:02x}".format(compat_ord(c)) for c in packet))

            for mismatch in sinst_info.byte_mismatch:
                snake_id = mismatch[0]
                pkt_id = mismatch[1]
                i = mismatch[2]
                gen_pkt = mismatch [3]
                packet = mismatch [4]
                log("ID: {} pktid: {} mismatch; byte: {} sent: 0x{:02x} rcvd: 0x{:02x} xor: 0x{:02x}".format( \
                snake_id, pkt_id, i, compat_ord(gen_pkt[i]), compat_ord(packet[i]), (compat_ord(gen_pkt[i]) ^ compat_ord(packet[i]))))

            return 'FAILED'

        log("\nVOS_PFSTATUS: PASS")
        return 'PASS'

    def clear_vos_stats(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Tunspst test clear_vos_stats', prog='snake clear_vos_stats', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=0, help='Tunspst id needed if more than one snake configured')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Tunspst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log("Tunspst with id",res.id,"doesn't exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Tunspst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        sinst_info.vos_num_gen_pkts = 0
        sinst_info.vos_num_rcvd_total = 0
        sinst_info.vos_num_rcvd_good = 0
        sinst_info.vos_num_rcvd_bad = 0
        sinst_info.vos_prot_sel_gen_cnt = [0] * PROT_MAX
        sinst_info.vos_prot_sel_good_rcv_cnt = [0] * PROT_MAX
        sinst_info.len_mismatch = []
        sinst_info.byte_mismatch = []
        Tunspst.vos_glob_mismatch = 0
        sinst_info.vos_gen_pkts = [0] * MAX_PKTS
        sinst_info.vos_rcv_pktids = [0] * MAX_PKTS
        sinst_info.stress_prot_sel = 0
        sinst_info.stress_data_bytes = None
        return 'PASS'

    def _gen_pkt_helper(self, sinst_info, res, size, pktid):
        data = []
        rem_size = size - len(sinst_info.l2hdr_etv4)
        prot_sel = -1

        # Generate a stream of bits of (rem_size)*8 size and create a hex string
        randbits='{:08x}'.format((rng.getrandbits((rem_size)*8)))
        x = 2
        # Convert the long hex string to list of bytes
        rand_bytes = [int(randbits[y - x:y], 16) for y in range(x, len(randbits) + x, x)]

        if len(rand_bytes) < rem_size:
            # It can so happen the leading bit in randbits could be 0s and the total num of bytes
            # could be less than anticipated. In such case, do padding
            pad = rem_size - len(rand_bytes)
            for pcur in range(pad):
                # Appending 0xAA
                rand_bytes.append(170)
                sinst_info.dbg1 += 1

        

        # Fill IPv4 tunnel header except checksum
        def fillTunHeader(d):
            ihl = 5

            d[TUN_IPV4_VER_IHL_OFFSET] = (((0x4 << 4) | ihl) & 0xff)
            #d[TUN_IPV4_DSCP_OFFSET] = sinst_info.tun_v4_dscp
            d[TUN_IPV4_DSCP_OFFSET] = 0 # Zeroing out
            # Total Length: OuterIPHdr+InnerIPHdr+InnerIPPayload
            d[TUN_IPV4_LEN_OFFSET] = (((rem_size) & 0xff00) >> 8)
            d[TUN_IPV4_LEN_OFFSET+1] = ((rem_size) & 0xff)
            d[TUN_IPV4_IDENT_OFFSET] = 0
            d[TUN_IPV4_IDENT_OFFSET+1] = 0
            flagfrag = (2 << 13) # To set DF bit
            d[TUN_IPV4_FLAGFRAG_OFFSET] = (flagfrag & 0xff00) >> 8
            d[TUN_IPV4_FLAGFRAG_OFFSET+1] = (flagfrag & 0xff) # =zero
            d[TUN_IPV4_TTL_OFFSET] = sinst_info.tun_v4_ttl
            d[TUN_IPV4_CSUM_OFFSET] = 0
            d[TUN_IPV4_CSUM_OFFSET+1] = 0
            start_devport = sinst_info.devport_list[0]
            end_devport = sinst_info.devport_list[-1]
            d[TUN_IPV4_SIP_OFFSET] =   (sinst_info.port_fwd_inst_list[start_devport].v4_tun_sip & 0xff000000) >> 24
            d[TUN_IPV4_SIP_OFFSET+1] = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_sip & 0xff0000) >> 16
            d[TUN_IPV4_SIP_OFFSET+2] = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_sip & 0xff00) >> 8
            d[TUN_IPV4_SIP_OFFSET+3] = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_sip & 0xff)
            d[TUN_IPV4_DIP_OFFSET]   = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_dip & 0xff000000) >> 24
            d[TUN_IPV4_DIP_OFFSET+1] = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_dip & 0xff0000) >> 16
            d[TUN_IPV4_DIP_OFFSET+2] = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_dip & 0xff00) >> 8
            d[TUN_IPV4_DIP_OFFSET+3] = (sinst_info.port_fwd_inst_list[start_devport].v4_tun_dip & 0xff)

        if size <= 126:
            ihl = 5
            prot_sel = PROT_IPV4_TCP
        else:
            tmp = rand_bytes[0]
            #Bits 0,1 for selecting from above protocol combination
            prot_sel = (tmp & 0x3)
            # Bits 2,3,4 for options
            ihl = ((tmp & 0x1c)>>2) + 5 # +5 because the minimum IHL is 5

        if prot_sel == PROT_IPV4_TCP or prot_sel == PROT_IPV4_UDP:
            data = sinst_info.l2hdr_etv4[:]
            data.extend(rand_bytes)
            fillTunHeader(data)
            data[TUN_IPV4_NXT_HDR] = 0x4 # IPv4 in IPv4
            #version,IHL field
            data[IPV4_VER_IHL_OFFSET] = (((0x4 << 4) | ihl) & 0xff)
            data[IPV4_DSCP_OFFSET] = sinst_info.v4_dscp
            # Total length field; +4 coz crc size should also be included
            data[IPV4_LEN_OFFSET] = (((rem_size - 20) & 0xff00) >> 8)
            data[IPV4_LEN_OFFSET+1] = ((rem_size - 20) & 0xff)
            flagfrag = (sinst_info.v4_flags << 13) | (sinst_info.v4_frag)
            data[IPV4_FLAGFRAG_OFFSET] = (flagfrag & 0xff00) >> 8
            data[IPV4_FLAGFRAG_OFFSET+1] = (flagfrag & 0xff)
            data[IPV4_TTL_OFFSET] = sinst_info.v4_ttl

            l4sport_offset = len(sinst_info.l2hdr_etv4) + ihl*4 + 20
            # Set protocol
            if prot_sel == PROT_IPV4_TCP:
                data[IPV4_NXT_HDR] = 0x06
                log_dbg(1, "IPv4 TCP pkt; l4sport_off {}".format(l4sport_offset))
            else:
                data[IPV4_NXT_HDR] = 0x11
                log_dbg(1, "IPv4 UDP pkt; l4sport_off {}".format(l4sport_offset))

            data[IPV4_CSUM_OFFSET] = 0x0
            data[IPV4_CSUM_OFFSET+1] = 0x0
            data[IPV4_SIP_OFFSET] = (sinst_info.ip2 & 0xff000000) >> 24
            data[IPV4_SIP_OFFSET+1] = (sinst_info.ip2 & 0xff0000) >> 16
            data[IPV4_SIP_OFFSET+2] = (sinst_info.ip2 & 0xff00) >> 8
            data[IPV4_SIP_OFFSET+3] = (sinst_info.ip2 & 0xff)

            data[IPV4_DIP_OFFSET] = (sinst_info.ip1 & 0xff000000) >> 24
            data[IPV4_DIP_OFFSET+1] = (sinst_info.ip1 & 0xff0000) >> 16
            data[IPV4_DIP_OFFSET+2] = (sinst_info.ip1 & 0xff00) >> 8
            data[IPV4_DIP_OFFSET+3] = (sinst_info.ip1 & 0xff)


            hdr = data[len(sinst_info.l2hdr_etv4)+20:len(sinst_info.l2hdr_etv4)+ihl*4+20]
            hdrsz = ihl*4
            csum = self.compute_l3_header_checksum(hdr, hdrsz)
            data[IPV4_CSUM_OFFSET] = (csum & 0xff00) >> 8
            data[IPV4_CSUM_OFFSET+1] = (csum & 0xff)

        elif prot_sel == PROT_IPV6_TCP or prot_sel == PROT_IPV6_UDP:
            data = sinst_info.l2hdr_etv6[:]
            data.extend(rand_bytes)
            fillTunHeader(data)
            data[TUN_IPV4_NXT_HDR] = 0x29 # IPv6 in IPv4

            l4sport_offset = len(sinst_info.l2hdr_etv6) + 40 + 20

            # version 4bits
            #data[IPV6_VER_OFFSET] = 0x60
            # TC split between VER_OFFSET and next byte.
            # Using the generated bytes at IPV6_VER_OFFSET, IPV6_VER_OFFSET+1, IPV6_VER_OFFSET+2 to fill the 20bits of flowlabel
            tmp = ((0x6 << 28) | (sinst_info.v6_tc << 20) | (data[IPV6_VER_OFFSET] << 12) | (data[IPV6_VER_OFFSET + 1] << 4) | (data[IPV6_VER_OFFSET + 2] & 0xf))
            data[IPV6_VER_OFFSET] = (tmp & 0xff000000) >> 24
            data[IPV6_VER_OFFSET + 1] = (tmp & 0xff0000) >> 16
            data[IPV6_VER_OFFSET + 2] = (tmp & 0xff00) >> 8
            data[IPV6_VER_OFFSET + 3] = (tmp & 0xff)

            # Payload length field; +4 coz crc size should also be included
            data[IPV6_LEN_OFFSET] = (((rem_size - 40 + 4 - 20) & 0xff00) >> 8)
            data[IPV6_LEN_OFFSET+1] = ((rem_size - 40 + 4 - 20) & 0xff)
            # Set protocol
            if prot_sel == PROT_IPV6_TCP:
                data[IPV6_NXT_HDR] = 0x06
                log_dbg(1, "IPv6 TCP pkt; l4sport_off {}".format(l4sport_offset))
            else:
                data[IPV6_NXT_HDR] = 0x11
                log_dbg(1, "IPv6 TCP pkt; l4sport_off {}".format(l4sport_offset))

            # Hop limit
            data[IPV6_HOP_OFFSET] = sinst_info.v6_hoplimit

            # SIP
            for i in range(16):
                data[IPV6_SIP_OFFSET + i] = sinst_info.v6_sip[i]

            # DIP
            for i in range(16):
                data[IPV6_DIP_OFFSET + i] = sinst_info.v6_dip[i]

        else:
            log_err("Prot_sel invalid: {}".format(prot_sel))
            return -1,-1,None

        # tunnel header checksum
        tun_hdr = data[len(sinst_info.l2hdr_etv4):len(sinst_info.l2hdr_etv4)+20]
        tun_csum = self.compute_l3_header_checksum(tun_hdr, (20))
        data[TUN_IPV4_CSUM_OFFSET] = (tun_csum & 0xff00) >> 8
        data[TUN_IPV4_CSUM_OFFSET+1] = (tun_csum & 0xff)

        data[l4sport_offset] = ((sinst_info.l4_sport & 0xff00) >> 8)
        data[l4sport_offset+1] = (sinst_info.l4_sport & 0xff)
        data[l4sport_offset+2] = ((sinst_info.l4_dport & 0xff00) >> 8)
        data[l4sport_offset+3] = (sinst_info.l4_dport & 0xff)
        apphdr_offset = l4sport_offset + 4

        data[apphdr_offset] = 0xBE
        data[apphdr_offset + 1] = 0xBA
        data[apphdr_offset + 2] = 0xFE
        data[apphdr_offset + 3] = 0xCA
        #Snake-id
        data[apphdr_offset + 4] = sinst_info.id
        # pkt-id
        data[apphdr_offset + 5] = ((pktid) & 0xff)
        data[apphdr_offset + 6] = (((pktid) & 0xff00) >> 8)
        data[apphdr_offset + 7] = (((pktid) & 0xff0000) >> 16)

        log_dbg(1, "Sz: {} len(data): {}".format(size, len(data)))

        data_bytes = b''
        for c in range(len(data)):
            data_bytes += compat_chr(data[c])

        return 0,prot_sel,data_bytes

    def _gen_pkt(self, sinst_info, res, size, pktid):
        if res.payload == "rrstress":
            return self._gen_pkt_helper(sinst_info, res, size, pktid)
        elif res.payload == "stress":
            rc = 0
            if sinst_info.stress_data_bytes == None:
                ret,prot_sel,data_bytes = self._gen_pkt_helper(sinst_info, res, size, pktid)
                if ret < 0 or prot_sel < 0:
                    return ret,prot_sel,data_bytes

                sinst_info.stress_data_bytes = data_bytes
                sinst_info.stress_prot_sel = prot_sel
                rc = ret

            return rc,sinst_info.stress_prot_sel,sinst_info.stress_data_bytes

    def _send_packet(self, sinst_info, pdata, res, size):
        try:
            packet = ifcs_ctypes.ifcs_hostif_packet_info_t()
            ifcs_ctypes.ifcs_hostif_packet_info_t_init(byref(packet))
            packet.tx_type = ifcs_ctypes.IFCS_HOSTIF_TX_TYPE_PIPELINE_BYPASS
            dport = sinst_info.devport_list[0]
            packet.dsp = sinst_info.port_fwd_inst_list[dport].sp_hdl
            packet.pkt_buf = pdata
            packet.pkt_buf_len = size
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except Exception as e:
            log_err("Exception when building pkt: {}".format(e))
            return -1

        tx_busy_count = 0
        while (1):
            rc = ifcs_ctypes.ifcs_hostif_send_packet(sinst_info.node_id, pointer(packet))
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_send_packet")
            if (rc == ifcs_ctypes.IFCS_SUCCESS):
                break
            if (rc != ifcs_ctypes.IFCS_BUSY):
                log_err("Packet send to pcie failed rc: {}".format(rc))
                return -1
            tx_busy_count += 1

            if tx_busy_count >= HOSTIF_SEND_PKT_BUSY_RETRY_CNT:
                log_err("Packet send failed after {} retries; rc: {}".format(HOSTIF_SEND_PKT_BUSY_RETRY_CNT, rc))
                return -1

            time.sleep(0.001)

        return 0


    def start_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Tunspst test start_traffic', prog='Tunspst start_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')
        parser.add_argument('-s', type=str, default="1500:1", help='Comma separated pktsizes; a pktsize can be given a count. Ex: 1500:20,9216:10 results in 20 pkts of size 1500bytes and 10 pkts of 9216bytes')
        #parser.add_argument('-payload', type=str, choices=['rrstress', 'custom'], default='rrstress', help='Packet payload')
        parser.add_argument('-payload', type=str, choices=['rrstress', 'stress'], default='rrstress', help='Packet payload')
        #parser.add_argument('-custom_value', type=auto_int, default=0, help='16-bit Custom payload. Used if payload is of type custom')
        parser.add_argument('-v', help='Verbose', action="store_true")
        parser.add_argument('-vos', default=None, help='Validate-on-stop. If selected, upon stop_traffic, the traffic is terminated back to CPU and compared against injected packets. Supported only for uni-dir, loopback=PCS or PMA, single snake only', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Tunspst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("Tunspst with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Tunspst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to start traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        payload = res.payload
        '''
        # Only rrstress supported, for now
        payload_data = res.custom_value
        # Basic validations
        if payload_data and payload != 'custom':
            log_err("ERROR: custom_value can be used only with payload of type custom")
            return 'FAILED'

        if (res.payload == 'custom') and (payload_data == None):
            log_err("ERROR: custom_value is mandatory for payload type custom")
            return 'FAILED'

        max_custom_val = 0xffff
        if payload_data and payload_data not in range(max_custom_val):
            log_err("ERROR: custom_value valid range is 0-{0}".format(max_custom_val))
            return 'FAILED'
        '''

        if res.vos:
            if sinst_info.lb_type == 'NONE':
                log_err("ERROR: Validate-on-stop is not supported for loopback-type NONE")
                return 'FAILED'
            sinst_info.vos = 1
        else:
            sinst_info.vos = 0

        pktsizes = res.s.split(',')
        sinst_info.vos_gen_pkts = [0] * MAX_PKTS
        sinst_info.vos_rcv_pktids = [0] * MAX_PKTS
        sinst_info.stress_prot_sel = 0
        sinst_info.stress_data_bytes = None

        # Only one packet size allowed for payload-type 'stress'
        if res.payload == 'stress' and len(pktsizes) > 1:
            log_err("Only one packet size allowed for payload-type=stress".format(MAX_PKTS))
            return 'FAILED'

        numpkts = 0
        for szitem in pktsizes:
            if numpkts >= MAX_PKTS:
                log_err("Max pkts supported: {}".format(MAX_PKTS))
                return 'FAILED'

            curcnt = 0
            cursize = 0
            if ':' in szitem:
                toks = szitem.split(':')
                cursize = int(toks[0])
                curcnt = int(toks[1])
            else:
                cursize = int(szitem)
                curcnt = 1

            if cursize < 64:
                cursize = 64

            cursize = cursize - 4
            for cc in range(curcnt):

                ret,prot_sel,data_bytes = self._gen_pkt(sinst_info, res, cursize, numpkts)
                if ret < 0 or prot_sel < 0:
                    log_err("Generate packet failed ret: {}".format(ret));
                    return 'FAILED'

                pdata = cast(data_bytes, c_void_p)
                ret = self._send_packet(sinst_info, pdata, res, cursize)
                if ret < 0:
                    log_err("Send packet failed ret: {}".format(ret));
                    return 'FAILED'

                if sinst_info.vos == 1:
                    sinst_info.vos_num_gen_pkts += 1
                    sinst_info.vos_prot_sel_gen_cnt[prot_sel] += 1
                    sinst_info.vos_gen_pkts.insert(numpkts, data_bytes)

                if(res.v == True):
                    log("Sent Packet-id {}(len:{}):".format(numpkts, len(data_bytes)))
                    log(" ".join("{:02x}".format(compat_ord(c)) for c in data_bytes))

                numpkts += 1

        sinst_info.state = SNAKE_RUNNING
        return 'PASS'

    def stop_traffic(self, args):
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Tunspst test stop_traffic', prog='Tunspst stop_traffic', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')
        parser.add_argument('-d', type=int, default=5, dest='delay', help='Delay - how much time do we want to sleep after l3 stop_traffic')

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for instance in Tunspst.sinst_info_runs:
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        break
                if find == False:
                    log_err("Tunspst with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Tunspst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to stop traffic on a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()

        #sysport_hdls = sinst_info.sysport_hdls
        devport_obj = Devport(self.cli)

        verbose = sinst_info.verbose
        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        # Configure same ip in all VRF aka L3VNI
        log_dbg(1, "Creating drop route entries")

        # Unidir: Set one route to drop for the only flow.
        # This will stop traffic since we have a snake traffic pattern
        drop_port_list = [devport_list[0]]

        if sinst_info.vos == 1:
            # Register rx callback
            Tunspst.rx_cbfn = ifcs_ctypes.ifcs_hostif_packet_notify_t(pkt_vos_cb)
            rc = ifcs_ctypes.ifcs_hostif_register_rx_packet_notify(self.cli.node_id, None, Tunspst.rx_cbfn)
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_register_rx_packet_notify")
            if (rc != ifcs_ctypes.IFCS_SUCCESS):
                log_err("ERROR: Registering Packet Callback Function")

        err = self.configXCnctIntfDroprule(sinst_info, port_fwd_inst_list, devport_list[0])
        if err:
            log_err("Failed to configure CrossConnect Intf droprule")
            return 'FAILED'

        # Check sent packets against received packets - keep sleeping for 100ms until they match
        # Only sleep up to a max time of res.delay
        received = False
        maxNumSleeps = res.delay * 10
        for x in range (maxNumSleeps):
            all_received_packets = Tunspst.vos_glob_mismatch + sinst_info.vos_num_rcvd_total
            all_sent_packets = sinst_info.vos_num_gen_pkts
            if all_received_packets == all_sent_packets:
                received = True
                break
            time.sleep(0.1)
        time.sleep(2) # Need to sleep for two extra seconds to let sysport polling catch up

        if not received:
            log("Stop traffic did not receive all packets in {} seconds".format(res.delay))

        err = self.clearXCnctIntfDroprule(sinst_info, devport_list[0])
        if err:
            log_err("Failed to clear CrossConnect Intf droprule")
            return 'FAILED'

        sinst_info.state = SNAKE_STOPPED
        log("Stopped traffic on Tunspst id {0}".format(sinst_info.id))
        return 'PASS'

    def config(self, args):
        global rng

        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Tunspst test config', prog='Tunspst config', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-p', type=str, default="all", help='Port list')
        parser.add_argument('-lb', type=str, choices=['NONE', 'PCS', 'PMA'], default='NONE', help='Loopback type')
        parser.add_argument('-sdd', help='Disable serdes tx on ports; used if lb is not NONE', action="store_true")
        parser.add_argument('-id', type=int, default=None, help='User defined snake id  [1-1023]')
        parser.add_argument('-seed', type=int, default=0, help='Optional seed value')
        parser.add_argument('-v', help='Verbose', action="store_true")

        try:
            res = parser.parse_args(self.arg_list)
        except SystemExit:
            return
        except:
            log_err("Parsing failed")
            return "FAILED"

        seed = 0
        if res.seed == 0:
            seed = random.randrange(sys.maxsize)
        else:
            seed = res.seed

        log("Seed used: {}".format(seed))
        rng = random.Random(seed)

        '''
        If -p arg not given, default port range is all ports.
        '''
        max_dev_port = self.get_max_devport()
        max_devport_range = "1-2"
        if max_dev_port:
            max_devport_range = "1-%d"%(max_dev_port)

        if res.p == 'all':
            # Port range not given, default to all ports
            devport_arg = max_devport_range
            devport_arg_list = max_devport_range.split(",")
        else:
            # Use given devport range
            try:
                devport_arg = res.p
                devport_arg_list = res.p.split(",")
            except:
                devport_arg = max_devport_range
                devport_arg_list = max_devport_range.split(",")

        # Allocate run's data object which saves config and stats
        sinst_info = SnakeInstInfo()

        find = False
        if res.id != None:
            for instance in Tunspst.sinst_info_runs:
                if instance.id == res.id:
                    log_err('Snake id already in use!\n')
                    return 'FAILED'
            sinst_info.id = res.id
        else:
            for index in range(1, 1024):
                find = False
                for instance in Tunspst.sinst_info_runs:
                    if instance.id == index:
                        find = True
                        break
                if find == False:
                    sinst_info.id = index
                    break
                if index == 1023:
                    log_err("Can not alloc snake id")
                    return 'FAILED'

        for i, dp in enumerate(devport_arg_list):
            if '-' in dp:
                dp_range = devport_arg.split(",")[i].split("-")
                for j in range(int(dp_range[0]), int(dp_range[1]) + 1):
                    sinst_info.devport_list.append(j)
            else:
                sinst_info.devport_list.append(int(dp))

        devport_list = sinst_info.devport_list
        port_fwd_inst_list = sinst_info.port_fwd_inst_list

        # check if devport_list of new snake is overlapping with devport list of existing snake(s), if yes, return FAILED
        new_devport_set = set(devport_list)
        port_overlap = False
        for instance in Tunspst.sinst_info_runs:
            if instance:
                existing_devport_set = set(instance.devport_list)
                if (existing_devport_set & new_devport_set):
                    port_overlap = True
                    break;
        if port_overlap:
            log_err("one or more ports in the devport list is already part of an existing snake. use ports that are not part of any existing snake(s)")
            return 'FAILED'

        lb_type = res.lb
        sinst_info.lb_type = lb_type

        verbose = res.v
        sinst_info.verbose = res.v

        sdd = res.sdd
        sinst_info.sdd = sdd

        sinst_info.type = 'unidir'

        # Configure
        ret = ifcs_ctypes.ifcs_status_t()
        attr = (ifcs_ctypes.ifcs_attr_t * 1)()

        attr[0].id = ifcs_ctypes.IFCS_LINKSCAN_ATTR_ENABLE
        attr[0].value.u32 = ifcs_ctypes.IFCS_BOOL_FALSE

        # generate one-time settings that includes
        # V4: Smac(6), Dmac(6), DSCP(1), Flags/Frag(2), TTL(1), SIP(4), DIP(4);
        # V6: TC(1), Hoplimit(1), SIPv6(16), DIPv6(16); L4: L4Srcport(2), L4Dstport(2)
        # V4Tun: DSCP(1), Flags/Frag(2), TTL(1), SIP1(4), SIP2(4), DIP(4);
        # These add up to: 78 bytes
        x = 2
        reqsize = 78
        randbits='{:08x}'.format((rng.getrandbits(reqsize*8)))
        # Convert the long hex string to list of bytes
        rand_bytes = [int(randbits[y - x:y], 16) for y in range(x, len(randbits) + x, x)]
        if len(rand_bytes) < reqsize:
            # It can so happen the leading bit in randbits could be 0s and the total num of bytes
            # could be less than anticipated. In such case, do padding
            pad = reqsize - len(rand_bytes)
            for pcur in range(pad):
                # Appending 0xAA
                rand_bytes.append(170)

        sinst_info.intfmac1 = (rand_bytes[0] & 0xfe, rand_bytes[1], rand_bytes[2], rand_bytes[3], rand_bytes[4], rand_bytes[5])
        sinst_info.intfmac2 = (rand_bytes[6] & 0xfe, rand_bytes[7], rand_bytes[8], rand_bytes[9], rand_bytes[10], rand_bytes[11])
        sinst_info.v4_dscp = rand_bytes[12]
        sinst_info.v4_flags = 0x1 # Always set MF=1
        sinst_info.v4_frag = ((rand_bytes[13] & 0x1F) << 8) | (rand_bytes[14])
        # Ensure v4_frag is non-zero
        if sinst_info.v4_frag == 0:
            sinst_info.v4_frag = 0xA5
        sinst_info.v4_ttl = rand_bytes[15]
        if sinst_info.v4_ttl <= 1:
            sinst_info.v4_ttl += 2

        # IPv4 multicast range: 224.0.0.0 - 239.255.255.255
        def avoidMulticast(rb, idx):
            # Avoiding multicast ipv4 range
            if rb[idx] > 223:
                rb[idx] = 223
            # Avoiding local ipv4
            if rb[idx] == 127:
                rb[idx] = 126

        avoidMulticast(rand_bytes, 16)
        avoidMulticast(rand_bytes, 20)
        sinst_info.ip2 = ((rand_bytes[16] << 24) | (rand_bytes[17] << 16) | (rand_bytes[18] << 8) | (rand_bytes[19]))
        sinst_info.ip1 = ((rand_bytes[20] << 24) | (rand_bytes[21] << 16) | (rand_bytes[22] << 8) | (rand_bytes[23]))


        sinst_info.dot1q_pcp = rand_bytes[24] & 0x7
        sinst_info.dot1q_dei = ((rand_bytes[24] & 0x8) >> 3)
        sinst_info.v6_tc = sinst_info.v4_dscp
        sinst_info.v6_hoplimit = sinst_info.v4_ttl

        # Avoiding multicast and local ipv6
        if rand_bytes[26] > 0xf0:
            rand_bytes[26] = 0xe0
        if rand_bytes[42] > 0xf0:
            rand_bytes[42] = 0xe0
        sinst_info.v6_sip.extend(rand_bytes[26:26+16])
        sinst_info.v6_dip.extend(rand_bytes[42:42+16])

        sinst_info.l4_sport = ((rand_bytes[58] << 8) | (rand_bytes[58]))
        sinst_info.l4_dport = ((rand_bytes[60] << 8) | (rand_bytes[61]))

        sinst_info.tun_v4_dscp = rand_bytes[62]
        sinst_info.tun_v4_flags = (rand_bytes[63] & 0xE0) >> 5
        sinst_info.tun_v4_frag = ((rand_bytes[63] & 0x1F) << 8) | (rand_bytes[64])
        sinst_info.tun_v4_ttl = sinst_info.v4_ttl # Making inner and outer TTL the same

        avoidMulticast(rand_bytes, 66)
        avoidMulticast(rand_bytes, 70)
        avoidMulticast(rand_bytes, 74)
        sinst_info.tun_sip1 = ((rand_bytes[66] << 24) | (rand_bytes[67] << 16) | (rand_bytes[68] << 8) | (rand_bytes[69]))
        sinst_info.tun_sip2 = ((rand_bytes[70] << 24) | (rand_bytes[71] << 16) | (rand_bytes[72] << 8) | (rand_bytes[73]))
        sinst_info.tun_dip_base = ((rand_bytes[74] << 24) | (rand_bytes[75] << 16) | (rand_bytes[76] << 8) | (rand_bytes[77]))

        try:
            for port in devport_list:
                port_inst = PortFwdInst()
                port_inst.sp_hdl = self.configDevportGetSysportHandle(port)
                #port_inst.sp_hdl = sysport_hdls[port]
                port_fwd_inst_list[port] = port_inst

        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Sysport get FAILED")
            pass

        # Disable all Devports
        err = self.configDevportsDisable(sinst_info)
        if err:
            log_err("Tunspst devports disable failed")
            return 'FAILED'

        # Set Loopback mode
        if verbose:
            log("Setting devports loopback mode to {0}".format(sinst_info.lb_type))
        err = self.configDevportsLoopback(sinst_info, sinst_info.lb_type)
        if err:
            log_err("Tunspst lpbk config failed")
            return 'FAILED'

        # Configure Sysports as L2_L3
        if verbose:
            log("Setting devports fwd mode to L2_L3")
        err = self.configSysportSetFwdMode(sinst_info, ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L2_L3)
        if err:
            log_err("Tunspst sysport fwdmode set failed")
            return 'FAILED'

        #Config Sysports
        if verbose:
            log("Configuring sysport attributes")
        err = self.configSysport(sinst_info, 1)
        if err:
            log_err("Tunspst sysport config failed")
            return 'FAILED'


        # Enable all Devports
        err = self.configDevportsEnable(sinst_info)
        if err:
            log_err("Tunspst devports enable failed")
            return 'FAILED'

        # Create L2VNI (L2VNI)
        if verbose:
            log("Creating L2 vnis")
        err = self.configL2vniCreate(sinst_info)
        if err:
            log_err("Tunspst l2vni create failed")
            return 'FAILED'

        # Create L3VNI (L3VNI)
        if verbose:
            log("Creating L3 vnis")
        err = self.configL3vniCreate(sinst_info)
        if err:
            log_err("Tunspst l3vni create failed")
            return 'FAILED'

        # Create L3 Interfaces (One per Sysport)
        if verbose:
            log("Creating L3 intfs")
        err = self.configIntfCreate(sinst_info)
        if err:
            log_err("Tunspst intf create failed")
            return 'FAILED'

        # Create Nexthops (NUM_NH_PER_PORT per SVI interface)
        if verbose:
            log("Creating nexthops")
        err = self.configNexthopCreate(sinst_info)
        if err:
            log_err("Tunspst nexthop create failed")
            return 'FAILED'

        # Create Txonly Tunnel Interfaces (One per Sysport)
        if verbose:
            log("Creating Txonly Tunnel intfs")
        err = self.configTxTnlIntfCreate(sinst_info)
        if err:
            log_err("Tunspst tx only tunnel intf create failed")
            return 'FAILED'

        # Create Tunnel Nexthops (One per sysport)
        if verbose:
            log("Creating Tunnel nexthops")
        err = self.configTnlNexthopCreate(sinst_info)
        if err:
            log_err("Tunspst tunnel nexthop create failed")
            return 'FAILED'

        # Create Cross Connect Tunnel Interfaces (One per Sysport)
        if verbose:
            log("Creating Tunnel Cross Connect intfs")
        err = self.configTnlXCnctIntfCreate(sinst_info)
        if err:
            log_err("Tunspst Tunnel Cross Connect intf create failed")
            return 'FAILED'

        err = self.saveL2hdr(sinst_info)
        if err:
            log_err("Tunspst saveL2hdr failed")
            return 'FAILED'

        nodeObj = Node(self.cli)
        nodeObj.set("ifcs set node stats_poll_interval 1000")
        queueObj = Queue(self.cli)
        for port in sinst_info.devport_list:
            queueObj.set("ifcs set queue devport {} queue_id 0 uc_dynamic_threshold_factor 8".format(port))
            queueObj.set("ifcs set queue devport {} queue_id 0 nonuc_dynamic_threshold_factor 8".format(port))

        tcObj = Tc(self.cli)
        for tcind in range(8):
            tcObj.set("ifcs set tc {} queue_id 0".format(tcind))

        # Create trap hdl on first snake config; used when validate_on_stop is specified
        if self.run == -1:
            self.trap_hdl.value = ifcs_ctypes.IFCS_HANDLE_HOSTIF_TRAP(self.trap_id)
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 1)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_HOSTIF_TRAP_ATTR_QUEUE_NUM)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), self.cpu_queue_num)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_hostif_trap_create(self.cli.node_id,
                                                     pointer(self.trap_hdl),
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_trap_create")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Hostif trap create failed for cpu queue {} with rc: {}".
                    format(self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create; rc: {}".format(rc)

            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 3)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_THRESHOLD_MODE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_THRESHOLD_MODE_STATIC)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_UC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 39000)
            attr_count += 1
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_NONUC_STATIC_THRESHOLD_LIMIT)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), 39000)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_cpu_queue_attr_set")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

        # Config success, save the config data useful for report generation
        self.insert_run_data(sinst_info)

        sinst_info.state = SNAKE_CONFIGD

        if (self.quiet == "false"):
            #display config
            sinst_info.display_config(sinst_info.id)

        # Wait for all ports to go link-up for 5 secs
        if verbose:
            log("Waiting for all ports to go link-up")

        if (lb_type != 'NONE'):
            timer_val = 5
        else:
            timer_val = 15
        wait_time = 0
        devport_attr_ct = 1
        devport_attr = (ifcs_ctypes.ifcs_attr_t * devport_attr_ct)()
        devport_attr[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_LINK_STATUS
        devport_attr[0].value.u32 = 0
        actual_count = c_uint32()
        link_status = True
        try:
            while wait_time < timer_val:
                link_status = True
                for devport in devport_list:
                    rc = ifcs_ctypes.ifcs_devport_attr_get (self.cli.node_id, devport, 1,
                                     compat_pointer(devport_attr, ifcs_ctypes.ifcs_attr_t), pointer(actual_count))
                    spstcommon_handle_device_access_error(rc, "ifcs_devport_attr_get")
                    assert rc == ifcs_ctypes.IFCS_SUCCESS, "ERROR during devport attr get for port {0}: rc={1}({2})".format(
                        devport, rc,
                        compat_bytesToStr(
                            ifcs_ctypes.ifcs_status_to_string(rc)))

                    if (devport_attr[0].value.u32 != 1):
                        link_status=False
                if link_status:
                    break
                else:
                    wait_time+=0.1
                    time.sleep(0.1)

            assert link_status == True, "Not all devports are up"
        except ValueError as ve:
            if Tunspst.device_access_error_exc_msg in "{}".format(ve):
                # Re-raise exception for handling.
                raise ve
            log_dbg(1, "{}".format(ve))
            log_err("Exception: {}".format(ve))
        except:
            log_err("Error in config: all devports are not up")
            return 'FAILED'

        if verbose:
            log("Config done")
        return 'PASS'

    def config_show(self, args):
        table = PrintTable()
        header = []
        header.append("Devports")
        header.append("Loopback type")
        header.append("Snake id")
        header.append("Snake type")
        table.add_row(header)
        sinst_info_sorted = sorted(Tunspst.sinst_info_runs, key=config_show_sort_key)
        for sinst_info in sinst_info_sorted:
            data = []
            data.append(str(sinst_info.devport_list)[1:-1])
            data.append(str(sinst_info.lb_type))
            data.append(str(sinst_info.id))
            data.append(str(sinst_info.type))
            table.add_row(data)

        table.print_table()
        table.reset_table()
        pass

    def unconfig(self, args):
        parser = argparse.ArgumentParser(description='Tunspst unconfig', prog='Tunspst unconfig', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-id', type=int, default=None, help='Snake id. Needed if more than one snake configured')

        try:
            res, unknown = parser.parse_known_args(self.arg_list)
        except:
            return 'FAILED'

        if res.id:
            if res.id == -1:
                sinst_info = self.get_cur_run_data()
            else:
                find = False
                for index, instance in enumerate(Tunspst.sinst_info_runs):
                    if instance.id == res.id:
                        sinst_info = instance
                        find = True
                        res.id = index
                        break
                if find == False:
                    log_err("Snake with id ", res.id, " does not exist")
                    return 'FAILED'
        else:
            snake_count = 0
            for instance in Tunspst.sinst_info_runs:
                snake_count += 1
            if snake_count > 1:
                log_err("More than one snake configured. Use snake id to remove configuration for a specific snake")
                return 'FAILED'
            sinst_info = self.get_cur_run_data()
            res.id = -1

        verbose = sinst_info.verbose

        # Delete Cross Connect Tunnel interfaces
        if verbose:
            log("Deleting Cross Connect Tunnel intfs")
        err = self.configTnlXCnctIntfDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Delete Tunnel nexthops
        if verbose:
            log("Deleting Tunnel nexthops")
        err = self.configTnlNexthopDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Delete interfaces
        if verbose:
            log("Deleting Tunnel intfs")
        err = self.configTxTnlIntfDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Delete nexthops
        if verbose:
            log("Deleting nexthops")
        err = self.configNexthopDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Delete interfaces
        if verbose:
            log("Deleting L3 intfs")
        err = self.configIntfDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Delete l3vnis
        if verbose:
            log("Deleting l3vnis")
        err = self.configL3vniDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Delete l2vnis
        if verbose:
            log("Deleting l2vnis")
        err = self.configL2vniDelete(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Disable all devports
        err = self.configDevportsDisable(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Set devports loopback to NONE
        if verbose:
            log("Setting devports loopback mode to NONE")
        err = self.configDevportsLoopback(sinst_info, 'NONE')
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Set devports Fwd mode to L2_L3
        if verbose:
            log("Setting devports fwd mode to L2_L3")
        err = self.configSysportSetFwdMode(sinst_info, ifcs_ctypes.IFCS_SYSPORT_FWD_MODE_L2_L3)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Remove Sysport params
        if verbose:
            log("Setting sysport params ")
        err = self.configSysport(sinst_info, 0)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        # Enable all devports
        err = self.configDevportsEnable(sinst_info)
        if err:
            log_err("Tunspst test unconfig failed")
            return 'FAILED'

        sinst_info.state = SNAKE_UNCONFIG

        log("Unconfigured snake id {0}".format(sinst_info.id))

        if res.id != -1:
            del Tunspst.sinst_info_runs[res.id]
        else:
            Tunspst.sinst_info_runs.pop()

        Tunspst.run -= 1

        if self.run == -1:
            
            attr_count = 0
            attr = (ifcs_ctypes.ifcs_attr_t * 3)()
            ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_CPU_QUEUE_ATTR_THRESHOLD_MODE)
            ifcs_ctypes.ifcs_attr_t_value_u32_set(compat_pointerAtIndex(attr, ifcs_ctypes.ifcs_attr_t, attr_count), ifcs_ctypes.IFCS_THRESHOLD_MODE_DYNAMIC)
            attr_count += 1
            rc = ifcs_ctypes.ifcs_cpu_queue_attr_set(self.cli.node_id,
                                                     self.cpu_queue_num,
                                                     attr_count,
                                                     compat_pointer(attr, ifcs_ctypes.ifcs_attr_t))
            spstcommon_handle_device_access_error(rc, "ifcs_cpu_queue_attr_set")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: dynamic threshold attribute set failed for cpu queue {} with rc: {}"
                    .format(sinst_info.id, self.cpu_queue_num, rc))
                assert 0, "ERR during cpu_queue threshold attr set; rc: {}".format(
                    rc)

            # Delete the trap on last snake unconfig
            rc = ifcs_ctypes.ifcs_hostif_trap_delete(self.cli.node_id, self.trap_hdl)
            spstcommon_handle_device_access_error(rc, "ifcs_hostif_trap_delete")
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err(
                    "Unconfigure snake id {}: hostif trap delete failed for cpu queue {} with rc: {}"
                    .format(sinst_info.id, self.cpu_queue_num, rc))
                assert 0, "ERR during trap handle create"

        if verbose:
            log("Unconfig done")

        return 'PASS'
