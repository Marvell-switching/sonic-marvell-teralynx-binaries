#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------


import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
from ifcs_cmds.node import Node as ifcs_node


# Class implements Diagtest related command
class Mbist(Command):
    def __init__(self, cli):
        self.sub_cmds = {'run'          : self.mbist_run,
                         'status'       : self.mbist_status,
                         ''             : self.mbist_status,
                         'help'         : self.help,
                         '?'            : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []
        super(Mbist, self).__init__()
        self.num_nodes = cli.num_nodes
        self.active_node = 0

    def run_cmd(self, args):
        log_dbg(1, "in mbist")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        try:
            if len(self.arg_list) > 2:
                rc = self.sub_cmds[self.arg_list[2]](args)
            else:
                rc = self.sub_cmds[''](args)
            return rc
        except (KeyError):
            log_dbg(
                1, "KeyError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except (ValueError):
            log_dbg(
                1, "ValueError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.help(args)
        except Exception:
            log_dbg(
                1, "OtherError in diagtest [{}] run_cmd: {}".format(
                    args, sys.exc_info()))
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def print_result_mbist_run(self, bist_status, bisr_status, detail):
        if ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            log("SMS BIST: 0x{:04x}".format(bist_status))
            log("SMS BISR: 0x{:04x}".format(bisr_status))
        else:
            log("SMS BIST: 0x{:016x}".format(bist_status))
            log("SMS BISR: 0x{:016x}".format(bisr_status))

        if bist_status:
            if (detail):
                log("\nMBIST failed before Self Repair")
            else:
                log("\nMBIST failed")
            failed_rings_bist = []
            for i in range(64):
                if bist_status & (1 << i):
                    failed_rings_bist.append(i + 1)
            failed_rings_bist_str = ','.join(map(str, failed_rings_bist))
            if (detail):
                log("Failed Ring numbers after BIST: {:s}\n".format(failed_rings_bist_str))
        else:
            if (detail):
                log("\nMBIST passed Without Self Repair")
            else:
                log("\nMBIST passed")
        if bisr_status:
            if (detail):
                log("MBIST failed after Self Repair")
            failed_rings_bisr = []
            for i in range(64):
                if bisr_status & (1 << i):
                    failed_rings_bisr.append(i + 1)
            failed_rings_bisr_str = ','.join(map(str, failed_rings_bisr))
            if (detail):
                log("Failed Ring numbers after BISR: {:s}\n".format(failed_rings_bisr_str))
        else:
            if (detail):
                log("MBIST passed after Self Repair\n")

    def mbist_run(self, args):
        '''
        Run SMS MBIST post node create
        '''
        detail = 1
        node_obj = ifcs_node(self.cli)
        if self.cli.node_id is None:
            log("Err: Invalid node ID, trying to run mbist prior to node create")
            return

        log("Running mbist...")
        sms_run_status = node_obj.setSmsBistRun(1)
        sms_bist_status = node_obj.getSmsBistStatus()
        sms_bisr_status = node_obj.getSmsBisrStatus()
        log("\nMBIST RUN result:\n")
        self.print_result_mbist_run(sms_bist_status, sms_bisr_status, detail)
        log("\nReinitialize SDK before proceeding\n")
        return

    def mbist_status(self, args):
        '''
        Run SMS MBIST Status get
        '''
        detail = 0
        node_obj = ifcs_node(self.cli)
        if self.cli.node_id is None:
            log("Err: Invalid node ID, trying to run mbist prior to node create")
            return
        arg_list = shlex.split(args)
        if (len(arg_list) == 4):
            if (arg_list[3] == 'detail'):
                detail = 1
        # Just print the mbist result as captured
        # in ifcs_ctypes.IFCS_NODE_ATTR_MBIST_RESULT
        if ifcs_ctypes.im_nmgr_node_device_type_get(self.cli.node_id) != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TL10:
            #TL7
            mbist_result = node_obj.getMbistResult()
            sms_bist_status = ifcs_ctypes.IM_NODE_MBIST_STATUS(mbist_result)
            sms_bisr_status = ifcs_ctypes.IM_NODE_MBISR_STATUS(mbist_result)
            self.print_result_mbist_run(sms_bist_status, sms_bisr_status, detail)
        else:
            # TL10
            sms_bist_status = node_obj.getSmsBistStatus()
            sms_bisr_status = node_obj.getSmsBisrStatus()
            self.print_result_mbist_run(sms_bist_status, sms_bisr_status, detail)

        return

    def show(self, args):
        pass

    def help(self, args):
        self.cli.error()
        log("Usage: \n", \
              "<no_option> diagtest mbist  - diagtest mbist status\n", \
              "status  diagtest mbist status - diagtest mbist status\n", \
              "run  diagtest mbist run  - diagtest mbist run\n", \
              "Show this text  - diagtest help or ?\n")
