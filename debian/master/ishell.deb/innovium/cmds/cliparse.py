
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import sys
from verbosity import log

# =============================
# Utility functions and classes
# =============================

class _AttributeHolder(object):
    """Abstract base class that provides __repr__.

    The __repr__ method returns a string in the format::
        ClassName(attr=name, attr=name, ...)
    The attributes are determined either by a class-level attribute,
    '_kwarg_names', or by inspecting the instance __dict__.
    """

    def __repr__(self):
        type_name = type(self).__name__
        arg_strings = []
        for arg in self._get_args():
            arg_strings.append(repr(arg))
        for name, value in self._get_kwargs():
            arg_strings.append('%s=%r' % (name, value))
        return '%s(%s)' % (type_name, ', '.join(arg_strings))

    def _get_kwargs(self):
        return sorted(self.__dict__.items())

    def _get_args(self):
        return []

class CliArgParser(_AttributeHolder):
    def __init__(self,
                 prog=None,
                 usage=None,
                 description=None,
                 epilog=None,
                 version=None,
                 add_help=True):
        self.prog = prog
        self.usage = usage
        self.description = description
        self.epilog = epilog
        self.version = version
        self.add_help = add_help
        self.keywords = []

    def add_keyword(self, key):
        if key not in self.keywords:
            self.keywords.append(key)

    def parse_cli_args(self, args=None, namespace=None):
        if args is None:
            # args default to the system args
            args = sys.argv[1:]
        else:
            # make sure that args are mutable
            args = list(args)

        # default Namespace built from parser defaults
        if namespace is None:
            namespace = Namespace()
            for k in range(len(self.keywords)):
                setattr(namespace, self.keywords[k], None)
        kw = self.keywords
        for a in range(len(args)):
            curarg = args[a]
            iskey = False
            for k in range(len(self.keywords)):
                if curarg == kw[k]:
                    curkey = kw[k]
                    iskey = True
                    nskey = getattr(namespace, curkey)
                    if nskey:
                        keyitem = nskey
                    else:
                        keyitem = []
                    break
            if iskey == False:
                try:
                    keyitem.append(curarg)
                    setattr(namespace, curkey, keyitem)
                except UnboundLocalError:
                    log("Invalid command syntax")
                    self.help()
        return namespace, args

class Namespace(_AttributeHolder):
    """Simple object for storing attributes.

    Implements equality by attribute names and values, and provides a simple
    string representation.
    """

    def __init__(self, **kwargs):
        for name in kwargs:
            setattr(self, name, kwargs[name])

    __hash__ = None

    def __eq__(self, other):
        return vars(self) == vars(other)

    def __ne__(self, other):
        return not (self == other)

    def __contains__(self, key):
        return key in self.__dict__
