#-------------------------------------------------------------------------------
# Copyright (c) (2023) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you, your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
import argparse
import ctypes
import numpy as np
import select
import sys
import traceback

from cmdmgr import Command, CommandError
from testutil import pci
from print_table import PrintTable
from verbosity import *

ifcs_ctypes = sys.modules['ifcs_ctypes']


def _status_to_string(rc):
    return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))

class SD0801:
    class Registers:
        # Macro ID Registers
        CMN_PID_TYPE = 0x0000
        CMN_PID_NUM = 0x003
        CMN_PID_REV = 0x0004
        CMN_PID_MFG = 0x0008
        CMN_PID_NODE = 0x0009
        CMN_PID_FLV0 = 0x000a
        CMN_PID_FLV1 = 0x000b
        CMN_PID_IOV = 0x000c
        CMN_PID_LANES = 0x000d
        CMN_PID_METAL0 = 0x0010
        CMN_PID_METAL1 = 0x0011
        CMN_PID_METAL2 = 0x0012
        CMN_PID_METAL3 = 0x0013
        CMN_PID_METALD = 0x0014
        # Startup State Machine Registers
        CMN_SSM_SM_CTRL = 0x0020
        CMN_SSM_BANDGAP_TMR = 0x0021
        CMN_SSM_BIAS_TMR = 0x0022
        CMN_SSM_USER_DEF_CTRL = 0x0027
        #  PLL 0 Control State Machine Registers
        CMN_PLLSM0_SM_CTRL = 0x0028
        CMN_PLLSM0_PLLEN_TMR = 0x0029
        CMN_PLLSM0_PLLPRE_TMR = 0x002a
        CMN_PLLSM0_PLLVREF_TMR = 0x002b
        CMN_PLLSM0_PLLLOCK_TMR = 0x002c
        CMN_PLLSM0_PLLCLKDIS_TMR = 0x002d
        CMN_PLLSM0_USER_DEF_CTRL = 0x002f
        #  PLL 1 Control State Machine Registers
        CMN_PLLSM1_SM_CTRL = 0x0030
        CMN_PLLSM1_PLLEN_TMR = 0x0031
        CMN_PLLSM1_PLLPRE_TMR = 0x0032
        CMN_PLLSM1_PLLVREF_TMR = 0x0033
        CMN_PLLSM1_PLLLOCK_TMR = 0x0034
        CMN_PLLSM1_PLLCLKDIS_TMR = 0x0035
        CMN_PLLSM1_USER_DEF_CTRL = 0x0037
        # Common Control Module Control And Diagnostics Registers
        CMN_CDIAG_PWRI_TMR = 0x0040
        CMN_CDIAG_PLLC_PWRI_OVRD = 0x0043
        CMN_CDIAG_PLLC_PWRI_STAT = 0x0044
        CMN_CDIAG_CCAL_PWRI_OVRD = 0x0045
        CMN_CDIAG_CCAL_PWRI_STAT = 0x0046
        CMN_CDIAG_XCVRC_PWRI_OVRD = 0x0047
        CMN_CDIAG_XCVRC_PWRI_STAT = 0x0048
        CMN_CDIAG_DIAG_PWRI_OVRD = 0x0049
        CMN_CDIAG_DIAG_PWRI_STAT = 0x004a
        CMN_CDIAG_PRATECLK_CTRL = 0x004b
        CMN_CDIAG_REFCLK_OVRD = 0x004c
        CMN_CDIAG_REFCLK_TEST = 0x004d
        CMN_CDIAG_PSMCLK_CTRL = 0x004e
        CMN_CDIAG_SDOSC_CTRL = 0x004f
        CMN_CDIAG_REFCLK_DRV0_CTRL = 0x0050
        CMN_CDIAG_PLL0_PROG_CLK_CTRL0 = 0x0051
        CMN_CDIAG_PLL0_PROG_CLK_CTRL1 = 0x0052
        CMN_CDIAG_PLL1_PROG_CLK_CTRL0 = 0x0053
        CMN_CDIAG_PLL1_PROG_CLK_CTRL1 = 0x0054
        CMN_CDIAG_CDB_DIAG = 0x005c
        CMN_CDIAG_RST_DIAG = 0x005d
        CMN_CDIAG_DCYA = 0x005f
        # Bandgap Calibration Controller Registers
        CMN_BGCAL_CTRL = 0x0060
        CMN_BGCAL_OVRD = 0x0061
        CMN_BGCAL_START = 0x0062
        CMN_BGCAL_TUNE = 0x0063
        CMN_BGCAL_INIT_TMR = 0x0064
        CMN_BGCAL_ITER_TMR = 0x0065
        # External Bias Current Calibration Controller Registers
        CMN_IBCAL_CTRL = 0x0070
        CMN_IBCAL_OVRD = 0x0071
        CMN_IBCAL_START = 0x0072
        CMN_IBCAL_TUNE = 0x0073
        CMN_IBCAL_INIT_TMR = 0x0074
        CMN_IBCAL_ITER_TMR = 0x0075
        #  PLL 0 Controller Registers
        CMN_PLL0_VCOCAL_CTRL = 0x0080
        CMN_PLL0_VCOCAL_START = 0x0081
        CMN_PLL0_VCOCAL_TCTRL = 0x0082
        CMN_PLL0_VCOCAL_OVRD = 0x0083
        CMN_PLL0_VCOCAL_INIT_TMR = 0x0084
        CMN_PLL0_VCOCAL_ITER_TMR = 0x0085
        CMN_PLL0_VCOCAL_REFTIM_START = 0x0086
        CMN_PLL0_VCOCAL_PLLCNT_START = 0x0088
        CMN_PLL0_INTDIV_M0 = 0x0090
        CMN_PLL0_FRACDIVL_M0 = 0x0091
        CMN_PLL0_FRACDIVH_M0 = 0x0092
        CMN_PLL0_HIGH_THR_M0 = 0x0093
        CMN_PLL0_DSM_DIAG_M0 = 0x0094
        CMN_PLL0_DSM_FBH_OVRD_M0 = 0x0095
        CMN_PLL0_DSM_FBL_OVRD_M0 = 0x0096
        CMN_PLL0_SS_CTRL1_M0 = 0x0098
        CMN_PLL0_SS_CTRL2_M0 = 0x0099
        CMN_PLL0_SS_CTRL3_M0 = 0x009a
        CMN_PLL0_SS_CTRL4_M0 = 0x009b
        CMN_PLL0_LOCK_REFCNT_START = 0x009c
        CMN_PLL0_LOCK_REFCNT_IDLE = 0x009d
        CMN_PLL0_LOCK_PLLCNT_START = 0x009e
        CMN_PLL0_LOCK_PLLCNT_THR = 0x009f
        CMN_PLL0_INTDIV_M1 = 0x00a0
        CMN_PLL0_FRACDIVL_M1 = 0x00a1
        CMN_PLL0_FRACDIVH_M1 = 0x00a2
        CMN_PLL0_HIGH_THR_M1 = 0x00a3
        CMN_PLL0_DSM_DIAG_M1 = 0x00a4
        CMN_PLL0_DSM_FBH_OVRD_M1 = 0x00a5
        CMN_PLL0_DSM_FBL_OVRD_M1 = 0x00a6
        CMN_PLL0_SS_CTRL1_M1 = 0x00a8
        CMN_PLL0_SS_CTRL2_M1 = 0x00a9
        CMN_PLL0_SS_CTRL3_M1 = 0x00aa
        CMN_PLL0_SS_CTRL4_M1 = 0x00ab
        # PLL 1 Controller Registers
        CMN_PLL1_VCOCAL_CTRL = 0x00c0
        CMN_PLL1_VCOCAL_START = 0x00c1
        CMN_PLL1_VCOCAL_TCTRL = 0x00c2
        CMN_PLL1_VCOCAL_OVRD = 0x00c3
        CMN_PLL1_VCOCAL_INIT_TMR = 0x00c4
        CMN_PLL1_VCOCAL_ITER_TMR = 0x00c5
        CMN_PLL1_VCOCAL_REFTIM_START = 0x00c6
        CMN_PLL1_VCOCAL_PLLCNT_START = 0x00c8
        CMN_PLL1_INTDIV_M0 = 0x00d0
        CMN_PLL1_FRACDIVL_M0 = 0x00d1
        CMN_PLL1_FRACDIVH_M0 = 0x00d2
        CMN_PLL1_HIGH_THR_M0 = 0x00d3
        CMN_PLL1_DSM_DIAG_M0 = 0x00d4
        CMN_PLL1_DSM_FBH_OVRD_M0 = 0x00d5
        CMN_PLL1_DSM_FBL_OVRD_M0 = 0x00d6
        CMN_PLL1_SS_CTRL1_M0 = 0x00d8
        CMN_PLL1_SS_CTRL2_M0 = 0x00d9
        CMN_PLL1_SS_CTRL3_M0 = 0x00da
        CMN_PLL1_SS_CTRL4_M0 = 0x00db
        CMN_PLL1_LOCK_REFCNT_START = 0x00dc
        CMN_PLL1_LOCK_REFCNT_IDLE = 0x00dd
        CMN_PLL1_LOCK_PLLCNT_START = 0x00de
        CMN_PLL1_LOCK_PLLCNT_THR = 0x00df
        # Transmitter Resistor Calibration Controller Registers
        # -  Transmitter pull up resistor calibration controller registers address space
        CMN_TXPUCAL_CTRL = 0x0100
        CMN_TXPUCAL_OVRD = 0x0101
        CMN_TXPUCAL_START = 0x0102
        CMN_TXPUCAL_TUNE = 0x0103
        CMN_TXPUCAL_INIT_TMR = 0x0104
        CMN_TXPUCAL_ITER_TMR = 0x0105
        # -  Transmitter pull down resistor calibration controller registers address space
        CMN_TXPDCAL_CTRL = 0x0108
        CMN_TXPDCAL_OVRD = 0x0109
        CMN_TXPDCAL_START = 0x010a
        CMN_TXPDCAL_TUNE = 0x010b
        CMN_TXPDCAL_INIT_TMR = 0x010c
        CMN_TXPDCAL_ITER_TMR = 0x010d
        # Receiver Resistor Calibration Controller Registers
        CMN_RXCAL_CTRL = 0x0110
        CMN_RXCAL_OVRD = 0x0111
        CMN_RXCAL_START = 0x0112
        CMN_RXCAL_TUNE = 0x0113
        CMN_RXCAL_INIT_TMR = 0x0114
        CMN_RXCAL_ITER_TMR = 0x0115
        # Signal Detect Clock Calibration Registers
        CMN_SD_CAL_CTRL = 0x0120
        CMN_SD_CAL_START = 0x0121
        CMN_SD_CAL_TCTRL = 0x0122
        CMN_SD_CAL_OVRD = 0x0123
        CMN_SD_CAL_INIT_TMR = 0x0124
        CMN_SD_CAL_ITER_TMR = 0x0125
        CMN_SD_CAL_REFTIM_START = 0x0126
        CMN_SD_CAL_PLLCNT_START = 0x0128
        # Common Clock Measurement Module Registers
        CMN_CMSMT_CLK_FREQ_MSMT_CTRL = 0x0180
        CMN_CMSMT_TEST_CLK_SEL = 0x0181
        CMN_CMSMT_REF_CLK_TMR_VALUE = 0x0182
        CMN_CMSMT_TEST_CLK_CNT_VALUE = 0x0183
        # Common PLL 0 Control And Diagnostics Registers
        CMN_PDIAG_PLL0_CTRL_M0 = 0x01a0
        CMN_PDIAG_PLL0_CLK_SEL_M0 = 0x01a1
        CMN_PDIAG_PLL0_OVRD_M0 = 0x01a2
        CMN_PDIAG_PLL0_ITRIM_M0 = 0x01a3
        CMN_PDIAG_PLL0_CP_PADJ_M0 = 0x01a4
        CMN_PDIAG_PLL0_CP_IADJ_M0 = 0x01a5
        CMN_PDIAG_PLL0_FILT_PADJ_M0 = 0x01a6
        CMN_PDIAG_PLL0_CP_TUNE_M0 = 0x01a7
        CMN_PDIAG_PLL0_CTRL_M1 = 0x01b0
        CMN_PDIAG_PLL0_CLK_SEL_M1 = 0x01b1
        CMN_PDIAG_PLL0_OVRD_M1 = 0x01b2
        CMN_PDIAG_PLL0_ITRIM_M1 = 0x01b3
        CMN_PDIAG_PLL0_CP_PADJ_M1 = 0x01b4
        CMN_PDIAG_PLL0_CP_IADJ_M1 = 0x01b5
        CMN_PDIAG_PLL0_FILT_PADJ_M1 = 0x01b6
        CMN_PDIAG_PLL0_CP_TUNE_M1 = 0x01b7
        # Common PLL 1 Control And Diagnostics Registers
        CMN_PDIAG_PLL1_CTRL_M0 = 0x01c0
        CMN_PDIAG_PLL1_CLK_SEL_M0 = 0x01c1
        CMN_PDIAG_PLL1_OVRD_M0 = 0x01c2
        CMN_PDIAG_PLL1_ITRIM_M0 = 0x01c3
        CMN_PDIAG_PLL1_CP_PADJ_M0 = 0x01c4
        CMN_PDIAG_PLL1_CP_IADJ_M0 = 0x01c5
        CMN_PDIAG_PLL1_FILT_PADJ_M0 = 0x01c6
        CMN_PDIAG_PLL1_CP_TUNE_M0 = 0x01c7
        # Common Functions Control And Diagnostics Registers
        CMN_DIAG_BIAS_OVRD1 = 0x01e1
        CMN_DIAG_BIAS_OVRD2 = 0x01e2
        CMN_DIAG_VREG_CTRL = 0x01e3
        CMN_DIAG_PM_CTRL = 0x01e4
        CMN_DIAG_SH_BANDGAP = 0x01e5
        CMN_DIAG_SH_RESISTOR = 0x01e6
        CMN_DIAG_SH_SDCLK = 0x01e7
        CMN_DIAG_ATB_CTRL1 = 0x01e8
        CMN_DIAG_ATB_CTRL2 = 0x01e9
        CMN_DIAG_ATB_ADC_CTRL0 = 0x01ea
        CMN_DIAG_ATB_ADC_CTRL1 = 0x01eb
        CMN_DIAG_HSRRSM_CTRL = 0x01ec
        CMN_DIAG_RST_DIAG = 0x01ed
        CMN_DIAG_DCYA = 0x01ee
        CMN_DIAG_ACYA = 0x01ef
        CMN_DIAG_GPANA_0 = 0x01f0
        CMN_DIAG_GPANA_1 = 0x01f1
        CMN_DIAG_GPANA_2 = 0x01f2
        CMN_DIAG_GPANA_ST = 0x01f3
        # Power State Machine Registers
        XCVR_PSM_CTRL = 0x4000
        XCVR_PSM_RCTRL = 0x4001
        XCVR_PSM_CALIN_TMR = 0x4002
        XCVR_PSM_A0IN_TMR = 0x4003
        XCVR_PSM_A0BYP_TMR = 0x4004
        XCVR_PSM_A1IN_TMR = 0x4005
        XCVR_PSM_A2IN_TMR = 0x4006
        XCVR_PSM_A3IN_TMR = 0x4007
        XCVR_PSM_A4IN_TMR = 0x4008
        XCVR_PSM_A5IN_TMR = 0x4009
        XCVR_PSM_CALOUT_TMR = 0x400a
        XCVR_PSM_A0OUT_TMR = 0x400b
        XCVR_PSM_A1OUT_TMR = 0x400c
        XCVR_PSM_A2OUT_TMR = 0x400d
        XCVR_PSM_A3OUT_TMR = 0x400e
        XCVR_PSM_A4OUT_TMR = 0x400f
        XCVR_PSM_RDY_TMR = 0x4011
        XCVR_PSM_DIAG = 0x4012
        XCVR_PSM_ST_0 = 0x4013
        XCVR_PSM_ST_0 = 0x4014
        XCVR_PSM_USER_DEF_CTRL = 0x401f
        # TX Coefficient Calculator Registers
        TX_TXCC_CTRL = 0x4040
        TX_TXCC_PRE_OVRD = 0x4041
        TX_TXCC_MAIN_OVRD = 0x4042
        TX_TXCC_POST_OVRD = 0x4043
        TX_TXCC_PRE_CVAL = 0x4044
        TX_TXCC_MAIN_CVAL = 0x4045
        TX_TXCC_POST_CVAL = 0x4046
        TX_TXCC_LF_MULT = 0x4047
        TX_TXCC_CPRE_MULT_00 = 0x4048
        TX_TXCC_CPRE_MULT_01 = 0x4049
        TX_TXCC_CPRE_MULT_10 = 0x404a
        TX_TXCC_CPRE_MULT_11 = 0x404b
        TX_TXCC_CPOST_MULT_00 = 0x404c
        TX_TXCC_CPOST_MULT_01 = 0x404d
        TX_TXCC_CPOST_MULT_10 = 0x404e
        TX_TXCC_CPOST_MULT_11 = 0x404f
        TX_TXCC_MGNFS_MULT_000 = 0x4050
        TX_TXCC_MGNFS_MULT_001 = 0x4051
        TX_TXCC_MGNFS_MULT_010 = 0x4052
        TX_TXCC_MGNFS_MULT_011 = 0x4053
        TX_TXCC_MGNFS_MULT_100 = 0x4054
        TX_TXCC_MGNFS_MULT_101 = 0x4055
        TX_TXCC_MGNFS_MULT_110 = 0x4056
        TX_TXCC_MGNFS_MULT_111 = 0x4057
        TX_TXCC_MGNHS_MULT_000 = 0x4058
        TX_TXCC_MGNHS_MULT_001 = 0x4059
        TX_TXCC_MGNHS_MULT_010 = 0x405a
        TX_TXCC_MGNHS_MULT_011 = 0x405b
        TX_TXCC_MGNHS_MULT_100 = 0x405c
        TX_TXCC_MGNHS_MULT_101 = 0x405d
        TX_TXCC_MGNHS_MULT_110 = 0x405e
        TX_TXCC_MGNHS_MULT_111 = 0x405f
        TX_TXCC_P0PRE_COEF_MULT = 0x4060
        TX_TXCC_P1PRE_COEF_MULT = 0x4061
        TX_TXCC_P2PRE_COEF_MULT = 0x4062
        TX_TXCC_P3PRE_COEF_MULT = 0x4063
        TX_TXCC_P4PRE_COEF_MULT = 0x4064
        TX_TXCC_P5PRE_COEF_MULT = 0x4065
        TX_TXCC_P6PRE_COEF_MULT = 0x4066
        TX_TXCC_P7PRE_COEF_MULT = 0x4067
        TX_TXCC_P8PRE_COEF_MULT = 0x4068
        TX_TXCC_P9PRE_COEF_MULT = 0x4069
        TX_TXCC_IPRE_COEF_VALUE = 0x406a
        TX_TXCC_P0POST_COEF_MULT = 0x4070
        TX_TXCC_P1POST_COEF_MULT = 0x4071
        TX_TXCC_P2POST_COEF_MULT = 0x4072
        TX_TXCC_P3POST_COEF_MULT = 0x4073
        TX_TXCC_P4POST_COEF_MULT = 0x4074
        TX_TXCC_P5POST_COEF_MULT = 0x4075
        TX_TXCC_P6POST_COEF_MULT = 0x4076
        TX_TXCC_P7POST_COEF_MULT = 0x4077
        TX_TXCC_P8POST_COEF_MULT = 0x4078
        TX_TXCC_P9POST_COEF_MULT = 0x4079
        TX_TXCC_IPOST_COEF_VALUE = 0x407a
        # Driver Controller Control And Diagnostics Registers
        DRV_DIAG_LANE_FCM_EN_TO = 0x40c0
        DRV_DIAG_LANE_FCM_EN_SWAIT_TMR = 0x40c1
        DRV_DIAG_LANE_FCM_EN_MGN_TMR = 0x40c2
        DRV_DIAG_LANE_FCM_EN_TUNE = 0x40c3
        DRV_DIAG_LFPS_CTRL = 0x40c4
        DRV_DIAG_RCVDET_TUNE = 0x40c5
        DRV_DIAG_TX_DRV = 0x40c6
        # Transceiver Control And Diagnostics Registers
        XCVR_DIAG_PWRI_TMR = 0x40e0
        XCVR_DIAG_XCAL_PWRI_OVRD = 0x40e1
        XCVR_DIAG_XCAL_PWRI_STAT = 0x40e2
        XCVR_DIAG_XDP_PWRI_OVRD = 0x40e3
        XCVR_DIAG_XDP_PWRI_STAT = 0x40e4
        XCVR_DIAG_PLLDRC_CTRL = 0x40e5
        XCVR_DIAG_HSCLK_SEL = 0x40e6
        XCVR_DIAG_HSCLK_DIV = 0x40e7
        XCVR_DIAG_TXCLK_CTRL = 0x40e8
        XCVR_DIAG_RXCLK_CTRL = 0x40e9
        XCVR_DIAG_BIDI_CTRL = 0x40ea
        XCVR_DIAG_PSC_OVRD = 0x40eb
        XCVR_DIAG_RST_DIAG = 0x40ec
        XCVR_DIAG_XCVR_CLK_CTRL = 0x40ed
        XCVR_DIAG_DCYA = 0x40ef
        XCVR_DIAG_GPANA_0 = 0x40f0
        XCVR_DIAG_GPANA_1 = 0x40f1
        XCVR_DIAG_GPANA_2 = 0x40f2
        XCVR_DIAG_GPANA_ST = 0x40f3
        # Transmitter Power State Controller Registers
        TX_PSC_A0 = 0x4100
        TX_PSC_A1 = 0x4101
        TX_PSC_A2 = 0x4102
        TX_PSC_A3 = 0x4103
        TX_PSC_A4 = 0x4104
        TX_PSC_A5 = 0x4105
        TX_PSC_CAL = 0x4106
        TX_PSC_RDY = 0x4107
        TX_RCVDET_CTRL = 0x4120
        TX_RCVDET_OVRD = 0x4121
        TX_RCVDET_EN_TMR = 0x4122
        TX_RCVDET_ST_TMR = 0x4123
        # Transmitter BIST Controller Registers
        TX_BIST_CTRL = 0x4140
        TX_BIST_UDDWR = 0x4141
        TX_BIST_SEED0 = 0x4142
        TX_BIST_SEED1 = 0x4143
        # Transmitter Control And Diagnostics Registers
        TX_DIAG_SFIFO_CTRL = 0x41e0
        TX_DIAG_SFIFO_TMR = 0x41e1
        TX_DIAG_ELEC_IDLE = 0x41e2
        TX_DIAG_RST_DIAG = 0x41e5
        TX_DIAG_DCYA = 0x41e6
        TX_DIAG_ACYA = 0x41e7
        # Receiver Power State Controller Registers
        RX_PSC_A0 = 0x8000
        RX_PSC_A1 = 0x8001
        RX_PSC_A2 = 0x8002
        RX_PSC_A3 = 0x8003
        RX_PSC_A4 = 0x8004
        RX_PSC_A5 = 0x8005
        RX_PSC_CAL = 0x8006
        RX_PSC_RDY = 0x8007
        #  Signal Detect Calibration 0 Controller Registers
        RX_SDCAL0_CTRL = 0x8040
        RX_SDCAL0_OVRD = 0x8041
        RX_SDCAL0_START = 0x8042
        RX_SDCAL0_TUNE = 0x8043
        RX_SDCAL0_INIT_TMR = 0x8044
        RX_SDCAL0_ITER_TMR = 0x8045
        # Signal Detect Calibration 1 Controller Registers
        RX_SDCAL1_CTRL = 0x8048
        RX_SDCAL1_OVRD = 0x8049
        RX_SDCAL1_START = 0x804a
        RX_SDCAL1_TUNE = 0x804b
        RX_SDCAL1_INIT_TMR = 0x804c
        RX_SDCAL1_ITER_TMR = 0x804d
        # Sampler Error DAC Control Registers
        RX_SAMP_DAC_CTRL = 0x8058
        # Receiver Sampler Latch Calibration Registers
        RX_SLC_CTRL = 0x8060
        RX_SLC_IPP_STAT = 0x8061
        RX_SLC_IPP_OVRD = 0x8062
        RX_SLC_IPM_STAT = 0x8063
        RX_SLC_IPM_OVRD = 0x8064
        RX_SLC_QPP_STAT = 0x8065
        RX_SLC_QPP_OVRD = 0x8066
        RX_SLC_QPM_STAT = 0x8067
        RX_SLC_QPM_OVRD = 0x8068
        RX_SLC_EPP_STAT = 0x8069
        RX_SLC_EPP_OVRD = 0x806a
        RX_SLC_EPM_STAT = 0x806b
        RX_SLC_EPM_OVRD = 0x806c
        RX_SLC_INIT_TMR = 0x806d
        RX_SLC_RUN_TMR = 0x806e
        RX_SLC_DIAG_CTRL = 0x806f
        RX_SLC_DIS = 0x8070
        # CDRLF Configuration Registers
        RX_CDRLF_CNFG = 0x8080
        RX_CDRLF_CNFG2 = 0x8081
        RX_CDRLF_CNFG3 = 0x8082
        RX_CDRLF_MGN_DIAG = 0x8083
        RX_CDRLF_FPL_TMR0 = 0x8084
        RX_CDRLF_FPL_TMR1 = 0x8085
        # Receiver Signal Detect Filter Registers
        RX_SIGDET_HL_FILT_TMR = 0x8090
        RX_SIGDET_HL_DLY_TMR = 0x8091
        RX_SIGDET_HL_MIN_TMR = 0x8092
        RX_SIGDET_HL_INIT_TMR = 0x8093
        RX_SIGDET_LH_FILT_TMR = 0x8094
        RX_SIGDET_LH_DLY_TMR = 0x8095
        RX_SIGDET_LH_MIN_TMR = 0x8096
        RX_SIGDET_LH_INIT_TMR = 0x8097
        # Receiver LFPS Detect Filter Registers
        RX_LFPSDET_MD_CNT = 0x8098
        RX_LFPSDET_NS_CNT = 0x8099
        RX_LFPSDET_RD_CNT = 0x809a
        RX_LFPSDET_MP_CNT = 0x809b
        RX_LFPSDET_DIAG_CTRL = 0x809c
        # Eye Surf Registers
        RX_EYESURF_CTRL = 0x80a0
        RX_EYESURF_TMR_DELLOW = 0x80a4
        RX_EYESURF_TMR_DELHIGH = 0x80a5
        RX_EYESURF_TMR_TESTLOW = 0x80a6
        RX_EYESURF_TMR_TESTHIGH = 0x80a7
        RX_EYESURF_NS_COORD = 0x80a8
        RX_EYESURF_EW_COORD = 0x80a9
        RX_EYESURF_ERRCNT = 0x80aa
        # Receiver BIST Controller Registers
        RX_BIST_CTRL = 0x80b0
        RX_BIST_SYNCCNT = 0x80b1
        RX_BIST_UDDWR = 0x80b2
        RX_BIST_ERRCNT = 0x80b3
        # Receiver Equalizer Engine (REE) Registers
        RX_REE_PTXEQSM_EQENM_EVAL = 0x8101
        RX_REE_GCSM1_CTRL = 0x8108
        RX_REE_GCSM1_EQENM_PH1 = 0x8109
        RX_REE_GCSM1_EQENM_PH2 = 0x810a
        RX_REE_GCSM2_CTRL = 0x8110
        RX_REE_PERGCSM_CTRL = 0x8118
        RX_REE_PEAK_LTHR = 0x8143
        RX_REE_PEAK_COVRD0 = 0x8145
        RX_REE_PEAK_DIAG = 0x8147
        RX_REE_TAP1_DIAG = 0x8152
        RX_REE_TAP2_DIAG = 0x8156
        RX_REE_TAP3_DIAG = 0x815a
        RX_REE_LFEQ_DIAG = 0x815e
        RX_REE_VGA_GAIN_DIAG = 0x8162
        RX_REE_PERGCSM_EQENM_PH1 = 0x8119
        RX_REE_PERGCSM_EQENM_PH2 = 0x811a
        RX_REE_SMGM_CTRL1 = 0x8177
        RX_REE_SMGM_CTRL2 = 0x8178
        RX_REE_ATTEN_DIAG = 0x814c
        RX_REE_OFF_COR_DIAG = 0x8166
        RX_REE_TAP4_DIAG = 0x8182
        RX_REE_TAP5_DIAG = 0x8186
        # Transceiver Clock Measurement Module Registers
        XCVR_CMSMT_CLK_FREQ_MSMT_CTRL = 0x81c0
        XCVR_CMSMT_TEST_CLK_SEL = 0x81c1
        XCVR_CMSMT_REF_CLK_TMR_VALUE = 0x81c2
        XCVR_CMSMT_TEST_CLK_CNT_VALUE = 0x81c3
        # Receiver Control And Diagnostics Registers
        RX_DIAG_DFE_CTRL = 0x81e0
        RX_DIAG_DFE_AMP_TUNE = 0x81e1
        RX_DIAG_DFE_AMP_TUNE_2 = 0x81e2
        RX_DIAG_DFE_AMP_TUNE_3 = 0x81e3
        RX_DIAG_DFE_AMP_TUNE_4 = 0x81e4
        RX_DIAG_REE_DAC_CTRL = 0x81e5
        RX_DIAG_NQST_CTRL = 0x81e6
        RX_DIAG_LFEQ_TUNE = 0x81e7
        RX_DIAG_SIGDET_TUNE = 0x81e8
        RX_DIAG_SH_SIGDET = 0x81e9
        RX_DIAG_SD_TEST = 0x81ea
        RX_DIAG_SAMP_CTRL = 0x81ec
        RX_DIAG_SH_SLC_IPP = 0x81ed
        RX_DIAG_SH_SLC_IPM = 0x81ed
        RX_DIAG_SH_SLC_QPP = 0x81ef
        RX_DIAG_SH_SLC_QPM = 0x81f0
        RX_DIAG_SH_SLC_EPP = 0x81f1
        RX_DIAG_SH_SLC_EPM = 0x81f2
        RX_DIAG_PI_RATE = 0x81f4
        RX_DIAG_PI_CAP = 0x81f5
        RX_DIAG_PI_TUNE = 0x81f6
        RX_DIAG_LPBK_CTRL = 0x81f8
        RX_DIAG_RST_DIAG = 0x81f9
        RX_DIAG_DCYA = 0x81fe
        RX_DIAG_ACYA = 0x81ff
        # PHY isolation
        PHY_PIPE_CMN_CTRL1 = 0xc000
        PHY_PIPE_CMN_CTRL2 = 0xc001
        PHY_PIPE_COM_LOCK_CFG1 = 0xc002
        PHY_PIPE_COM_LOCK_CFG2 = 0xc003
        PHY_PIPE_EIE_LOCK_CFG = 0xc004
        PHY_PIPE_LANE_DSBL = 0xc005
        PHY_PIPE_RCV_DET_INH = 0xc006
        PHY_PIPE_RX_ELEC_IDLE_DLY = 0xc007
        PHY_ISO_CMN_CTRL = 0xc008
        PHY_STATE_CHG_TIMEOUT = 0xc00a
        PHY_ETH_TRAIN_CFG = 0xc00c
        PHY_PLL_CFG = 0xc00e
        PHY_AUTO_CFG_SPDUP = 0xc00f
        # - Lane
        PHY_PIPE_ISO_TX_CTRL = 0xd000
        PHY_PIPE_ISO_TX_LPC_LO = 0xd001
        PHY_PIPE_ISO_TX_LPC_HI = 0xd002
        PHY_PCS_ISO_TX_DMPH_LO = 0xd003
        PHY_PIPE_ISO_TX_DMPH_HI = 0xd004
        PHY_PIPE_ISO_TX_FSLF = 0xd005
        PHY_PCS_ISO_TX_DATA_LO = 0xd006
        PHY_PCS_ISO_TX_DATA_HI = 0xd007
        PHY_PCS_ISO_RX_CTRL = 0xd008
        PHY_PIPE_ISO_RX_EQ_EVAL = 0xd009
        PHY_ISO_LINK_CFG = 0xd00a
        PHY_PCS_ISO_LINK_CTRL = 0xd00b
        PHY_PIPE_ISO_USB_BER_CNT = 0xd00c
        PHY_ETH_ISO_EQ_CTRL = 0xd00d
        PHY_PCS_ISO_RX_DATA_LO = 0xd00e
        PHY_PCS_ISO_RX_DATA_HI = 0xd00f
        PHY_ETH_ISO_MAC_CLK_CFG = 0xd010
        PHY_ETH_ISO_MAC_CLK_DIV = 0xd011
        PHY_RAW_ISO_LINK_CFG = 0xd014
        PHY_RAW_ISO_LINK_CTRL = 0xd015
        # PMA Configuration and Control - Common
        PHY_PMA_CMN_CTRL1 = 0xe000
        PHY_PMA_CMN_CTRL2 = 0xe001
        PHY_PMA_SSM_STATE = 0xe002
        PHY_PMA_PLL_RAW_CTRL = 0xe003
        # PMA isolation
        PHY_PMA_ISO_CMN_CTRL = 0xe004
        PHY_PMA_ISO_PLL_CTRL0 = 0xe005
        PHY_PMA_ISO_PLL_CTRL1 = 0xe006
        DTB_CTRL = 0xe008
        DTB_DATA_LOW = 0xe009
        DTB_DATA_HIGH = 0xe00a
        PHY_PMA_ISOLATION_CTRL = 0xe00f
        # PMA Configuration and Control - Lane
        PHY_PMA_XCVR_CTRL = 0xf000
        PHY_PMA_XCVR_LPBK = 0xf001
        PHY_PMA_PI_POS = 0xf002
        # PMA isolation - Lane
        PHY_PMA_ISO_XCVR_CTRL = 0xf003
        PHY_PMA_ISO_TX_LPC_LO = 0xf004
        PHY_PMA_ISO_TX_LPC_HI = 0xf005
        PHY_PMA_ISO_TX_DMPH_LO = 0xf006
        PHY_PMA_ISO_TX_DMPH_HI = 0xf007
        PHY_PMA_ISO_TX_FSLF = 0xf008
        PHY_PMA_ISO_TX_MGN = 0xf009
        PHY_PMA_ISO_LINK_MODE = 0xf00a
        PHY_PMA_ISO_PWRST_CTRL = 0xf00b
        PHY_PMA_ISO_RX_EQ_CTRL = 0xf00d
        PHY_PMA_ISO_DATA_LO = 0xf00e
        PHY_PMA_ISO_DATA_HI = 0xf00f
        PHY_PMA_PSM_STATE_LO = 0xf010
        PHY_PMA_PSM_STATE_HI = 0xf011

    COMMON_REGS = (
        'PHY_PLL_CFG',
        'CMN_SSM_BIAS_TMR',
        'CMN_PLLSM0_PLLEN_TMR',
        'CMN_PLLSM0_PLLPRE_TMR',
        'CMN_PLLSM0_PLLLOCK_TMR',
        'CMN_PLLSM1_PLLEN_TMR',
        'CMN_PLLSM1_PLLPRE_TMR',
        'CMN_PLLSM1_PLLLOCK_TMR',
        'CMN_BGCAL_INIT_TMR',
        'CMN_BGCAL_ITER_TMR',
        'CMN_IBCAL_INIT_TMR',
        'CMN_IBCAL_ITER_TMR',
        'CMN_TXPUCAL_INIT_TMR',
        'CMN_TXPUCAL_ITER_TMR',
        'CMN_TXPDCAL_INIT_TMR',
        'CMN_TXPDCAL_ITER_TMR',
        'CMN_RXCAL_INIT_TMR',
        'CMN_RXCAL_ITER_TMR',
        'CMN_SD_CAL_REFTIM_START',
        'CMN_SD_CAL_PLLCNT_START',
        'CMN_PDIAG_PLL0_CLK_SEL_M0',
        'CMN_PDIAG_PLL0_CLK_SEL_M1',
        'CMN_PDIAG_PLL1_CLK_SEL_M0',
        'CMN_PDIAG_PLL1_ITRIM_M0',
        'CMN_PDIAG_PLL0_CP_PADJ_M0',
        'CMN_PDIAG_PLL1_CP_PADJ_M0',
        'CMN_PDIAG_PLL0_CP_IADJ_M0',
        'CMN_PDIAG_PLL0_CTRL_M0',
        'CMN_PDIAG_PLL1_CTRL_M0',
        'CMN_PLL0_VCOCAL_INIT_TMR',
        'CMN_PLL1_VCOCAL_INIT_TMR',
        'CMN_PLL0_VCOCAL_ITER_TMR',
        'CMN_PLL1_VCOCAL_ITER_TMR',
        'CMN_PLL0_VCOCAL_REFTIM_START',
        'CMN_PLL1_VCOCAL_REFTIM_START',
        'CMN_PLL0_VCOCAL_PLLCNT_START',
        'CMN_PLL1_VCOCAL_PLLCNT_START',
        'CMN_PLL0_LOCK_REFCNT_START',
        'CMN_PLL1_LOCK_REFCNT_START',
        'CMN_PLL0_LOCK_PLLCNT_START',
        'CMN_PLL1_LOCK_PLLCNT_START',
        'CMN_PLL0_LOCK_PLLCNT_THR',
        'CMN_PLL1_LOCK_PLLCNT_THR',
        'CMN_DIAG_BIAS_OVRD1',
        'CMN_CDIAG_PLL0_PROG_CLK_CTRL0',
        'CMN_CDIAG_PLL0_PROG_CLK_CTRL1',
        'CMN_CDIAG_PLL1_PROG_CLK_CTRL0',
        'CMN_CDIAG_PLL1_PROG_CLK_CTRL1',
        'CMN_PLL0_DSM_FBH_OVRD_M0',
        'CMN_PLL0_DSM_FBL_OVRD_M0',
        'CMN_PLL1_DSM_FBH_OVRD_M0',
        'CMN_PLL1_DSM_FBL_OVRD_M0',
    )

    LANE_REGS = (
        'PHY_PMA_XCVR_CTRL',
        'PHY_PMA_XCVR_LPBK',
        'RX_SDCAL0_INIT_TMR',
        'RX_SDCAL0_ITER_TMR',
        'RX_SDCAL1_INIT_TMR',
        'RX_SDCAL1_ITER_TMR',
        'TX_RCVDET_ST_TMR',
        'XCVR_DIAG_HSCLK_SEL',
        'XCVR_DIAG_HSCLK_DIV',
        'XCVR_DIAG_PLLDRC_CTRL',
        'TX_PSC_A0',
        'TX_PSC_A1',
        'TX_PSC_A2',
        'TX_PSC_A3',
        'RX_PSC_A0',
        'RX_PSC_A1',
        'RX_PSC_A2',
        'RX_PSC_A3',
        'RX_PSC_A4',
        'RX_PSC_A5',
        'RX_PSC_CAL',
        'RX_PSC_RDY',
        'DRV_DIAG_TX_DRV',
        'TX_TXCC_CPOST_MULT_00',
        'TX_TXCC_MGNFS_MULT_000',
        'TX_TXCC_CTRL',
        'RX_REE_PTXEQSM_EQENM_EVAL',
        'RX_REE_GCSM1_EQENM_PH1',
        'RX_REE_GCSM1_EQENM_PH2',
        'RX_REE_PERGCSM_EQENM_PH1',
        'RX_REE_PERGCSM_EQENM_PH2',
        'RX_REE_SMGM_CTRL1',
        'RX_REE_SMGM_CTRL2',
        'XCVR_DIAG_PSC_OVRD',
        'RX_DIAG_DFE_CTRL',
        'RX_DIAG_NQST_CTRL',
        'RX_DIAG_DFE_AMP_TUNE_2',
        'RX_DIAG_DFE_AMP_TUNE_3',
        'RX_DIAG_PI_RATE',
        'RX_DIAG_PI_CAP',
        'RX_DIAG_ACYA',
        'RX_CDRLF_CNFG',
        'TX_TXCC_IPRE_COEF_VALUE',
        'TX_TXCC_IPOST_COEF_VALUE',
        'TX_TXCC_PRE_OVRD',
        'TX_TXCC_MAIN_OVRD',
        'TX_TXCC_POST_OVRD',
        'TX_TXCC_PRE_CVAL',
        'TX_TXCC_MAIN_CVAL',
        'TX_TXCC_POST_CVAL',
    )

    BIST_REGS = (
        'TX_BIST_CTRL',
        'TX_BIST_UDDWR',
        'TX_BIST_SEED0',
        'TX_BIST_SEED1',
        'RX_BIST_CTRL',
        'RX_BIST_SYNCCNT',
        'RX_BIST_UDDWR',
        'RX_BIST_ERRCNT',
    )

    REE_REGS = (
        'RX_REE_TAP1_DIAG',
        'RX_REE_TAP2_DIAG',
        'RX_REE_TAP3_DIAG',
        'RX_REE_TAP4_DIAG',
        'RX_REE_TAP5_DIAG',
        'RX_REE_PEAK_DIAG',
        'RX_REE_ATTEN_DIAG',
        'RX_REE_LFEQ_DIAG',
        'RX_REE_VGA_GAIN_DIAG',
        'RX_REE_OFF_COR_DIAG',
    )

    def __init__(self):
        pass

    @staticmethod
    def _usleep(usec):
        select.select([], [], [], usec / 1000000)

    @staticmethod
    def _apbRead(addr):
        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == Serdes.RETRY_COUNT:
                raise Exception('apb_read: timeout waiting for req_rdy_f before access')
            SD0801._usleep(1)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        pci.write_fields('MPIC_DO_APB_ACCESS',
            wr_data_f = 0,
            addr_f    = addr,
        )

        pci.write_fields('MPIC_DO_APB_ACCESS_CTRL',
            write_f = 0
        )

        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == Serdes.RETRY_COUNT:
                raise Exception('apb_read: timeout waiting for req_rdy_f before access')
            SD0801._usleep(1)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        data = fields['rsp_data_f']
        return data

    @staticmethod
    def _apbWrite(addr, data):
        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == Serdes.RETRY_COUNT:
                raise Exception('apb_write: timeout waiting for req_rdy_f before access')
            SD0801._usleep(1)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        pci.write_fields('MPIC_DO_APB_ACCESS',
            wr_data_f = data,
            addr_f    = addr
        )

        pci.write_fields('MPIC_DO_APB_ACCESS_CTRL',
            write_f = 1
        )

        retry = 0
        fields = pci.read_fields('MPIC_STS_APB_ACCESS')
        while fields['req_rdy_f'] == 0:
            retry += 1
            if retry == Serdes.RETRY_COUNT:
                raise Exception('apb_write: timeout waiting for req_rdy_f before access')
            SD0801._usleep(1)
            fields = pci.read_fields('MPIC_STS_APB_ACCESS')

        return addr

    @staticmethod
    def _getAddr(reg):
        if isinstance(reg, str):
            addr = getattr(SD0801.Registers, reg)
        else:
            addr = reg
        return addr

    @staticmethod
    def _getName(addr):
        for reg_name in dir(SD0801.Registers):
            if not reg_name.startswith('__'):
                if getattr(SD0801.Registers, reg_name) == addr:
                    return reg_name
        return None

    @staticmethod
    def _getCmnAddr(reg):
        addr = SD0801._getAddr(reg)
        assert ((addr & 0xc000) == 0x0000) or (((addr & 0xf800) == 0xc000)) or (((addr & 0xf800) == 0xe000))
        return addr

    @staticmethod
    def _getLaneAddr(reg, lane):
        addr = SD0801._getAddr(reg)
        assert ((addr & 0xc000) == 0x8000) or ((addr & 0xc000) == 0x4000)
        addr = ((lane & 0x000f) << 9) + addr
        return addr

    @staticmethod
    def _getPmaLaneAddr(reg, lane):
        addr = SD0801._getAddr(reg)
        assert ((addr & 0xf800) == 0xf000) or ((addr & 0xf800) == 0xd000)
        addr = ((lane & 0x0007) << 8) + addr
        return addr

    @staticmethod
    def isPmaLaneAddr(reg_addr):
        addr = SD0801._getAddr(reg_addr)
        return ((addr & 0xf800) == 0xf000) or ((addr & 0xf800) == 0xd000)

    @staticmethod
    def isLaneAddr(reg_addr):
        addr = SD0801._getAddr(reg_addr)
        return ((addr & 0xc000) == 0x8000) or ((addr & 0xc000) == 0x4000)

    @staticmethod
    def isCmnAddr(reg_addr):
        return not SD0801.isPmaLaneAddr(reg_addr) and not SD0801.isLaneAddr(reg_addr)

    @staticmethod
    def apbRead(reg, lane):
        addr = SD0801._getAddr(reg)
        if SD0801.isPmaLaneAddr(addr):
            addr, data = SD0801.apbReadPmaLane(reg, lane)
        elif SD0801.isLaneAddr(addr):
            addr, data = SD0801.apbReadLane(reg, lane)
        else:
            addr, data = SD0801.apbReadCmn(reg)
        return (addr, data)

    @staticmethod
    def apbWrite(reg, data, lane):
        addr = SD0801._getAddr(reg)
        if SD0801.isPmaLaneAddr(addr):
            addr, data = SD0801.apbWritePmaLane(reg, data, lane)
        elif SD0801.isLaneAddr(addr):
            addr, data = SD0801.apbWriteLane(reg, data, lane)
        else:
            addr, data = SD0801.apbWriteCmn(reg, data)
        return (addr, data)

    @staticmethod
    def apbReadCmn(reg):
        addr = SD0801._getCmnAddr(reg)
        data = SD0801._apbRead(addr)
        return (addr, data)

    @staticmethod
    def apbReadLane(reg, lane):
        addr = SD0801._getLaneAddr(reg, lane)
        data = SD0801._apbRead(addr)
        return (addr, data)

    @staticmethod
    def apbReadPmaLane(reg, lane):
        addr = SD0801._getPmaLaneAddr(reg, lane)
        data = SD0801._apbRead(addr)
        return (addr, data)

    @staticmethod
    def apbWriteCmn(reg, data):
        addr = SD0801._getCmnAddr(reg)
        SD0801._apbWrite(addr, data)
        return (addr, data)

    @staticmethod
    def apbWriteLane(reg, data, lane):
        addr = SD0801._getLaneAddr(reg, lane)
        SD0801._apbWrite(addr, data)
        return (addr, data)

    @staticmethod
    def apbWritePmaLane(reg, data, lane):
        addr = SD0801._getPmaLaneAddr(reg, lane)
        SD0801._apbWrite(addr, data)
        return (addr, data)

    @staticmethod
    def mdioPortAddr(lane):
        flds = pci.read_fields('MPIC{}_ENABLE'.format(lane))
        if flds['speed_mode_f'] == 1:
            port_addr = flds['pcs_10g_port_addr_f']
        else:
            flds = pci.read_fields('MPIC{}_CTRL'.format(lane))
            port_addr = flds['pcs_1g_port_addr_f']
        return port_addr

    @staticmethod
    def mdioRead(addr, lane):
        port_addr = SD0801.mdioPortAddr(lane)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=0,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=addr)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=3,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=0)
        v = pci.read_fields('MPIC{}_MDIO_CTRL_REG'.format(lane))
        return v['data_wr_f']

    @staticmethod
    def mdioWrite(addr, data, lane):
        port_addr = SD0801.mdioPortAddr(lane)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=0,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=addr)
        pci.write_fields('MPIC{}_MDIO_CTRL_REG'.format(lane),
            clause_sel_f=0,
            operation_f=1,
            port_addr_f=port_addr,
            dev_addr_f=3,
            zero_f=0,
            data_wr_f=data)

    @staticmethod
    def getPatternName(value):
        value = (value >> 8) & 0x0f
        if value == 0:
            name = "User defined"
        elif value == 0x08:
            name = "PRBS7"
        elif value == 0x09:
            name = "PRBS15"
        elif value == 0x0a:
            name = "PRBS23"
        elif value == 0x0b:
            name = "PRBS31"
        else:
            name = "Unknown"
        return name

class PCS:
    MDIO_COMMON_REGS = {
        0x00: 'PCS Control Register 1',
        0x01: 'PCS Status Register 1',
        0x02: 'PCS Device Identifier 1',
        0x03: 'PCS Device Identifier 2',
        0x04: 'PCS Speed Ability',
        0x05: 'PCS Devices in Package 1',
        0x06: 'PCS Devices in Package 2',
        0x07: 'PCS Control Register 2',
        0x08: 'PCS Status Register 2',
        0x0e: 'PCS Package identifier register 1',
        0x0f: 'PCS Package identifier register 2',
    }

    MDIO_1G_REGS = {
        0x18: '10G Base-X PCS status register',
        0x19: '10G Base-X PCS test control register',
    }

    MDIO_10G_REGS = {
        0x20: '10GBASE-R PCS Status 1',
        0x21: '10GBASE-R PCS Status 2',
        0x22: '10GBASE-R PCS Test Pattern Seed A_0',
        0x23: '10GBASE-R PCS Test Pattern Seed A_1',
        0x24: '10GBASE-R PCS Test Pattern Seed A_2',
        0x25: '10GBASE-R PCS Test Pattern Seed A_3',
        0x26: '10GBASE-R PCS Test Pattern Seed B_0',
        0x27: '10GBASE-R PCS Test Pattern Seed B_1',
        0x28: '10GBASE-R PCS Test Pattern Seed B_2',
        0x29: '10GBASE-R PCS Test Pattern Seed B_3',
        0x2a: '10GBASE-R PCS Test Pattern Control',
        0x2b: '10GBASE-R PCS Test Pattern Error Counter',
        0xaa: '10GBASE-R FEC ability',
        0xab: '10GBASE-R FEC control',
        0xac: '10GBASE-R FEC corrected blocks counter (lo)',
        0xad: '10GBASE-R FEC corrected blocks counter (hi)',
        0xae: '10GBASE-R FEC uncorrected blocks counter (lo)',
        0xaf: '10GBASE-R FEC uncorrected blocks counter (hi)',
    }

    @staticmethod
    def getDesc(addr, speed):
        desc = PCS.MDIO_COMMON_REGS.get(addr)
        if desc is not None:
            return desc
        desc = PCS.MDIO_10G_REGS.get(addr) if speed == 10 else PCS.MDIO_1G_REGS.get(addr)
        if desc is not None:
            return desc
        return ''

class EyeSurf:
    WIDTH_UNIT_SIZE  = 31.25 #mUI
    HEIGHT_UNIT_SIZE = 8     #mV
    ASCII_CHARS      = ' .:-=+(#%@'

    def __init__(self, data):
        self.data = data
        eye_data = np.array(data, dtype=np.uint16)
        min_val = np.min(eye_data)
        max_val = np.max(eye_data)
        self.eye_data = (eye_data - min_val) / (max_val - min_val)

    def plot(self):
        eye_width, eye_width_offset = self.get_eye_width()
        eye_height, eye_height_offset = self.get_eye_height()
        max_eye_width = self.get_max_eye_width()
        max_eye_height = self.get_max_eye_height()
        log('Eye width: offset={:+d} ({:+.2f}mUI), width={} ({:.2f}mUI), max width={} ({:.2f}mUI)'.format(
            eye_width_offset, eye_width_offset * EyeSurf.WIDTH_UNIT_SIZE,
            eye_width, eye_width * EyeSurf.WIDTH_UNIT_SIZE,
            max_eye_width, max_eye_width * EyeSurf.WIDTH_UNIT_SIZE))
        log('Eye height: offset={:+d} ({:+d}mV), height={} ({}mV), max height={} ({}mV)'.format(
            eye_height_offset, eye_height_offset * EyeSurf.HEIGHT_UNIT_SIZE,
            eye_height, eye_height * EyeSurf.HEIGHT_UNIT_SIZE,
            max_eye_height, max_eye_height * EyeSurf.HEIGHT_UNIT_SIZE))
        log('')
        # output eye data in ascii characters
        center_row = (self.eye_data.shape[0] // 2) + 1
        center_col = (self.eye_data.shape[1] // 2) + 1
        for row, row_data in enumerate(self.eye_data):
            ascii_row = [EyeSurf.ASCII_CHARS[int(val * (len(EyeSurf.ASCII_CHARS) - 1))] for val in row_data]
            ascii_row.insert(center_col, '|')
            log(''.join(ascii_row))
            if row == center_row:
                left = (len(row_data) + 1) // 2
                right = len(row_data) - left
                ascii_row = '-' * left + '+' + '-' * right
                log(ascii_row)

    def get_eye_width(self):
        height = self.eye_data.shape[0]
        eye_width, eye_offset = self._row_width(height // 2)
        eye_offset = (eye_offset + (eye_width // 2)) - (self.eye_data.shape[1] // 2)
        return eye_width, eye_offset

    def get_eye_height(self):
        width = self.eye_data.shape[1]
        eye_height, eye_offset = self._column_height(width // 2)
        eye_offset = (self.eye_data.shape[0] // 2) - (eye_offset + (eye_height // 2))
        return eye_height, eye_offset

    def get_max_eye_width(self):
        max_width = 0

        for row in range(self.eye_data.shape[0]):
            current_width, _ = self._row_width(row)
            if current_width > max_width:
                max_width = current_width

        return max_width

    def get_max_eye_height(self):
        max_height = 0

        for col in range(self.eye_data.shape[1]):
            current_height, _ = self._column_height(col)
            if current_height > max_height:
                max_height = current_height

        return max_height

    def _row_width(self, row):
        current_width = 0
        current_offset = None
        max_width = 0
        max_offset = 0
        for offset, value in enumerate(self.eye_data[row]):
            if value == 0:
                current_width += 1
                if current_offset is None:
                    current_offset = offset
                if current_width > max_width:
                    max_width = current_width
                    max_offset = current_offset
            else:
                current_width = 0
                current_offset = None
        return max_width, max_offset

    def _column_height(self, col):
        current_height = 0
        current_offset = None
        max_height = 0
        max_offset = 0
        for row in range(self.eye_data.shape[0]):
            if self.eye_data[row][col] == 0:
                current_height += 1
                if current_offset is None:
                    current_offset = row
                if current_height > max_height:
                    max_height = current_height
                    max_offset = current_offset
            else:
                current_height = 0
                current_offset = None
        return max_height, max_offset
class Serdes(Command):
    NUM_LANES = 2
    RETRY_COUNT = 1000

    JITTER_PATTERNS = {
        #       1G                                   					10G
        '1T': ((0x2aa,),                            					(0xaa,)),
        #       11_0011_0011
        #       00_1100_1100                          					0011_0011
        '2T': ((0x333, 0x0cc),                      					(0x33,)),
        #       11_0000_1111 = 30f
        #       11_1100_0011 = 3c3
        #       00_1111_0000 = 0f0
        #       00_0011_1100 = 03c                  					0000_1111
        '4T': ((0x30f, 0x3c3, 0x0f0, 0x03c),        					(0x0f,)),
        #                                           					0001_1111 = 1f
        #                                           					0111_1100 = 7c
        #                                           					1111_0000 = f0
        #                                           					1100_0001 = c1
        #       00_0001_1111                        					0000_0111 = 07
        '5T': ((0x1f,),                             					(0x1f, 0x7c, 0xf0, 0xc1, 0x07)),
        #       00_1111_1111 = 0ff
        #       11_1100_0000 = 3c0
        #       00_0000_1111 = 00f
        #       11_1111_1100 = 3fc
        #       11_0000_0000 = 300
        #       00_0011_1111 = 03f
        #       11_1111_0000 = 3f0                  					1111_1111 = ff
        #       00_0000_0011 = 003                  					0000_0000 = 00
    '8T': ((0x0ff, 0x3c0, 0x00f, 0x3fc, 0x300, 0x03f,0x3f0, 0x003), 	(0xff, 0x00)),
        #                                           					1111_1111 = ff
        #                                           					0000_0011 = 03
        #                                           					1111_0000 = f0
        #       11_1111_1111 = 3ff                  					0011_1111 = 3f
        #       00_0000_0000 = 000                  					0000_0000 = 00
        '10T':((0x3ff, 0x000),                      					(0xff, 0x03, 0xf0, 0x3f, 0x00)),
    }

    LPBK_MODES = ('none', 'serial', 'isi', 'line', 'rclk', 'nepar', 'fepar')

    PATTERNS = ('7', 'PRBS7', '15', 'PRBS15', '23', 'PRBS23', '31', 'PRBS31', '1T', '2T', '4T', '5T', '8T', '10T')

    @staticmethod
    def _hex_int(x):
        if x[:2] == '0x':
            return int(x, 16)
        return int(x, 10)

    def __init__(self, node_id):
        self.node_id = node_id
        self.tx_pattern = [None] * Serdes.NUM_LANES
        self.rx_pattern = [None] * Serdes.NUM_LANES

        self.parser = parser = argparse.ArgumentParser(prog='diagtest serdes mgmt')
        parser.add_argument('--devport', help='all, one ore more comma seperated devport numbers')
        parser.add_argument('--lane', help='all, one ore more comma seperated lane numbers')
        sub_parsers = parser.add_subparsers()

        parser = sub_parsers.add_parser('help')
        parser.add_argument('cmd', nargs='?', default='')
        parser.set_defaults(func=lambda kwargs: Serdes._cliHelp(self, **kwargs))

        parser = sub_parsers.add_parser('apb', help='SerDes APB registers')
        apb = parser.add_subparsers()
        parser = apb.add_parser('read', help='Read SerDes register')
        parser.add_argument('--reg', type=str, help='Register name')
        parser.add_argument('--addr', type=Serdes._hex_int, help='Register address')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbRead(self, **kwargs))

        parser = apb.add_parser('write', help='Write SerDes register')
        parser.add_argument('--reg', type=str, help='Register name')
        parser.add_argument('--addr', type=Serdes._hex_int, help='Register address')
        parser.add_argument('--value', type=Serdes._hex_int, help='Value to write')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbWrite(self, **kwargs))

        parser = apb.add_parser('dump', help='Dump SerDes register')
        dump = parser.add_subparsers()
        parser = dump.add_parser('common', help='Dump all common SerDes registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpCommon(self, **kwargs))

        parser = dump.add_parser('lane', help='Dump all lane SerDes registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpLane(self, **kwargs))

        parser = dump.add_parser('ree', help='Dump all REE registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpRee(self, **kwargs))

        parser = dump.add_parser('all', help='Dump all registers')
        parser.add_argument('--filename', '-f', type=str, help='Filename')
        parser.set_defaults(func=lambda kwargs: Serdes._cliApbDumpAll(self, **kwargs))

        parser = sub_parsers.add_parser('bist', help='Built-in Self Test')
        bist = parser.add_subparsers()
        parser = bist.add_parser('on', help='Enable BIST function')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistOn(self, **kwargs))

        parser = bist.add_parser('off', help='Disable BIST function')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistOff(self, **kwargs))

        parser = bist.add_parser('tx', help='BIST TX functions')
        bist_tx = parser.add_subparsers()
        parser = bist_tx.add_parser('start', help='Start TX pattern generator')
        parser.add_argument('--pattern', type=str.upper, choices=Serdes.PATTERNS)
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistTxStart(self, **kwargs))

        parser = bist_tx.add_parser('stop', help='Stop TX pattern generator')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistTxStop(self, **kwargs))

        parser = bist_tx.add_parser('error', help='Inject error in the TX pattern generator')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistTxError(self, **kwargs))

        parser = bist.add_parser('rx', help='BIST RX functions')
        bist_rx = parser.add_subparsers()
        parser = bist_rx.add_parser('start', help='Start RX pattern checker')
        parser.add_argument('--pattern', type=str.upper, choices=Serdes.PATTERNS)
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRxStart(self, **kwargs))

        parser = bist_rx.add_parser('stop', help='Stop RX pattern checker')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRxStop(self, **kwargs))

        parser = bist_rx.add_parser('reset', help='Reset RX error counter')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRxReset(self, **kwargs))

        parser = bist.add_parser('status', help='BIST status')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistStatus(self, **kwargs))

        parser = bist.add_parser('regs', help='Read all BIST registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliBistRegs(self, **kwargs))

        parser = sub_parsers.add_parser('mdio', help='MDIO registers')
        mdio = parser.add_subparsers()
        parser = mdio.add_parser('read', help='Read from MDIO register')
        parser.add_argument('--addr', type=Serdes._hex_int, required=True, help='MDIO register address')
        parser.set_defaults(func=lambda kwargs: Serdes._cliMdioRead(self, **kwargs))

        parser = mdio.add_parser('write', help='Write to MDIO register')
        parser.add_argument('--addr', type=Serdes._hex_int, required=True, help='MDIO register address')
        parser.add_argument('--value', type=Serdes._hex_int, required=True, help='Value to write')
        parser.set_defaults(func=lambda kwargs: Serdes._cliMdioWrite(self, **kwargs))

        parser = mdio.add_parser('dump', help='Dump all MDIO registers')
        parser.set_defaults(func=lambda kwargs: Serdes._cliMdioDump(self, **kwargs))

        parser = sub_parsers.add_parser('phy', help='Physical layer functions')
        phy = parser.add_subparsers()

        parser = phy.add_parser('invert_tx', help='Set TX polarity')
        parser.add_argument('invert_tx', type=str, choices=('on', 'off'))
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyInvertTx(self, **kwargs))

        parser = phy.add_parser('invert_rx', help='Set RX polarity')
        parser.add_argument('invert_rx', type=str, choices=('on', 'off'))
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyInvertRx(self, **kwargs))

        parser = phy.add_parser('lpbk', help='Set loopback mode')
        parser.add_argument('--mode', choices=Serdes.LPBK_MODES, required=True)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyLpbk(self, **kwargs))

        parser = phy.add_parser('rx_training', help='Enable RX training')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyRxTraining(self, **kwargs))

        parser = phy.add_parser('on', help='Turn on phy')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyOn(self, **kwargs))

        parser = phy.add_parser('off', help='Turn off phy')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyOff(self, **kwargs))

        parser = phy.add_parser('reset', help='Toggle phy reset')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyReset(self, **kwargs))

        parser = phy.add_parser('status', help='Show phy status')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyStatus(self, **kwargs))

        parser = phy.add_parser('taps', help='TX Taps functions')
        taps = parser.add_subparsers()
        parser = taps.add_parser('init', help='Set TX INIT taps')
        parser.add_argument('--pre', type=Serdes._hex_int, required=True)
        parser.add_argument('--main', type=Serdes._hex_int, required=True)
        parser.add_argument('--post', type=Serdes._hex_int, required=True)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsInit(self, **kwargs))

        parser = taps.add_parser('set', help='Set TX taps override')
        parser.add_argument('--pre', type=Serdes._hex_int)
        parser.add_argument('--main', type=Serdes._hex_int)
        parser.add_argument('--post', type=Serdes._hex_int)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsSet(self, **kwargs))

        parser = taps.add_parser('get', help='Get TX taps')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsGet(self, **kwargs))

        parser = taps.add_parser('clear', help='Clear TX taps')
        parser.add_argument('--pre', action='store_true')
        parser.add_argument('--main', action='store_true')
        parser.add_argument('--post', action='store_true')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyTapsClear(self, **kwargs))

        parser = phy.add_parser('attn', help='TX Taps functions')
        attn = parser.add_subparsers()
        parser = attn.add_parser('set')
        parser.add_argument('attn', type=int)
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyAttnSet(self, **kwargs))

        parser = attn.add_parser('get')
        parser.set_defaults(func=lambda kwargs: Serdes._cliPhyAttnGet(self, **kwargs))

        parser = sub_parsers.add_parser('link', help='Show link status')
        parser.set_defaults(func=lambda kwargs: Serdes._cliLinkStatus(self, **kwargs))

        parser = sub_parsers.add_parser('bathtub', help='The bathtub eye surf function')
        parser.add_argument('--cycles', type=Serdes._hex_int, default=0x2000, help='Number of test cycles')
        parser.add_argument('--delay', type=Serdes._hex_int, default=0x000f, help='Eye surf timer delay')
        parser.add_argument('--filename', '-f', type=str, default=None, help='Save the data to a file')
        parser.add_argument('--xrange', '-x', type=int, default=31, help='Range of x axis +/-N')
        parser.add_argument('--peak', '-p', type=int, default=1, help='Specify the peak value')
        parser.set_defaults(func=lambda kwargs: Serdes._cliEyeSurfBathTub(self, **kwargs))

        parser = sub_parsers.add_parser('eyesurf', help='The full eye surf function')
        parser.add_argument('--cycles', type=Serdes._hex_int, default=0x2000, help='Number of test cycles')
        parser.add_argument('--delay', type=Serdes._hex_int, default=0x000f, help='Eye surf timer delay')
        parser.add_argument('--filename', '-f', type=str, default=None, help='Save the data to a file')
        parser.add_argument('--xyrange', '-r', type=int, default=None, help='Range of x and y axis +/-N')
        parser.add_argument('--xrange', '-x', type=int, default=31, help='Range of x axis +/-N')
        parser.add_argument('--yrange', '-y', type=int, default=31, help='Range of x axis +/-N')
        parser.add_argument('--peak', '-p', type=int, default=1, help='Specify the peak value')
        parser.set_defaults(func=lambda kwargs: Serdes._cliEyeSurfFull(self, **kwargs))

        parser = sub_parsers.add_parser('eyeplot', help='Plot eye diagram from the specified data file')
        parser.add_argument('--filename', '-f', type=str, help='eye data file')
        parser.add_argument('--peak', '-p', type=int, default=1, help='Specify the peak value')
        parser.set_defaults(func=lambda kwargs: Serdes._cliEyePlot(self, **kwargs))

        self.sub_cmds = self.parser._subparsers._actions[-1].choices

        super(Serdes, self).__init__()

    @staticmethod
    def _bistPattern(speed, pattern):
        if pattern == '7' or pattern == 'PRBS7' or pattern is None:
            pattern = 0x0800 # PRBS7
            name = 'PRBS7'
        elif pattern == '15' or pattern == 'PRBS15':
            pattern = 0x0900 # PRBS15
            name = 'PRBS15'
        elif pattern == '23' or pattern == 'PRBS23':
            pattern = 0x0a00 # PRBS23
            name = 'PRBS23'
        elif pattern == '31' or pattern == 'PRBS31':
            pattern = 0x0b00 # PRBS31
            name = 'PRBS31'
        else:
            name = pattern
            pattern = Serdes.JITTER_PATTERNS.get(name)
            if pattern is not None:
                pattern = pattern[0] if speed == 1 else pattern[1]
        return (name, pattern)

    @staticmethod
    def _laneSpeed(lane):
        fields = pci.read_fields('MPIC{}_ENABLE'.format(lane))
        speed = 10 if fields['speed_mode_f'] == 1 else 1
        return speed

    @staticmethod
    def _pcsLink(lane):
        flds = pci.read_fields('MPIC{}_ENABLE'.format(lane))
        speed = Serdes._laneSpeed(lane)
        if speed == 10:
            pcs_link = flds['pcs_10g_block_lock_f']
        else:
            pcs_link = flds['pcs_1g_sync_status_f']
        return pcs_link

    @staticmethod
    def _linkFault(lane):
        fields = pci.read_fields('MPIC{}_RX_CONFIG'.format(lane))
        return fields['remote_fault_f'] or fields['local_fault_f']

    @staticmethod
    def _enablePowerIslandOveride():
        # Enable the power island controller input override
        addr, value = SD0801.apbReadCmn('CMN_CDIAG_DIAG_PWRI_OVRD')
        value |= 0x8000
        SD0801.apbWriteCmn('CMN_CDIAG_DIAG_PWRI_OVRD', value)

        # Set the power recovery request override
        value |= 0x0200
        SD0801.apbWriteCmn('CMN_CDIAG_DIAG_PWRI_OVRD', value)

    @staticmethod
    def _disablePowerIslandOveride():
        # Disable the power recovery request override
        addr, value = SD0801.apbReadCmn('CMN_CDIAG_DIAG_PWRI_OVRD')
        value &= 0xffff - 0x0200
        SD0801.apbWriteCmn('CMN_CDIAG_DIAG_PWRI_OVRD', value)

        # Disable the power island controller input override
        value &= 0xffff - 0x8000
        SD0801.apbWriteCmn('CMN_CDIAG_DIAG_PWRI_OVRD', value)

    @staticmethod
    def _phyReset(lane):
        phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
        if phy_lane_reset_n:
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            SD0801._usleep(1)
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})

    @staticmethod
    def _pmaPowerStateLane0(state):
        if state == 0:
            pci.write_fields('PMA_XCVR_LN0', power_state_req_ln_0_f=0)
            return
        fields = pci.read_fields('PMA_XCVR_LN0')
        prev_state = fields['power_state_ack_ln_0_f']
        pci.write_fields('PMA_XCVR_LN0', power_state_req_ln_0_f=state)
        retry_count = 1000
        while True:
            fields = pci.read_fields('PMA_XCVR_LN0')
            if fields['power_state_ack_ln_0_f'] == state:
                break
            retry_count -= 1
            if retry_count == 0:
                raise Exception('Lane 0: power state change {} to {} failed'.format(prev_state, state))

    @staticmethod
    def _pmaPowerStateLane1(state):
        if state == 0:
            pci.write_fields('PMA_XCVR_LN1', power_state_req_ln_1_f=0)
            return
        fields = pci.read_fields('PMA_XCVR_LN1')
        prev_state = fields['power_state_ack_ln_1_f']
        pci.write_fields('PMA_XCVR_LN1', power_state_req_ln_1_f=state)
        retry_count = 1000
        while True:
            fields = pci.read_fields('PMA_XCVR_LN1')
            if fields['power_state_ack_ln_1_f'] == state:
                break
            retry_count -= 1
            if retry_count == 0:
                raise Exception('Lane 1: power state change {} to {} failed'.format(prev_state, state))

    @staticmethod
    def _pmaPowerState(lane, state):
        if lane == 0:
            Serdes._pmaPowerStateLane0(state)
        else:
            Serdes._pmaPowerStateLane1(state)
        SD0801._usleep(1)

    @staticmethod
    def _pmaPowerDown(lane):
        Serdes._pmaPowerState(lane, 0)

    @staticmethod
    def _pmaPowerUp(lane):
        Serdes._pmaPowerState(lane, 4)
        Serdes._pmaPowerState(lane, 0)
        Serdes._pmaPowerState(lane, 1)

    def _cliHelp(self, devport, lane, cmd=''):
        if cmd == '':
            self.parser.print_help()
            return ifcs_ctypes.IFCS_SUCCESS
        parser = self.parser._subparsers._actions[-1].choices.get(cmd)
        if parser is None:
            log_err('Unknown command: {}'.format(cmd))
            return ifcs_ctypes.IFCS_INVAL
        parser.print_help()
        return ifcs_ctypes.IFCS_SUCCESS

    def _getLanes(self, devport, lane, required=False):
        if devport is not None and lane is not None:
            raise CommandError('Specify either devport or lane number')
        if devport is None:
            if lane is None:
                raise CommandError('Please specify --devport or --lane option')
            if lane == 'all':
                if required:
                    raise CommandError('Please supply a specific devport or lane number')
                return compat_listrange(Serdes.NUM_LANES)
            if isinstance(lane, int):
                return [lane]
            try:
                lanes = lane.split(',')
                lanes = [int(l, 10) for l in lanes]
                return lanes
            except Exception as e:
                raise CommandError('Invalid lane specification {}'.format(lane))
        if devport == 'all':
            if required:
                raise CommandError('Please supply a specific devport or lane number')
            return compat_listrange(Serdes.NUM_LANES)
        if isinstance(devport, str):
            try:
                devports = devport.split(',')
                devports = [int(d, 10) for d in devports]
            except Exception as e:
                raise CommandError('Invalid devport specification {}'.format(devport))
        else:
            devports = [devport]
        lanes = []
        for devport in devports:
            count = ctypes.c_uint32()
            attrs = (ifcs_ctypes.ifcs_attr_t * 2)()
            attrs[0].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
            attrs[1].id = ifcs_ctypes.IFCS_DEVPORT_ATTR_START_LANE
            rc = ifcs_ctypes.ifcs_devport_attr_get(self.node_id, devport, len(attrs), compat_pointer(attrs, ifcs_ctypes.ifcs_attr_t), pointer(count))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                raise CommandError('Devport attr get failed on devport {}, rc={}'.format(devport, _status_to_string(rc)))
            assert attrs[0].bitmap.u32 == 1
            assert attrs[1].bitmap.u32 == 1
            if attrs[0].value.u32 != ifcs_ctypes.IFCS_DEVPORT_TYPE_AUX:
                raise CommandError('The specified devport {} is not an mgmt type'.format(devport))
            lanes.append(attrs[1].value.u32)
        return lanes

    def _cliApbRead(self, reg, addr, devport, lane):
        lanes = self._getLanes(devport, lane)
        if reg is None:
            if addr is None:
                log('Please specify either --reg or --addr')
                return
        else:
            if addr is not None:
                log('Please specify either --reg or --addr')
                return
        if reg:
            if not hasattr(SD0801.Registers, reg):
                log_err('Unknown register {}'.format(reg))
                return
            addr = SD0801._getAddr(reg)
            reg_addr = reg
        else:
            reg = SD0801._getName(addr)
            reg_addr = addr
        if SD0801.isCmnAddr(reg_addr):
            lanes = (0,)
        table = PrintTable()
        table.set_justification('left')
        row = ['Register']
        for lane in lanes:
            row.extend(('Lane {}'.format(lane), ''))
        table.add_row(row)
        row = [reg if reg else '']
        for lane in lanes:
            addr, value = SD0801.apbRead(reg_addr, lane)
            row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
        table.add_row(row)
        table.print_table()

    def _cliApbWrite(self, reg, addr, value, devport, lane):
        lanes = self._getLanes(devport, lane)
        if reg is None:
            if addr is None:
                log('Please specify either --reg or --addr')
                return
            reg = SD0801._getName(addr)
            reg_addr = addr
        else:
            if addr is not None:
                log('Please specify either --reg or --addr')
                return
            if not hasattr(SD0801.Registers, reg):
                log_err('Unknown register {}'.format(reg))
                return
            addr = SD0801._getAddr(reg)
            reg_addr = reg
        if SD0801.isCmnAddr(addr):
            lanes = (0,)
        table = PrintTable()
        table.set_justification('left')
        row = ['Register']
        for lane in lanes:
            row.extend(('Lane {}'.format(lane), ''))
        table.add_row(row)
        row = [reg if reg else '']
        for lane in lanes:
            addr, value = SD0801.apbWrite(reg_addr, value, lane)
            row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
        table.add_row(row)
        table.print_table()

    def _cliApbDumpCommon(self, devport, lane):
        table = PrintTable()
        table.set_justification('left')
        table.add_row(('Register', 'Address','Value'))
        for reg in SD0801.COMMON_REGS:
            addr, value = SD0801.apbReadCmn(reg)
            table.add_row((reg, '{:04x}'.format(addr), '{:04x}'.format(value)))
        table.print_table()

    def _cliApbDumpLane(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(['Lane {}'.format(lane), 'Value'])
        table.add_row(row)

        for reg in SD0801.LANE_REGS:
            row = [reg]
            for lane in lanes:
                addr, value = SD0801.apbRead(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)
        table.print_table()

    def _cliApbDumpRee(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(['Lane {}'.format(lane), 'Value'])
        table.add_row(row)

        for reg in SD0801.REE_REGS:
            row = [reg]
            for lane in lanes:
                addr, value = SD0801.apbRead(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)
        table.print_table()

    @staticmethod
    def _dumpRegs(output, name, base, count):
        base_str = '{:016b}'.format(base)
        if (base & 0xc000) == 0xc000:
            base_str = base_str[0:2] + '_' + base_str[2] + '_' + base_str[3] + '_' + base_str[4:8]
        else:
            base_str = base_str[0:2] + '_' + base_str[2] + '_' + base_str[3:7]
        if isinstance(output, PrintTable):
            output.add_row((name, '0x{:04x}'.format(base), '', base_str))
        else:
            output.write('{}: 0x{:04x} - {}\n'.format(name, base, base_str))
        for idx in range(count):
            addr = base + idx
            name = SD0801._getName(addr)
            if name is None:
                name = "*"
            _, data = SD0801.apbRead(addr, 0)
            binstr = "{:016b}".format(data)
            binstr = '_'.join([binstr[i:i+4] for i in range(0, len(binstr), 4)])
            if isinstance(output, PrintTable):
                output.add_row(('0x{:04x}'.format(addr), '0x{:04x}'.format(data), '0b{}'.format(binstr), name))
            else:
                output.write('0x{:04x}: 0x{:04x} - 0b{} {}\n'.format(addr, data, binstr, name))

    def _cliApbDumpAll(self, devport, lane, filename):
        if filename is None:
            output = PrintTable()
            output.set_justification('left')
        else:
            log('Dumping SerDes registers to file:', filename)
            output = open(filename, "wt")
        self._dumpRegs(output, 'Common',         0x0000, 0x200)
        self._dumpRegs(output, 'Tx Lane 0',      0x4000, 0x200)
        self._dumpRegs(output, 'RX Lane 0',      0x8000, 0x200)
        self._dumpRegs(output, 'Common PHY PCS', 0xc000, 0x100)
        self._dumpRegs(output, 'Lane PHY PCS',   0xd000, 0x100)
        self._dumpRegs(output, 'Common PHY PMA', 0xe000, 0x100)
        self._dumpRegs(output, 'Lane PHY PMA',   0xf000, 0x100)
        if isinstance(output, PrintTable):
            output.print_table()

    def _cliBistOn(self, devport, lane):
        self._enablePowerIslandOveride()

    def _cliBistOff(self, devport, lane):
        bist_active = False
        # Make sure BIST Tx and Rx are disable
        for lane in range(Serdes.NUM_LANES):
            addr, value = SD0801.apbReadLane('TX_BIST_CTRL', lane)
            if value & 0x001:
                log('Lane {}: bist tx is active'.format(lane))
                bist_active = True

            addr, value = SD0801.apbReadLane('RX_BIST_CTRL', lane)
            if value & 0x001:
                log('Lane {}: bist rx is active'.format(lane))
                bist_active = True

        if bist_active:
            return

        self._disablePowerIslandOveride()

    def _cliBistTxStart(self, pattern, devport, lane):
        lanes = self._getLanes(devport, lane)
        addr, value = SD0801.apbReadCmn('CMN_CDIAG_DIAG_PWRI_OVRD')
        if (value & 0x8200) != 0x8200:
            log('Please run bist on first')
            return
        for lane in lanes:
            (pattern_name, pattern_value) = self._bistPattern(self._laneSpeed(lane), pattern)
            addr, value = SD0801.apbReadLane('TX_BIST_CTRL', lane)
            value &= 0xffff - 0x0f01
            SD0801.apbWriteLane('TX_BIST_CTRL', value, lane)
            if pattern_name.startswith('PRBS'):
                value |= pattern_value
            else:
                SD0801.apbWriteLane('TX_BIST_CTRL', value | 0x0002, lane)
                for user in pattern_value:
                    SD0801.apbWriteLane('TX_BIST_UDDWR', user, lane)
            value |= 0x0001
            SD0801.apbWriteLane('TX_BIST_CTRL', value, lane)
            self.tx_pattern[lane] = pattern_name

    def _cliBistTxStop(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            #12: Disable the transmitter BIST
            addr, value = SD0801.apbReadLane('TX_BIST_CTRL', lane)
            value &= 0xffff - 0x0001
            SD0801.apbWriteLane('TX_BIST_CTRL', value, lane)

    def _cliBistTxError(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            addr, value = SD0801.apbReadLane('TX_BIST_CTRL', lane)
            if not (value & 0x0001):
                continue
            # Toggle force error
            SD0801.apbWriteLane('TX_BIST_CTRL', value | 0x0010, lane)
            SD0801.apbWriteLane('TX_BIST_CTRL', value & (0xffff - 0x0010), lane)

    def _cliBistRxStart(self, pattern, devport, lane):
        lanes = self._getLanes(devport, lane)
        addr, value = SD0801.apbReadCmn('CMN_CDIAG_DIAG_PWRI_OVRD')
        if (value & 0x8200) != 0x8200:
            log('Please run bist on first')
            return
        for lane in lanes:
            (pattern_name, pattern_value) = self._bistPattern(self._laneSpeed(lane), pattern)
            # Set the BIST receiver sync count to 250
            SD0801.apbWriteLane('RX_BIST_SYNCCNT', 0x00fa, lane)
            #4: Select rx data pattern
            addr, value = SD0801.apbReadLane('RX_BIST_CTRL', lane)
            value &= 0xffff - 0x0f00
            if pattern_name.startswith('PRBS'):
                value |= pattern_value
            else:
                # Receiver BIST user defined data FIFO clear
                SD0801.apbWriteLane('RX_BIST_CTRL', value | 0x0002, lane)
                for user in pattern_value:
                    SD0801.apbWriteLane('RX_BIST_UDDWR', user, lane)
            value |= 0x0001
            SD0801.apbWriteLane('RX_BIST_CTRL', value, lane)
            self.rx_pattern[lane] = pattern_name

    def _cliBistRxStop(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            #13: Receiver BIST error reset
            addr, value = SD0801.apbReadLane('RX_BIST_CTRL', lane)
            value |= 0x0010
            SD0801.apbWriteLane('RX_BIST_CTRL', value, lane)
            #11: Disable the receiver BIST
            value &= 0xffff - 0x0001
            SD0801.apbWriteLane('RX_BIST_CTRL', value, lane)
            # Clear Receiver BIST error reset
            value &= 0xffff - 0x0010
            SD0801.apbWriteLane('RX_BIST_CTRL', value, lane)

    def _cliBistRxReset(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            addr, value = SD0801.apbReadLane('RX_BIST_CTRL', lane)
            value |= 0x0010
            SD0801.apbWriteLane('RX_BIST_CTRL', value, lane)
            value &= 0xffff - 0x0010
            SD0801.apbWriteLane('RX_BIST_CTRL', value, lane)

    def _cliBistStatus(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        header_row = ['']
        tx_row = ['TX']
        tx_invert_row = ['Invert TX']
        rx_row = ['RX']
        rx_invert_row = ['Invert RX']
        sync_row = ['Pattern sync']
        err_row = ['Error counter']
        for lane in lanes:
            header_row.append('Lane {}'.format(lane))
            addr, value = SD0801.apbReadLane('TX_BIST_CTRL', lane)
            if value & 0x0001:
                if self.tx_pattern[lane] is None:
                    tx_row.append(SD0801.getPatternName(value))
                else:
                    tx_row.append(self.tx_pattern[lane])
            else:
                tx_row.append('off')

            addr, value = SD0801.apbReadLane('RX_BIST_CTRL', lane)
            if value & 0x0001:
                if self.rx_pattern[lane] is None:
                    rx_row.append(SD0801.getPatternName(value))
                else:
                    rx_row.append(self.rx_pattern[lane])
            else:
                rx_row.append('off')

            addr, value = SD0801.apbReadPmaLane('PHY_PMA_XCVR_CTRL', lane)
            sync_row.extend(('yes' if value & 0x0002 else 'no',))
            tx_invert_row.append('on' if value & 0x0100 else 'off')
            rx_invert_row.append('on' if value & 0x0001 else 'off')

            addr, value = SD0801.apbReadLane('RX_BIST_ERRCNT', lane)
            err_row.append(value)

        table = PrintTable()
        table.set_justification('left')
        table.add_row(header_row)
        table.add_row(tx_row)
        table.add_row(rx_row)
        table.add_row(tx_invert_row)
        table.add_row(rx_invert_row)
        table.add_row(sync_row)
        table.add_row(err_row)
        table.print_table()

        for lane in lanes:
            self._cliBistRxReset(devport=None, lane=lane)

        for lane in lanes:
            fields = pci.read_fields('PMA_RX_CNFG_LN{}'.format(lane))
            if fields['eq_training_data_valid_f']:
                pci.write_fields('PMA_RX_CNFG_LN{}'.format(lane), eq_training_data_valid_f=0)
                log('Lane {}: RX training disabled'.format(lane))

    def _cliBistRegs(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(('Lane {}'.format(lane), 'Value'))
        table.add_row(row)

        regs = ('CMN_CDIAG_DIAG_PWRI_OVRD',)
        for reg in regs:
            row = [reg]
            for lane in lanes:
                if lane == 0:
                    addr, value = SD0801.apbReadCmn(reg)
                    row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
                else:
                    row.extend(('', ''))
            table.add_row(row)

        for reg in SD0801.BIST_REGS:
            row = [reg]
            for lane in lanes:
                addr, value = SD0801.apbReadLane(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)

        for reg in ('PHY_PMA_XCVR_CTRL',):
            row = [reg]
            for lane in lanes:
                addr, value = SD0801.apbReadPmaLane(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)

        table.print_table()

    def _cliMdioRead(self, addr, devport, lane):
        lanes = self._getLanes(devport, lane, required=True)
        table = PrintTable()
        table.set_justification('left')
        table.add_row(('Address', 'Description', 'Value'))

        value = SD0801.mdioRead(addr, lanes[0])
        desc = PCS.getDesc(addr, Serdes._laneSpeed(lanes[0]))
        table.add_row(('{:04x}'.format(addr), desc, '{:04x}'.format(value)))

        table.print_table()

    def _cliMdioWrite(self, addr, value, devport, lane):
        lanes = self._getLanes(devport, lane, required=True)
        SD0801.mdioWrite(addr, value, lanes[0])
        self._cliMdioRead(addr, lanes[0])

    def _cliMdioDump(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')
        row = ['Address', 'Description']
        row.extend(('Lane {}'.format(lane) for lane in lanes))
        table.add_row(row)

        for addr, desc in PCS.MDIO_COMMON_REGS.items():
            row = ['{:04x}'.format(addr), desc]
            for lane in lanes:
                value = SD0801.mdioRead(addr, lane)
                row.append('{:04x}'.format(value))
            table.add_row(row)

        speed = Serdes._laneSpeed(lane)
        for addr, desc in PCS.MDIO_10G_REGS.items() if speed == 10 else PCS.MDIO_1G_REGS.items():
            row = ['{:04x}'.format(addr), desc]
            for lane in lanes:
                value = SD0801.mdioRead(addr, lane)
                row.append('{:04x}'.format(value))
            table.add_row(row)
        table.print_table()

    def _cliPhyInvertRx(self, invert_rx, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            addr, value = SD0801.apbReadPmaLane('PHY_PMA_XCVR_CTRL', lane)
            if invert_rx == 'on':
                value |= 0x0001
            else:
                value &= 0xffff - 0x0001
            SD0801.apbWritePmaLane('PHY_PMA_XCVR_CTRL', value, lane)
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: invert_rx={}'.format(lane, invert_rx))

    def _cliPhyInvertTx(self, invert_tx, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            addr, value = SD0801.apbReadPmaLane('PHY_PMA_XCVR_CTRL', lane)
            if invert_tx == 'on':
                value |= 0x0100
            else:
                value &= 0xffff - 0x0100
            SD0801.apbWritePmaLane('PHY_PMA_XCVR_CTRL', value, lane)
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: invert_tx={}'.format(lane, invert_tx))

    def _cliPhyLpbk(self, mode, devport, lane):
        lanes = self._getLanes(devport, lane)
        if mode == 'none':
            mode = None
        for lane in lanes:
            addr, value = SD0801.apbReadPmaLane('PHY_PMA_XCVR_LPBK', lane)
            value &= 0xffff - 0x003f
            if mode is not None:
                value |= 0x0001 << (Serdes.LPBK_MODES.index(mode) - 1)
            SD0801.apbWritePmaLane('PHY_PMA_XCVR_LPBK', value, lane)
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
                SD0801._usleep(1)
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: loopback={}'.format(lane, mode))

    def _cliPhyRxTraining(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PMA_RX_CNFG_LN{}'.format(lane), eq_training_data_valid_f = 1)
            log('Lane {}: RX training enabled'.format(lane))

    def _cliPhyOn(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: SerDes on'.format(lane))

    def _cliPhyOff(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
            log('Lane {}: SerDes off'.format(lane))

    def _cliPhyReset(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
                SD0801._usleep(1)
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})
            log('Lane {}: SerDes reset'.format(lane))

    def _cliPhyStatus(self, devport, lane):
        enabled_row = ['Enabled']
        speed_row = ['Speed']
        signal_detect_row = ['Signal Detect']
        pcs_link_row = ['PCS Link']
        loopback_row = ['Loopback']
        tx_invert_row = ['Invert TX']
        rx_invert_row = ['Invert RX']

        for lane in range(Serdes.NUM_LANES):
            speed_row.append('{}G'.format(Serdes._laneSpeed(lane)))

            flds = pci.read_fields('PHY_LANE_CTRL')
            enabled_row.append('yes' if flds['phy_l{:02}_reset_n_f'.format(lane)] else 'no')
            signal_detect_row.append('yes' if flds['pma_rx_signal_detect_ln_{}_f'.format(lane)] else 'no')

            pcs_link = Serdes._pcsLink(lane)
            pcs_link_row.append('up' if pcs_link else 'down')

            addr, value = SD0801.apbReadPmaLane('PHY_PMA_XCVR_LPBK', lane)
            if value & 0x0001:
                loopback = 'serial'
            elif value & 0x0002:
                loopback = 'isi'
            elif value & 0x0004:
                loopback = 'line'
            elif value & 0x0008:
                loopback = 'recovered clock'
            elif value & 0x0010:
                loopback = 'ne parallel'
            elif value & 0x0020:
                loopback = 'fe parallel'
            else:
                loopback = 'none'
            loopback_row.append(loopback)

            addr, value = SD0801.apbReadPmaLane('PHY_PMA_XCVR_CTRL', lane)
            tx_invert_row.append('on' if value & 0x0100 else 'off')
            rx_invert_row.append('on' if value & 0x0001 else 'off')

        table = PrintTable()
        table.set_justification('left')
        table.add_row(('', 'Lane 0', 'Lane 1'))
        table.add_row(speed_row)
        table.add_row(enabled_row)
        table.add_row(signal_detect_row)
        table.add_row(pcs_link_row)
        table.add_row(loopback_row)
        table.add_row(tx_invert_row)
        table.add_row(rx_invert_row)
        table.print_table()

    def _cliPhyTapsInit(self, pre, main, post, devport, lane):
        lanes = self._getLanes(devport, lane)

        ipre = ((main & 0x3f) << 8) + (pre & 0x3f)
        ipost = (post & 0x3f)

        addr, value = SD0801.apbReadCmn('CMN_DIAG_SH_RESISTOR')
        tx_res_cal = (value >> 8) & 0x3f
        total_taps = abs(main) + abs(pre) + abs(post)
        if total_taps > tx_res_cal:
            log_err('The total taps {} must be less or equal to tx_res_cal {}'.format(total_taps, tx_res_cal))
            return

        for lane in lanes:
            SD0801.apbWriteLane('TX_TXCC_IPRE_COEF_VALUE', ipre, lane)
            SD0801.apbWriteLane('TX_TXCC_IPOST_COEF_VALUE', ipost, lane)
            phy_lane_reset_n = pci.read_fields('PHY_LANE_CTRL')['phy_l{:02}_reset_n_f'.format(lane)]
            if phy_lane_reset_n:
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 0})
                SD0801._usleep(1)
                pci.write_fields('PHY_LANE_CTRL', **{'phy_l{:02}_reset_n_f'.format(lane): 1})

    def _cliPhyTapsSet(self, pre, main, post, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            if pre is not None:
                addr, value = SD0801.apbReadLane('TX_TXCC_PRE_OVRD', lane)
                value &= 0xffff - 0x003f
                value |= 0x0100 | (pre & 0x003f)
                SD0801.apbWriteLane('TX_TXCC_PRE_OVRD', value, lane)

            if main is not None:
                addr, value = SD0801.apbReadLane('TX_TXCC_MAIN_OVRD', lane)
                value &= 0xffff - 0x003f
                value |= 0x0100 | (main & 0x003f)
                SD0801.apbWriteLane('TX_TXCC_MAIN_OVRD', value, lane)

            if post is not None:
                addr, value = SD0801.apbReadLane('TX_TXCC_POST_OVRD', lane)
                value &= 0xffff - 0x003f
                value |= 0x0100 | (post & 0x003f)
                SD0801.apbWriteLane('TX_TXCC_POST_OVRD', value, lane)

    def _cliPhyTapsClear(self, pre, main, post, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            if pre:
                addr, value = SD0801.apbReadLane('TX_TXCC_PRE_OVRD', lane)
                value &= 0xffff - 0x013f
                SD0801.apbWriteLane('TX_TXCC_PRE_OVRD', value, lane)

            if main:
                addr, value = SD0801.apbReadLane('TX_TXCC_MAIN_OVRD', lane)
                value &= 0xffff - 0x013f
                SD0801.apbWriteLane('TX_TXCC_MAIN_OVRD', value, lane)

            if post:
                addr, value = SD0801.apbReadLane('TX_TXCC_POST_OVRD', lane)
                value &= 0xffff - 0x013f
                SD0801.apbWriteLane('TX_TXCC_POST_OVRD', value, lane)

    def _cliPhyTapsGet(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        table = PrintTable()
        table.set_justification('left')

        row = ['Register']
        for lane in lanes:
            row.extend(['Lane {}'.format(lane), 'Value'])
        table.add_row(row)

        regs = ('CMN_DIAG_SH_RESISTOR',)
        for reg in regs:
            row = [reg]
            for lane in range(Serdes.NUM_LANES):
                if lane == 0:
                    addr, value = SD0801.apbReadCmn(reg)
                    row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
                else:
                    row.extend(('', ''))
            table.add_row(row)

        regs =  ('TX_TXCC_IPRE_COEF_VALUE', 'TX_TXCC_IPOST_COEF_VALUE',
                 'TX_TXCC_PRE_OVRD', 'TX_TXCC_MAIN_OVRD', 'TX_TXCC_POST_OVRD',
                 'TX_TXCC_PRE_CVAL', 'TX_TXCC_MAIN_CVAL', 'TX_TXCC_POST_CVAL',
                 'TX_TXCC_MGNFS_MULT_000','TX_TXCC_MGNFS_MULT_001',
                 'TX_TXCC_MGNFS_MULT_010', 'TX_TXCC_MGNFS_MULT_011',
                 'TX_TXCC_MGNFS_MULT_100', 'TX_TXCC_MGNFS_MULT_101',
                 'TX_TXCC_MGNFS_MULT_110', 'TX_TXCC_MGNFS_MULT_111')
        for reg in regs:
            row = [reg]
            for lane in lanes:
                addr, value = SD0801.apbReadLane(reg, lane)
                row.extend(('{:04x}'.format(addr), '{:04x}'.format(value)))
            table.add_row(row)

        table.print_table()

    def _cliPhyAttnSet(self, attn, devport, lane):
        if attn > 7:
            log_err("The largest allowed value is 7")
            return
        if attn < 0:
            log_err("The lowest allowed value is 0")
            return
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            pci.write_fields('PMA_TX_CNFG_LN{}'.format(lane), vmargin_f=attn)
            flds = pci.read_fields('PMA_TX_CNFG_LN{}'.format(lane))
            vmargin = flds['vmargin_f']
            addr, value = SD0801.apbReadLane('TX_TXCC_MGNFS_MULT_{:03b}'.format(vmargin), lane)
            log('Lane {}: Attenuation: vmargin={}, multiplier={}/128'.format(lane, vmargin, value))

    def _cliPhyAttnGet(self, devport, lane):
        lanes = self._getLanes(devport, lane)
        for lane in lanes:
            flds = pci.read_fields('PMA_TX_CNFG_LN{}'.format(lane))
            vmargin = flds['vmargin_f']
            addr, value = SD0801.apbReadLane('TX_TXCC_MGNFS_MULT_{:03b}'.format(vmargin), lane)
            log('Lane {}: Attenuation: vmargin={}, multiplier={}/128'.format(lane, vmargin, value))

    def _cliLinkStatus(self, devport, lane):
        table = PrintTable()
        table.set_justification('left')
        table.add_row(('', 'Lane 0', 'Lane 1'))

        fields = pci.read_fields('PHY_LANE_CTRL')
        table.add_row(('PHY_LANE_CTRL', '', ''))
        table.add_row(('phy_cmn_reset_n', fields['phy_cmn_reset_n_f'], ''))
        table.add_row(('phy_lane_reset_n', fields['phy_l00_reset_n_f'], fields['phy_l01_reset_n_f']))
        table.add_row(('pma_rx_signal_detect', fields['pma_rx_signal_detect_ln_0_f'], fields['pma_rx_signal_detect_ln_1_f']))
        table.add_row(('','',''))

        reg = 'MPIC{}_ENABLE'
        values = []
        for lane in range(Serdes.NUM_LANES):
            values.append(pci.read_fields(reg.format(lane)))

        table.add_row((reg.format('n'), '', ''))
        fields = ('pcs_10g_loopback_input', 'pcs_10g_scr_loopbk_en', 'pcs_10g_block_lock', 'pcs_10g_scr_loopbk_en')
        for field in fields:
            row = [field]
            for lane in range(Serdes.NUM_LANES):
                row.append(values[lane]['{}_f'.format(field)])
            table.add_row(row)
        table.add_row(('','',''))

        reg = 'MPIC{}_RX_CONFIG'
        values = []
        for lane in range(Serdes.NUM_LANES):
            values.append(pci.read_fields(reg.format(lane)))

        table.add_row((reg.format('n'), '', ''))
        fields = ('remote_fault', 'local_fault',)
        for field in fields:
            row = [field]
            for lane in range(Serdes.NUM_LANES):
                row.append(values[lane]['{}_f'.format(field)])
            table.add_row(row)

        table.print_table()

    @staticmethod
    def _enableEyeSurf(lane, cycles, delay):
        addr, value = SD0801.apbRead('XCVR_DIAG_GPANA_2', lane)
        value |= 0x0001
        SD0801.apbWrite('XCVR_DIAG_GPANA_2', value, lane)

        # Enable the analog receiver E path in the A0 and A1 power states
        for reg in ('RX_PSC_A0', 'RX_PSC_A1'):
            addr, value = SD0801.apbRead(reg, lane)
            value |= 0x0002
            SD0801.apbWrite(reg, value, lane)

        Serdes._pmaPowerDown(lane)
        Serdes._pmaPowerUp(lane)
        Serdes._phyReset(lane)
        SD0801._usleep(1000)
        link_up = Serdes._pcsLink(lane) and not Serdes._linkFault(lane)
        if not link_up:
            log("enableEyeSurf: lane {} link down".format(lane))
            retry = 1000
            while not link_up:
                retry -= 1
                if retry == 0:
                    break
                SD0801._usleep(1000)
                Serdes._phyReset(lane)
                link_up = Serdes._pcsLink(lane) and not Serdes._linkFault(lane)
            if link_up:
                log("enableEyeSurf: lane {} link up".format(lane))

        # Disable all receiver equalization functions
        for reg in ('RX_REE_GCSM1_CTRL', 'RX_REE_GCSM2_CTRL', 'RX_REE_PERGCSM_CTRL'):
            addr, value = SD0801.apbRead(reg, lane)
            value &= 0xffff - 0x0001
            SD0801.apbWrite(reg, value, lane)

        addr, value = SD0801.apbRead('XCVR_DIAG_GPANA_2', lane)
        value |= 0x0002
        SD0801.apbWrite('XCVR_DIAG_GPANA_2', value, lane)

        SD0801.apbWrite('RX_EYESURF_TMR_DELLOW', delay & 0xffff, lane)
        SD0801.apbWrite('RX_EYESURF_TMR_DELHIGH', (delay >> 16) & 0xffff, lane)
        SD0801.apbWrite('RX_EYESURF_TMR_TESTLOW', cycles & 0xffff, lane)
        SD0801.apbWrite('RX_EYESURF_TMR_TESTHIGH', (cycles >> 16) & 0xffff, lane)

    @staticmethod
    def _disableEyeSurf(lane):
        addr, value = SD0801.apbRead('XCVR_DIAG_GPANA_2', lane)
        value &= 0xffff - 0x0002
        SD0801.apbWrite('XCVR_DIAG_GPANA_2', value, lane)

        # Enable all receiver equalization function
        for reg in ('RX_REE_GCSM1_CTRL', 'RX_REE_GCSM2_CTRL', 'RX_REE_PERGCSM_CTRL'):
            addr, value = SD0801.apbRead(reg, lane)
            value |= 0x0001
            SD0801.apbWrite(reg, value, lane)

        # Disable the analog receiver E path in the A0 and A1 power states
        for reg in ('RX_PSC_A0', 'RX_PSC_A1'):
            addr, value = SD0801.apbRead(reg, lane)
            value &= 0xffff - 0x0002
            SD0801.apbWrite(reg, value, lane)

        Serdes._pmaPowerDown(lane)
        Serdes._pmaPowerUp(lane)
        Serdes._phyReset(lane)
        SD0801._usleep(1000)

        addr, value = SD0801.apbRead('XCVR_DIAG_GPANA_2', lane)
        value &= 0xffff - 0x0001
        SD0801.apbWrite('XCVR_DIAG_GPANA_2', value, lane)

        link_up = Serdes._pcsLink(lane) and not Serdes._linkFault(lane)
        if not link_up:
            log("disableEyeSurf: lane {} link down".format(lane))
            retry = 1000
            while not link_up:
                retry -= 1
                if retry == 0:
                    break
                SD0801._usleep(1000)
                Serdes._phyReset(lane)
                link_up = Serdes._pcsLink(lane) and not Serdes._linkFault(lane)
            if link_up:
                log("disableEyeSurf: lane {} link up".format(lane))

    @staticmethod
    def _eyeSurfTestPoint(lane, x = 0, y = 0):
        # Set the test point north/south coordinate
        addr, value = SD0801.apbRead('RX_EYESURF_NS_COORD', lane)
        if y >= 0:
            # north
            value |= 0x0100
        else:
            # south
            value &= 0xfeff
        value &= 0xffff - 0x00ff
        value |= abs(y) & 0xff
        SD0801.apbWrite('RX_EYESURF_NS_COORD', value, lane)
        addr, value = SD0801.apbRead('RX_EYESURF_NS_COORD', lane)
        assert value & 0xff == abs(y)
        assert value & 0x0100 == (0x0100 if y >= 0 else 0)

        # Set the test point east/west coordinate
        addr, value = SD0801.apbRead('RX_EYESURF_EW_COORD', lane)
        if x >= 0:
            # east
            value |= 0x0100
        else:
            # west
            value &= 0xfeff
        value &= 0xffff - 0x00ff
        value |= abs(x) & 0xff
        SD0801.apbWrite('RX_EYESURF_EW_COORD', value, lane)
        addr, value = SD0801.apbRead('RX_EYESURF_EW_COORD', lane)
        assert value & 0xff == abs(x)
        assert value & 0x0100 == (0x0100 if x >= 0 else 0)

        # Initiate the eye surf process for the test point
        addr, value = SD0801.apbRead('RX_EYESURF_CTRL', lane)
        SD0801.apbWrite('RX_EYESURF_CTRL', value | 0x8000, lane)

        retry_cnt = 0
        err_cnt = None

        # Wait for confirmation that the eye surf process is complete
        while True:
            SD0801._usleep(1)
            addr, value = SD0801.apbRead('RX_EYESURF_CTRL', lane)
            if value & 0x4000:
                # Get  bit errors that occurred at the test point during the test
                addr, value = SD0801.apbRead('RX_EYESURF_ERRCNT', lane)
                err_cnt = value
                break
            retry_cnt += 1
            if retry_cnt > 1000:
                break

        # Stop the eye surf process
        addr, value = SD0801.apbRead('RX_EYESURF_CTRL', lane)
        SD0801.apbWrite('RX_EYESURF_CTRL', value & 0x7fff, lane)

        # Wait for confirmation that the eye surf process is complete
        while True:
            SD0801._usleep(1)
            addr, value = SD0801.apbRead('RX_EYESURF_CTRL', lane)
            if (value & 0x4000) == 0:
                break

        if err_cnt is None:
            raise Exception('Eye surf test point failed')

        return err_cnt

    def _cliEyeSurfBathTub(self, devport, lane, cycles, delay, filename, xrange, peak):
        lanes = self._getLanes(devport, lane)

        if filename is not None:
            log('Writing to file {}'.format(filename))
            output = open(filename, 'w')
        else:
            output = sys.stdout

        self._enablePowerIslandOveride()

        for lane in lanes:
            self._enableEyeSurf(lane, cycles, delay)

        for lane in lanes:
            try:
                eye_data = []
                eye_row = []
                row = ''
                for x in range(-xrange, xrange + 1):
                    err_cnt = self._eyeSurfTestPoint(lane, x)
                    if len(row) > 0:
                        row += ','
                    row += '{:d}'.format(err_cnt)
                    if peak:
                        eye_row.append(err_cnt if err_cnt < peak else peak)
                    else:
                        eye_row.append(err_cnt)
                eye_data.append(eye_row)
                output.write(row)
                output.write('\n')
                output.flush()
                eye_surf = EyeSurf(eye_data)
                eye_surf.plot()
            except Exception as exc:
                log_err('{}'.format(exc))

        for lane in lanes:
            self._disableEyeSurf(lane)

        self._disablePowerIslandOveride()

        if filename is not None:
            output.close()

    def _cliEyeSurfFull(self, devport, lane, cycles, delay, filename, xyrange, xrange, yrange, peak):
        lanes = self._getLanes(devport, lane)

        if xyrange is not None:
            xrange = yrange = xyrange

        self._enablePowerIslandOveride()

        for lane in lanes:
            self._enableEyeSurf(lane, cycles, delay)

        if filename is not None:
            log('Writing to file {}'.format(filename))
            output = open(filename, 'w')
        else:
            output = sys.stdout

        for lane in lanes:
            try:
                eye_data = []
                for y in range(yrange, -yrange - 1, -1):
                    row = ''
                    eye_row = []
                    for x in range(-xrange, xrange + 1):
                        err_cnt = self._eyeSurfTestPoint(lane, x, y)
                        if len(row) > 0:
                            row += ','
                        row += '{:d}'.format(err_cnt)
                        if peak:
                            eye_row.append(err_cnt if err_cnt < peak else peak)
                        else:
                            eye_row.append(err_cnt)
                    eye_data.append(eye_row)
                    output.write(row)
                    output.write('\n')
                    output.flush()
                eye_surf = EyeSurf(eye_data)
                eye_surf.plot()
            except Exception as exc:
                log_err('{}'.format(exc))

        for lane in lanes:
            self._disableEyeSurf(lane)

        self._disablePowerIslandOveride()

        for lane in lanes:
            self._phyReset(lane)

        if filename is not None:
            output.close()

    def _cliEyePlot(self, devport, lane, filename, peak):
        eye_data = []
        with open(filename, 'r') as file:
            for line in file:
                eye_row = []
                for value in line.split(','):
                    value = int(value)
                    if peak:
                        eye_row.append(value if value < peak else peak)
                    else:
                        eye_row.append(value)
                eye_data.append(eye_row)
        eye_surf = EyeSurf(eye_data)
        eye_surf.plot()

serdes_instances = {}

def run_cmd(node_id, args_list):
    try:
        serdes = serdes_instances.get(node_id)
        if serdes is None:
            serdes = Serdes(node_id)
            serdes_instances[node_id] = serdes
        args = serdes.parser.parse_args(args_list)
        if not hasattr(args, 'func'):
            args_list.append('--help')
            args = serdes.parser.parse_args(args_list)
            return ifcs_ctypes.IFCS_INVAL
        cmd_func = args.func
        kwargs = vars(args)
        kwargs.pop('func')
        log_dbg(1, 'args: {}'.format(kwargs))
        return cmd_func(kwargs)
    except CommandError as cmd_err:
        log_err('{}'.format(cmd_err))
        return cmd_err.rc
    except Exception as ex:
        log_err(str(ex))
        log(traceback.format_exc())
    return ifcs_ctypes.IFCS_INVAL
