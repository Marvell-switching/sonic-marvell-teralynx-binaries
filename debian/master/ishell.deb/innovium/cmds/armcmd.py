#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

import shlex
import time

from testutil import bincopy
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

from testutil import arm
from operator import add
from itertools import *
if COMPAT_PY2:
    from exceptions import IOError

# temporary, to provide backtrace on breakage
import sys,traceback

class Arm(Command):
    def __init__(self, cli):
        self.sub_cmds = {'read'        : self.read_cmd,
                         'write'       : self.write_cmd,
                         'load'        : self.load,
                         'run'         : self.run,
                         'stop'        : self.stop,
                         'status'      : self.status,
                         'debug'       : self.debug,
                         'meminit'     : self.meminit,
                         'dump'        : self.dump,
                         'reset'       : self.reset,
                         'halt'        : self.halt,
                         'sysreset'    : self.sysreset,
                         'dbgreset'    : self.dbgreset,
                         'mbox'        : self.mbox,
                         'help'        : self.help,
                         '?'           : self.help
                        }
        self.cli = cli

        super(Arm, self).__init__()

    # ------------
    # Read command
    # ------------
    def read_cmd(self, arg_list):
        if arm.is_unsafe():
            raise IOError(1, "ARM subsystem is in reset, cannot read memory")

        addr = int(arg_list[0], 0)
        count = 1
        if len(arg_list) > 1:
            count = int(arg_list[1], 0)

        read_vals = arm.read32(addr, count)

        # Take output 4 words at a time
        for group in compat_izip_longest(*[iter(read_vals)]*4):
            log_no_newline("{:08x}: ".format(addr))
            addr += 4 * 4
            for val in group:
                 if val is not None:
                     log_no_newline("{:08x} ".format(val))
            log("")

    # ------------
    # Write command
    # ------------
    def write_cmd(self, arg_list):
        if arm.is_unsafe():
            raise IOError(1, "ARM subsystem is in reset, cannot write memory")

        addr = int(arg_list[0], 0)
        val_list = compat_listmap(lambda s:int(s, 0), arg_list[1:])
        arm.write32(addr, val_list)

    # ------------
    # Load command
    # ------------
    def load(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        arm.load(arg_list[0])


    # ------------
    # Run command
    # ------------
    def run(self, arg_list):
        if len(arg_list) < 1:
            self.cli_error()
            return
        arm.stop()
        arm.load(arg_list[0])
        arm.log_start()
        arm.halt_clear()

    # ------------
    # Stop command
    # ------------
    def stop(self, arg_list):
        arm.stop()
        time.sleep(0.01)
        arm.log_stop()

    def log(self, arg_list):
        arm.print_log()

    # ------------
    # Debug command
    # ------------
    def debug(self, arg_list):
        arm.stop()
        arm.dbgreset_clear()
        arm.load("arm_fw/hold.srec")
        arm.log_start()
        arm.halt_clear()
        log("Ready for debug...");

    # ------------
    # Dump command
    # ------------
    def dump(self, arg_list):
        if arm.is_unsafe():
            raise IOError(1, "ARM subsystem is in reset, cannot read memory")

        addr = int(arg_list[0], 0)
        num_bytes = int(arg_list[1], 0)
        filename = None
        if len(arg_list) > 2:
            filename = arg_list[2]

        word_data = arm.read32(addr, compat_division((num_bytes + 3), 4))  # round up if not on a word boundary
        bytedata = bytearray()
        for word in word_data:
            bytedata.append(word & 0xff)
            bytedata.append((word >> 8)  & 0xff)
            bytedata.append((word >> 16) & 0xff)
            bytedata.append((word >> 24) & 0xff)

        # if not on a word boundary, truncate
        bytedata = bytedata[:num_bytes]

        binfile = bincopy.BinFile()
        binfile.add_binary(bytedata, addr)

        if filename is None:
            log(binfile.as_hexdump())
        else:
            newfile = open(filename, 'wb')
            if filename.lower().endswith('srec'):
                newfile.write(binfile.as_srec())
            elif filename.lower().endswith('ihex'):
                newfile.write(binfile.as_ihex())
            else:
                newfile.write(bytedata)

    # ------------
    # Reset command
    # ------------
    def reset(self, arg_list):
        if len(arg_list) == 0 or arg_list[0] == 'on':
            arm.reset_set()
        elif arg_list[0] == 'off':
            arm.reset_clear()
        else:
            self.cli.error()

    # ------------
    # SysReset command
    # ------------
    def sysreset(self, arg_list):
        if len(arg_list) == 0 or arg_list[0] == 'on':
            arm.sysreset_set()
        elif arg_list[0] == 'off':
            arm.sysreset_clear()
        else:
            self.cli.error()

    # ------------
    # DbgReset command
    # ------------
    def dbgreset(self, arg_list):
        if len(arg_list) == 0 or arg_list[0] == 'on':
            arm.dbgreset_set()
        elif arg_list[0] == 'off':
            arm.dbgreset_clear()
        else:
            self.cli.error()

    # ------------
    # Halt command
    # ------------
    def halt(self, arg_list):
        if len(arg_list) == 0 or arg_list[0] == 'on':
            arm.halt_set()
        elif arg_list[0] == 'off':
            arm.halt_clear()
        else:
            cli.error()

    # ------------
    # Status command
    # ------------
    def status(self, arg_list):
        halted = arm.halt_is_active()
        reset = arm.reset_is_active()
        sysreset = arm.sysreset_is_active()
        dbgreset = arm.dbgreset_is_active()
        onoff = {True: "on", False: "off"}

        out = "Status: "
        if sysreset or reset or halted:
            out += "SysReset {}".format(onoff[sysreset])
            out += ", Reset {}".format(onoff[reset])
            out += ", Halt {}".format(onoff[halted])
        else:
            out += "Running "

        out += ", DbgReset {}".format(onoff[dbgreset])
        log(out)

    # ------------
    # MemInit command
    # ------------
    def meminit(self, arg_list):
        if arm.is_unsafe():
            raise IOError(1, "ARM subsystem is in reset, cannot access memory")

        arm.write64(0x00000000, [0x0000000000000000] * 32 * 1024)
        arm.write64(0x00800000, [0x0000000000000000] * 32 * 1024)
        arm.write64(0x00840000, [0x0000000000000000] * 32 * 1024)

    # MBOX command
    # ------------
    def mbox(self, arg_list):
        if len(arg_list) < 2:
            arg_list = ['help']
        else:
            num = int(arg_list[1])
        if len(arg_list) == 2 and arg_list[0] == 'read':
            values = arm.mbox_read(num)
            log_no_newline("MBOX %d: [" % num)
            for v in values:
                log_no_newline("0x%08x" % v)
            log("]")
        elif len(arg_list) >= 3 and arg_list[0] == 'write':
            val_list = compat_listmap(lambda s:int(s, 0), arg_list[2:])
            arm.mbox_write(num, val_list)
        else:
            log("Usage: 'arm mbox read <#>', 'arm mbox write <#> <value> [<value>...]'")

    def run_cmd(self, args):
        arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(arg_list))

        try:
            return self.sub_cmds[arg_list[1]](arg_list[2:])
        except Exception as ex:
            traceback.print_exc(file=sys.stdout)
            log("run cmd: ", type(ex).__name__, ex.args)
            self.cli.error()
            self.help(args)
            return
        except:
            log_dbg(1, "Arm error")
            self.cli.error()
            self.help(args)
        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def help(self, args):
        log("Usage: ")
        log("arm read <addr> [count]               - Read <count> words from ARM TCM")
        log("arm write <addr> <val1> [<val2> ...]  - Write words to ARM TCM")
        log("arm load <filename>                   - Load ARM TCM from SREC file")
        log("arm run <filename>                    - Load, then start execution")
        log("arm stop                              - Stops ARM core with reset pulse + halt")
        log("arm status                            - Shows status of ARM Halt & Resets")
        log("arm debug                             - Setup the ARM for interactive debugging")
        log("arm meminit                           - Initialize ARM TCMs")
        log("arm reset (on|off)                    - Set ARM core Reset state")
        log("arm sysreset (on|off)                 - Set ARM core SysReset state")
        log("arm dbgreset (on|off)                 - Set ARM core ResetDBG state")
        log("arm halt (on|off)                     - Set ARM core Halt state")
        log("arm dump <addr> <len> [filename]      - Dump <len> bytes from ARM TCM")
        log("arm mbox (read|write) <#> [values...] - Read or Write to mailbox")
