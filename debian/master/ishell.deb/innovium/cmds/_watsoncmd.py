#-------------------------------------------------------------------------------
# Copyright (c) (2025) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
import argparse
import cmdmgr
import ctypes
import json
import re
import shlex
import sys
import traceback
import _watson_rx as watson_rx

from datetime import datetime, timedelta, timezone
from testutil import pci
from utils import compat_util
from verbosity import *

ifcs_ctypes = sys.modules['ifcs_ctypes']

NODE_ID = 0

class WatsonDevport:
    def __init__(self, ib, ibport, devport):
        self.ib = ib
        self.ibport = ibport
        self.devport = devport

class WatsonFilter:
    _instance = None

    def __init__(self):
        self.ib_count = ifcs_ctypes.im_node_num_ibs(NODE_ID)
        self.ib_mask = 0
        self.ib_port_masks = [0] * self.ib_count
        self.ib_queue_masks = [0] * self.ib_count
        self.ib_partition_masks = [0] * self.ib_count
        self.devports = {}

        callback = ifcs_ctypes.ifcs_devport_user_cb_t(WatsonFilter.__devport_get_all_cb)
        rc = ifcs_ctypes.ifcs_devport_get_all(NODE_ID, 0, None,
                compat_funcPointer(callback, ifcs_ctypes.ifcs_devport_user_cb_t), None, None)
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        callback = ifcs_ctypes.ifcs_queue_id_user_cb_t(WatsonFilter.__queue_get_all_cb)
        rc = ifcs_ctypes.ifcs_queue_id_get_all(NODE_ID, 0, None,
                compat_funcPointer(callback, ifcs_ctypes.ifcs_queue_id_user_cb_t),
                None, None)
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        callback = ifcs_ctypes.ifcs_dtm_buffer_partition_user_cb_t(WatsonFilter.__dtm_buffer_partition_get_all_cb)
        rc = ifcs_ctypes.ifcs_dtm_buffer_partition_get_all(NODE_ID, None, 0, None,
                compat_funcPointer(callback, ifcs_ctypes.ifcs_dtm_buffer_partition_user_cb_t),
                None, None)
        assert rc == ifcs_ctypes.IFCS_SUCCESS

        actual_count = ctypes.c_uint32()
        attr = ifcs_ctypes.ifcs_attr_t()
        ifcs_ctypes.ifcs_attr_t_init(ctypes.pointer(attr))
        ifcs_ctypes.ifcs_attr_t_id_set(ctypes.pointer(attr), ifcs_ctypes.IFCS_IB_ATTR_WATSON_ENABLE)
        for ib in range(self.ib_count):
            rc = ifcs_ctypes.ifcs_ib_attr_get(NODE_ID, ib, 1, ctypes.pointer(attr), actual_count)
            assert rc == ifcs_ctypes.IFCS_SUCCESS
            assert actual_count.value == 1

            if attr.value.data:
                self.ib_mask |= 1 << ib

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(WatsonFilter, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def _devport_get_all_cb(self, devport, ib, ibport):
        self.devports[devport] = WatsonDevport(ib, ibport, devport)
        self.ib_port_masks[ib] |= 1 << ibport

    def _queue_id_get_all_cb(self, queue_id):
        for ib in range(self.ib_count):
            self.ib_queue_masks[ib] |= 1 << queue_id

    def _partition_get_all_cb(self, ib, partition_id):
        self.ib_partition_masks[ib] |= 1 << partition_id

    def get_enabled(self):
        port_masks = ''
        queue_masks = ''
        partition_masks = ''
        for ib in range(self.ib_count):
            if self.ib_mask & (1 << ib):
                if port_masks:
                    port_masks += ':'
                port_masks += '0x{:x}'.format(self.ib_port_masks[ib])
                if queue_masks:
                    queue_masks += ':'
                queue_masks += '0x{:x}'.format(self.ib_queue_masks[ib])
                if partition_masks:
                    partition_masks += ':'
                partition_masks += '0x{:x}'.format(self.ib_partition_masks[ib])
        enabled = 'ib=0x{:x},ports={},queues={},partitions={}'.format(self.ib_mask, port_masks, queue_masks, partition_masks)
        return enabled

    def get_devports(self):
        devports = ''
        for devport in self.devports.values():
            if devports:
                devports += ':'
            devports += '{}={}.{}'.format(devport.devport, devport.ib, devport.ibport)
        return devports

    @staticmethod
    def __devport_get_all_cb(node_id, devport, attr_count, attr_list, user_data):
        attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE]
        assert attr.id == ifcs_ctypes.IFCS_DEVPORT_ATTR_TYPE
        if attr.value.u32 != ifcs_ctypes.IFCS_DEVPORT_TYPE_ETH:
            return

        attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_IB]
        assert attr.id == ifcs_ctypes.IFCS_DEVPORT_ATTR_IB
        ib = attr.value.u32

        attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_IBPORT]
        assert attr.id == ifcs_ctypes.IFCS_DEVPORT_ATTR_IBPORT
        ibport = attr.value.u32

        attr = attr_list[ifcs_ctypes.IFCS_DEVPORT_ATTR_WATSON_ENABLE]
        assert attr.id == ifcs_ctypes.IFCS_DEVPORT_ATTR_WATSON_ENABLE
        enable = attr.value.data

        if enable:
            WatsonFilter._instance._devport_get_all_cb(devport, ib, ibport)

    @staticmethod
    def __queue_get_all_cb(node_id, queue_id, attr_count, attr_list, user_data):
        attr = attr_list[ifcs_ctypes.IFCS_QUEUE_ID_ATTR_WATSON_ENABLE]
        assert attr.id == ifcs_ctypes.IFCS_QUEUE_ID_ATTR_WATSON_ENABLE
        enable = attr.value.data

        if enable:
            WatsonFilter._instance._queue_id_get_all_cb(queue_id)

    @staticmethod
    def __dtm_buffer_partition_get_all_cb(node_id, dtm_buffer_partition_p, attr_count, attr_list, user_data):
        attr = attr_list[ifcs_ctypes.IFCS_DTM_BUFFER_PARTITION_ATTR_WATSON_ENABLE]
        assert attr.id == ifcs_ctypes.IFCS_DTM_BUFFER_PARTITION_ATTR_WATSON_ENABLE
        enable = attr.value.data

        if enable:
            ib = dtm_buffer_partition_p.contents.ib
            partition_id = dtm_buffer_partition_p.contents.partition_id
            WatsonFilter._instance._partition_get_all_cb(ib, partition_id)

class Watson(cmdmgr.Command):
    def __init__(self, cli):
        self.cli = cli
        self.wrx = None

        self.parser = argparse.ArgumentParser('watson')
        sub_parser = self.parser.add_subparsers()

        parser = sub_parser.add_parser('capture', help='Start Watson capture process')
        parser.add_argument('--source', type=str, default='i2c', help='Capture source file/i2c/mgmt0/mgmt1')
        parser.add_argument('--output', type=str, help='Capture file base filename')
        parser.add_argument('--debug', action='store_true', help='Enable debug output')
        parser.add_argument('--reset', action='store_true', help='Hard reset Watson FPGA')
        parser.add_argument('--background', action='store_true', help='Run capture in background')
        parser.set_defaults(func=lambda kwargs: Watson._capture_start(self, **kwargs))

        parser = sub_parser.add_parser('stop', help='Stop Watson capture process')
        parser.set_defaults(func=lambda kwargs: Watson._capture_stop(self, **kwargs))

        parser = sub_parser.add_parser('dump', help='Dump capture Watson file')
        parser.add_argument('--input', type=str, required=True, help='Capture file base filename')
        parser.add_argument('--output', type=str, required=True, help='Output file')
        parser.add_argument('--filter', type=str, help='Filter output')
        parser.add_argument('--devports', type=str, help='Number of devports to dump')
        parser.set_defaults(func=lambda kwargs: Watson._dump(self, **kwargs))

        parser = sub_parser.add_parser('time', help='Time function')
        time_sub_parser = parser.add_subparsers()
        parser = time_sub_parser.add_parser('set', help='Set PTP global time to current time')
        parser.add_argument('time_value', type=str, nargs='?', default='current', help='Time to set')
        parser.set_defaults(func=lambda kwargs: Watson._time_set(self, **kwargs))

        parser = time_sub_parser.add_parser('get', help='Get PTP global time')
        parser.set_defaults(func=lambda kwargs: Watson._time_get(self, **kwargs))

        self.sub_cmds = self.parser._subparsers._actions[-1].choices

        super(Watson, self).__init__()

    def subcomplete(self, text, remline):
        parser = self.parser
        while True:
            cmd, remline, line = self.cli.parseline(remline)
            sub_cmds = parser._subparsers._actions[-1].choices if parser._subparsers else None
            if cmd is None:
                return compat_listkeys(sub_cmds) if sub_cmds else None
            parser = sub_cmds.get(cmd)
            if not parser:
                return [j for j in sub_cmds.keys() if j.startswith(cmd)] if sub_cmds else None
            if cmd == text:
                break
        return None

    def run_cmd(self, args):
        log_dbg(1, 'in Watson run')
        arg_list = shlex.split(args)
        if len(arg_list) <= 1:
            self.parser.print_help()
            return ifcs_ctypes.IFCS_PARAM

        try:
            args = self.parser.parse_args(arg_list[1:])
            if not hasattr(args, 'func'):
                self.parser.print_help()
                return ifcs_ctypes.IFCS_PARAM
            cmd_func = args.func
            kwargs = vars(args)
            kwargs.pop('func')
            log_dbg(1, 'args: {}'.format(kwargs))
            return cmd_func(kwargs)
        except cmdmgr.CommandError as cmd_err:
            log_err('{}'.format(cmd_err))
            log_dbg(traceback.format_exc())
            return cmd_err.rc
        except Exception as e:
            log_err('{}'.format(e))
            log_dbg(1, traceback.format_exc())
            return ifcs_ctypes.IFCS_PARAM

    def _capture_start(self, source, output, debug, reset, background):
        if self.wrx and self.wrx.is_running():
            log_err('Watson capture already running')
            return ifcs_ctypes.IFCS_INVAL

        ib_filter = WatsonFilter()
        cmd_args = ['--sku', 'ib=%d,port=%d,queue=%d,partition=%d' % (ifcs_ctypes.IFCS_MAX_IBS_NUM, ifcs_ctypes.IFCS_MAX_ETH_IB_PORTS_NUM, ifcs_ctypes.IFCS_ETH_PORT_MAX_QUEUES, ifcs_ctypes.II_NODE_NUM_PARTITIONS)]
        cmd_args.extend(['--reset', 'hard' if reset else 'soft'])
        cmd_args.extend(['--output', output if output is not None else "watson"])
        cmd_args.extend(['--enable', ib_filter.get_enabled()])
        devports = ib_filter.get_devports()
        if devports:
            cmd_args.extend(['--devports', ib_filter.get_devports()])
        cmd_args.extend(['--source', source])
        if background:
            cmd_args.extend(['--background'])

        if debug:
            log('Running: watson_rx {}'.format(' '.join(cmd_args)))

        self.wrx = watson_rx.WatsonCapture(cmd_args)
        self.wrx.start()
        if not self.wrx.args.background:
            try:
                self.wrx.run()
                self.wrx.stop()
            finally:
                self.wrx = None

        return ifcs_ctypes.IFCS_SUCCESS

    def _capture_stop(self):
        if self.wrx:
            self.wrx.stop()
            self.wrx = None
            log('Watson capture stopped')
        return ifcs_ctypes.IFCS_SUCCESS

    def _dump_devport_stats(self, id, devport_stats, filter, devports):
        output = ''
        for devport, counter in devport_stats.items():
            if filter == 'nz' and counter == 0:
                continue
            devport = int(devport)
            if devports and devport not in devports:
                continue
            if output:
                output += ', '
            if (id == ifcs_ctypes.IFCS_WATSON_STAT_PORT_UTILIZATION or
               id == ifcs_ctypes.IFCS_WATSON_STAT_PORT_UTILIZATION_AVERAGE):
                util_pct = (counter / 64) * 100
                output += 'devport_{}={:.2f}'.format(devport, util_pct)
            else:
                output += 'devport_{}={}'.format(devport, counter)
        return output

    def _dump_queue_stats(self, id, queue_stats, filter, devports):
        output = ''
        for devport, queues in queue_stats.items():
            devport = int(devport)
            if devports and devport not in devports:
                continue
            for queue_id, counter in queues.items():
                if id == ifcs_ctypes.IFCS_WATSON_STAT_QUEUE_CONGESTION_RATIO:
                    n = (counter >> 8) & 0xff
                    d = counter & 0xff
                    if d == 0:
                        continue
                    counter = (n / d) * 100
                if filter == 'nz' and not counter:
                    continue
                if output:
                    output += ', '
                if id == 1:
                    output += 'devport_{}_queue_{}={:.2f}'.format(devport, queue_id, counter)
                else:
                    output += 'devport_{}_queue_{}={}'.format(devport, queue_id, counter)
        return output

    def _dump_partition_stats(self, id, partition_stats, filter):
        partition_cnt = 0
        output = ''
        for ib, partitions in partition_stats.items():
            for partition, counter in partitions.items():
                if filter == 'nz' and counter == 0:
                    continue
                if partition_cnt:
                    output += ', '
                output += 'ib_{}_partition_{}={}'.format(ib, partition, counter)
                partition_cnt += 1
        return output

    def _dump_file(self, filename, out_file, filter = None, devports = None):
        log('Dumping file {} to {}'.format(filename, out_file.name))
        with open(filename, 'rt') as file:
            data = file.read()
            watson = json.loads(data)
            msgs = watson['messages']
            for msg in msgs:
                id = msg['id']
                ts = msg['ts']
                secs = ts >> 32
                nsecs = ts & 0xffff_ffff
                dt = datetime.fromtimestamp(secs, tz=timezone.utc)
                dt += timedelta(microseconds=nsecs / 1000)
                mod = msg['mod']
                stats = msg.get('stats')
                event = msg.get('event')
                output = None
                if stats:
                    if mod == 'port':
                        output = self._dump_devport_stats(id, stats, filter, devports)
                    elif mod == 'queue':
                        output = self._dump_queue_stats(id, stats, filter, devports)
                    elif mod == 'partition':
                        output = self._dump_partition_stats(id, stats, filter)
                if output:
                    out_file.write('{}-{}: id={} ts={} {}\n'.format(mod, 'stats', id, dt, output))

    def _get_devports(self, devports):
        if devports:
            if devports == 'all':
                devports = None
            elif re.match(r'^\d+-\d+$', devports):
                start, end = compat_listmap(int, devports.split('-'))
                devports = list(range(start, end + 1))
            else:
                devports = json.loads(devports)
                if isinstance(devports, int):
                    devports = [devports]
        return devports

    def _dump(self, input, output, filter, devports):
        devports = self._get_devports(devports)
        with open(output, 'wt') as out_file:
            log('Writing to file: {}'.format(output))
            self._dump_file(input, out_file, filter, devports)
        return ifcs_ctypes.IFCS_SUCCESS

    def _time_set(self, time_value):
        if time_value == 'current':
            dt = datetime.now(timezone.utc)
        else:
            DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
            try:
                dt = datetime.strptime(time_value, DATETIME_FORMAT)
            except ValueError:
                log_err('Invalid time value: {}. Expected format: {}'.format(time_value, DATETIME_FORMAT))
                return ifcs_ctypes.IFCS_INVAL
        ts = int(dt.timestamp())
        pci.write_fields('cpu_ptp_globaltimer_sec_31_0', st_f=(ts & 0xffffffff))
        pci.write_fields('cpu_ptp_globaltimer_sec_47_32', st_f=(ts >> 32))
        dt = datetime.fromtimestamp(ts, tz=timezone.utc)
        log('Global time is set to {}'.format(dt))

    def _time_get(self):
        flds = pci.read_fields('cpu_ptp_devicetimer_47_32')
        flds = pci.read_fields('cpu_ptp_globaltimer_sec_31_0')
        sec = flds['st_f']
        flds = pci.read_fields('cpu_ptp_globaltimer_ns_31_0')
        ns = flds['st_f']
        dt = datetime.fromtimestamp(sec, tz=timezone.utc)
        dt += timedelta(microseconds=ns / 1000)
        log('Current global time: {}'.format(dt))

    def help(self, arg_list):
        Watson._usage(self.parser)

    @staticmethod
    def _usage(parser):
        if parser._subparsers:
            for parser in parser._subparsers._actions[-1].choices.values():
                Watson._usage(parser)
        else:
            parser.print_usage()
