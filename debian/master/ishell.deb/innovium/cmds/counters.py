
#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import shlex
import argparse
import itertools
import time
import json
import sys
from utils.compat_util import *
from verbosity import *
from cmdmgr import Command
from ctypes import *
from collections import OrderedDict
from ifcs_cmds.all import *
from print_table import PrintTable
 
ifcs_ctypes = sys.modules['ifcs_ctypes']

# Class implements Ifcs related commands
class Counters(Command):
    def __init__(self, cli):
        self.sub_cmds = {
            'enable': self.enable,
            'disable': self.disable,
            'show': self.show,
            'clear': self.clear,
            'help': self.help,
            '?': self.help
        }
        self.counter_display_method = {
            'sysport': self.display_sysport_counters,
            'devport': self.display_devport_counters,
            'l2vni': self.display_l2vni_counters,
            'intf': self.display_intf_counters,
            'cpu_queue': self.display_cpu_queue_counters,

 
        }
        self.counter_clear_method = {
            'sysport': self.clear_sysport_counters,
            'devport': self.clear_devport_counters,
            'l2vni': self.clear_l2vni_counters,
            'intf': self.clear_intf_counters,
            'cpu_queue': self.clear_cpu_queue_counters,
            'hardware': self.clear_hardware_counters,
 
        }
        self.supported_operands = ['sysport','devport','l2vni','intf', 'cpu_queue', 'hardware', 'pipeline']
        self.supported_hw_operands = ['port','ib','global','partition','queue']
        self.cli = cli
        self.arg_list = []
        super(Counters, self).__init__()
        self.ifcs_names = ['port', 'l2vni']
        self.help_str = "ifcs:        IFCS object cli commands\n"
        buflen = 64
        namebuf = create_string_buffer(buflen)

    def __del__(self):
        return

    def run_cmd(self, args):
        log_dbg(1, "In Counters run")
        self.arg_list = shlex.split(args)
        log_dbg(1, "context: " + str(self.arg_list))
        rc = self.sub_cmds[self.arg_list[1]](args)
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to run CLI command: {0}".format(convert_error_code_to_string(rc)))
            return rc

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)
        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]
        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def complete_show(self, text):
        if text.upper() == text:
            return [i.upper()
                    for i in self.ifcs_names if i.upper().startswith(text)]
        else:
            return [i.lower()
                    for i in self.ifcs_names if i.lower().startswith(text)]

    complete_port = complete_show
    complete_l2vni = complete_show

    def getDevport_bam_queues(self, devport):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            key_obj = ifcs_ctypes.ifcs_bam_queue_t()
            memmove(pointer(key_obj), arg, sizeof(key_obj))
            bam_queue_list.append(pointer(key_obj))

        bam_queue_list = []

        callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None), ifcs_ctypes.ifcs_node_id_t,
                                  POINTER(ifcs_ctypes.ifcs_bam_queue_t), c_uint32,
                                  POINTER(ifcs_ctypes.ifcs_attr_t), POINTER(None))
        callback = callback_type(myCallback)

        bam_queue_entry = ifcs_ctypes.ifcs_bam_queue_t()
        rc = ifcs_ctypes.ifcs_bam_queue_t_init(pointer(bam_queue_entry))
        ifcs_ctypes.ifcs_bam_queue_t_devport_set(pointer(bam_queue_entry), devport)
        try:
            rc = ifcs_ctypes.ifcs_bam_queue_get_all(self.cli.node_id, pointer(bam_queue_entry), 0, None, compat_funcPointer(callback, ifcs_ctypes.ifcs_bam_queue_user_cb_t), None,
                                        None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to get Devport {0}, all bam_queue rc: {1}".format(
                    str(port), convert_error_code_to_string(rc)))
        except Exception as e:
            log_err("Failed to get Devport's bam_queue : {0}".format(e))
            raise e
        return bam_queue_list

    def getDevport_queues(self, devport):
        def myCallback(node_id, arg, attr_count, attr_list, user_data):
            key_obj = ifcs_ctypes.ifcs_queue_t()
            memmove(pointer(key_obj), arg, sizeof(key_obj))
            queue_list.append(pointer(key_obj))

        queue_list = []

        callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None), ifcs_ctypes.ifcs_node_id_t,
                                  POINTER(ifcs_ctypes.ifcs_queue_t), c_uint32,
                                  POINTER(ifcs_ctypes.ifcs_attr_t), POINTER(None))
        callback = callback_type(myCallback)

        queue_entry = ifcs_ctypes.ifcs_queue_t()
        rc = ifcs_ctypes.ifcs_queue_t_init(pointer(queue_entry))
        ifcs_ctypes.ifcs_queue_t_devport_set(pointer(queue_entry), devport)
        try:
            rc = ifcs_ctypes.ifcs_queue_get_all(self.cli.node_id, pointer(queue_entry), 0, None, compat_funcPointer(callback, ifcs_ctypes.ifcs_queue_user_cb_t), None,
                                    None)
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log_err("Failed to get Devport {0}, all queue rc: {1}".format(
                    str(port), convert_error_code_to_string(rc)))
        except Exception as e:
            log_err("Failed to get Devport's queue : {0}".format(e))
            raise e
        return queue_list


    def getCountersType(self, args):
        log_dbg(1, "In getCountersType with args: " + args)

        counter_type = args.split()[3]

        # This if condition needs to be expanded for other counter types
        if counter_type == 'sysport':
            return 'sysport'
        elif counter_type == 'devport':
            return 'devport'
        elif counter_type == 'l2vni':
            return 'l2vni'
        elif counter_type == 'intf':
            return 'intf'
        elif counter_type == 'cpu_queue':
            return 'cpu_queue'
        elif counter_type == 'hardware':
            return 'hardware'
        elif counter_type == 'pipeline':
            return 'pipeline'
        else:
            return 'unsupported'

    def getIfcsType(self, ifcs_obj_name):
        '''Get IFCS Type Object'''
        log_dbg(1, "In getIfcsType ifcs_obj_name " + ifcs_obj_name)

        if ifcs_obj_name == 'sysport':
            return Sysport(self.cli)
        if ifcs_obj_name == 'devport':
            return Devport(self.cli)
        if ifcs_obj_name == 'l2vni':
            return L2vni(self.cli)
        if ifcs_obj_name == 'intf':
            return Intf(self.cli)
        if ifcs_obj_name == 'hardware':
            return Hardware(self.cli)
        if ifcs_obj_name == 'Pipeline':
            return Pipeline(self.cli)

        return None

    # ------------
    # disable command
    # ------------
    def disable(self, args):
        log_dbg(1, "Disable the stats polling thread " + args)

        allobjs = IfcsAll(self.cli)
        node = allobjs.get_ifcs_obj_from_name('node')
        node.setStatsPollInterval(0)

        log("Disabled statistics polling")
        return

    # ------------
    # enable command
    # ------------
    def enable(self, args):
        log_dbg(1, "Enable the stats polling thread " + args)

        allobjs = IfcsAll(self.cli)
        node = allobjs.get_ifcs_obj_from_name('node')
        node.setStatsPollInterval(1000)

        log("Enabled statistics polling")
        return

    # ------------
    # show command
    # ------------
    def show(self, args, filter_option):
        log_dbg(1, "In counters show with args: " + args)

        self.filter_option = filter_option

        try:
            counter_type = self.getCountersType(args)
        except IndexError:
            log_err("Counter type not specified")

        try:
            rc = self.counter_display_method[counter_type](args)
        except BaseException:
            log_err("Failed to get counters")

        return rc

    # ------------
    # clear command
    # ------------
    def clear(self, args):
        log_dbg(1, "In counters clear with args: " + args)

        try:
            counter_type = self.getCountersType(args)
        except IndexError:
            log_err("Counter type not specified")

        try:
            rc = self.counter_clear_method[counter_type]()
        except BaseException:
            log_err("Failed to clear counters")

        return rc

    # --------------------------------------------
    #   Rate collection
    # --------------------------------------------
    # -------------------------------------------
    # hardware counter clear methods
    # -------------------------------------------
    def clear_hardware_counters(self):
        log_dbg(1, "In display hardware counters show ")

    # -------------------------------------------
    # sysport counter clear methods
    # -------------------------------------------
    def clear_sysport_counters(self):
        log_dbg(1, "In display sysport counters show ")

        allobjs = IfcsAll(self.cli)
        sysport = allobjs.get_ifcs_obj_from_name('sysport')
        if sysport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_sysports = sysport.bulk_get_all_sysport_keys()
        except BaseException:
            log_err("Error retrieving sysports")

        # iterate over all devports
        for port in all_sysports:
            # clear the sysport stats
            sysport.stats_clear(port)

    # -------------------------------------------
    # l2vni counter clear methods
    # -------------------------------------------
    def clear_l2vni_counters(self):
        log_dbg(1, "In display l2vni counters show ")

        allobjs = IfcsAll(self.cli)
        l2vni = allobjs.get_ifcs_obj_from_name('l2vni')
        if l2vni is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_l2vni = l2vni.bulk_get_all_l2vni_keys()
        except BaseException:
            log_err("Error retrieving l2vni")

        # iterate over all l2vni
        for iter_l2vni in all_l2vni:
            # clear the l2vni stats
            l2vni.stats_clear(iter_l2vni)

    # -------------------------------------------
    # intf counter clear methods
    # -------------------------------------------
    def clear_intf_counters(self):
        log_dbg(1, "In display intf counters show ")

        allobjs = IfcsAll(self.cli)
        intf = allobjs.get_ifcs_obj_from_name('intf')
        if intf is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_intf = intf.bulk_get_all_intf_keys()
        except BaseException:
            log_err("Error retrieving intf")

        # iterate over all intf
        for iter_intf in all_intf:
            # clear the intf stats
            intf.stats_clear(iter_intf)

    # -------------------------------------------
    # counter clear methods
    # -------------------------------------------
    def clear_devport_counters(self):
        log_dbg(1, "In devport counters clear ")

        allobjs = IfcsAll(self.cli)
        devport = allobjs.get_ifcs_obj_from_name('devport')
        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_devports = devport.bulk_get_all_devport_keys()
        except BaseException:
            log_err("Error retrieving devports")

        # iterate over all devports
        for port in all_devports:
            devport.stats_clear(port)

    # -------------------------------------------
    # cpu queue counter clear methods
    # -------------------------------------------
    def clear_cpu_queue_counters(self):
        log_dbg(1, "In cpu queue counters clear ")

        allobjs = IfcsAll(self.cli)
        cpu_queue = allobjs.get_ifcs_obj_from_name('cpu_queue')
        if cpu_queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return

        try:
            rc, all_cpu_queues = cpu_queue.bulk_get_all_cpu_queue_keys()
        except BaseException:
            log_err("Error retrieving cpu queues")

        # iterate over all cpu queues
        for queue in all_cpu_queues:
            cpu_queue.stats_clear(queue)

    # -------------------------------------------
    # sysport counter display methods
    # -------------------------------------------
    def display_sysport_counters_all(self, args):
        log_dbg(1, "In sysport counters clear ")

        allobjs = IfcsAll(self.cli)
        sysport = allobjs.get_ifcs_obj_from_name('sysport')

        if sysport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_sysports = sysport.bulk_get_all_sysport_keys()
        except BaseException:
            log_err("Error retrieving All Sysports")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'Sysport (handle)',
            'Rx Bytes',
            'Rx Pkts',
            'Rx Errors',
            'Rx Drops',
            'Tx Bytes',
            'Tx Pkts',
            'Tx Drops',
        ]
        table.add_row(field_names)

        all_sysports = sorted(all_sysports)

        in_drop_list = [ ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_AFT_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_HDR_ERR,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_LKUP_MISS,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_SRC_MISS_MOVE,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_HDR_ERR,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_LKUP_MISS,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_NOT_ENABLED,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_TTL_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_DLP_DROP,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_FWD_OBJ_ERR,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_HW_ERR,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_L2_INTF_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_PROG_ERR,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_SPANNING_TREE_DROP,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_VNI_MEMBERSHIP_DROP,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_L3MTU_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_L2L3_HDR_ERR,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_TTL_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_VNID_LKUP_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_USER_DROP,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_ECC_DROP,
                       ]
        out_drop_list = [ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_BRTTL_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_HW_ERR_1,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_INTF_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_L2MTU_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_VNI_STI_CHECK_FAIL,
                         ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_ECC_DROP,
                        ]
        # iterate over all sysports
        for port in all_sysports:
            # get the sysport stats
            stats_list = sysport.stats_get(port)

            input_bytes = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_RX] \
                          + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_RX] \
                          + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_BYTES_RX]
            input_pkts = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_RX] \
                         + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_RX] \
                         + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_PKTS_RX]
            input_errors = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_HEADER_ERRS_PKTS_RX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_ADDR_ERRS_PKTS_RX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_HEADER_ERRS_PKTS_RX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_ADDR_ERRS_PKTS_RX]
            output_bytes = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_TX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_TX] \
                           + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_BYTES_TX]
            output_pkts = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_TX] \
                          + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_TX] \
                          + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_PKTS_TX]

            in_pkt_drops = 0
            out_pkt_drops = 0
            for ctr in in_drop_list:
                in_pkt_drops += stats_list[ctr]

            for ctr in out_drop_list:
                out_pkt_drops += stats_list[ctr]

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if input_bytes or input_pkts or input_errors or output_bytes or output_pkts or \
                   in_pkt_drops or out_pkt_drops:
                    table.add_row([sysport.handle_to_str(port), str(input_bytes), str(
                        input_pkts), str(input_errors), str(in_pkt_drops),
                        str(output_bytes), str(output_pkts), str(out_pkt_drops)])
            else:
                table.add_row([sysport.handle_to_str(port),str(input_bytes), str(
                    input_pkts), str(input_errors), str(in_pkt_drops),
                    str(output_bytes), str(output_pkts), str(out_pkt_drops)])

        table.print_table(brief=True)

    def display_sysport_counters(self, args):
        log_dbg(1, "In sysport counters clear ")

        arg_list = args.split()
        filter_drop = False

        if (len(arg_list) > 5):
            log_err("Invalid Parameters. Too many args")
            return ifcs_ctypes.IFCS_INVAL
        elif (len(arg_list) > 4) and (arg_list[-1] != 'drop'):
            log_err("Invalid Parameters. Supported option is Drop")
            return ifcs_ctypes.IFCS_INVAL
        elif (len(arg_list) == 5) and (arg_list[-1] == 'drop'):
            filter_drop = True


        allobjs = IfcsAll(self.cli)
        sysport = allobjs.get_ifcs_obj_from_name('sysport')

        if sysport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_sysports = sysport.bulk_get_all_sysport_keys()
        except BaseException:
            log_err("Error retrieving All Sysports")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()

        if (filter_drop == True):
            field_names = [
                'Sysport (handle)',
                'Rx Drops',
                'Tx Drops',
            ]
        else:
            field_names = [
                'Sysport (handle)',
                'Rx Bytes',
                'Rx Pkts',
                'Rx Errors',
                'Tx Bytes',
                'Tx Pkts',
            ]

        table.add_row(field_names)

        all_sysports = sorted(all_sysports)

        if (filter_drop == True):
            in_drop_list = [ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_AFT_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_HDR_ERR,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_LKUP_MISS,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L2_SRC_MISS_MOVE,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_HDR_ERR,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_LKUP_MISS,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_NOT_ENABLED,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_FWD_L3_TTL_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_DLP_DROP,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_FWD_OBJ_ERR,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_HW_ERR,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_L2_INTF_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_PROG_ERR,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_SPANNING_TREE_DROP,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_VNI_MEMBERSHIP_DROP,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_L3MTU_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_L2L3_HDR_ERR,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_TTL_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_TTERM_VNID_LKUP_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_USER_DROP,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_ING_ECC_DROP,
                           ]
            out_drop_list = [ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_BRTTL_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_HW_ERR_1,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_INTF_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_L2MTU_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_VNI_STI_CHECK_FAIL,
                             ifcs_ctypes.IFCS_SYSPORT_STATS_ID_DROP_EGR_ECC_DROP,
                            ]
        # iterate over all sysports
        for port in all_sysports:
            # get the sysport stats
            stats_list = sysport.stats_get(port)

            if (filter_drop == True):
                in_pkt_drops = 0
                out_pkt_drops = 0
                for ctr in in_drop_list:
                    in_pkt_drops += stats_list[ctr]

                for ctr in out_drop_list:
                    out_pkt_drops += stats_list[ctr]
                if len(self.filter_option.keys()) and 'nz' in self.filter_option['filter']:
                    if in_pkt_drops or out_pkt_drops:
                        table.add_row([sysport.handle_to_str(port), str(in_pkt_drops),
                                       str(out_pkt_drops)])
                else:
                    table.add_row([sysport.handle_to_str(port), str(in_pkt_drops),
                                   str(out_pkt_drops)])

            else:
                input_bytes = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_RX] \
                              + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_RX] \
                              + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_BYTES_RX]
                input_pkts = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_RX] \
                             + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_RX] \
                             + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_PKTS_RX]
                input_errors = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_HEADER_ERRS_PKTS_RX] \
                               + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_ADDR_ERRS_PKTS_RX] \
                               + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_HEADER_ERRS_PKTS_RX] \
                               + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_ADDR_ERRS_PKTS_RX]
                output_bytes = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_BYTES_TX] \
                               + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_BYTES_TX] \
                               + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_BYTES_TX]
                output_pkts = stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV4_PKTS_TX] \
                              + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_IPV6_PKTS_TX] \
                              + stats_list[ifcs_ctypes.IFCS_SYSPORT_STATS_ID_MPLS_PKTS_TX]

                if len(self.filter_option.keys()) and 'nz' in self.filter_option['filter']:
                    if input_bytes or input_pkts or input_errors or output_bytes or output_pkts:
                        table.add_row([sysport.handle_to_str(port), str(input_bytes), \
                            str(input_pkts), str(input_errors),
                            str(output_bytes), str(output_pkts)])
                else:
                    table.add_row([sysport.handle_to_str(port), str(input_bytes), \
                        str(input_pkts), str(input_errors),
                        str(output_bytes), str(output_pkts)])

        table.print_table(brief=True)

    # -------------------------------------------
    # l2vni counter display methods
    # -------------------------------------------
    def display_l2vni_counters(self, args):
        log_dbg(1, "In display l2vni counters show ")

        allobjs = IfcsAll(self.cli)
        l2vni = allobjs.get_ifcs_obj_from_name('l2vni')

        if l2vni is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_l2vni = l2vni.bulk_get_all_l2vni_keys()
        except BaseException:
            log_err("Error retrieving l2vni")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'L2vni',
            'Rx Bytes',
            'Rx Pkts',
            'Tx Bytes',
            'Tx Pkts',
        ]
        table.add_row(field_names)

        all_l2vni = sorted(all_l2vni)

        # iterate over all l2vnis
        for itr_l2vni in all_l2vni:
            # get the l2vni stats
            stats_list = l2vni.stats_get(itr_l2vni)

            input_bytes = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_INGRESS_BYTES]
            input_pkts = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_INGRESS_PKTS]
            output_bytes = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_EGRESS_BYTES]
            output_pkts = stats_list[ifcs_ctypes.IFCS_L2VNI_STATS_ID_EXTENDED_STATS_EGRESS_PKTS]


            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if input_bytes or input_pkts or output_bytes or output_pkts:
                    table.add_row([l2vni.handle_to_str(itr_l2vni), str(input_bytes), str(
                        input_pkts), str(output_bytes), str(output_pkts)])
            else:
                table.add_row([l2vni.handle_to_str(itr_l2vni), str(input_bytes), str(
                    input_pkts), str(output_bytes), str(output_pkts)])

        table.print_table(brief=True)

    # -------------------------------------------
    # intf counter display methods
    # -------------------------------------------
    def display_intf_counters(self, args):
        log_dbg(1, "In display int fcounters show ")

        allobjs = IfcsAll(self.cli)
        intf = allobjs.get_ifcs_obj_from_name('intf')

        if intf is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_intf = intf.bulk_get_all_intf_keys()
        except BaseException:
            log_err("Error retrieving intf")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'Intf',
            'Rx Bytes',
            'Rx Pkts',
        ]
        table.add_row(field_names)

        all_intf = sorted(all_intf)

        # iterate over all intf
        for itr_intf in all_intf:
            # get the intf stats
            stats_list = intf.stats_get(itr_intf)

            input_pkts = stats_list[ifcs_ctypes.IFCS_INTF_STATS_ID_L3INTF_INGRESS_UCAST_PKTS]
            input_bytes = stats_list[ifcs_ctypes.IFCS_INTF_STATS_ID_L3INTF_INGRESS_UCAST_BYTES]

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if input_bytes or input_pkts:
                    table.add_row([intf.handle_to_str(itr_intf), str(input_bytes), str(
                        input_pkts)])
            else:
                table.add_row([intf.handle_to_str(itr_intf), str(input_bytes), str(
                    input_pkts)])

        table.print_table(brief=True)

    # -------------------------------------------
    # devport counter display methods
    # -------------------------------------------
    def display_devport_counters_all(self, args):
        log_dbg(1, "In display devport counters show ")

        allobjs = IfcsAll(self.cli)
        devport = allobjs.get_ifcs_obj_from_name('devport')
        bam_queue = allobjs.get_ifcs_obj_from_name('bam_queue')
        queue = allobjs.get_ifcs_obj_from_name('queue')


        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_devports = devport.bulk_get_all_devport_keys()
        except BaseException:
            log_err("Error retrieving devports")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()

        #field_names = ["Devport" , "Rx Frames", "Rx Bytes", "Tx Frames", "Tx Bytes"]
        #table.add_row(field_names)

        field_names = [
            'Devport (id)',
            'Rx Frames All',
            'Rx Frames Ok',
            'Rx Frames Err',
            'Rx Drops',
            'BAM Q Drops',
            'Rx Bytes All',
            'Rx Bytes Ok',
            'Tx Frames All',
            'Tx Frames Ok',
            'Tx Frames Err',
            'Tx Drops',
            'Q Drops',
            'Tx Bytes All',
            'Tx Bytes Ok',
        ]
        table.add_row(field_names)


        in_drop_list = [ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_DROP,
                        ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY,
                       ]
        out_drop_list = [ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_DROP,
                         ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY,
                         ifcs_ctypes.IFCS_DEVPORT_STATS_ID_AQM_GREEN_PACKET_DROP_COUNT,
                         ifcs_ctypes.IFCS_DEVPORT_STATS_ID_AQM_YELLOW_PACKET_DROP_COUNT,
                         ifcs_ctypes.IFCS_DEVPORT_STATS_ID_AQM_RED_PACKET_DROP_COUNT,
                        ]

        all_devports = sorted(all_devports)

        # iterate over all devports
        for port in all_devports:

            # get the sysport stats
            stats_list = devport.stats_get(port)

            rx_frames_all = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ALL]
            rx_frames_ok  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
            rx_frames_err = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]
            rx_bytes_all  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
            rx_bytes_ok   = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
            tx_frames_all = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ALL]
            tx_frames_ok  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
            tx_frames_err = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]
            tx_bytes_all  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
            tx_bytes_ok   = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]

            in_pkt_drops = 0
            out_pkt_drops = 0
            for ctr in in_drop_list:
                in_pkt_drops += stats_list[ctr]

            for ctr in out_drop_list:
                out_pkt_drops += stats_list[ctr]

            # FIXME: Check if there is a API way to figure this value out
            NUM_BAM_QS = 0
            NUM_QS = 8

            if port > 0:
                for qid in range(NUM_BAM_QS):
                    bam_q_key = bam_queue.initialize_key(port, qid)
                    try:
                        bam_q_stats = bam_queue.stats_get(bam_q_key)
                        bam_q_pkts_drop += bam_q_stats[ifcs_ctypes.IFCS_BAM_QUEUE_STATS_ID_PACKET_DROP_COUNT]
                    except:
                        pass

                for qid in range(NUM_QS):
                    q_key = queue.initialize_key(port, qid)
                    try:
                        q_stats = queue.stats_get(q_key)
                        q_pkts_drop += q_stats[ifcs_ctypes.IFCS_QUEUE_STATS_ID_PACKET_DROP_COUNT]
                    except:
                        pass

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if rx_frames_all or rx_frames_ok or rx_frames_err or in_pkt_drops or bam_q_pkts_drop or\
                   rx_bytes_all or rx_bytes_ok or \
                   tx_frames_all or tx_frames_ok or tx_frames_err or tx_bytes_all or q_pkts_drop or \
                   tx_bytes_ok or out_pkt_drops:
                    table.add_row([str(int(port)), str(rx_frames_all), str(rx_frames_ok), str(rx_frames_err), \
                        str(in_pkt_drops), str(bam_q_pkts_drop), str(rx_bytes_all), str(rx_bytes_ok), \
                        str(tx_frames_all), str(tx_frames_ok), str(tx_frames_err), str(out_pkt_drops), str(q_pkts_drop), \
                        str(tx_bytes_all), str(tx_bytes_ok)])
            else:
                table.add_row([str(int(port)), str(rx_frames_all), str(rx_frames_ok), str(rx_frames_err), \
                    str(in_pkt_drops), str(bam_q_pkts_drop), str(rx_bytes_all), str(rx_bytes_ok), \
                    str(tx_frames_all), str(tx_frames_ok), str(tx_frames_err), str(out_pkt_drops), str(q_pkts_drop), \
                    str(tx_bytes_all), str(tx_bytes_ok)])

        table.print_table(brief=True)

    def display_devport_counters(self, args):
        log_dbg(1, "In display devport counters show ")

        arg_list = args.split()
        filter_drop = False

        if (len(arg_list) > 5):
            log_err("Invalid Parameters. Too many args")
            return ifcs_ctypes.IFCS_INVAL
        elif (len(arg_list) > 4) and (arg_list[-1] != 'drop'):
            log_err("Invalid Parameters. Supported option is Drop")
            return ifcs_ctypes.IFCS_INVAL
        elif (len(arg_list) == 5) and (arg_list[-1] == 'drop'):
            filter_drop = True

        allobjs = IfcsAll(self.cli)
        devport = allobjs.get_ifcs_obj_from_name('devport')
        bam_queue = allobjs.get_ifcs_obj_from_name('bam_queue')
        queue = allobjs.get_ifcs_obj_from_name('queue')

        if devport is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_devports = devport.bulk_get_all_devport_keys()
        except BaseException:
            log_err("Error retrieving devports")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()

        #field_names = ["Devport" , "Rx Frames", "Rx Bytes", "Tx Frames", "Tx Bytes"]
        #table.add_row(field_names)

        if (filter_drop == True):
            field_names = [
                'Devport (id)',
                'Rx Errs/Drops',
                'BAM Q Drops',
                'Tx Errs/Drops',
                'Q Drops',
            ]
        else:
            field_names = [
                'Devport (id)',
                'Rx Frames All',
                'Rx Frames Ok',
                'Rx Frames Err',
                'Rx Bytes All',
                'Rx Bytes Ok',
                'Tx Frames All',
                'Tx Frames Ok',
                'Tx Frames Err',
                'Tx Bytes All',
                'Tx Bytes Ok',
            ]

        table.add_row(field_names)

        if (filter_drop == True):
            in_drop_list = [ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_DROP,
                            ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY,
                           ]
            out_drop_list = [ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_DROP,
                             ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY,
                             ifcs_ctypes.IFCS_DEVPORT_STATS_ID_AQM_GREEN_PACKET_DROP_COUNT,
                             ifcs_ctypes.IFCS_DEVPORT_STATS_ID_AQM_YELLOW_PACKET_DROP_COUNT,
                             ifcs_ctypes.IFCS_DEVPORT_STATS_ID_AQM_RED_PACKET_DROP_COUNT,
                            ]

        all_devports = sorted(all_devports)


        '''
        rc, all_bam_qs = bam_queue.bulk_get_all_bam_queue_keys()
        rc, all_qs = queue.bulk_get_all_queue_keys()
        for bam_q in all_bam_qs:
            bam_q.stats_get(bam_q)
            bam_q_pkts_drop += stats_list[ifcs_ctypes.IFCS_BAM_QUEUE_STATS_ID_PACKET_DROP_COUNT]

        for q in all_qs:
            q.stats_get(q)
            q_pkts_drop += stats_list[ifcs_ctypes.IFCS_QUEUE_STATS_ID_PACKET_DROP_COUNT]
        '''

        # iterate over all devports
        for port in all_devports:

            # get the sysport stats
            stats_list = devport.stats_get(port)

            if (filter_drop == True):
                in_pkt_drops = 0
                out_pkt_drops = 0
                for ctr in in_drop_list:
                    in_pkt_drops += stats_list[ctr]

                for ctr in out_drop_list:
                    out_pkt_drops += stats_list[ctr]

                bam_q_pkts_drop = 0
                q_pkts_drop = 0

                if port > 0:
                    port_bam_qs = self.getDevport_bam_queues(port)
                    port_qs = self.getDevport_queues(port)

                    for bam_q in port_bam_qs:
                        bam_q_key = bam_queue.initialize_key(port, bam_q.contents.queue_id)
                        bam_q_stats_list = bam_queue.stats_get(bam_q_key)
                        bam_q_pkts_drop += bam_q_stats_list[ifcs_ctypes.IFCS_BAM_QUEUE_STATS_ID_PACKET_DROP_COUNT]

                    for q in port_qs:
                        q_key = queue.initialize_key(port, q.contents.queue_id)
                        q_stats_list = queue.stats_get(q_key)
                        q_pkts_drop += q_stats_list[ifcs_ctypes.IFCS_QUEUE_STATS_ID_PACKET_DROP_COUNT]

                if len(self.filter_option.keys()) and 'nz' in self.filter_option['filter']:
                    if in_pkt_drops or out_pkt_drops or bam_q_pkts_drop or q_pkts_drop:
                        table.add_row([str(int(port)), str(in_pkt_drops), str(bam_q_pkts_drop),
                                       str(out_pkt_drops), str(q_pkts_drop)])
                else:
                    table.add_row([str(int(port)), str(in_pkt_drops), str(bam_q_pkts_drop),
                                   str(out_pkt_drops), str(q_pkts_drop)])

            else:
                rx_frames_all = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ALL]
                rx_frames_ok  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_OK]
                rx_frames_err = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_FRAMES_ERR_ANY]
                rx_bytes_all  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_ALL]
                rx_bytes_ok   = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_RX_BYTES_OK]
                tx_frames_all = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ALL]
                tx_frames_ok  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_OK]
                tx_frames_err = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_FRAMES_ERR_ANY]
                tx_bytes_all  = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_ALL]
                tx_bytes_ok   = stats_list[ifcs_ctypes.IFCS_DEVPORT_STATS_ID_TX_BYTES_OK]

                if len(self.filter_option.keys()) and 'nz' in self.filter_option['filter']:
                    if rx_frames_all or rx_frames_ok or rx_frames_err or rx_bytes_all or rx_bytes_ok or \
                       tx_frames_all or tx_frames_ok or tx_frames_err or tx_bytes_all or tx_bytes_ok:
                        table.add_row([str(int(port)), str(rx_frames_all), str(rx_frames_ok), str(rx_frames_err), \
                                       str(rx_bytes_all), str(rx_bytes_ok), \
                                       str(tx_frames_all), str(tx_frames_ok), str(tx_frames_err), \
                                       str(tx_bytes_all), str(tx_bytes_ok)])
                else:
                    table.add_row([str(int(port)), str(rx_frames_all), str(rx_frames_ok), str(rx_frames_err), \
                                   str(rx_bytes_all), str(rx_bytes_ok), \
                                   str(tx_frames_all), str(tx_frames_ok), str(tx_frames_err), \
                                   str(tx_bytes_all), str(tx_bytes_ok)])

        table.print_table(brief=True)

    # -------------------------------------------
    # cpu_queue counter display methods
    # -------------------------------------------
    def display_cpu_queue_counters(self, args):
        log_dbg(1, "In display cpu queue counters show ")

        allobjs = IfcsAll(self.cli)
        cpu_queue = allobjs.get_ifcs_obj_from_name('cpu_queue')

        if cpu_queue is None:
            log_err('Unknown IFCS Object: ' + ifcs_obj)
            return ifcs_ctypes.IFCS_UNSUPPORTED

        try:
            rc, all_cpu_queues = cpu_queue.bulk_get_all_cpu_queue_keys()
        except BaseException:
            log_err("Error retrieving cpu queues")
            return ifcs_ctypes.IFCS_SUCCESS

        table = PrintTable()
        field_names = [
            'CPU Q (id)',
            'Total In Use',
            'Total Use Watermark',
            'Packets Dropped',
            'Cells Dropped',
            'Tx Packets',
            'Tx Bytes',
        ]
        table.add_row(field_names)

        all_cpu_queues = sorted(all_cpu_queues)

        # iterate over all CPU queues
        for queue in all_cpu_queues:

            # get the sysport stats
            stats_list = cpu_queue.stats_get(queue)

            total_in_use = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_TOTAL_USE_COUNT]
            total_use_watermark  = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_TOTAL_USE_WATERMARK]
            packets_dropped   = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_PACKET_DROP_COUNT]
            cells_dropped = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_CELL_DROP_COUNT]
            tx_packets = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_PACKET_TX_COUNT]
            tx_bytes  = stats_list[ifcs_ctypes.IFCS_CPU_QUEUE_STATS_ID_BYTE_TX_COUNT]

            if len(self.filter_option.keys()
                   ) and 'nz' in self.filter_option['filter']:
                if tx_packets or tx_bytes or current_in_use or total_use_watermark or packets_dropped or cells_dropped:
                    table.add_row([str(int(queue)), str(total_in_use), str(total_use_watermark), str(packets_dropped),
                        str(cells_dropped), str(tx_packets), str(tx_bytes)])
            else:
                    table.add_row([str(int(queue)), str(total_in_use), str(total_use_watermark), str(packets_dropped),
                        str(cells_dropped), str(tx_packets), str(tx_bytes)])

        table.print_table(brief=True)

    # -------------------------------------------
    # hardware counter display methods
    # -------------------------------------------


 

    def help(self, args):
        table = PrintTable()

        table.add_row(['IFCS Counters Help', 'Description'])
        table.add_row(['ifcs show counters devport',
                       'Displays input & output packets and bytes for all devports'])
        table.add_row(['ifcs show counters l2vni',
                       'Displays input & output packets and bytes for all l2vnis'])
        table.add_row(['ifcs show counters intf',
                       'Displays input & output packets and bytes for all intfs'])
        table.add_row(['ifcs show counters sysport',
                       'Displays input & output packets and bytes for all sysports'])
        table.add_row(['ifcs clear counters devport',
                       'Clears input & output packets and bytes for all devports'])
        table.add_row(['ifcs clear counters l2vni',
                       'Clears input & output packets and bytes for all l2vnis'])
        table.add_row(['ifcs clear counters intf',
                       'Clears input & output packets and bytes for all intfs'])
        table.add_row(['ifcs clear counters sysport',
                       'Clears input & output packets and bytes for all sysports'])
        log("")
        table.set_justification('left')
        table.print_table()
        table.reset_table()
