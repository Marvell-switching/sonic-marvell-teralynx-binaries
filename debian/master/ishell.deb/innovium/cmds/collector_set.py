#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------

import shlex
import time
import random
import copy
import argparse

from cmdmgr import Command
from utils.compat_util import *
from verbosity import *
from ctypes import *
from testutil import pci
from collections import OrderedDict
from ifcs_cmds.devport import Devport as Devport
from print_table import PrintTable
from node import *
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']

class CollectorSet(Command):
    def __init__(self, cli):
        self.sub_cmds = {
                         'create'           : self.create,
                         'add_members'      : self.add_members,
                         'remove_members'   : self.remove_members,
                         'help'             : self.help,
                         '?'                : self.help
                        }
        self.cli = cli
        self.cli.node_id = 0
        self.arg_list = []




    def _create_(
            self,
            nodeId,
            collectorSetType=None,
            direction=None,
            userHandle=None,
            expRc=None,
            invalidAttrId=None,
            attrCount=None,
            ifcsCall=True):

        handle = ifcs_ctypes.ifcs_handle_t()
        if userHandle is not None:
            handle.value = userHandle
        else:
            handle.value = ifcs_ctypes.IFCS_NULL_HANDLE

        attrList = (ifcs_ctypes.ifcs_attr_t * 4)()
        for index in range(4):
            rc = ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attrList, ifcs_ctypes.ifcs_attr_t, index))
            assert rc == ifcs_ctypes.IFCS_SUCCESS
        index = 0

        if invalidAttrId is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            attrList[index].value.u32 = 0
            index += 1
        if collectorSetType is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_COLLECTOR_SET_TYPE
            attrList[index].value.u32 = collectorSetType
            index += 1
        if direction is not None:
            attrList[index].id = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_DIRECTION
            attrList[index].value.u32 = direction
            index += 1
        if attrCount is None:
            if index > ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT:
                attrCount = ifcs_ctypes.IFCS_COLLECTOR_SET_ATTR_MAX_COUNT
            else:
                attrCount = index
        if ifcsCall is True:
            rc = ifcs_ctypes.IFCS_STATUS_REASON(
                ifcs_ctypes.ifcs_collector_set_create(
                    nodeId,
                    pointer(handle),
                    attrCount,
                    attrList))
            if rc != ifcs_ctypes.IFCS_SUCCESS:
                log("CollectorSet creation failed rc: {0}".format(rc))
            else:
                log("CollectorSet handle= " + hex(handle.value))
            return rc

    def _add_members_(
            self,
            collector_set_handle,
            memberList,
            attrList=None,
            memberCount=None,
            attrCount=None,
            expRc=None,
            customLog=None):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            if memberList is not None:
                memberCount = len(memberList)
            else:
                memberCount = 0
        if attrCount is None:
            if attrList is not None:
                attrCount = len(attrList)
            else:
                attrCount = 0
        if not attrList:
            attrList = None
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_add(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t),
                attrCount,
                attrList))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("CollectorSet member add failed rc: {0}".format(rc))
        else:
            log("CollectorSet member add successful")
        return rc

    def _remove_members_(
            self,
            collector_set_handle,
            memberList,
            memberCount=None,
            expRc=None,
            customLog=None):

        memberhandleList = (ifcs_ctypes.ifcs_handle_t * len(memberList))()
        for index in compat_xrange(len(memberList)):
            memberhandleList[index] = memberList[index]
        if memberCount is None:
            memberCount = len(memberList)
        rc = ifcs_ctypes.IFCS_STATUS_REASON(
            ifcs_ctypes.ifcs_collector_set_member_remove(
                self.cli.node_id,
                collector_set_handle,
                memberCount,
                compat_pointer(memberhandleList, ifcs_ctypes.ifcs_handle_t)))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log("CollectorSet member remove failed rc: {0}".format(rc))
        else:
            log("CollectorSet member remove successful")
        return rc


    def run_cmd(self, args):
        log_dbg(1, "in Collector set run")
        self.arg_list = shlex.split(args)
        try:
            return self.sub_cmds[self.arg_list[2]](args)
        except (KeyError):
            log_dbg(1, "CollectorsetKeyError")
            self.help(args)
        except (ValueError):
            log_dbg(1, "CollectorsetValueError")
            self.help(args)
        except Exception as ex:
            self.cli.error()
            self.help(args)

        return

    def subcomplete(self, text, remline):
        cmd, remline, line = self.cli.parseline(remline)
        if cmd is None:
            return compat_listkeys(self.sub_cmds)

        elif cmd == text:
            return [j for j in self.sub_cmds.keys() if j.startswith(text)]

        else:
            try:
                return getattr(self, 'complete_' + cmd)(text)
            except AttributeError:
                return None

    def create(self, args):
        log_dbg(1, "in Collector_set create")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Collector set create', prog='collectorset', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-direction', action="store", help='Direction INGRESS | EGRESS', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Create parse_args failed')
            return 1

        # Get direction
        Dir = str(res.direction)
        if Dir == 'INGRESS':
            direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_INGRESS
        elif Dir == 'EGRESS':
            direction = ifcs_ctypes.IFCS_TRAFFIC_MONITOR_DIRECTION_EGRESS

        return self._create_(self.cli.node_id, collectorSetType=ifcs_ctypes.IFCS_COLLECTOR_TYPE_SFLOW, direction=direction)


    def add_members(self, args):
        log_dbg(1, "in Collector Set add_members")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Collector Set add_members', prog='collectset', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-collector_set_handle', action="store", help='Collector Set handle', required=True)
        requiredArgs.add_argument('-members', action="store", help='Comma separated handles', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Add_members parse_args failed')
            return 1
        collector_set_handle = int(res.collector_set_handle, 0)
        members = res.members.split(",")
        members = [int(i, 0) for i in members]
        return self._add_members_(collector_set_handle, members)

    def remove_members(self, args):
        log_dbg(1, "in Collector Set remove_members")
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        self.arg_list.pop(0)
        parser = argparse.ArgumentParser(description='Collector Set remove_members', prog='collectset', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        #mandatory arguments
        requiredArgs = parser.add_argument_group('Mandatory arguments')
        requiredArgs.add_argument('-collector_set_handle', action="store", help='Collector Set handle', required=True)
        requiredArgs.add_argument('-members', action="store", help='Comma separated handles', required=True)
        try:
            res = parser.parse_args(self.arg_list)
        except:
            log('Remove_members parse_args failed')
            return 1
        collector_set_handle = int(res.collector_set_handle, 0)
        members = res.members.split(",")
        members = [int(i, 0) for i in members]
        return self._remove_members_(collector_set_handle, members)

    def help(self, args):
        table = PrintTable()
        table.add_row(['Command', 'Description'])
        table.add_row(['create', 'Create Collector Set'])
        table.add_row(['add_members', 'Add members to Collector Set'])
        table.add_row(['remove_members', 'Remove members from Collector Set'])
        table.set_justification('left')
        table.print_table()
        table.reset_table()
        collector_set_help_string = """
Usage::

    Type "config collector_set <command>" followed by -h to see command's sub-options.
"""
        log(collector_set_help_string)
