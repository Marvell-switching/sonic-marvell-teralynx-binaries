#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_ctypes import *
from ifcs_objs.all import *
from verbosity import log

num_innovium_nodes = 0
nodeId = 0
nh_obj = None
numPorts= 8
ports = [0] * numPorts
sysports = [0] * numPorts


def mtypes(mlist) :
    match_types = ifcs_u32_list_t()
    match_types.count = len(mlist)
    match_types.arr = (c_uint32 * match_types.count)()
    for i in range(len(mlist)):
        match_types.arr[i] = mlist[i]
    return match_types

def atypes(alist) :
    action_types = ifcs_u32_list_t()
    action_types.count = len(alist)
    action_types.arr = (c_uint32 * action_types.count)()
    for i in range(len(alist)):
        action_types.arr[i] = alist[i]
    return action_types

def match(mlist):
    m = ifcs_u8_list_t()
    m.count = len(mlist)
    m.arr = (c_uint8 * len(mlist))()
    for i in range(len(mlist)):
        m.arr[i] = mlist[i]
    return m


def _get_sysport_from_devport(node_id, devport):
    '''
        Utility function that takes a devport
        and returns the handle to its corresponding
        sysport
    '''
    attr = ifcs_attr_t()
    count  = ctypes.c_uint32()

    attr.id = IFCS_DEVPORT_ATTR_SYSPORT
    attr_count = 1
    rc = ifcs_devport_attr_get(node_id, devport, attr_count, pointer(attr),
                               pointer(count))
    if rc != IFCS_SUCCESS:
        log("Failed to get sysport for devport %d" % devport)
        return

    return attr.value


def create_ing_acl(devport):
    #Create a Match Profile
    match_types = mtypes([IFCS_ACL_MATCH_TYPE_SOURCE_IPV4_ADDRESS, IFCS_ACL_MATCH_TYPE_DESTINATION_IPV4_ADDRESS,IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT])
    mp = AclMatchProfile(nodeId, match_types, IFCS_ACL_DIRECTION_INGRESS, IFCS_ACL_MATCH_MAX_WIDTH_160_BITS)

    #Create a Action Profile
    action_types = atypes([IFCS_ACL_ACTION_TYPE_DROP])
    ap = AclActionProfile(nodeId, action_types, IFCS_ACL_DIRECTION_INGRESS)

    #Create a ACL Table
    t1 = AclTable(nodeId, mp, ap, IFCS_ACL_DIRECTION_INGRESS, scope = IFCS_ACL_SCOPE_NODE, priority = 1, size = 128, prematch = IFCS_ACL_PREMATCH_IPV4)

    #Create condition 1
    sip = match([192,168,1,1])
    m1 = AclMatch(nodeId, mp, IFCS_ACL_MATCH_TYPE_SOURCE_IPV4_ADDRESS, sip)

    dip = match([192,168,2,1])
    m2 = AclMatch(nodeId, mp, IFCS_ACL_MATCH_TYPE_DESTINATION_IPV4_ADDRESS, dip)

    sysport1 = _get_sysport_from_devport(nodeId, devport)
    m3 = AclMatch(nodeId, mp, IFCS_ACL_MATCH_TYPE_INGRESS_SYSPORT, object=sysport1)

    action_type = IFCS_ACL_ACTION_TYPE_DROP
    value = ifcs_acl_action_value_t()
    value.drop = ifcs_acl_drop_action_t()
    rc = ifcs_acl_drop_action_t_init(pointer(value.drop))
    assert rc == IFCS_SUCCESS
    value.drop.red = 1
    value.drop.yellow = 1
    #value.drop.green = 0

    a1 = AclAction(nodeId, ap, action_type, value)#

    #Create ace
    ace1 = Ace(nodeId, 10, [m1, m2, m3], [a1])
    #Create acl1
    acl1 = Acl(nodeId)

    #add acl to table
    t1.addAcls([acl1])

    #add ace to acl
    acl1.addAces([ace1])

def create_egr_acl(devport):
    #Create a Match Profile
    match_types = mtypes([IFCS_ACL_MATCH_TYPE_SOURCE_IPV4_ADDRESS, IFCS_ACL_MATCH_TYPE_DESTINATION_IPV4_ADDRESS,IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT])
    mp = AclMatchProfile(nodeId, match_types, IFCS_ACL_DIRECTION_EGRESS, IFCS_ACL_MATCH_MAX_WIDTH_160_BITS)

    #Create a Action Profile
    action_types = atypes([IFCS_ACL_ACTION_TYPE_DROP])
    ap = AclActionProfile(nodeId, action_types, IFCS_ACL_DIRECTION_EGRESS)

    #Create a ACL Table
    t1 = AclTable(nodeId, mp, ap, IFCS_ACL_DIRECTION_EGRESS, scope = IFCS_ACL_SCOPE_NODE, priority = 1, size = 128, prematch = IFCS_ACL_PREMATCH_IPV4)

    #Create condition 1
    sip = match([192,168,1,1])
    m1 = AclMatch(nodeId, mp, IFCS_ACL_MATCH_TYPE_SOURCE_IPV4_ADDRESS, sip)

    dip = match([192,168,2,1])
    m2 = AclMatch(nodeId, mp, IFCS_ACL_MATCH_TYPE_DESTINATION_IPV4_ADDRESS, dip)

    sysport1 = _get_sysport_from_devport(nodeId, devport)
    m3 = AclMatch(nodeId, mp, IFCS_ACL_MATCH_TYPE_EGRESS_SYSPORT, object=sysport1)

    action_type = IFCS_ACL_ACTION_TYPE_DROP
    value = ifcs_acl_action_value_t()
    value.drop = ifcs_acl_drop_action_t()
    rc = ifcs_acl_drop_action_t_init(pointer(value.drop))
    assert rc == IFCS_SUCCESS
    value.drop.red = 1
    value.drop.yellow = 1
    #value.drop.green = 0

    a1 = AclAction(nodeId, ap, action_type, value)#

    #Create ace
    ace1 = Ace(nodeId, 10, [m1, m2, m3], [a1])
    #Create acl1
    acl1 = Acl(nodeId)

    #add acl to table
    t1.addAcls([acl1])

    #add ace to acl
    acl1.addAces([ace1])

    # now clean it up.
    #acl1.removeAces([ace1])
    #print "Table Usage %d" % (t1.getUsage())
    #t1.removeAcls([acl1])
    #ace1.delete()
    #acl1.delete()
    #a1.delete()
    #m2.delete()
    #m1.delete()
    #t1.delete()
    #ap.delete()
    #mp.delete()

def test_acl_basic():
    create_ing_acl(2)
    create_egr_acl(16)

def main():
    test_acl_basic()

if __name__ == "__main__":
    main()
