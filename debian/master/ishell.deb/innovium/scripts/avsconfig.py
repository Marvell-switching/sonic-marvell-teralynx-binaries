#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
import sys
import argparse
from verbosity import log, log_dbg, log_err
from utils.compat_util import *
import ctypes
ifcs_ctypes = sys.modules['ifcs_ctypes']


class AvsConfig:

    def __init__(self, args):
        self._node_id = 0
        self._avs_voltage = 0

        try:
            self._parse_args(args)
            if self._avs_voltage != 0:
                self._set_avs_core_voltage()
            self._display_avs_core_voltage()

        except:
            log_dbg(
                1, 'Error executing avs commands with args{}:\n{}'.
                format(args, sys.exc_info()))

    def _status_to_string(self, rc):
        return compat_bytesToStr(ifcs_ctypes.ifcs_status_to_string(rc))

    def _parse_args(self, args):
        args = args.strip()
        if not args:
            return  # No parsing needed.

        args = args.split()
        parser = argparse.ArgumentParser(
            prog='run avs',
            description='Program AVS core voltage',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
        parser.add_argument('-v',
                            '--volt',
                            type=int,
                            choices=[775, 780, 785, 790, 795, 800],
                            help='Voltage in mV')
        try:
            res = parser.parse_args(args)
            self._avs_voltage = res.volt
        except Exception as ex:
            raise ex

    def _set_avs_core_voltage(self):

        attr = ifcs_ctypes.ifcs_attr_t()
        assert ifcs_ctypes.ifcs_attr_t_init(
            pointer(attr)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(attr),
            ifcs_ctypes.IM_NODE_ATTR_AVS_CORE_VOLTAGE) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_value_u32_set(
            pointer(attr),
            self._avs_voltage) == ifcs_ctypes.IFCS_SUCCESS
        rc = ifcs_ctypes.im_node_attr_set(self._node_id, 1, pointer(attr))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            msg = 'Failed to set AVS core voltage rc: {0}'.format(
                self._status_to_string(rc))
            log_err(msg)
            raise Exception(msg)

    def _display_avs_core_voltage(self):
        actual_count = ifcs_ctypes.ifcs_uint32_t(0)
        core_voltage = ifcs_ctypes.ifcs_uint32_t(0)
        attr = ifcs_ctypes.ifcs_attr_t()
        assert ifcs_ctypes.ifcs_attr_t_init(
            pointer(attr)) == ifcs_ctypes.IFCS_SUCCESS
        assert ifcs_ctypes.ifcs_attr_t_id_set(
            pointer(attr),
            ifcs_ctypes.IM_NODE_ATTR_AVS_CORE_VOLTAGE) == ifcs_ctypes.IFCS_SUCCESS

        rc = ifcs_ctypes.im_node_attr_get(self._node_id, 1, pointer(attr), pointer(actual_count))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            msg = 'IM API failed to get AVS core voltage rc: {0}'.format(
                self._status_to_string(rc))
            log_err(msg)
            raise Exception(msg)

        rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(pointer(attr), pointer(core_voltage))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            msg = 'Failed to get AVS core voltage rc: {0}'.format(
                self._status_to_string(rc))
            log_err(msg)
            raise Exception(msg)

        log("AVS core voltage: {}".format(core_voltage.value))


def main(args):
    x = AvsConfig(args)
