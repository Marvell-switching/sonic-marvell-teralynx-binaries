/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */
#ifndef __ISAI_IM_NMGR_H__
#define __ISAI_IM_NMGR_H__

/**
 * @file isai_im_nmgr.h
 * @brief Innovium Internal ISAI Node Manager header file
 */



#include "common/isai_im_modlockdef.h"
#include "ifcs_sai_shim_util.h"

#include "saitypes.h"
#include "ifcs_types.h"

typedef enum isai_ii_mod_state_e {
    ISAI_II_MOD_STATE_UNINIT = 0,
    ISAI_II_STATE_ENABLED    = 1
} isai_ii_mod_state_t;


#define ISAI_MODULE_VECTOR(mod)                                      \
    extern isai_ii_modulevec_t isai_ii_mod_ ## mod ## _module_vec;   \
    isai_ii_modulevec_t isai_ii_mod_ ## mod ## _module_vec =         \
    {                                                                \
        .name        = (char *) # mod,                               \
        .mod_prio    = (isai_ii_mod_prio_t)ISAI_LOCAL_MOD_LOCK_PRIO, \
        .lock_bitmap = (isai_ii_modlock_t)ISAI_MOD_LOCK_BITMAP,      \
        .lock_mask   = (isai_ii_modlock_t)ISAI_LOCAL_MOD_LOCK_MASK,  \
    }


typedef struct isai_modulevec {
    const char         *name;
    uint32_t           mod_info_size;
    isai_ii_mod_prio_t mod_prio;
    isai_ii_modlock_t  lock_bitmap;
    isai_ii_modlock_t  lock_mask;
} isai_ii_modulevec_t;

extern isai_ii_modulevec_t *isai_modulevec[];


/* Module init/config */
ifcs_status_t
isai_im_nmgr_nmgr_init(void);
ifcs_status_t
isai_im_nmgr_nmgr_deinit(void);

/* Node creation and init/deinit */
sai_status_t
isai_im_nmgr_create_node(ifcs_node_id_t node_id);

sai_status_t
isai_im_nmgr_node_init(ifcs_node_id_t       node_id,
                       ifcs_sai_boot_type_t boot_type);
sai_status_t
isai_im_nmgr_node_deinit(ifcs_node_id_t       node_id,
                         ifcs_shutdown_type_t shut_type);

/* Lock routines */
sai_status_t
isai_im_nmgr_mod_lock(sai_object_id_t    switch_id,
                      isai_ii_mod_prio_t mod_prio,
                      int tid);
void
isai_im_nmgr_mod_unlock(sai_object_id_t    switch_id,
                        isai_ii_mod_prio_t mod_prio,
                        int tid);
void
isai_im_nmgr_mod_lock_all(ifcs_node_id_t node_id);
void
isai_im_nmgr_mod_unlock_all(ifcs_node_id_t node_id);



/**
 * @brief Get the lock-count (of locks this thread is holding) of nmgr locks
 *
 * @param [in]     switch_id - Node Identifier
 * @param [out]    lockcount - output paramter returning the count
 * @return sai_status_t
 */
sai_status_t
isai_im_nmgr_get_lockcount(sai_object_id_t switch_id,
                           uint32_t        *lockcount);

/**
 * @brief Check if the caller thread is still holding any node-mgr locks
 *
 * @param [in]     switch_id - Node Identifier
 * @param [in]    lockcount - previous counts
 * @return ifcs_status_t
 */
sai_status_t
isai_im_nmgr_check_lockowner(sai_object_id_t switch_id,
                             uint32_t        *lockcount);

sai_status_t
isai_im_nmgr_node_set_state(ifcs_node_id_t      node_id,
                            isai_ii_mod_state_t state);


#endif /* __ISAI_IM_NMGR_H__ */
