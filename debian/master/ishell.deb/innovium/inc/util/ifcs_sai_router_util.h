/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_router_util.h
 * @brief ISAI Util Include file for ROUTER module
 */


#ifndef __IFCS_SAI_ROUTER_UTIL_H__
#define __IFCS_SAI_ROUTER_UTIL_H__

#include "util/ifcs_sai_router_util_dep.h"

/*
 * @brief Translates VR SAI object ID to L3VNI IFCS handle
 *
 * @param [out] ifcs_handle_p - Pointer to IFCS handle
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_stoi_xlate_oid(
    sai_object_id_t sai_object_id,
    ifcs_handle_t   *ifcs_handle_p);


/*
 * @brief Translates L3VNI IFCS handle to SAI object ID
 *
 * @param [in]  ifcs_handle - IFCS handle
 * @param [out] object_id_p - Pointer to SAI object ID
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_itos_xlate_oid(
    sai_object_id_t switch_oid,
    ifcs_handle_t   ifcs_handle,
    sai_object_id_t *object_id_p);


/**
 * @brief: Create virtual router
 *
 * @param [in] virtual_router_object_id_p    - Pointer to Router object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                    - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
extern sai_status_t
isai_im_virtual_router_create(sai_object_id_t       *virtual_router_object_id_p,
                              sai_object_id_t       switch_id,
                              uint32_t              attr_count,
                              const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove virtual router
 *
 * @param [in] virtual_router_object_id  - Router object id
 *
 * @return sai_status_t
 */
extern sai_status_t
isai_im_virtual_router_remove(
                  sai_object_id_t virtual_router_object_id);

/**
 * @brief: Update IFCS attributes of route to
 * configure TTL profile based on VR configuration
 *
 * @param [in] switch_id        - Switch Id
 * @param [in] vr_oid           - Virtual router object ID
 * @param [in] attr_count_p     - Pointer to IFCS attribute count
 * @param [in] attr_list_p      - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_virtual_router_rt_ttl_profile_update(
    sai_object_id_t       switch_id,
    sai_object_id_t       vr_oid,
    uint32_t              *attr_count_p,
    ifcs_attr_t           *attr_list_p);

/**
 * @brief Initializes router module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes router module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_router_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

#endif /* __IFCS_SAI_ROUTER_UTIL_H__ */
