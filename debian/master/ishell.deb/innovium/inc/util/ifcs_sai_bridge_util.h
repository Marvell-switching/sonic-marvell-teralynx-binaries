/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_bridge_util.h
 * @brief ISAI Util Include file for BRIDGE module
 */


#ifndef __IFCS_SAI_BRIDGE_UTIL_H__
#define __IFCS_SAI_BRIDGE_UTIL_H__

#include "util/ifcs_sai_bridge_util_dep.h"

sai_status_t
isai_im_bridge_find_bridge_port(sai_object_id_t         bridge_port_oid,
                                  sai_shim_bridge_port_db_entry_t *bpkey);

sai_status_t
isai_im_bridge_get_bridge_port_type(sai_object_id_t bridge_port_oid,
                               uint32_t        *bp_type);

sai_status_t
isai_im_bridge_get_bridge_port_nhg_handle(sai_object_id_t    bridge_port_oid,
                               ifcs_handle_t    *nhg_handle_p);
sai_status_t
isai_im_bridge_get_bridge_port_nhg_oid(sai_object_id_t    bridge_port_oid,
                               sai_object_id_t    *nhg_oid_p);
sai_status_t
isai_im_bridge_get_bridge_port_tunnel_id(sai_object_id_t    bridge_port_oid,
                               sai_object_id_t    *tunnel_id_p);

sai_status_t
isai_im_bridge_get_bridge_port_oid(sai_object_id_t bridge_oid,
                                   sai_object_id_t port_oid,
                                   sai_object_id_t *bridge_port_oid_p);
sai_status_t
isai_im_bridge_get_bridge_port_oid_from_port_lag_oid( sai_object_id_t port_oid,
                                   sai_object_id_t *bport_oid_p);

/**
 * @brief: Create Bridge
 *
 * @param [in] bridge_object_id_p            - Pointer to Bridge object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                     - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_create(sai_object_id_t       *bridge_object_id_p,
                      sai_object_id_t       switch_id,
                      uint32_t              attr_count,
                      const sai_attribute_t *attr_list_p);

/**
 * @brief: Create Bridge Port
 *
 * @param [in] bridge_port_object_id_p       - Pointer to Bridge Port object
 * @param [in] switch_id                     - Switch Id
 * @param [in] attr_count                     - Number of attributes
 * @param [in] attr_list_p                   - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_create(sai_object_id_t       *bridge_port_object_id_p,
                           sai_object_id_t       switch_id,
                           uint32_t              attr_count,
                           const sai_attribute_t *attr_list_p);

/**
 * @brief: Remove Bridge Port
 *
 * @param [in] bridge_port_object_id         - Bridge object
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_remove(sai_object_id_t bridge_port_object_id);

/**
 * @brief: Bridge Port get IFCS handle from Bridge Port DS
 *
 * @param [in] bp_oid         - Bridge Port object id
 * @param [out] ifcs_hdl_p    - Pointer to IFCS handle
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_ds_get_ifcs_hdl(sai_object_id_t     bp_oid,
                                    ifcs_handle_t       *ifcs_hdl_p);

/**
 * @brief: Bridge Port get OID for given IFCS handle from Bridge Port DS
 *
 * @param [in] node_id        - IFCS Node id
 * @param [in] ifcs_hdl       - IFCS sysport/intf handle
 * @param [out] bp_oid_p      - Pointer to bridge_port oid
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_bridge_port_get_oid_ifcs_hdl(ifcs_node_id_t node_id,
                                     ifcs_handle_t     ifcs_hdl,
                                     sai_object_id_t   *bp_oid_p);
sai_status_t
isai_im_bridge_init(sai_switch_init_info_t *sai_switch_init_info_p);
sai_status_t
isai_im_bridge_deinit(sai_switch_deinit_info_t *sai_switch_deinit_info_p);
sai_status_t
isai_im_bridge_port_get_isg_attached_bps(ifcs_node_id_t   node_id,
                                          sai_object_id_t isg_oid,
                                          sai_attribute_t *attr_p);
sai_status_t
isai_im_bridge_port_configure_ace(ifcs_node_id_t node_id,
                                  ifcs_handle_t  sysport,
                                  ifcs_handle_t  ing_intf_hdl);
sai_status_t
isai_im_bridge_port_unconfigure_ace(ifcs_node_id_t node_id,
                                    ifcs_handle_t  sysport,
                                    sai_object_id_t bp_oid);
sai_status_t
isai_im_bridge_port_get_oid_from_tunnel_ds(ifcs_node_id_t node_id,
                                     sai_object_id_t   *bp_oid_p);

sai_status_t
isai_im_bridge_release_es_peer_id(
              sai_object_id_t   node_id,
              uint64_t          es_peer_id);
sai_status_t
isai_im_bridge_allocate_es_peer_id(
                        ifcs_node_id_t  node_id,
                        sai_object_id_t bp_oid,
                        uint64_t        *es_peer_id);
sai_status_t
isai_im_bridge_port_ds_set_es_enable_ref_count(
                        ifcs_node_id_t  node_id,
                        sai_object_id_t bp_oid,
                        uint32_t        es_enable_ref_count);

sai_status_t
isai_im_bridge_port_ds_get_es_enable_ref_count(
                        ifcs_node_id_t  node_id,
                        sai_object_id_t bp_oid,
                        uint32_t        *es_enable_ref_count);
sai_status_t
isai_im_bridge_port_ds_get_df_tx_drop_status(
                    ifcs_node_id_t  node_id,
                     sai_object_id_t bp_oid,
                     bool *df_tx_drop_status);


#endif /* __IFCS_SAI_BRIDGE_UTIL_H__ */
