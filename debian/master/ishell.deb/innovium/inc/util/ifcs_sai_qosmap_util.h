/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_qosmap_util.h
 * @brief ISAI Util Include file for QOSMAP module
 */


#ifndef __IFCS_SAI_QOSMAP_UTIL_H__
#define __IFCS_SAI_QOSMAP_UTIL_H__

#include "util/ifcs_sai_qosmap_util_dep.h"



sai_status_t
isai_im_qosmap_pre_attach_process(ifcs_node_id_t node_id);

sai_status_t
isai_im_qosmap_qmg_init(ifcs_node_id_t         node_id,
                        sai_switch_init_info_t *sai_switch_init_info_p);

sai_status_t
isai_im_qosmap_qmg_deinit(ifcs_node_id_t           node_id,
                          sai_switch_deinit_info_t *switch_deinit_info_p);

sai_status_t
isai_im_qosmap_qmg_port_create(sai_object_id_t       port_oid,
                          const sai_attribute_t *attr_list_p,
                          uint32_t              qosmap_attr_arr[],
                          uint32_t              qosmap_attr_count);

sai_status_t
isai_im_qosmap_qmg_port_set(sai_object_id_t port_oid,
                           sai_attribute_t *attr_p);

sai_status_t
isai_im_qosmap_qmg_port_get(sai_object_id_t port_oid,
                            sai_attribute_t *attr_p);


extern sai_status_t
isai_im_qosmap_qmhdl_hash_insert_item(ifcs_node_id_t             node_id,
                                      ifcs_handle_t              qm_handle,
                                      isai_shim_qmhdl_db_entry_t *qmhdl_entry_p);

extern sai_status_t
isai_im_qosmap_qmhdl_hash_delete_item(ifcs_node_id_t             node_id,
                                      ifcs_handle_t              qm_handle);

extern sai_status_t
isai_im_qosmap_qmhdl_ref_count_inc(ifcs_node_id_t node_id,
                                   ifcs_handle_t  qmhdl);

extern sai_status_t
isai_im_qosmap_qmhdl_ref_count_dec(ifcs_node_id_t node_id,
                                   ifcs_handle_t  qmhdl);
/**
 * @brief: Retrieve QoS Map Attribute
 *
 * @param [in] qos_map_object_id            - QosMap object
 * @param [in] attr_count                   - Number of attributes
 * @param [in] attr_list_p                  - Pointer to List of attributes
 * @return sai_status_t
 *
 */
sai_status_t
isai_im_qosmap_attribute_get(sai_object_id_t qos_map_object_id,
                            uint32_t         attr_count,
                            sai_attribute_t  *attr_list_p);
/**
 * @brief Initializes qosmap module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_qosmap_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes qosmap module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_qosmap_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);
#endif /* __IFCS_SAI_QOSMAP_UTIL_H__ */
