/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

/**
 * @file  ifcs_sai_rpf_group_util.h
 * @brief ISAI Util Include file for RPF_GROUP  module
 */

#ifndef __IFCS_SAI_RPF_GROUP_UTIL_H__
#define __IFCS_SAI_RPF_GROUP_UTIL_H__

#include "util/ifcs_sai_rpf_group_util_dep.h"
#include "ifcs_intf.h"

/**
 * @brief Gets RPF Group DS attributes
 *
 * @param [in] node_id                  - IFCS node ID
 * @param [in] rpf_group_object_id      - RPF Group Object ID
 * @param [in] attr_count               - Attribute count
 * @param [in] attr_list_p              - Pointer to attribute list
 * @return sai_status_t
 */
sai_status_t
isai_im_rpf_group_ds_get_attr(
    ifcs_node_id_t  node_id,
    sai_object_id_t rpf_group_object_id,
    uint32_t        attr_count,
    sai_attribute_t *attr_list_p);

/*
 * @brief Get rpf_group_member DS entry from SAI rpf group member attributes
 *     Used by internal shim function
 *     It store the entry into a internal shim structure format
 *
 * @param [in]  node_id       - IFCS node id
 * @param [in]  ds_handle     - Data store handle
 * @param [in]  ds_entry_p    - Pointer to shim ds entry structure
 * @return sai_status_t
 */
sai_status_t
isai_im_rpf_group_member_get_ds_entry(
    ifcs_node_id_t                        node_id,
    ifcs_handle_t                         ds_handle,
    isai_shim_rpf_group_member_ds_entry_t *ds_entry_p);

/**
 * @brief Initializes rpf group module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_rpf_group_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes rpf group module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_rpf_group_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

#endif /* __IFCS_SAI_RPF_GROUP_UTIL_H__ */
