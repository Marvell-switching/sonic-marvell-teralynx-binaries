/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_queue_util.h
 * @brief ISAI Util Include file for QUEUE module
 */


#ifndef __IFCS_SAI_QUEUE_UTIL_H__
#define __IFCS_SAI_QUEUE_UTIL_H__

#include "util/ifcs_sai_queue_util_dep.h"


sai_status_t
isai_im_queue_remove(sai_object_id_t queue_object_id);

sai_status_t
isai_im_queue_default_attr(isai_shim_qos_info_t *obj_p,
                           sai_object_id_t      id);

sai_status_t
isai_im_queue_update_pfc_wd_egress_ace_for_port(sai_object_id_t queue_object_id,
                                                bool            ace_enable);

sai_status_t
isai_im_queue_default_attr_fill(ifcs_node_id_t       node_id,
                                isai_shim_qos_info_t *obj_p);

sai_status_t
isai_im_queue_flood_control_enable_get(sai_object_id_t queue_object_id,
                                       bool            *is_enable_p);
sai_status_t
isai_im_queue_get_fp_stats(sai_object_id_t        queue_id,
                           uint32_t               number_of_counters,
                           const sai_queue_stat_t *counter_ids,
                           uint64_t               *counters);
/**
 * @brief Initializes queue module
 *
 * @param [in]  sai_switch_init_info_p   - Pointer to swith init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_queue_init(sai_switch_init_info_t *sai_switch_init_info_p);


/**
 * @brief Un-initializes queue module
 *
 * @param [in]  switch_deinit_info_p   - Pointer to switch de-init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_queue_deinit(sai_switch_deinit_info_t *switch_deinit_info_p);

/*
 * @brief Validate if port scheduler mode aligns with Queue scheduler count
 *
 * @param [in]     port_id   - SAI Switch object ID
 * @param [in]     node_id   - NodeID
 * @param [in]     devport   - devport
 * @return sai_status_t
 */
sai_status_t
isai_im_queue_validate_scheduler_config_port(sai_object_id_t portOid,
                                             ifcs_node_id_t node_id,
                                             ifcs_devport_t  devport);
#endif /* __IFCS_SAI_QUEUE_UTIL_H__ */
