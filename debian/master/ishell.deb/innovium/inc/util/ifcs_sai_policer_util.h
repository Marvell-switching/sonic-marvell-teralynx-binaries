/*
 *-------------------------------------------------------------------------------------
 * Copyright (c) (2021) Marvell. All rights reserved.
 * The following file is subject to the limited use license agreement
 * by and between Marvell and you your employer or other entity on
 * behalf of whom you act. In the absence of such license agreement
 * the following file is subject to Marvell's standard Limited Use License Agreement.
 *-------------------------------------------------------------------------------------
 */

 /*  */

/**
 * @file  ifcs_sai_policer_util.h
 * @brief ISAI Util Include file for POLICER module
 */


#ifndef __IFCS_SAI_POLICER_UTIL_H__
#define __IFCS_SAI_POLICER_UTIL_H__

#include "util/ifcs_sai_policer_util_dep.h"

/*
 * @brief  Initializes policer module
 *
 * @param [in]  sai_switch_init_info_p - Pointer to switch init information
 * @return sai_status_t
 */
extern sai_status_t
isai_im_policer_init(
    sai_switch_init_info_t *sai_switch_init_info_p);

/*
 * Create actions for the ACE that is created when policer is attached to
 * bindpoints like mirror session, sflow trap or port objects.
 *
 * Use passed policer OID and IB number in isai_policer_key_info_t to key
 * into policer hdl ds to get the following:
 * (a) Meter handle for ACL meter action
 * (b) Counter handle for ACL counter action.
 * (c) Packet actions based on policer SAI attribute list.
 *
 * Note that this function creates ACL packet actions that will affect
 * dataplane and NOT control plane.
 *
 * Policer packet action FORWARD is translated to SDK ACL action drop 'DISABLE'.
 * Policer packet action DROP is translated to SDK ACL action drop 'ENABLE'.
 * The action handles thus created are appended to the user passed
 * ACL action handle list.
 *
 * Memory to save the action handles is expected to be allocated by
 * the caller.
 */
extern
sai_status_t
isai_im_policer_create_meter_action(ifcs_node_id_t     node_id,
                                    isai_policer_key_info_t   *policer_key_info_p,
                                    ifcs_handle_t      action_profile_hdl,
                                    ifcs_handle_list_t *action_hdl_list_p);

/*
 * @brief Get the IFCS meter and counter handles for a given target OID.
 * @param [in] policer_key_info_p    - Pointer to policer key info (oid and ib).
 * @param [out] meter_handle_p - Return pointer to meter handle.
 * @param [out] counter_handle_p - Return pointer toi counter handle.
 *
 * @return sai_status_t
 */
sai_status_t
isai_im_policer_get_meter_counter_handle(isai_policer_key_info_t   *policer_key_info_p,
                                         ifcs_handle_t   *meter_handle_p,
                                         ifcs_handle_t   *counter_handle_p);

/*
 * @brief Converts SAI attr to IFCS attr
 *
 * @param [in] api_type        - CRUD operation type
 * @param [in] attr_count        - SAI Attr count
 * @param [in] attr_list_p       - SAI Attr pointer
 * @param [in] policer_id        - Policer OID
 * @param [out] ifcs_attr_count  - IFCS attr count
 * @param [out] ifcs_attr_list_pp - IFCS attr list
 * @return sai_status_t
 */
sai_status_t
isai_im_policer_attr_stoi(
    ifcs_node_id_t        node_id,
    sai_common_api_t      api_type,
    uint32_t              attr_count,
    const sai_attribute_t *attr_list_p,
    sai_object_id_t       policer_id,
    uint32_t              *ifcs_attr_count,
    ifcs_attr_t           **ifcs_attr_list_pp);


/*
 * @brief Check if the policer already has bindpoint of a specific type.
 * @param [in] node_id - Node ID
 * @param [in] bindpoint_list - Bindpoint list of the policer
 * @param [in] bindpoint_oid  - target bindpoint OID.
 *
 * @return bool          - return TRUE is there are existing users.
 */
bool
isai_im_policer_meter_check_users(ifcs_node_id_t    node_id,
                                  sai_object_list_t bindpoint_list,
                                  sai_object_type_t bind_oid_type);


/**
 * @brief Program policer CIR in bps based on user configured CIR in pps and avg pkt size
 *
 * @param [in] policer_key_info_p     - Pointer to policer key info (oid and ib)
 * @param [in] pkt_size           - avg pkt size
 * @param [in] bind_oid           - Bindpoint OID
 * @return sai_status_t
 */

sai_status_t
isai_im_policer_rate_set(isai_policer_key_info_t   *policer_key_info_p,
                         sai_object_id_t bind_oid,
                         uint32_t        pkt_size);

/*
 * Delete the ACE associated with mirror/sflow session when policer is attached.
 */
sai_status_t
isai_im_policer_delete_meter_ace(ifcs_node_id_t  node_id,
                                 sai_object_id_t port_oid,
                                 ifcs_handle_t   ace_hdl);

/*
 * Create the ACE that will police the mirrored/sampled packets.
 * The ACE's scope is per IB as it is put in the egress PFC WD table which
 * is created with IB scope.
 * Match: Collector handle
 * Actions: meter, counter, packet action.
 */
sai_status_t
isai_im_policer_create_meter_ace(ifcs_node_id_t    node_id,
                                 sai_object_id_t   port_oid,
                                 isai_policer_key_info_t   *policer_key_info_p,
                                 ifcs_handle_t     collector_hdl,
                                 sai_object_type_t bind_oid_type,
                                 ifcs_handle_t     *ace_hdl_p);

sai_status_t
isai_im_policer_get_color_packet_action(ifcs_node_id_t           node_id,
                                        sai_object_id_t          policer_oid,
                                        ifcs_sai_policer_color_t ecolor,
                                        sai_packet_action_t      *action_color_p);

/**
 * @brief Update the refcount in the policer hdl hash DS entry.
 *
 * Caller provides the SAI policer OID and IB number in isai_policer_key_info_t
 * and the ACL table handle on which the meter was created. The refcount will
 * be incremented/decremented based on the bool passed by the caller.
 * In case the refcount is decremented, caller can optionally choose to have the
 * meter deleted and the entry deleted from the Policer hdl hash DS.
 *
 * @param [in] node_id          - IFCS node id,
 * @param [in] policer_key_info_p   - Pointer to policer key info (oid and ib),
 * @param [in] increment        - Boolean, true is increment, false is decrement,
 * @param [in] delete_on_zero   - On true and refcount hitting zero, meter
 *                                is deleted.
 * @return sai_status_t
 */
sai_status_t
isai_im_policer_meter_update_ref_count(ifcs_node_id_t  node_id,
                                       isai_policer_key_info_t    *policer_key_info_p,
                                       bool            increment,
                                       bool            delete_on_zero);

/**
 * @brief Update the refcount in incremental/decremental of provided count value
 * in the policer hdl hash DS entry.
 *
 * Caller provides the SAI policer OID and the IB number in isai_policer_key_info_t
 * on which the meter was created. The refcount will be incremented/decremented
 * based on the bool passed by the caller.
 * In case the refcount is decremented, caller can optionally choose to have the
 * meter deleted and the entry deleted from the Policer hdl hash DS.
 *
 * @param [in] node_id          - IFCS node id,
 * @param [in] policer_key_info_p   - Pointer to policer key info (oid and ib),
 * @param [in] increment        - Boolean, true is increment, false is decrement,
 * @param [in] delete_on_zero   - On true and refcount hitting zero, meter
 *                                is deleted,
 * @param [in] count            - Count value to increment or decrement.
 * @return sai_status_t
 */
sai_status_t
isai_im_policer_meter_update_multi_ref_count(ifcs_node_id_t  node_id,
                                       isai_policer_key_info_t    *policer_key_info_p,
                                       bool            increment,
                                       bool            delete_on_zero,
                                       uint32_t        count);

sai_status_t
isai_im_policer_get_packet_action(sai_object_id_t     policer_oid,
                                  sai_packet_action_t *green_action_p,
                                  sai_packet_action_t *yellow_action_p,
                                  sai_packet_action_t *red_action_p);

/**
 * @brief Create meter on user created ACL table.
 *
 * @param [in] policer_oid  - policer oid
 * @param [in] tbl_hdl - ACL table handle to create the meter on.
 * @param [in] meter_attr_count - User specific meter attribute count.
 * @param [in] meter_attr_list_p - User specific meter attribute list (eg: scope, IB).
 * @param [out] meter_handle_p - Pointer to meter handle created by this API.
 * @return sai_status_t
 *
 * @details: This API is to be used when user wants to create a meter on
 * user created ACL table. In this case, Policer module will NOT create the
 * counter. User needs to create the counter. This is because user created
 * ACL table could have counter action also and hence the ACEs in this ACL
 * table will need per ACE counters. Meter is created on hardware and entry
 * created in policer hdl DS.
 */

sai_status_t
isai_im_policer_create_meter_acl_user(sai_object_id_t policer_oid,
                                      ifcs_handle_t   tbl_hdl,
                                      uint32_t        meter_attr_count,
                                      ifcs_attr_t     *meter_attr_list_p,
                                      ifcs_handle_t   *meter_handle_p);

sai_status_t
isai_im_policer_create_counter_acl_tbl_hdl(sai_object_id_t policer_oid,
                                           ifcs_handle_t   tbl_hdl,
                                           uint32_t        counter_attr_count,
                                           ifcs_attr_t     *counter_attr_list_p,
                                           ifcs_handle_t   *counter_handle_p);

/**
 * @brief Create meter on internal ACL table.
 *
 * @param [in] policer_oid  - policer oid
 * @param [in] attrs_p  - User passed parameters to create the meter is embedded
 *                        in this internal structure. Following details are to
 *                        be passed by the user.
 *  acl_table_handle    - IFCS Handle of the ACL table on which the meter
 *                is to be attached.
 *  meter_attr_count         - Caller passed meter attribute count
 *  counter_attr_count       - Caller passed counter attribute count
 *  meter_attr_list_p        - Caller passed meter attribute list
 *  counter_attr_list_p      - Caller passed counter attribute list
 * @param [in] increment_ref_count       - Increment refcount of meter after
 *                                         creating in Policer Hdl DS.
 * @param [out] meter_handle_p          - Return pointer to meter handle creted
 * @param [out] counter_handle_p        - Return pointer to counter handle creted
 *
 * @return sai_status_t
 *
 * @details: This API is to be used when user wants to create a meter on
 * internal ACL table. In this case, Policer module will create the
 * counter. This counter handle can be shared by all the bindpoints that are
 * bound to the same policer. Eg: Hostif trap group, mirror session. Meter
 * is created on hardware and entry created in policer hdl DS.
 */

sai_status_t
isai_im_policer_create_meter_acl_internal(
    sai_object_id_t               policer_oid,
    isai_policer_meter_internal_t *attrs_p,
    bool                          increment_ref_count,
    ifcs_handle_t                 *meter_handle_p,
    ifcs_handle_t                 *counter_handle_p);

/*
 * @brief  Delete the IFCS meter object (when app no longer needs meter)
 *
 * @param [in]  policer_key_info_p         - Pointer to policer key info (oid and ib)
 * @return sai_status_t
 *
 * This API deletes the hardware meter and removes it from the Policer hdl
 * DS.
 */
sai_status_t
isai_im_policer_delete_meter(isai_policer_key_info_t  *policer_key_info_p);


/*
 * @brief  Check if the policer is bound to any other object types.
 *
 * @param [in]  policer_oid         - policer oid
 * @param [in]  bind_obj_type       - Type of object being bound to policer.
 * @return sai_status_t
 *
 * This API also checks if the policer is already bound to objects
 * of other types.
 */
sai_status_t
isai_im_policer_bind_type_validate(
    sai_object_id_t   policer_oid,
    sai_object_type_t bind_obj_type);

/*
 * @brief  Check for policer attributes as per caller's request.
 *
 * @param [in]  policer_oid         - policer oid
 * @param [in]  check_byte_mode     - Is meter 'mode' type bytes?
 * @param [in]  check_packet_action - Is packet action FORWARD or DROP?
 * @return sai_status_t
 *
 * This API checks if the policer is compatible with the object that it is
 * being bound to. There are certain bindpoint type specific constraints on the
 * policer parameters like 'meter' mode and policer packet action.
 */
sai_status_t
isai_im_policer_bind_attr_validate(
    sai_object_id_t   policer_oid,
    bool              check_byte_mode,
    bool              check_packet_actions);

sai_status_t
isai_im_policer_configure_cpu_queue(sai_object_id_t    policer_oid,
                                     uint32_t           queue_id,
                                     bool is_called_during_dp_init);

sai_status_t
isai_im_policer_reset_cpu_queue_config(sai_object_id_t    policer_oid,
                                       uint32_t           queue_id,
                                       bool is_called_during_dp_init);

sai_status_t
isai_im_policer_copp_node_validate(sai_object_id_t  policer_oid);

sai_status_t
isai_im_policer_enable_meter_ace(ifcs_node_id_t   node_id,
                                ifcs_handle_t   ace_hdl,
                                ifcs_handle_t   collector_hdl);
sai_status_t
isai_im_policer_disable_meter_ace(ifcs_node_id_t  node_id,
                                 ifcs_handle_t   ace_hdl);
#endif /* __IFCS_SAI_POLICER_UTIL_H__ */
