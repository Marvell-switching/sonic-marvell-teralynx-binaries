/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saitypescustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITYPESCUSTOM_H_
#define __SAITYPESCUSTOM_H_

#include <saitypes.h>


/**
 * @brief Static member selection mode
 *
 * Used to select how the Next hop group and LAG members are resolved.
 * Member can be selected based on the hash, random or in round robin manner.
 */
typedef enum _sai_custom_static_member_selection_mode_t
{
    /** Static member selection mode is hash, hash algorithm set at switch level */
    SAI_CUSTOM_STATIC_MEMBER_SELECTION_MODE_HASH,

    /** Static member selection mode is random */
    SAI_CUSTOM_STATIC_MEMBER_SELECTION_MODE_RANDOM,

    /** Static member selection mode is round robin */
    SAI_CUSTOM_STATIC_MEMBER_SELECTION_MODE_ROUND_ROBIN,

} sai_custom_static_member_selection_mode_t;


/**
 *  @brief SAI object type custom trap
 */
typedef enum _sai_hostif_trap_type_custom_t
{
    /**
     * @brief Custom trap to perform Flood Control on Broadcast,
     * Unknown Unicast and Multicast traffic per Traffic Class
     * (default packet action is forward)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_TC_FLOOD_CONTROL_DISCARD = SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE + 0x1,

    /**
     * @brief Peer Delay PTP traffic. Conditions are
     * ((EtherType = 0x88F7 or UDP dst port == 319 or UDP dst port == 320)
     * and (PTP messageType ==  0x2 or PTP messageType == 0x3 or PTP messageType == 0x10))
     * Recommended priority: Higher than SAI_HOSTIF_TRAP_TYPE_PTP
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_PTP_PEER_DELAY = SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE + 0x2

}sai_hostif_trap_type_custom_t;


/**
 * @brief Attribute data for #SAI_SWITCH_ATTR_CUSTOM_PTP_CLOCK_TYPE
 */
typedef enum _sai_switch_custom_ptp_clock_type_t
{
    /** Do not set PTP Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_NONE,

    /** Boundary Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_BOUNDARY,

    /** Ordinary Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_ORDINARY,

    /** End to End Transparent Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_TRANSPARENT_E2E,

    /** Peer to Peer Transparent Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_TRANSPARENT_P2P,

} sai_switch_custom_ptp_clock_type_t;


/**
 * @brief SAI object type custom acl action
 */
typedef enum _sai_acl_action_type_custom_t
{
    /** Bind a TAM object */
    SAI_ACL_ACTION_TYPE_CUSTOM_TAM_OBJECT = SAI_ACL_ACTION_TYPE_CUSTOM_RANGE_BASE,

    /** Set metadata to carry forward to next ACL stage */
    SAI_ACL_ACTION_TYPE_CUSTOM_SET_ACL_META_DATA_2

}sai_acl_action_type_custom_t;

#endif /* __SAITYPESCUSTOM_H_ */
