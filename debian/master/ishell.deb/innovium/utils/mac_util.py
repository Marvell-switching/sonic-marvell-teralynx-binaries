#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
 
from common_util import *
from utils.compat_util import *

macArr = [0] * 6

#API to set a particular seed value
def set_mac_seed(lseed):
    set_seed(lseed)

#API to convert the Python list of MAC bytes to string
def mac_addr_to_str(mac_arr):
    mac_str = []
    for i in range (0, 6):
       #a_byte = '{:02X}'.format(mac_arr[i])
       if int(mac_arr[i]) < 16:
          a_byte = "0" + hex(int(mac_arr[i]))[-1:]
       else:
          a_byte = hex(int(mac_arr[i]))[2:]
       mac_str.append(a_byte)

    out_str = mac_str[0] + ":" + mac_str[1] + ":" + \
              mac_str[2] + ":" + mac_str[3] + ":" + \
              mac_str[4] + ":" + mac_str[5]
    return out_str

def convertMacstrtoInt(macStr):
    bytes = macStr.split(":")
    macInt = (compat_long(bytes[0], 16) << 40) | (compat_long(bytes[1], 16) << 32) | \
              (compat_long(bytes[2], 16) << 24) | (compat_long(bytes[3], 16) << 16) | \
              (compat_long(bytes[4], 16) << 8) | (compat_long(bytes[5], 16))
    return macInt

def convertMacInttoStr(macInt):
    macstr="{:012X}".format(macInt)
    returnStr=macstr[0:2]
    for i in range(5):
        returnStr += ":" + macstr[(i+1)*2:(i+2)*2]
    return returnStr

def generateMacinRange(startAddr, endAddr, num_entries=1):
    start = convertMacstrtoInt(startAddr)
    end = convertMacstrtoInt(endAddr)
    assert (end - start + 1) >= num_entries, "invalid range specified for {} entries".format(num_entries)
    assert num_entries >= 0, "negative num entries specified"
    addrs = []
    while not len(addrs) == num_entries:
        random_list=[]
        for i in compat_xrange(compat_long(num_entries * 1.5)):
            random_list.append(random.randint(start, end))
        addrs = list(set(addrs + random_list))[0:num_entries]
    addrstr = [convertMacInttoStr(x) for x in addrs]
    return addrs, addrstr

def get_ctype_arr(mac_arr):
    arr = (ctypes.c_uint8 * 6)()
    arr = (ctypes.c_uint8 * len(mac_arr))(*mac_arr)
    return arr

def convertMacstrtoarr(macStr):
    bytes = macStr.split(":")
    macArr = (compat_long(bytes[0], 16), compat_long(bytes[1], 16), compat_long(bytes[2], 16),
              compat_long(bytes[3], 16), compat_long(bytes[4], 16), compat_long(bytes[5], 16))
    return macArr

#Get a randomized MAC as a C-Array of unit8*6
def get_random_mac(isMulticast=0,length=6):
    global macArr

    if (isMulticast):
        macArr = get_rand_list(0 ,255, length)
        macArr[0] = macArr[0] | 0x01
    else:
        macArr = get_rand_list(0 ,255, length)
        macArr[0] = macArr[0] & 0xfe #Make sure its unicast MAC

    return (macArr)

def get_random_mac_list(isMulticast=0,length=6,num_entries=1):
    random_list=[]
    temp_list=[]
    if length < 6:
        while not len(random_list) == num_entries:
            getPrefix=get_random_mac(isMulticast,length)
            for i in compat_xrange(compat_long(num_entries * 1.5)):
                temp_list.append(mac_addr_to_str(getPrefix + get_random_mac()[:(6-length)]))
            random_list=list(set(random_list + temp_list))[0:num_entries]
    else:
        for i in compat_xrange(compat_long(num_entries * 1.5)):
            random_list.append(mac_addr_to_str(get_random_mac()))

    assert num_entries == len(list(set(random_list))[0:num_entries])
    return list(set(random_list))[0:num_entries]
