#-------------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------
from ctypes import *

def macAddrTupleToCByte(macAddr):
    '''Convert MAC address from tuple to ctypes - ubyte'''
    return (c_ubyte * 6)(*macAddr)

def macAddrCbyteToTuple(macAddr):
    '''Convert macaddr from c_byte array to Tuple'''
    return tuple(macAddr[i] for i in range(6))

def ip6AddrTupleToCByte(ipAddr):
    '''Convert IPV6 address from tuple to ctypes - ubyte'''
    return (c_ubyte * 16)(*ipAddr)

def ip6AddrCByteToTuple(ipAddr):
    '''Convert IPV6 address from c_byte array to Tuple'''
    return tuple(ipAddr[i] for i in range(16))

def alloc(objType, numElements = 1):
    '''Allocates an object Type object and initializes to 0'''
    if numElements > 1:
        ifcsObj = (objType * numElements)()
    else:
        ifcsObj = objType()
    memset(pointer(ifcsObj), 0, sizeof(objType) * numElements)
    return ifcsObj
