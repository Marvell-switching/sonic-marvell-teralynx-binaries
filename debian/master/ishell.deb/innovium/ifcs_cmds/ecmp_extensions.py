#-------------------------------------------------------------------------------
# Copyright (c) (2023) Marvell. All rights reserved
# *
# * This material is proprietary to Innovium. All rights reserved.
# * The methods and techniques described herein are considered trade secrets
# * and/or confidential. Reproduction or distribution, in whole or in part, is
# * forbidden except by express written permission of Innovium.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import *
from print_table import PrintTable
import sys
from utils.compat_util import *
ifcs_ctypes = sys.modules['ifcs_ctypes']

ecmp_group_type_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG1_REGULAR: "Regular",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_CLONE: "Clone",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_DUAL: "Dual",
}

ecmp_mbr_type_dict = {
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_TUNNEL: "Tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_NON_TUNNEL: "Non-tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_DUAL: "Dual",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_LAG: "LAG",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_NON_TUNNEL: "Non-tunnel",
    ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_CLONE: "Clone",
}

def parse_hw_state(hw_state):
    order = []
    ib = 0
    temp_list = hw_state.split("_DATA_F_GROUP_PORT_LIST_F")
    port_list = str(temp_list[1][4:195])
    modified_port_list = ''.join(x for x in port_list if x.isalnum())
    length = len(modified_port_list)
    for i in range(length, 0, -16):
        ib_port_list = modified_port_list[i-16:i]
        binary_ib_port_list = '{0:064b}'.format(int(ib_port_list,16))
        binary_ib_port_list = binary_ib_port_list[::-1]
        for j in range(len(binary_ib_port_list)):
            if binary_ib_port_list[j] == '0':
                continue
            order.append(str(ib) + "/" + str(j))
        ib = ib+1
    return order

def ecmp_hwstate_get(ecmp, self):
        rc = self.cli.ifcs_ctypes.IFCS_SUCCESS
        actual_length = c_uint64()
        length = self.cli.ifcs_ctypes.ifcs_uint64_t()
        rc = self.cli.ifcs_ctypes.ifcs_ecmp_hw_state_string_get(self.cli.node_id, ecmp, 0, None, 0, byref(actual_length))

        hw_state = b" " * actual_length.value
        length = actual_length.value
        rc = self.cli.ifcs_ctypes.ifcs_ecmp_hw_state_string_get(self.cli.node_id, ecmp, 0, hw_state, length, byref(actual_length))
        return parse_hw_state(str(hw_state.decode()))

def show_ecmp_extension_usage_detail(arg1, arg2, self):
    num_attr = 2
    attr_list = (ifcs_ctypes.ifcs_attr_t * num_attr)()
    ecmp_enable = ifcs_ctypes.ifcs_bool_t()
    ecmp_profile = ifcs_ctypes.ifcs_uint32_t()

    for index in range(num_attr):
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index))

    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_HIERARCHICAL_ENABLE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_PROFILE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    count = ifcs_ctypes.ifcs_uint32_t()
    for index in range(num_attr):
        ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(count))

    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), pointer(ecmp_enable))
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), pointer(ecmp_profile))
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    usage_p = (ifcs_ctypes.ifcs_usage_t * 3)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * 3)()

    obj[0].ecmp = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG1_REGULAR
    obj[1].ecmp = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_CLONE
    obj[2].ecmp = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_STG2_DUAL

    for index in range(2):
        ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_ECMP)
        ifcs_ctypes.ifcs_usage_t_obj_type_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            compat_pointerAtIndex(obj, ifcs_ctypes.ifcs_usage_obj_t, index))
        rc = ifcs_ctypes.ifcs_ecmp_usage_detail_get(
            0, 0, None, compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get ECMP usage rc: {1}".format(
                convert_error_code_to_string(rc)))
            return

    log_dbg(1, " Inside extension ecmp usage show")
    log("Stage 1:")
    table = PrintTable()
    table.add_row(["group type", "max", "used", "available"])
    table.add_row([
        ecmp_group_type_dict[obj[0].ecmp], usage_p[0].max, usage_p[0].current,
        usage_p[0].max - usage_p[0].current
    ])
    table.print_table(brief=True)
    table.reset_table()

    if not ecmp_enable:
        return

    log("Stage 2:")
    table2 = PrintTable()
    table2.add_row(["group type", "max", "used", "available"])
    table2.add_row([
        ecmp_group_type_dict[obj[1].ecmp], usage_p[1].max, usage_p[1].current,
        usage_p[1].max - usage_p[1].current
    ])
    table2.add_row([
        ecmp_group_type_dict[obj[2].ecmp], usage_p[2].max, usage_p[2].current,
        usage_p[2].max - usage_p[2].current
    ])
    table2.print_table(brief=True)
    table2.reset_table()
    log("Note: Dual and clone groups are internal")
    return


def show_ecmp_member_extension_usage_detail(arg1, arg2, self):
    num_attr = 2
    attr_list = (ifcs_ctypes.ifcs_attr_t * num_attr)()
    ecmp_enable = ifcs_ctypes.ifcs_bool_t()
    ecmp_profile = ifcs_ctypes.ifcs_uint32_t()

    for index in range(num_attr):
        ifcs_ctypes.ifcs_attr_t_init(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index))

    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_HIERARCHICAL_ENABLE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_id_set(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), ifcs_ctypes.IFCS_NODE_ATTR_ECMP_PROFILE)
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    count = ifcs_ctypes.ifcs_uint32_t()
    for index in range(num_attr):
        ifcs_ctypes.ifcs_node_attr_get(self.cli.node_id, 1, compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, index), pointer(count))

    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 0), pointer(ecmp_enable))
    assert rc == ifcs_ctypes.IFCS_SUCCESS
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointerAtIndex(attr_list, ifcs_ctypes.ifcs_attr_t, 1), pointer(ecmp_profile))
    assert rc == ifcs_ctypes.IFCS_SUCCESS

    usage_p = (ifcs_ctypes.ifcs_usage_t * 6)()
    obj = (ifcs_ctypes.ifcs_usage_obj_t * 6)()

    obj[0].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_TUNNEL
    obj[1].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_NON_TUNNEL
    obj[2].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_DUAL
    obj[3].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG1_LAG
    obj[4].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_NON_TUNNEL
    obj[5].ecmp_mbr = ifcs_ctypes.IFCS_USAGE_OBJ_ECMP_MBR_STG2_CLONE

    for index in range(6):
        ifcs_ctypes.ifcs_usage_t_obj_api_class_id_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            ifcs_ctypes.IFCS_USAGE_OBJ_API_CLASS_ID_ECMP)
        ifcs_ctypes.ifcs_usage_t_obj_type_set(
            compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index),
            compat_pointerAtIndex(obj, ifcs_ctypes.ifcs_usage_obj_t, index))
        rc = ifcs_ctypes.ifcs_ecmp_member_usage_detail_get(
            0, 0, 0, None, compat_pointerAtIndex(usage_p, ifcs_ctypes.ifcs_usage_t, index))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get ECMP member usage rc: {1}".format(
                convert_error_code_to_string(rc)))
            return

    log_dbg(1, " Inside extension ecmp member usage show")
    log("Stage 1:")
    table = PrintTable()
    table.add_row(["member type", "max", "used", "available"])
    table.add_row([
        ecmp_mbr_type_dict[obj[0].ecmp_mbr], usage_p[0].max, usage_p[0].current,
        usage_p[0].max - (usage_p[0].current + usage_p[1].current + usage_p[3].current)
    ])
    table.add_row([
        ecmp_mbr_type_dict[obj[1].ecmp_mbr], usage_p[1].max, usage_p[1].current,
        usage_p[1].max - (usage_p[1].current + usage_p[0].current + usage_p[3].current)
    ])
    table.add_row([
        ecmp_mbr_type_dict[obj[3].ecmp_mbr], usage_p[3].max, usage_p[3].current,
        usage_p[3].max - (usage_p[0].current + usage_p[1].current + usage_p[3].current)
    ])
    if usage_p[2].max != 0:
        table.add_row([
            ecmp_mbr_type_dict[obj[2].ecmp_mbr], usage_p[2].max, usage_p[2].current,
            0
        ])

    table.print_table(brief=True)
    table.reset_table()

    if ecmp_enable:
        log("Stage 2:")
        table2 = PrintTable()
        table2.add_row(["member type", "max", "used", "available"])
        if usage_p[4].max != 0:
            if((usage_p[4].current + usage_p[5].current) >= usage_p[4].max):
                table2.add_row([
                    ecmp_mbr_type_dict[obj[4].ecmp_mbr], usage_p[4].max, usage_p[4].current,
                    0
                ])
            else:
                table2.add_row([
                    ecmp_mbr_type_dict[obj[4].ecmp_mbr], usage_p[4].max, usage_p[4].current,
                    usage_p[4].max - (usage_p[4].current + usage_p[5].current)
                ])
        table2.add_row([
            ecmp_mbr_type_dict[obj[5].ecmp_mbr], usage_p[5].max, usage_p[5].current,
            usage_p[5].max - (usage_p[5].current + usage_p[4].current)
        ])
        table2.print_table(brief=True)
        table2.reset_table()
        log("Note: Dual and clone members are internal")

    rc, all_ecmp = self.bulk_get_all_ecmp_keys()

    ecmp = arg2
    if ecmp not in all_ecmp:
        return

    table = PrintTable()
    field_names = []
    field_names.append('ecmp')
    field_names.append('member_count')
    alb_is_valid = self.cli.ifcs_ctypes.im_ecmp_attr_is_valid(
        self.cli.node_id, self.cli.ifcs_ctypes.IFCS_ECMP_ATTR_ALB)
    if alb_is_valid:
        alb = self.getAlb(ecmp, True)
        if alb == 0:
            return
    else:
        return

    field_names.append('alb')
    field_names.append('alb_member_sequence (ib/ibport)')
    table.add_row(field_names)

    attr_row = []
    attr_row.append(self.handle_to_str(ecmp))

    member_count = self.getMemberCount(ecmp, True)
    attr_row.append(
        'N/A' if member_count is None else str(member_count))
    attr_row.append(
            'N/A' if alb == 0 else self.handle_to_str(alb))
    port_list = ecmp_hwstate_get(ecmp, self)
    attr_row.append(port_list)

    table.add_row(attr_row)

    table.print_table(brief=True)
    table.reset_table()
    return

def show_ecmp_extension_brief(arg2, self):
    ''' Displays summary of all instance of type ecmp'''
    log_dbg(1, "In show_ecmp_brief method")

    try:
        rc, all_ecmp = self.bulk_get_all_ecmp_keys()
    except:
        log_err(" Failed to get all ecmp")
        return

    table = PrintTable()
    field_names = []
    field_names.append('ecmp')

    field_names.append('type')
    field_names.append('number_of_slots')
    field_names.append('group_size')
    field_names.append('member_count')
    static_member_selection_mode_is_valid = self.cli.ifcs_ctypes.im_ecmp_attr_is_valid(
        self.cli.node_id,
        self.cli.ifcs_ctypes.IFCS_ECMP_ATTR_STATIC_MEMBER_SELECTION_MODE)
    if static_member_selection_mode_is_valid:
        field_names.append('static_member_selection_mode')
    alb_is_valid = self.cli.ifcs_ctypes.im_ecmp_attr_is_valid(
        self.cli.node_id, self.cli.ifcs_ctypes.IFCS_ECMP_ATTR_ALB)
    if alb_is_valid:
        field_names.append('alb')
    field_names.append('ref_count')
    table.add_row(field_names)
    try:
        if self.filter_option['sort'] in self.get_methods.keys():
            all_ecmp = sorted(
                all_ecmp,
                key=lambda x: self.get_methods[self.filter_option['sort']]
                (x))
        else:
            log("Cannot sort on {0}".format(self.filter_option['sort']))
            all_ecmp = sorted(all_ecmp)
    except:
        all_ecmp = sorted(all_ecmp)

    log("Total ecmp count: {0} ".format(len(all_ecmp)))
    count = 0
    for ecmp in all_ecmp:
        attr_row = []
        attr_row.append(self.handle_to_str(ecmp))

        try:
            type = self.getType(ecmp, True)
            number_of_slots = self.getNumberOfSlots(ecmp, True)
            group_size = self.getGroupSize(ecmp, True)
            member_count = self.getMemberCount(ecmp, True)
            if static_member_selection_mode_is_valid:
                static_member_selection_mode = self.getStaticMemberSelectionMode(
                    ecmp, True)
            if alb_is_valid: alb = self.getAlb(ecmp, True)
            ref_count = self.getRefCount(ecmp, True)

        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show ecmp brief. ecmp: {}, error: {}".format(
                    self.handle_to_str(ecmp), einfo))
            if self.not_found_exc_msg.format(
                    self.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise
        attr_row.append(
            'N/A' if type is None else self.enum_to_str('type', type))
        attr_row.append(
            'N/A' if number_of_slots is None else str(number_of_slots))
        attr_row.append('N/A' if group_size is None else str(group_size))
        attr_row.append(
            'N/A' if member_count is None else str(member_count))
        if static_member_selection_mode_is_valid:
            attr_row.append(
                'N/A' if static_member_selection_mode is None else self.
                enum_to_str('static_member_selection_mode',
                            static_member_selection_mode))
        if alb_is_valid:
            attr_row.append(
                'N/A' if alb == 0 else self.handle_to_str(alb))
        attr_row.append('N/A' if ref_count is None else str(ref_count))

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total ecmp count: {0}".format(count))
