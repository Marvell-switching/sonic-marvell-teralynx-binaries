
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *

from print_table import PrintTable
import sys
ifcs_ctypes=sys.modules['ifcs_ctypes']
from ifcs_cmds.acl import *
from ifcs_cmds.ace import *
from ifcs_cmds.acl_match import *
from ifcs_cmds.acl_action import *
from ifcs_cmds.acl_match_profile import *
from ifcs_cmds.acl_action_profile import *
from ifcs_cmds.acl_table import *
from ifcs_cmds.acl_counter import *


def show_acl_table_extension_detail(args, acl_table):
    log_dbg(1, " Inside extension detail show")
    handle = int(args)
    acl_table.show_acl_table_attrs(None, handle)
    mp = AclMatchProfile(acl_table.cli)
    mp_list = get_acl_table_attr(acl_table, handle, 'match_profile_list_with_pkttype')
    if mp_list and mp_list != '[ ]':
        for mpl in mp_list:
            mp.show_acl_match_profile_attrs(None, mpl.mp_handle)
    else:
       mp.show_acl_match_profile_attrs(None, acl_table.getMatchProfile(handle))
    ap = AclActionProfile(acl_table.cli)
    ap.show_acl_action_profile_attrs(None, acl_table.getActionProfile(handle))
    #print the table content
    table = PrintTable()
    field_names = []
    field_names.append('acl')
    field_names.append('ace')
    field_names.append('ace_name')
    field_names.append('enable')
    field_names.append('priority')
    field_names.append('match_set')
    field_names.append('action_set')
    field_names.append('packets')
    field_names.append('bytes')
    table.add_row(field_names)
    acls = acl_table.getAcls(handle)
    ace_obj = Ace(acl_table.cli)
    acl_obj = Acl(acl_table.cli)
    match_obj = AclMatch(acl_table.cli)
    action_obj = AclAction(acl_table.cli)
    counter_obj = AclCounter(acl_table.cli)
    rows = []
    for acl in acls:
        rows.append(acl_obj.handle_to_str(acl))
        aces = sorted(acl_obj.getAces(acl), key = lambda x : ace_obj.getPriority(x))
        for ace in aces:
            rows.append(ace_obj.handle_to_str(ace))
            name = ace_obj.getName(ace, True)
            # Remove extra NULL characters from the string
            if name is not None:
                null_idx = name.find('\0')
                if null_idx != -1:
                    name = name[:null_idx]
            rows.append('' if name is None else name)
            rows.append(ace_obj.enum_to_str('bool', ace_obj.getEnable(ace)))
            rows.append(ace_obj.getPriority(ace))
            match_set = ace_obj.getMatchSet(ace)
            matches = []
            for match in match_set:
                m = int(match.split(':')[1].split(')')[0], 0)
                m = ifcs_ctypes.IFCS_HANDLE_ACL_MATCH(m)
                match_value = match_obj.getValue(m)
                match_mask = match_obj.getMask(m)
                if match_value is None or match_mask is None:
                    log_dbg(1, " Match value ({}) or mask ({}) is none, ignore match object ({})".format(match_value, match_mask, m))
                    continue

                if len(match_value):
                    if len(match_mask):
                        matches.append( "m-"+ match.split(':')[1].split(')')[0].strip() + " "+match_obj.enum_to_str("type", match_obj.getType(m)) + "(V=" + str(match_value) + ",M="+str(match_mask)+"),")
                    else:
                        matches.append( "m-"+ match.split(':')[1].split(')')[0].strip() + " "+match_obj.enum_to_str("type", match_obj.getType(m)) + "(V=" + str(match_value) + "),")
                else:
                    matches.append( "m-"+ match.split(':')[1].split(')')[0].strip() + " "+match_obj.enum_to_str("type", match_obj.getType(m)) + "(" + str(hex(match_obj.getObject(m))) + "),")
            action_set = ace_obj.getActionSet(ace)
            actions = []
            c_obj = None
            for action in action_set:
                a = int(action.split(':')[1].split(')')[0], 0)
                a = ifcs_ctypes.IFCS_HANDLE_ACL_ACTION(a)
                if action_obj.enum_to_str("type", action_obj.getType(a)) == 'DROP':
                    actions.append("a-"+ action.split(':')[1].split(')')[0].strip() + " "+ action_obj.enum_to_str("type", action_obj.getType(a)) + "(" + str(hex(action_obj.getValue(a).drop.pp_drop_reason)) + ")")
                elif action_obj.enum_to_str("type", action_obj.getType(a)) == 'COPY_TO_CPU':
                    actions.append("a-"+ action.split(':')[1].split(')')[0].strip() + " "+ action_obj.enum_to_str("type", action_obj.getType(a)) + "(" + str(hex(action_obj.getValue(a).ctc.hostif)) + ")")
                else:
                    actions.append("a-"+ action.split(':')[1].split(')')[0].strip() + " "+ action_obj.enum_to_str("type", action_obj.getType(a)) + "(" + str(hex(action_obj.getObject(a))) + ")")
                c_obj = action_obj.getObject(a) if action_obj.enum_to_str("type", action_obj.getType(a)) == 'ACL_COUNTER' else c_obj
            packets = []
            bytes = []
            default_stats = acl_table.getDefaultStats(handle)
            if default_stats:
                packets.append("%d"%ace_obj.getPackets(ace))
                bytes.append("%d"%ace_obj.getBytes(ace))
            else:
                if c_obj:
                    stats = counter_obj.stats_get(c_obj)
                    packets=['T=%d'%stats[0], 'G=%d'%stats[2], 'Y=%d'%stats[4], 'R=%d'%stats[6]]
                    bytes=[stats[1], stats[3], stats[5], stats[7]]
            num = len(actions) if len(actions) > len(matches) else len(matches)
            num = len(packets) if len(packets) > num else num
            for i in range(num):
                rows.append(matches[i] if i < len(matches) else '')
                rows.append(actions[i] if i < len(actions) else '')
                rows.append(packets[i] if i < len(packets) else '')
                rows.append(bytes[i]   if i < len(bytes)   else '')
                table.add_row(rows)
                rows = ['','','','','']
            rows = [ '' ]
        rows = []
    table.print_table(brief=True)
    table.reset_table()
    return

def show_acl_table_extension_brief(args, args2):
    ''' Displays summary of all instance of type acl_table'''
    log_dbg(1, "In show_acl_table_brief method")

    try:
        rc, all_acl_table = args2.bulk_get_all_acl_table_keys()
    except:
        log_err(" Failed to get all acl_table")
        return

    table = PrintTable()
    field_names = []
    field_names.append('acl_table')

    field_names.append('match_profile')
    field_names.append('action_profile')
    field_names.append('direction')
    field_names.append('priority')
    field_names.append('size')
    field_names.append('usage')
    field_names.append('usage_per_ib')
    field_names.append('acl_count')
    field_names.append('actual_size')
    table.add_row(field_names)
    all_acl_table = sorted(all_acl_table)

    log("Total acl_table count: {0} ".format(len(all_acl_table)))
    count = 0
    for acl_table in all_acl_table:
        attr_row = []
        attr_row.append(args2.handle_to_str(acl_table))

        try:
            match_profile = args2.getMatchProfile(acl_table, True)
            action_profile = args2.getActionProfile(acl_table, True)
            direction = args2.getDirection(acl_table, True)
            priority = args2.getPriority(acl_table, True)
            size = args2.getSize(acl_table, True)
            usage = args2.getUsage(acl_table, True)
            usage_per_ib = args2.getUsagePerIb(acl_table, True)
            acl_count = args2.getAclCount(acl_table, True)
            actual_size = args2.getActualSize(acl_table, True)

        except KeyError:
            einfo = "{}".format(sys.exc_info())
            log_dbg(
                1,
                "KeyError in show acl_table brief. acl_table: {}, error: {}"
                .format(args2.handle_to_str(acl_table), einfo))
            if args2.not_found_exc_msg.format(
                    args2.cli.ifcs_ctypes.IFCS_NOTFOUND) in einfo:
                # Skip the instance as the object is not found.
                continue
            # Re-raise other exceptions for handling.
            raise
        attr_row.append('N/A' if match_profile is None else args2.
                        handle_to_str(match_profile))
        attr_row.append('N/A' if action_profile is None else args2.
                        handle_to_str(action_profile))
        attr_row.append('N/A' if direction is None else args2.
                        enum_to_str('direction', direction))
        attr_row.append('N/A' if priority is None else str(priority))
        attr_row.append('N/A' if size is None else str(size))
        attr_row.append('N/A' if usage is None else str(usage))
        attr_row.append(
            'N/A' if usage_per_ib is None else str(usage_per_ib))
        attr_row.append('N/A' if acl_count is None else str(acl_count))
        attr_row.append('N/A' if actual_size is None else str(actual_size))

        table.add_row(attr_row)
        count += 1

    table.print_table(brief=True)
    table.reset_table()
    log("Total acl_table count: {0}".format(count))

#get single attr value for acl table
def get_acl_table_attr(acl_table, handle, req_attr):
    ''' Method to get signle acl_table attribute for a single acl_table'''
    log_dbg(1, "In acl_table show attrs for : " + str(handle))

    if not handle:
        return

    attrCount = ifcs_ctypes.IFCS_ACL_TABLE_ATTR_COUNT_GET_ALL

    attr = (ifcs_ctypes.ifcs_attr_t * attrCount)()
    attr_p = compat_pointer(attr, ifcs_ctypes.ifcs_attr_t)

    try:
        actual_count = acl_table.getAttr(handle, attr, attr_p, attrCount, True)

    except KeyError:
        einfo = "{}".format(sys.exc_info())
        log_dbg(
            1, "KeyError in get acl_table attrs. acl_table: {}, error: {}".
            format(handle, einfo))
        if acl_table.not_found_exc_msg.format(
                ifcs_ctypes.IFCS_NOTFOUND) in einfo:
            # Don't display error message for expected exception.
            # Re-raise for handling.
            return None
        log_err("Failed to get attributes for acl_table ")
        raise
    except:
        log_dbg(
            1,
            "OtherError in get acl_table attrs. acl_table: {}, error: {}".
            format(handle, sys.exc_info()))
        log_err("Failed to get attributes for acl_table ")
        raise KeyError

    for j in range(actual_count.value):
        attr_name, attr_type, attr_val, attr_valid = acl_table.get_attr_name_value(
            attr[j])
        if not attr_valid:
            continue

        if attr_name == req_attr:
            return attr_val

    return None
