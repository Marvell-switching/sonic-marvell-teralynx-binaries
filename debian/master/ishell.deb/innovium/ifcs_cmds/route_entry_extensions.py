
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
# *-----------------------------------------------------------------------------
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.cli_types import *
from itertools import *
from time import *
from utils.compat_util import *
from verbosity import log, log_dbg
from ifcs_cmds.route_entry import *
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']


def show_route_entry_extension_brief(args, route_entry):

    def myCallback(node_id, str_val, user_data):
        str_disp = str(str_val.decode())
        log(str_disp.rstrip())

    log_dbg(1, " Inside route_entry extension brief show")
    callback_type = CFUNCTYPE(ifcs_ctypes.UNCHECKED(None),
                              ifcs_ctypes.ifcs_node_id_t, c_char_p,
                              POINTER(None))
    callback = callback_type(myCallback)
    callback_p = compat_funcPointer(
        callback, ifcs_ctypes.im_route_entry_util_cli_helper_user_cb_t)

    if args:
        rc = ifcs_ctypes.im_route_entry_util_cli_helper(route_entry.cli.node_id,
                                                        args, callback_p, None,
                                                        None)
    else:
        rc = ifcs_ctypes.im_route_entry_util_cli_helper(route_entry.cli.node_id,
                                                        None, callback_p, None,
                                                        None)
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get all route_entry rc: {}".format(
            route_entry.status_to_string(rc)))
    log("")
    return


def show_route_entry_extension_usage_helper(route_entry, filter_option):
    usage_p = ifcs_ctypes.ifcs_usage_t()

    if filter_option not in ['v4_prefix', 'v6_prefix', 'v4_host', 'v6_host', 'v4_fallback', 'v6_fallback',
                             'srp2', 'srp1', 'pth','v4_l3vni_override','v6_l3vni_override']:
        log_err("Invalid filter option {0}".format(filter_option))
        return

    ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))

    if 'v4' in filter_option:
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)
    else: # v6 filter
        ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_key = ifcs_ctypes.ifcs_route_entry_key_t()
    ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_key))
    if 'fallback' in filter_option:
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))
    elif 'l3vni_override' in filter_option:
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI_OVERRIDE)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_override_set(pointer(route_key), route_key.key.ip_dest_l3vni_override)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_override_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni_override), pointer(ip_dest))
    else: # IP_DEST_L3VNI
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))

    attr = ifcs_ctypes.ifcs_attr_t()
    ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)

    if 'prefix' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX)
    elif 'host' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST)
    elif 'srp2' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP2)
    elif 'srp1' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP1)
    elif 'pth' in filter_option:
        ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), ifcs_ctypes.IFCS_USAGE_GET_TYPE_PTH)

    if 'fallback' in filter_option or 'l3vni_override' in filter_option:
        rc = ifcs_ctypes.ifcs_route_entry_usage_get(0, pointer(route_key), 0, None, pointer(usage_p))
    else:
        rc = ifcs_ctypes.ifcs_route_entry_usage_get(0, pointer(route_key), 1, pointer(attr), pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get all {0} route_entry rc: {1}".format(filter_option,
                convert_error_code_to_string(rc)))
        return

    # If max is zero, we need not display it
    if usage_p.max == 0:
        return

    log("Usage for {0} route entries".format(filter_option))

    table = PrintTable()
    table.add_row(["Current", "Max"])
    table.add_row([usage_p.current, usage_p.max])
    table.print_table()
    table.reset_table()
    log("\n")

    return


def show_route_entry_extension_usage(arg1, arg2, route_entry):
    log_dbg(1, " Inside extension usage show")

    if route_entry.filter_option == {}:
        for filter_option in ['v4_prefix', 'v6_prefix', 'v4_host', 'v6_host', 'v4_fallback', 'v6_fallback', 'srp2', 'srp1', 'v4_l3vni_override', 'v6_l3vni_override']:
            show_route_entry_extension_usage_helper(route_entry, filter_option)
    else:
        filter_option = (route_entry.filter_option['filter']).strip()
        show_route_entry_extension_usage_helper(route_entry, filter_option)

    return

def get_node_attrs():
    fwd_profile = c_uint32()
    ht_update_enable = c_uint32()
    ilpm_update_enable = c_uint32()
    ltu_3x_count_attr_val = c_uint32()
    ilpm_enable = ifcs_ctypes.ifcs_bool_t()
    ext_l3vni_enable = ifcs_ctypes.ifcs_bool_t()

    actual_count = c_uint32()

    node_device_type = ifcs_ctypes.im_nmgr_node_device_type_get(0)
    if node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
        attr_count = 5
    else:
        attr_count = 6
    attrs = (ifcs_ctypes.ifcs_attr_t * attr_count)()

    for x in range(attr_count):
        ifcs_ctypes.ifcs_attr_t_init(compat_pointer(attrs[x], ifcs_ctypes.ifcs_attr_t))
    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointer(attrs[0], ifcs_ctypes.ifcs_attr_t),
                                   ifcs_ctypes.IFCS_NODE_ATTR_FORWARD_PROFILE)
    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointer(attrs[1], ifcs_ctypes.ifcs_attr_t),
                                   ifcs_ctypes.IFCS_NODE_ATTR_ILPM_ENABLE)
    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointer(attrs[2], ifcs_ctypes.ifcs_attr_t),
                                   ifcs_ctypes.IFCS_NODE_ATTR_EXTENDED_L3VNI_MODE_ENABLE)
    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointer(attrs[3], ifcs_ctypes.ifcs_attr_t),
                                   ifcs_ctypes.IFCS_NODE_ATTR_HT_UPDATE_ENABLE)
    ifcs_ctypes.ifcs_attr_t_id_set(compat_pointer(attrs[4], ifcs_ctypes.ifcs_attr_t),
                                   ifcs_ctypes.IFCS_NODE_ATTR_ILPM_UPDATE_ENABLE)
    if node_device_type != ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
        ifcs_ctypes.ifcs_attr_t_id_set(compat_pointer(attrs[5], ifcs_ctypes.ifcs_attr_t),
                                       ifcs_ctypes.IFCS_NODE_ATTR_IP_DEST_L3VNI_LTU_3X_MODE_COUNT)
    rc = ifcs_ctypes.ifcs_node_attr_get(0, attr_count, compat_pointer(attrs, ifcs_ctypes.ifcs_attr_t), pointer(actual_count))
    if (rc != ifcs_ctypes.IFCS_SUCCESS) or (attr_count != actual_count.value):
        log_err("Failed to get system parameters")
        return(None, None, None, None)

    #Forwarding profile
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointer(attrs[0], ifcs_ctypes.ifcs_attr_t), pointer(fwd_profile))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IFCS_NODE_ATTR_FORWARD_PROFILE")
        return(None, None, None, None, None)
    fwd_profile = fwd_profile.value

    #ILPM enabled
    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointer(attrs[1], ifcs_ctypes.ifcs_attr_t), pointer(ilpm_enable))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IFCS_NODE_ATTR_ILPM_ENABLE")
        return(fwd_profile, None, None, None, None)
    if ilpm_enable.value == ifcs_ctypes.IFCS_BOOL_TRUE:
        ilpm = True
    else:
        ilpm = False

    #Extended L3VNI
    rc = ifcs_ctypes.ifcs_attr_t_value_data_get(compat_pointer(attrs[2], ifcs_ctypes.ifcs_attr_t), pointer(ext_l3vni_enable))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IFCS_NODE_ATTR_EXTENDED_L3VNI_MODE_ENABLE")
        return(fwd_profile, ilpm_enable, None, None, None)
    if ext_l3vni_enable.value == ifcs_ctypes.IFCS_BOOL_TRUE:
        ext_l3vni = True
    else:
        ext_l3vni = False

    #HT Update Enable
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointer(attrs[3], ifcs_ctypes.ifcs_attr_t), pointer(ht_update_enable))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IFCS_NODE_ATTR_HT_UPDATE_ENABLE")
        return(fwd_profile, ilpm_enable, ext_l3vni, None, None)

    ht_update = ht_update_enable.value

    #ILPM Update Enable
    rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointer(attrs[4], ifcs_ctypes.ifcs_attr_t), pointer(ilpm_update_enable))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err("Failed to get IFCS_NODE_ATTR_ILPM_UPDATE_ENABLE")
        return(fwd_profile, ilpm_enable, ext_l3vni, ht_update, None)

    ilpm_update = ilpm_update_enable.value

    #LTU 3x count
    ltu_3x_count = 0
    if node_device_type == ifcs_ctypes.IM_NMGR_NODE_DEVICE_TYPE_TERALYNX:
        ltu_3x_count = 0
    else:
        rc = ifcs_ctypes.ifcs_attr_t_value_u32_get(compat_pointer(attrs[5], ifcs_ctypes.ifcs_attr_t), pointer(ltu_3x_count_attr_val))
        if rc != ifcs_ctypes.IFCS_SUCCESS:
            log_err("Failed to get IFCS_NODE_ATTR_IP_DEST_L3VNI_LTU_3X_MODE_COUNT")
            return(fwd_profile, ilpm_enable, ext_l3vni, ht_update, None)

        ltu_3x_count = ltu_3x_count_attr_val.value

    return(fwd_profile, ilpm, ext_l3vni, ht_update, ilpm_update, ltu_3x_count)

def get_usage_by_type(usage_type, addr_family):
    usage_p = ifcs_ctypes.ifcs_usage_t()

    ip_dest = ifcs_ctypes.ifcs_ip_prefix_t()
    ifcs_ctypes.ifcs_ip_prefix_t_init(pointer(ip_dest))
    ifcs_ctypes.ifcs_ip_prefix_t_addr_family_set(pointer(ip_dest), addr_family)

    route_key = ifcs_ctypes.ifcs_route_entry_key_t()
    ifcs_ctypes.ifcs_route_entry_key_t_init(pointer(route_key))

    if usage_type in [ifcs_ctypes.IFCS_USAGE_GET_TYPE_FALLBACK, ifcs_ctypes.IFCS_USAGE_GET_TYPE_FALLBACK_ATTR]:
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_ONLY)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_only_set(pointer(route_key), route_key.key.ip_dest_only)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_only_t_ip_dest_set(pointer(route_key.key.ip_dest_only), pointer(ip_dest))
    elif usage_type in [ifcs_ctypes.IFCS_USAGE_GET_TYPE_L3VNI_OVERRIDE, ifcs_ctypes.IFCS_USAGE_GET_TYPE_L3VNI_OVERRIDE_ATTR]:
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI_OVERRIDE)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_override_set(pointer(route_key), route_key.key.ip_dest_l3vni_override)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_override_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni_override), pointer(ip_dest))
    else: # IP_DEST_L3VNI
        ifcs_ctypes.ifcs_route_entry_key_t_key_type_set(pointer(route_key), ifcs_ctypes.IFCS_ROUTE_ENTRY_KEY_TYPE_IP_DEST_L3VNI)
        ifcs_ctypes.ifcs_route_entry_key_t_ip_dest_l3vni_set(pointer(route_key), route_key.key.ip_dest_l3vni)
        ifcs_ctypes.ifcs_route_entry_key_ip_dest_l3vni_t_ip_dest_set(pointer(route_key.key.ip_dest_l3vni), pointer(ip_dest))

    attr = ifcs_ctypes.ifcs_attr_t()
    ifcs_ctypes.ifcs_attr_t_id_set(pointer(attr), ifcs_ctypes.IFCS_ROUTE_ENTRY_ATTR_USAGE_GET_ROUTE_TYPE)
    ifcs_ctypes.ifcs_attr_t_value_u32_set(pointer(attr), usage_type)

    rc = ifcs_ctypes.ifcs_route_entry_usage_detail_get(
        0, pointer(route_key), 1, pointer(attr), pointer(usage_p))
    if rc != ifcs_ctypes.IFCS_SUCCESS:
        log_err(
            "Failed to get {0} counters rc: {1}".format(usage_type, convert_error_code_to_string(rc)))
        return (0, 0)

    return (usage_p.current, usage_p.max, usage_p.available)

def init_usage_dict(route_usage, fwd_profile):
    # V4 Host
    route_usage['current']['host']['v4']['noattr'], route_usage['max']['host']['v4']['noattr'], \
    route_usage['available']['host']['v4']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['host']['v4']['attr'], route_usage['max']['host']['v4']['attr'], \
        route_usage['available']['host']['v4']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    # V4 Host (TCAM)
    route_usage['current']['host_tcam']['v4']['noattr'], route_usage['max']['host_tcam']['v4']['noattr'], \
        route_usage['available']['host_tcam']['v4']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST_TCAM, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['host_tcam']['v4']['attr'], route_usage['max']['host_tcam']['v4']['attr'], \
        route_usage['available']['host_tcam']['v4']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST_TCAM_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    # V6 Host
    route_usage['current']['host']['v6']['noattr'], route_usage['max']['host']['v6']['noattr'], \
        route_usage['available']['host']['v6']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['host']['v6']['attr'], route_usage['max']['host']['v6']['attr'], \
        route_usage['available']['host']['v6']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # V6 Host (TCAM)
    route_usage['current']['host_tcam']['v6']['noattr'], route_usage['max']['host_tcam']['v6']['noattr'], \
        route_usage['available']['host_tcam']['v6']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST_TCAM, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['host_tcam']['v6']['attr'], route_usage['max']['host_tcam']['v6']['attr'], \
        route_usage['available']['host_tcam']['v6']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_HOST_TCAM_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # V4 Prefix
    route_usage['current']['prefix']['v4']['noattr'], route_usage['max']['prefix']['v4']['noattr'], \
        route_usage['available']['prefix']['v4']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['prefix']['v4']['attr'], route_usage['max']['prefix']['v4']['attr'], \
        route_usage['available']['prefix']['v4']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    # V6 Prefix (Narrow)
    route_usage['current']['prefix']['v6']['noattr'], route_usage['max']['prefix']['v6']['noattr'], \
        route_usage['available']['prefix']['v6']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['prefix']['v6']['attr'], route_usage['max']['prefix']['v6']['attr'], \
        route_usage['available']['prefix']['v6']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # V6 Prefix (Wide)
    route_usage['current']['prefix_wide']['v6']['noattr'], route_usage['max']['prefix_wide']['v6']['noattr'], \
        route_usage['available']['prefix_wide']['v6']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX_V6_WIDE, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['prefix_wide']['v6']['attr'], route_usage['max']['prefix_wide']['v6']['attr'], \
        route_usage['available']['prefix_wide']['v6']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_PREFIX_V6_WIDE_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # V4 Fallback
    route_usage['current']['fallback']['v4']['noattr'], route_usage['max']['fallback']['v4']['noattr'], \
        route_usage['available']['fallback']['v4']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_FALLBACK, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['fallback']['v4']['attr'], route_usage['max']['fallback']['v4']['attr'], \
        route_usage['available']['fallback']['v4']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_FALLBACK_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    # V6 Fallback
    route_usage['current']['fallback']['v6']['noattr'], route_usage['max']['fallback']['v6']['noattr'], \
        route_usage['available']['fallback']['v6']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_FALLBACK, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['fallback']['v6']['attr'], route_usage['max']['fallback']['v6']['attr'], \
        route_usage['available']['fallback']['v6']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_FALLBACK_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # V4 L3vni Override
    route_usage['current']['l3vni_override']['v4']['noattr'], route_usage['max']['l3vni_override']['v4']['noattr'], \
        route_usage['available']['l3vni_override']['v4']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_L3VNI_OVERRIDE, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['l3vni_override']['v4']['attr'], route_usage['max']['l3vni_override']['v4']['attr'], \
        route_usage['available']['l3vni_override']['v4']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_L3VNI_OVERRIDE_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    # V6 L3vni Override
    route_usage['current']['l3vni_override']['v6']['noattr'], route_usage['max']['l3vni_override']['v6']['noattr'], \
        route_usage['available']['l3vni_override']['v6']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_L3VNI_OVERRIDE, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['l3vni_override']['v6']['attr'], route_usage['max']['l3vni_override']['v6']['attr'], \
        route_usage['available']['l3vni_override']['v6']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_L3VNI_OVERRIDE_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # SRP1
    route_usage['current']['srp1']['noattr'], route_usage['max']['srp1']['noattr'], \
        route_usage['available']['srp1']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP1, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['srp1']['attr'], route_usage['max']['srp1']['attr'], \
        route_usage['available']['srp1']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP1_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # SRP2
    route_usage['current']['srp2']['noattr'], route_usage['max']['srp2']['noattr'], \
        route_usage['available']['srp2']['noattr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP2, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['srp2']['attr'], route_usage['max']['srp2']['attr'], \
        route_usage['available']['srp2']['attr'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRP2_ATTR, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # TCAM slots
    route_usage['current']['tcam_slots']['narrow']['v4'], route_usage['max']['tcam_slots']['narrow']['v4'], \
        route_usage['available']['tcam_slots']['narrow']['v4'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_NARROW, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['tcam_slots']['narrow']['v6'], route_usage['max']['tcam_slots']['narrow']['v6'], \
        route_usage['available']['tcam_slots']['narrow']['v6'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_NARROW, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['tcam_slots']['wide'], route_usage['max']['tcam_slots']['wide'], \
        route_usage['available']['tcam_slots']['wide'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_WIDE, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['tcam_slots']['fallback'], route_usage['max']['tcam_slots']['fallback'], \
        route_usage['available']['tcam_slots']['fallback'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_NARROW, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    # Fallback TCAM slots
    route_usage['current']['fallback_tcam_slots']['narrow']['v4'], \
    route_usage['max']['fallback_tcam_slots']['narrow']['v4'], \
    route_usage['available']['fallback_tcam_slots']['narrow']['v4'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_NARROW, \
                            ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['fallback_tcam_slots']['narrow']['v6'], \
    route_usage['max']['fallback_tcam_slots']['narrow']['v6'], \
    route_usage['available']['fallback_tcam_slots']['narrow']['v6'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_NARROW, \
                            ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    route_usage['current']['fallback_tcam_slots']['wide'], \
    route_usage['max']['fallback_tcam_slots']['wide'], \
    route_usage['available']['fallback_tcam_slots']['wide'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_TCAM_SLOTS_FALLBACK_WIDE, \
                            ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # SRAM slots
    route_usage['current']['sram_slots']['narrow'], route_usage['max']['sram_slots']['narrow'], \
        route_usage['available']['sram_slots']['narrow'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_SLOTS_NARROW, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['sram_slots']['wide'], route_usage['max']['sram_slots']['wide'], \
        route_usage['available']['sram_slots']['wide'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_SLOTS_WIDE, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    # SRAM buckets
    route_usage['current']['sram_buckets']['narrow'], route_usage['max']['sram_buckets']['narrow'], \
        route_usage['available']['sram_buckets']['narrow'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_BUCKETS_NARROW, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV4)

    route_usage['current']['sram_buckets']['wide'], route_usage['max']['sram_buckets']['wide'], \
        route_usage['available']['sram_buckets']['wide'] \
        = get_usage_by_type(ifcs_ctypes.IFCS_USAGE_GET_TYPE_SRAM_BUCKETS_WIDE, ifcs_ctypes.IFCS_IP_ADDR_FAMILY_IPV6)

    return

def get_rg_used_count_1x(route_usage, route_wt, rg):
    current_count = 0

    if rg == 1:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['host_tcam']['v4'][attr] * route_wt['host_tcam']['v4'][attr]) + \
                (route_usage['current']['prefix']['v4'][attr] * route_wt['prefix']['v4'][attr]) + \
                (route_usage['current']['prefix']['v6'][attr] * route_wt['prefix']['v6'][attr])

    elif rg == 2:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['host']['v4'][attr] * route_wt['host']['v4'][attr]) + \
                (route_usage['current']['host']['v6'][attr] * route_wt['host']['v6'][attr])

    elif rg == 3:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['fallback']['v4'][attr] * route_wt['fallback']['v4'][attr]) + \
                (route_usage['current']['fallback']['v6'][attr] * route_wt['fallback']['v6'][attr])

    elif rg == 4:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['srp1'][attr] * route_wt['srp1'][attr])

    elif rg == 5:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['srp2'][attr] * route_wt['srp2'][attr])

    elif rg == 6:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['host_tcam']['v6'][attr] * route_wt['host_tcam']['v6'][attr]) + \
                (route_usage['current']['prefix_wide']['v6'][attr] * route_wt['prefix_wide']['v6'][attr])

    # Keeping the L3VNI override entries in resource group 7 (a separate resource) because
    # the reserved space does not interfere with other resource groups.
    elif rg == 7:
        for attr in ['attr', 'noattr']:
            current_count += (route_usage['current']['l3vni_override']['v4'][attr] * route_wt['l3vni_override']['v4'][attr]) + \
                (route_usage['current']['l3vni_override']['v6'][attr] * route_wt['l3vni_override']['v6'][attr])

    return (current_count)

def init_soft_min():
    # Subkey value False/True is for extl3vni
    soft_min = {
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_C):
        {
            'host': {
                False: {
                    'v4': {'attr': '47000', 'noattr': '47000'},
                    'v6': {'attr': '11000', 'noattr': '18000'}
                },
                True: {
                    'v4': {'attr': '47000', 'noattr': '47000'},
                    'v6': {'attr': '9000', 'noattr': '9000'}
                }
            },
            'host_tcam': {
                False: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                },
                True: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                }
            },
            'prefix': {
                False: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'prefix_wide': {
                False: {'v6': {'attr': '115', 'noattr': '115'}},
                True: {'v6': {'attr': '115', 'noattr': '115'}}
            },
            'fallback': {
                False: {
                    'v4': {'attr': 'NA', 'noattr': 'NA'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': 'NA', 'noattr': 'NA'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'srp1': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            },
            'srp2': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            }
        },

        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_G):
        {
            'host': {
                False: {
                    'v4': {'attr': '47000', 'noattr': '47000'},
                    'v6': {'attr': '11000', 'noattr': '18000'}
                },
                True: {
                    'v4': {'attr': '47000', 'noattr': '47000'},
                    'v6': {'attr': '9000', 'noattr': '9000'}
                }
            },
            'host_tcam': {
                False: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                },
                True: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                }
            },
            'prefix': {
                False: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'prefix_wide': {
                False: {'v6': {'attr': '115', 'noattr': '115'}},
                True: {'v6': {'attr': '115', 'noattr': '115'}}
            },
            'fallback': {
                False: {
                    'v4': {'attr': '8192', 'noattr': '8192'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '8192', 'noattr': '8192'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'srp1': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            },
            'srp2': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            }
        },

        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_K):
        {
            'host': {
                False: {
                    'v4': {'attr': '23000', 'noattr': '23000'},
                    'v6': {'attr': '8000', 'noattr': '9000'}
                },
                True: {
                    'v4': {'attr': '23000', 'noattr': '23000'},
                    'v6': {'attr': '5000', 'noattr': '5000'}
                }
            },
            'host_tcam': {
                False: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                },
                True: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                }
            },
            'prefix': {
                False: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'prefix_wide': {
                False: {'v6': {'attr': '115', 'noattr': '115'}},
                True: {'v6': {'attr': '115', 'noattr': '115'}}
            },
            'fallback': {
                False: {
                    'v4': {'attr': '8192', 'noattr': '8192'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '8192', 'noattr': '8192'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'srp1': {
                False: {'attr': '5000', 'noattr': '5000'},
                True: {'attr': '5000', 'noattr': '5000'}
            },
            'srp2': {
                False: {'attr': '5000', 'noattr': '9000'},
                True: {'attr': '5000', 'noattr': '5000'}
            }
        },

        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_M):
        {
            'host': {
                False: {
                    'v4': {'attr': '23000', 'noattr': '23000'},
                    'v6': {'attr': '8000', 'noattr': '9000'}
                },
                True: {
                    'v4': {'attr': '23000', 'noattr': '23000'},
                    'v6': {'attr': '5000', 'noattr': '5000'}
                }
            },
            'host_tcam': {
                False: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                },
                True: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                }
            },
            'prefix': {
                False: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '110000', 'noattr': '255000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'prefix_wide': {
                False: {'v6': {'attr': '115', 'noattr': '115'}},
                True: {'v6': {'attr': '115', 'noattr': '115'}}
            },
            'fallback': {
                False: {
                    'v4': {'attr': 'NA', 'noattr': 'NA'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': 'NA', 'noattr': 'NA'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'srp1': {
                False: {'attr': '5000', 'noattr': '5000'},
                True: {'attr': '5000', 'noattr': '5000'}
            },
            'srp2': {
                False: {'attr': '5000', 'noattr': '9000'},
                True: {'attr': '5000', 'noattr': '5000'}
            }
        },

        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_N):
        {
            'host': {
                False: {
                    'v4': {'attr': '47000', 'noattr': '47000'},
                    'v6': {'attr': '11000', 'noattr': '18000'}
                },
                True: {
                    'v4': {'attr': '47000', 'noattr': '47000'},
                    'v6': {'attr': '9000', 'noattr': '9000'}
                }
            },
            'host_tcam': {
                False: {
                    'v4': {'attr': '4096', 'noattr': '8192'},
                    'v6': {'attr': '115', 'noattr': '115'}
                },
                True: {
                    'v4': {'attr': '4096', 'noattr': '8192'},
                    'v6': {'attr': '115', 'noattr': '115'}
                }
            },
            'prefix': {
                False: {
                    'v4': {'attr': '4096', 'noattr': '8192'},
                    'v6': {'attr': '2048', 'noattr': '4096'}
                },
                True: {
                    'v4': {'attr': '4096', 'noattr': '8192'},
                    'v6': {'attr': '2048', 'noattr': '4096'}
                }
            },
            'prefix_wide': {
                False: {'v6': {'attr': '115', 'noattr': '115'}},
                True: {'v6': {'attr': '115', 'noattr': '115'}}
            },
            'fallback': {
                False: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '70000', 'noattr': '140000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'srp1': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            },
            'srp2': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            }
        },

        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_P):
        {
            'host': {
                False: {
                    'v4': {'attr': '23000', 'noattr': '23000'},
                    'v6': {'attr': '8000', 'noattr': '9000'}
                },
                True: {
                    'v4': {'attr': '23000', 'noattr': '23000'},
                    'v6': {'attr': '5000', 'noattr': '5000'}
                }
            },
            'host_tcam': {
                False: {
                    'v4': {'attr': '150000', 'noattr': '300000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                },
                True: {
                    'v4': {'attr': '150000', 'noattr': '300000'},
                    'v6': {'attr': '115', 'noattr': '115'}
                }
            },
            'prefix': {
                False: {
                    'v4': {'attr': '150000', 'noattr': '300000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': '150000', 'noattr': '300000'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'prefix_wide': {
                False: {'v6': {'attr': '115', 'noattr': '115'}},
                True: {'v6': {'attr': '115', 'noattr': '115'}}
            },
            'fallback': {
                False: {
                    'v4': {'attr': 'NA', 'noattr': 'NA'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                },
                True: {
                    'v4': {'attr': 'NA', 'noattr': 'NA'},
                    'v6': {'attr': 'NA', 'noattr': 'NA'}
                }
            },
            'srp1': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            },
            'srp2': {
                False: {'attr': 'NA', 'noattr': 'NA'},
                True: {'attr': 'NA', 'noattr': 'NA'}
            }
        }
    }

    return soft_min

def init_v6_prefix_row_title():
    v6_row_title_dict = {
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_C): {
            1: {True: '<=64', False: '<=64'},
            6: {True: '>64', False: '>64'}
        },
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_G): {
            1: {True: '<=64', False: '<=64'},
            6: {True: '>64', False: '>64'}
        },
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_K): {
            1: {True: '<=77', False: '<=80'},
            6: {True: '>77', False: '>80'}
        },
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_M): {
            1: {True: '<=77', False: '<=80'},
            6: {True: '>77', False: '>80'}
        },
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_N): {
            1: {True: '<=77', False: '<=80'},
            6: {True: '>77', False: '>80'}
        },
        str(ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_P): {
            1: {True: '<=77', False: '<=80'},
            6: {True: '>77', False: '>80'}
        }
    }

    return(v6_row_title_dict)

def get_v6_prefix_width(v6_wide_title, fwd_profile, rg, ext_l3vni_enable):
    fwd_profile = str(fwd_profile)
    try:
        subtitle = v6_wide_title[fwd_profile][rg][ext_l3vni_enable]
    except:
        if rg == 1:
            subtitle = '<=64'
        else:
            subtitle = '>64'
    return subtitle

def get_v6_prefix_row_title(v6_wide_title, fwd_profile, rg, ext_l3vni_enable):
    subtitle = get_v6_prefix_width(v6_wide_title, fwd_profile, rg, ext_l3vni_enable)
    return('V6 PREFIX (' + subtitle + ')')

def get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, addr_family, attr):

    if addr_family == 'v4' and route_type in ['prefix', 'host_tcam']:
        if ilpm_update_enable != ifcs_ctypes.IFCS_ILPM_UPDATE_EN_DEPTH:
            return('NA')
    elif addr_family == 'v6' and route_type == 'prefix':
        if ilpm_update_enable != ifcs_ctypes.IFCS_ILPM_UPDATE_EN_DEPTH:
            return('NA')
    elif addr_family == 'v6' and route_type in ['prefix_wide', 'host_tcam']:
        if ltu_3x_count > 0:
            return('NA')

    if route_type == 'srp2':
        if ht_update_enable not in [ifcs_ctypes.IFCS_HT_UPDATE_EN_T1, ifcs_ctypes.IFCS_HT_UPDATE_EN_ALL]:
            return('NA')
    elif route_type == 'srp1':
        if ht_update_enable not in [ifcs_ctypes.IFCS_HT_UPDATE_EN_T2, ifcs_ctypes.IFCS_HT_UPDATE_EN_ALL]:
            return('NA')
    elif route_type == 'host':
        if ht_update_enable not in [ifcs_ctypes.IFCS_HT_UPDATE_EN_T3, ifcs_ctypes.IFCS_HT_UPDATE_EN_ALL]:
            return('NA')

    fwd_profile = str(fwd_profile)

    try:
        if addr_family == None:
            val = soft_min[fwd_profile][route_type][ext_l3vni_enable][attr]
        else:
            val = soft_min[fwd_profile][route_type][ext_l3vni_enable][addr_family][attr]
    except:
        val = 'NA'

    return val

def init_route_wt(fwd_profile, ext_l3vni_enable):
    route_wt = {
        'host': {
            'v4': {'attr': 1, 'noattr': 1},
            'v6': {'attr': 3, 'noattr': 2}
        },
        'host_tcam': {
            'v4': {'attr': 2, 'noattr': 1},
            'v6': {'attr': 2, 'noattr': 1}
        },
        'prefix': {
            'v4': {'attr': 2, 'noattr': 1},
            'v6': {'attr': 4, 'noattr': 2}
        },
        'prefix_wide': {
            'v6': {'attr': 2, 'noattr': 1}
        },
        'fallback': {
            'v4': {'attr': 1, 'noattr': 1},
            'v6': {'attr': 2, 'noattr': 2}
        },
        'l3vni_override': {
            'v4': {'attr': 1, 'noattr': 1},
            'v6': {'attr': 1, 'noattr': 1}
        },
        'srp1': {'attr': 2, 'noattr': 2},
        'srp2': {'attr': 3, 'noattr': 2}
    }

    if ext_l3vni_enable == True:
        # TODO - update this block - SRP1 & 2
        route_wt['host']['v6']['attr'] = 3
        route_wt['host']['v6']['noattr'] = 3

    if fwd_profile == ifcs_ctypes.IFCS_FORWARD_PROFILE_ID_PROFILE_N:
        route_wt['fallback']['v4']['attr'] = 2
        route_wt['fallback']['v6']['attr'] = 4

    return route_wt

def print_rg_table(route_usage, route_wt, soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, rg, ext_l3vni_enable, v6_prefix_title, filter_key):
    used_1x = 0
    log("Resource Group {0}".format(str(rg)))

    table = PrintTable()
    table.set_justification("left")

    table.add_row(["Type", "Comfortable Min", "Current", "Free", "Max"])

    if rg == 1:
        #used_1x = get_rg_used_count_1x(route_usage, route_wt, rg)

        for route_type in ['host_tcam', 'prefix']:
            for addr_family in ['v4', 'v6']:
                if filter_key != None:
                    if (filter_key[0] != route_type.split('_')[0]) or (filter_key[1] != addr_family):
                        continue

                if route_type == 'host_tcam' and addr_family == 'v6':
                    continue # This combination is part of RG6

                for attr in ['attr', 'noattr']:
                    smin = get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, addr_family, attr)
                    used_count = route_usage['current'][route_type][addr_family][attr]
                    max_count = route_usage['max'][route_type][addr_family][attr]
                    #free_count = max(0, int(max_count - (used_1x / route_wt[route_type][addr_family][attr])))
                    free_count = route_usage['available'][route_type][addr_family][attr]

                    if route_type == 'prefix' and addr_family == 'v6':
                        row_title = get_v6_prefix_row_title(v6_prefix_title, fwd_profile, rg, ext_l3vni_enable)
                    else:
                        row_title = addr_family.upper() + " " + route_type.upper()

                    if attr == 'attr':
                        row_title += ' (Attr set)'
                    else:
                        row_title += ' (No Attr)'

                    table.add_row([row_title, smin, used_count, free_count, max_count])

    elif rg == 2:
        #used_1x = get_rg_used_count_1x(route_usage, route_wt, rg)

        route_type = 'host'
        for addr_family in ['v4', 'v6']:
            for attr in ['attr', 'noattr']:
                if filter_key != None:
                    if (filter_key[0] != route_type) or (filter_key[1] != addr_family):
                        continue

                smin = get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, addr_family, attr)
                used_count = route_usage['current'][route_type][addr_family][attr]
                max_count = route_usage['max'][route_type][addr_family][attr]
                #free_count = max(0, int(max_count - (used_1x / route_wt[route_type][addr_family][attr])))
                free_count = route_usage['available'][route_type][addr_family][attr]

                row_title = addr_family.upper() + ' '  + route_type.upper()
                if attr == 'attr':
                    row_title += ' (Attr set)'
                else:
                    row_title += ' (No Attr)'

                table.add_row([row_title, smin, used_count, free_count, max_count])

    elif rg == 3:
        used_1x = get_rg_used_count_1x(route_usage, route_wt, rg)

        route_type = 'fallback'
        for addr_family in ['v4', 'v6']:
            for attr in ['attr', 'noattr']:
                if filter_key != None:
                    if (filter_key[0] != route_type) or (filter_key[1] != addr_family):
                        continue

                smin = get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, addr_family, attr)
                used_count = route_usage['current'][route_type][addr_family][attr]
                max_count = route_usage['max'][route_type][addr_family][attr]
                free_count = max(0, int(max_count - (used_1x / route_wt[route_type][addr_family][attr])))

                row_title = addr_family.upper() + ' '  + route_type.upper()
                if attr == 'attr':
                    row_title += ' (Attr set)'
                else:
                    row_title += ' (No Attr)'

                table.add_row([row_title, smin, used_count, free_count, max_count])

    elif rg in [4, 5]:
        used_1x = get_rg_used_count_1x(route_usage, route_wt, rg)

        route_type = 'srp1'
        if rg == 5:
            route_type = 'srp2'

        for attr in ['attr', 'noattr']:
            smin = get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, None, attr)
            used_count = route_usage['current'][route_type][attr]
            max_count = route_usage['max'][route_type][attr]
            free_count = max(0, int(max_count - (used_1x / route_wt[route_type][attr])))

            row_title = route_type.upper()
            if attr == 'attr':
                row_title += ' (Attr set)'
            else:
                row_title += ' (No Attr)'

            table.add_row([row_title, smin, used_count, free_count, max_count])

    elif rg == 6:
        used_1x = get_rg_used_count_1x(route_usage, route_wt, rg)

        for route_type in ['host_tcam', 'prefix_wide']:
            addr_family = 'v6'

            if filter_key != None:
                if (filter_key[0] != route_type.split('_')[0]) or (filter_key[1] != addr_family):
                    continue
            for attr in ['attr', 'noattr']:
                smin = get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, addr_family, attr)
                used_count = route_usage['current'][route_type][addr_family][attr]
                max_count = route_usage['max'][route_type][addr_family][attr]
                free_count = max(0, int(max_count - (used_1x / route_wt[route_type][addr_family][attr])))
                row_title = addr_family.upper() + " " + route_type.upper()

                if route_type == 'prefix_wide' and addr_family == 'v6':
                    row_title = get_v6_prefix_row_title(v6_prefix_title, fwd_profile, rg, ext_l3vni_enable)
                else:
                    row_title = addr_family.upper() + " " + route_type.upper()

                if attr == 'attr':
                    row_title += ' (Attr set)'
                else:
                    row_title += ' (No Attr)'

                table.add_row([row_title, smin, used_count, free_count, max_count])

    elif rg == 7:
        #used_1x = get_rg_used_count_1x(route_usage, route_wt, rg)

        route_type = 'l3vni_override'
        for addr_family in ['v4', 'v6']:
            for attr in ['attr', 'noattr']:
                if filter_key != None:
                    if (filter_key[0] != route_type) or (filter_key[1] != addr_family):
                        continue

                smin = get_soft_min(soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, ext_l3vni_enable, route_type, addr_family, attr)
                used_count = route_usage['current'][route_type][addr_family]['attr'] + route_usage['current'][route_type][addr_family]['noattr']
                max_count = route_usage['max'][route_type][addr_family][attr]
                free_count = max(0, int(max_count - (used_count / route_wt[route_type][addr_family][attr])))

                row_title = addr_family.upper() + ' '  + route_type.upper()
                if attr == 'attr':
                    row_title += ' (Attr set)'
                else:
                    row_title += ' (No Attr)'

                table.add_row([row_title, smin, used_count, free_count, max_count])

    table.print_table()

def print_hw_resource_table(route_usage, v6_wide_title, fwd_profile, ext_l3vni_enable):
    subtitle = get_v6_prefix_width(v6_wide_title, fwd_profile, 1, ext_l3vni_enable)

    # TCAM slots - narrow
    table = PrintTable()
    table.set_justification("left")

    table.add_row(["Type", "Current", "Free", "Max"])

    table.add_row(['Narrow TCAM V4 slots ('+ subtitle + ')', route_usage['current']['tcam_slots']['narrow']['v4'], \
        route_usage['available']['tcam_slots']['narrow']['v4'],
        route_usage['max']['tcam_slots']['narrow']['v4']])

    table.add_row(['Narrow TCAM V6 slots (' + subtitle +')', route_usage['current']['tcam_slots']['narrow']['v6'], \
        route_usage['available']['tcam_slots']['narrow']['v6'], 
        route_usage['max']['tcam_slots']['narrow']['v6']])

    log("\nNarrow TCAM slots")
    table.print_table()

    # TCAM slots - wide
    subtitle = get_v6_prefix_width(v6_wide_title, fwd_profile, 6, ext_l3vni_enable)
    table = PrintTable()
    table.set_justification("left")

    table.add_row(["Type", "Current", "Free", "Max"])

    table.add_row(['Wide TCAM slots (' + subtitle + ')', route_usage['current']['tcam_slots']['wide'], \
        route_usage['available']['tcam_slots']['wide'], \
        route_usage['max']['tcam_slots']['wide']])

    log("\nWide TCAM slots")
    table.print_table()

    # Fallback TCAM slots - narrow
    subtitle = get_v6_prefix_width(v6_wide_title, fwd_profile, 1,
                                   ext_l3vni_enable)
    table = PrintTable()
    table.set_justification("left")

    table.add_row(["Type", "Current", "Free", "Max"])

    table.add_row(['Fallback Narrow TCAM V4 slots', \
        route_usage['current']['fallback_tcam_slots']['narrow']['v4'], \
        route_usage['available']['fallback_tcam_slots']['narrow']['v4'], \
        route_usage['max']['fallback_tcam_slots']['narrow']['v4']])

    table.add_row(['Fallback Narrow TCAM V6 slots (' + subtitle + ')', \
        route_usage['current']['fallback_tcam_slots']['narrow']['v6'], \
        route_usage['available']['fallback_tcam_slots']['narrow']['v6'], \
        route_usage['max']['fallback_tcam_slots']['narrow']['v6']])

    log("\nFallback narrow TCAM slots")
    table.print_table()

    # Fallback TCAM slots - wide
    table = PrintTable()
    table.set_justification("left")

    subtitle = get_v6_prefix_width(v6_wide_title, fwd_profile, 6,
                                   ext_l3vni_enable)

    table.add_row(["Type", "Current", "Free", "Max"])

    table.add_row(['Fallback Wide TCAM V6 slots (' + subtitle + ')', \
        route_usage['current']['fallback_tcam_slots']['wide'], \
        route_usage['available']['fallback_tcam_slots']['wide'], \
        route_usage['max']['fallback_tcam_slots']['wide']])

    log("\nFallback wide TCAM slots")
    table.print_table()

    # SRAM slots/buckets
    table = PrintTable()
    table.set_justification("left")

    table.add_row(["Type", "Current", "Free", "Max"])

    table.add_row(['Narrow SRAM slots', route_usage['current']['sram_slots']['narrow'], \
        route_usage['available']['sram_slots']['narrow'], \
        route_usage['max']['sram_slots']['narrow']])

    table.add_row(['Wide SRAM slots', route_usage['current']['sram_slots']['wide'], \
        route_usage['available']['sram_slots']['wide'], \
        route_usage['max']['sram_slots']['wide']])

    table.add_row(['Narrow SRAM buckets', route_usage['current']['sram_buckets']['narrow'], \
        route_usage['available']['sram_buckets']['narrow'], \
        route_usage['max']['sram_buckets']['narrow']])

    table.add_row(['Wide SRAM buckets', route_usage['current']['sram_buckets']['wide'], \
        route_usage['available']['sram_buckets']['wide'], \
        route_usage['max']['sram_buckets']['wide']])

    log("\nSRAM slots & buckets")
    table.print_table()

def print_footer():
    log("NOTE:")
    log("\tEach resource group includes all classes of routes that share common hardware resources.\n"
        "\tFree count for each class of route in a resource group is affected by all route entries present in that group.\n"
        "\n"
        "\tHardware resources for route entry are also shared with multicast route. Free entries may be less than displayed\n"
        "\tvalues if multicast routes are configured.")

def show_route_entry_extension_usage_detail(arg1, arg2, route_entry):
    log_dbg(1, " Inside extension usage detail show")

    route_usage = {
        'current': {
            'host': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'host_tcam': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'prefix': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'prefix_wide': {
                'v6': {'attr': 0, 'noattr': 0}
            },
            'fallback': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'l3vni_override': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'srp1': {'attr': 0, 'noattr': 0},
            'srp2': {'attr': 0, 'noattr': 0},
            'fallback_tcam_slots': {
                'narrow': {'v4': 0, 'v6': 0},
                'wide': 0
            },
            'tcam_slots': {
                'narrow': {'v4': 0, 'v6': 0},
                'wide': 0,
                'fallback': 0
            },
            'sram_slots': {'narrow': 0, 'wide': 0},
            'sram_buckets': {'narrow': 0, 'wide': 0}
        },

        'available': {
            'host': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'host_tcam': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'prefix': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'prefix_wide': {
                'v6': {'attr': 0, 'noattr': 0}
            },
            'fallback': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'l3vni_override': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'srp1': {'attr': 0, 'noattr': 0},
            'srp2': {'attr': 0, 'noattr': 0},
            'fallback_tcam_slots': {
                'narrow': {'v4': 0, 'v6': 0},
                'wide': 0
            },
            'tcam_slots': {
                'narrow': {'v4': 0, 'v6': 0},
                'wide': 0,
                'fallback': 0
            },
            'sram_slots': {'narrow': 0, 'wide': 0},
            'sram_buckets': {'narrow': 0, 'wide': 0}
        },

        'max': {
            'host': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'host_tcam': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'prefix': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'prefix_wide': {
                'v6': {'attr': 0, 'noattr': 0}
            },
            'fallback': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'l3vni_override': {
                'v4': {'attr': 0, 'noattr': 0},
                'v6': {'attr': 0, 'noattr': 0}
            },
            'srp1': {'attr': 0, 'noattr': 0},
            'srp2': {'attr': 0, 'noattr': 0},
            'fallback_tcam_slots': {
                'narrow': {'v4': 0, 'v6': 0},
                'wide': 0
            },
            'tcam_slots': {
                'narrow': {'v4': 0, 'v6': 0},
                'wide': 0,
                'fallback': 0
            },
            'sram_slots': {'narrow': 0, 'wide': 0},
            'sram_buckets': {'narrow': 0, 'wide': 0}
        }
    }

    # RG1: Prefix - v4 & v6 (<80), Host (TCAM) - v4
    # RG2: Host - v4 & v6
    # RG3: Fallback - v4 & v6
    # RG4 - SRP1
    # RG5 - SRP2
    # RG6: Host (TCAM) - v6, Prefix - v6(wide)
    filter_to_rg = {
        'v4_prefix': [1],
        'v6_prefix': [1, 6],
        'v4_host': [1, 2],
        'v6_host': [2, 6],
        'v4_fallback': [3],
        'v6_fallback': [3],
        'v4_l3vni_override': [7],
        'v6_l3vni_override': [7],
        'srp1': [4],
        'srp2': [5],
        'all': [1, 2, 3, 4, 5, 6,7]
    }

    fwd_profile, ilpm_enable, ext_l3vni_enable, ht_update_enable, ilpm_update_enable, ltu_3x_count = get_node_attrs()
    if ht_update_enable == None:
        log_err(1, "Failed to read node info")
        return

    init_usage_dict(route_usage, fwd_profile)
    route_wt = init_route_wt(fwd_profile, ext_l3vni_enable)
    soft_min = init_soft_min()
    v6_prefix_title = init_v6_prefix_row_title()

    filter_option = 'all'
    if route_entry.filter_option != {}:
        filter_option = (route_entry.filter_option['filter']).strip()
        filter_key = list(reversed(filter_option.split('_')))
    else:
        filter_key = None

    log("Filter option: " + filter_option)
    for rg in filter_to_rg[filter_option]:
        print_rg_table(route_usage, route_wt, soft_min, fwd_profile, ht_update_enable, ilpm_update_enable, ltu_3x_count, rg, ext_l3vni_enable, v6_prefix_title, filter_key)
        log(" ")

    print_footer()
    log("\n")
    if filter_option == 'all':
        print_hw_resource_table(route_usage, v6_prefix_title, fwd_profile, ext_l3vni_enable)
    log("\n")

    return
