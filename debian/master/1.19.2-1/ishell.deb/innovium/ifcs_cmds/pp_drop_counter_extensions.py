
#-------------------------------------------------------------------------------
# * Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------------

from ctypes import *
from ifcs_cmds.intf import *
from utils.compat_util import *
from verbosity import log, log_dbg, log_err
from print_table import PrintTable
import sys
ifcs_ctypes = sys.modules['ifcs_ctypes']

def show_pp_drop_counter_extension_usage_detail(arg1, arg2, self):
    usage_p = (ifcs_ctypes.ifcs_usage_t * 4)()
    current_usage = self.cli.ifcs_ctypes.ifcs_uint32_t()
    max_usage = self.cli.ifcs_ctypes.ifcs_uint32_t()
    rc = ifcs_ctypes.ifcs_pp_drop_counter_usage_detail_get(
            0, 0, None, usage_p)
    log_dbg(1, " Inside extension pp_drop_counter usage show")
    table = PrintTable()
    self.set_print_table_search_begin_exprs(table)
    max_ingress_drop_counter = usage_p[0].max
    max_egress_drop_counter = usage_p[1].max
    max_ingress_user_drop_counter = usage_p[2].max
    max_egress_user_drop_counter = usage_p[3].max
    log("User Created PP DROP Counters")
    table.add_header_row(["Direction", "Max", "Used", "Available" ])
    table.add_row(["Ingress", max_ingress_user_drop_counter, usage_p[0].current, (max_ingress_user_drop_counter - usage_p[0].current)])
    table.add_row(["Egress", max_egress_user_drop_counter, usage_p[1].current, (max_egress_user_drop_counter - usage_p[1].current)])
    table.print_table(brief=True)
    table.reset_table()
    log("SDK Created PP DROP Counters")
    max_sdk_ingress_drop_counter = max_ingress_drop_counter - max_ingress_user_drop_counter
    max_sdk_egress_drop_counter = max_egress_drop_counter - max_egress_user_drop_counter
    table.add_header_row(["Direction", "Max", "Used", "Available" ])
    table.add_row(["Ingress", max_sdk_ingress_drop_counter, usage_p[0].available, (max_sdk_ingress_drop_counter - usage_p[0].available)])
    table.add_row(["Egress", max_sdk_egress_drop_counter, usage_p[1].available, (max_sdk_egress_drop_counter - usage_p[1].available)])
    table.print_table(brief=True)
    table.reset_table()

    return
