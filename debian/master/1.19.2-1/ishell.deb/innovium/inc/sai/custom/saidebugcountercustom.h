/**
 *copyright (c) 2026 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saidebugcountercustom.h
 *
 * @brief   This module defines custom debug counter extensions of the
 *          Switch Abstraction Interface (SAI)
 */

#ifndef __SAIDEBUGCOUNTERCUSTOM_H_
#define __SAIDEBUGCOUNTERCUSTOM_H_

#include <saidebugcounter.h>
#include <saitypes.h>

/**
 * @brief Vendor extensions to #sai_in_drop_reason_t for granular MoD.
 */
typedef enum _sai_in_drop_reason_custom_t
{
    /** Packet dropped by ingress policer action */
    SAI_IN_DROP_REASON_CUSTOM_POLICER_DROP = SAI_IN_DROP_REASON_CUSTOM_RANGE_BASE,

    /** Packet dropped by tunnel termination processing */
    SAI_IN_DROP_REASON_CUSTOM_TTERM_DROP,

    /** Packet dropped by ingress hardware trap processing */
    SAI_IN_DROP_REASON_CUSTOM_HW_DROP,

} sai_in_drop_reason_custom_t;

/*
 * @brief Attribute data for buffer drop reasons
 */
typedef enum _sai_buffer_drop_reason_custom_t
{
    /** Egress buffer  packet drops */
    SAI_BUFFER_DROP_REASON_CUSTOM_EGRESS_QUEUE_DROP = SAI_BUFFER_DROP_REASON_CUSTOM_RANGE_START,

} sai_buffer_drop_reason_custom_t;

#endif /* __SAIDEBUGCOUNTERCUSTOM_H_ */
