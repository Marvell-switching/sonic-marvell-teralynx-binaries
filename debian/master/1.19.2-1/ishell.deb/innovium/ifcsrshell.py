#-------------------------------------------------------------------------
# Copyright (c) (2021) Marvell. All rights reserved
#
# The following file is subject to the limited use license agreement
# by and between Marvell and you,  your employer or other entity on
# behalf of whom you act. In the absence of such license agreement the
# following file is subject to Marvell's standard Limited Use License Agreement.
#-------------------------------------------------------------------------

import os
import sys
import time
import errno
import socket
import argparse
from ifcs_cli import IFCS_CLI
from utils.compat_util import *
from verbosity import log

# Numeric loopback. The name "localhost" is resolved by getaddrinfo() and
# follows /etc/hosts and DNS, which can point it at a non-local address.
HOST = '127.0.0.1'
# Default number of connection attempts to the Innovium shell server
# (one try per second). 21 matches the original client's retry count.
CONNECT_ATTEMPTS = 21

def create_inet_socket(PORT, attempts=CONNECT_ATTEMPTS):
    s_out = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s_out.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    # Try to connect to the socket in a loop: exactly `attempts` tries,
    # one per second (no sleep after the final failed attempt), so e.g.
    # -a 1 fails fast with a single attempt.
    connected = False
    for attempt in range(1, attempts + 1):
        try:
            s_out.connect((HOST, PORT))
            connected = True
            break
        except BaseException:
            log('Attempting to connect to Innovium shell .. ' + str(attempt))
            if attempt < attempts:
                time.sleep(1)

    if not connected:
        log('Failed to connect to Innovium shell')
        sys.exit(1)

    return s_out


def create_unix_socket(SERV, attempts=CONNECT_ATTEMPTS):
    s_out = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

    # Try to connect to the socket in a loop: exactly `attempts` tries,
    # one per second (no sleep after the final failed attempt), so e.g.
    # -a 1 fails fast with a single attempt.
    connected = False
    for attempt in range(1, attempts + 1):
        try:
            s_out.connect(SERV)
            connected = True
            break
        except BaseException:
            log('Attempting to connect to Innovium shell .. ' + str(attempt))
            if attempt < attempts:
                time.sleep(1)

    if not connected:
        log('Failed to connect to Innovium shell')
        sys.exit(1)

    return s_out


def close_socket(sock):
    # (IOError, OSError) is cross-version: on Py3 both alias OSError; on Py2
    # socket.error (raised by shutdown/close) is a subclass of IOError.
    try:
        sock.shutdown(socket.SHUT_RDWR)
    except (IOError, OSError):
        pass
    try:
        sock.close()
    except (IOError, OSError):
        pass


def main():

    intro = "\n\t\tInnovium Remote Command Shell Client. \n\tType '?' or 'help' for help. Type 'exit' or 'quit' to exit shell."
    parser = argparse.ArgumentParser(
        description="IFCS Shell",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        '-e',
        '--env',
        type=str,
        nargs='*',
        default=['switch'],
        help=' runtime environment for cli, set board, emulator or switch')
    parser.add_argument(
        '-p',
        '--port',
        nargs='?',
        help='port to connect with the innovium shell server')
    parser.add_argument(
        '-u',
        '--serv',
        nargs='?',
        help='server address to connect with the innovium shell server')
    parser.add_argument(
        '-s',
        '--single',
        type=str,
        help='run a single command')
    parser.add_argument(
            '-C',
            '--cmd',
            dest='cmd',
            nargs='*',
            help='space separated list of commands to execute')
    parser.add_argument(
            '-t',
            '--timeout',
            type=int,
            default=0,
            help='timeout in seconds for initial server response '
                 '(0 = block indefinitely, default)')
    parser.add_argument(
            '-a',
            '--attempts',
            type=int,
            default=CONNECT_ATTEMPTS,
            help='number of connection attempts to the innovium shell server')

    args = parser.parse_args()

    cli = IFCS_CLI(intro)
    try:
        if args.env:
            cli.set_rt_env(args.env[0])
    except BaseException:
        log("Unsupported environment. Exiting..")
        return

    cli.set_remote(True)
    if not args.single:
        cli.init_cmds()
    if args.port:
        sock = create_inet_socket(int(args.port), args.attempts)

    if args.serv:
        sock = create_unix_socket(args.serv, args.attempts)

    cli.set_remote_port(sock)

    # By default the handshake read blocks indefinitely (original behavior);
    # a positive --timeout opts into a bounded wait.
    if args.timeout and args.timeout > 0:
        sock.settimeout(args.timeout)
    try:
        data = compat_bytesToStr(sock.recv(1024))
    except socket.timeout:
        log("Timed out waiting for response from Innovium Shell Server")
        close_socket(sock)
        return
    except (IOError, OSError) as e:
        # (IOError, OSError) is cross-version: on Py3 both alias OSError
        # (covering ConnectionResetError/BrokenPipeError); on Py2 socket.error
        # is a subclass of IOError.
        log("Connection to Innovium Shell Server lost: %s" % str(e))
        close_socket(sock)
        return
    except KeyboardInterrupt:
        log("\nInterrupted. Closing connection.")
        close_socket(sock)
        return

    # Restore blocking behavior for the interactive session
    sock.settimeout(None)

    if not data:
        log("Connection closed by Innovium Shell Server")
        close_socket(sock)
        return

    if "Err" in data:
        if "Max client" in data:
            log("Max clients %d reached. Closing connection" % int(data.split('-')[1]))
            close_socket(sock)
            return
    if "Success" in data:
        log("\t\tConnected to Innovium Shell Server")

    try:
        if args.cmd:
            for aCmd in args.cmd:
                log("Executing Command: %s" % aCmd)
                cli.onecmd(aCmd)

        if args.single:
            cli.onecmd(args.single)
        else:
            doQuit = False
            while doQuit != True:
                try:
                    cli.cmdloop()
                    doQuit = True
                except KeyboardInterrupt:
                    log("\n")
                except (IOError, OSError):
                    # Connection to the server dropped; stop looping and let
                    # the outer handler log and close cleanly instead of
                    # re-entering cmdloop() on a dead socket.
                    raise
                except Exception as e:
                    log("%s\n" % str(e))
    except KeyboardInterrupt:
        log("\nInterrupted. Closing connection.")
    except (IOError, OSError) as e:
        log("Connection to Innovium Shell Server lost: %s" % str(e))

    close_socket(sock)


if __name__ == "__main__":
    main()
